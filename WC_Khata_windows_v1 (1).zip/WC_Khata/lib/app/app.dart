import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../core/services/app_navigator.dart';
import 'theme/app_theme.dart';
import 'splash_screen.dart';
import '../core/utils/app_platform.dart';
import '../core/widgets/desktop_title_bar.dart';

class LifeApp extends StatelessWidget {
  const LifeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeController>(
      builder: (context, themeController, _) {
        return MaterialApp(
          navigatorKey: appNavigatorKey,
          title: 'WC Khata',
          debugShowCheckedModeBanner: false,
          // This app uses a light-only interface. System dark mode is intentionally ignored.
          themeMode: ThemeMode.light,
          theme: AppPlatform.isDesktop
              ? themeController.light.copyWith(visualDensity: VisualDensity.compact)
              : themeController.light,
          // Respect the user's accessibility text-size preference, but
          // clamp it to a sane range. Without this, an OS text scale of
          // 3x-3.5x (common on Android accessibility settings) breaks
          // fixed-height layouts (grid tiles, chips, bottom sheets) app
          // -wide. Screens still scale for readability between ~0.9x and
          // ~1.3x; beyond that we cap it so nothing overflows, while still
          // honouring `MediaQuery when actually needed` per design spec.
          builder: (context, child) {
            final mq = MediaQuery.of(context);
            final clampedScaler = AppPlatform.isDesktop
                ? const TextScaler.linear(0.93) // slightly smaller, denser text on a PC screen
                : mq.textScaler.clamp(minScaleFactor: 0.9, maxScaleFactor: 1.1);
            final body = MediaQuery(
              data: mq.copyWith(textScaler: clampedScaler),
              child: AnnotatedRegion<SystemUiOverlayStyle>(
                value: const SystemUiOverlayStyle(
                  statusBarColor: Colors.transparent,
                  statusBarIconBrightness: Brightness.dark,
                  statusBarBrightness: Brightness.light,
                  systemStatusBarContrastEnforced: false,
                  systemNavigationBarColor: Colors.transparent,
                  systemNavigationBarIconBrightness: Brightness.dark,
                  systemNavigationBarDividerColor: Colors.transparent,
                  systemNavigationBarContrastEnforced: false,
                ),
                child: child!,
              ),
            );
            return DesktopFrame.wrap(body);
          },
          home: const SplashScreen(),
        );
      },
    );
  }
}
