import 'package:flutter/material.dart';
import '../../features/home/home_screen.dart';
import '../../core/widgets/app_bottom_nav.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../features/ledger/ledger_screen.dart';
import '../../features/sale/sale_screen.dart';
import '../../features/items/items_screen.dart';
import '../../features/more/more_screen.dart';
import '../../core/services/app_navigator.dart';
import '../../core/widgets/app_sidebar.dart';
import '../theme/app_theme.dart';
import '../../core/utils/app_platform.dart';
import '../../core/widgets/desktop_sidebar.dart';
import '../../features/profile/profile_screen.dart';
import '../../features/settings/settings_screen.dart';
import '../../features/security/security_screen.dart';
import '../../features/backup/backup_screen.dart';
import '../../features/backup/restore_screen.dart';
import '../../features/recycle_bin/recycle_bin_screen.dart';
import '../../features/desktop/desktop_backup_screen.dart';
import '../../features/desktop/desktop_sale_tab.dart';

/// Root of the app: five full-screen tabs behind an Easy-Khata style
/// bottom bar. Tabs stay alive (IndexedStack) so Home keeps its state.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;

  // ---- Desktop (Windows) layout only ----
  final GlobalKey<NavigatorState> _contentNavKey = GlobalKey<NavigatorState>();
  final ValueNotifier<int> _indexNotifier = ValueNotifier<int>(0);
  String? _extra; // which sidebar item (Profile, Settings...) is open, if any

  static const double _desktopContentMaxWidth = 1250;

  static const _extras = <({IconData icon, String label})>[
    (icon: Icons.person_rounded, label: 'Profile'),
    (icon: Icons.settings_rounded, label: 'Settings'),
    (icon: Icons.lock_rounded, label: 'Security'),
    (icon: Icons.restore_from_trash_rounded, label: 'Recycle Bin'),
    (icon: Icons.cloud_sync_rounded, label: 'Backup & Restore'),
  ];

  static final _extraBuilders = <String, WidgetBuilder>{
    'Profile': (_) => const ProfileScreen(),
    'Settings': (_) => const SettingsScreen(),
    'Security': (_) => const SecurityScreen(),
    'Recycle Bin': (_) => const RecycleBinScreen(),
    'Backup & Restore': (_) => const DesktopBackupScreen(),
  };

  @override
  void dispose() {
    _indexNotifier.dispose();
    super.dispose();
  }
  final GlobalKey<HomeScreenState> _homeKey = GlobalKey<HomeScreenState>();
  final GlobalKey<LedgerScreenState> _ledgerKey = GlobalKey<LedgerScreenState>();
  final GlobalKey<ItemsScreenState> _itemsKey = GlobalKey<ItemsScreenState>();

  static const _items = [
    AppNavItem(icon: Icons.home_outlined, activeIcon: Icons.home_rounded, label: 'Home'),
    AppNavItem(icon: Icons.menu_book_outlined, activeIcon: Icons.menu_book_rounded, label: 'Ledger'),
    AppNavItem(icon: Icons.point_of_sale_outlined, activeIcon: Icons.point_of_sale_rounded, label: 'Sale'),
    AppNavItem(icon: Icons.inventory_2_outlined, activeIcon: Icons.inventory_2_rounded, label: 'Products'),
    AppNavItem(icon: Icons.grid_view_outlined, activeIcon: Icons.grid_view_rounded, label: 'More'),
  ];

  void _openTab(int index) {
    if (AppPlatform.isDesktop) {
      _contentNavKey.currentState?.popUntil((r) => r.isFirst);
      _extra = null;
      _indexNotifier.value = index;
    }
    setState(() => _index = index);
    _homeKey.currentState?.onTabChanged(index == 0);
    if (index == 0) {
      _homeKey.currentState?.refreshLedgerTotals();
    } else if (index == 1) {
      _ledgerKey.currentState?.reload();
    } else if (index == 3) {
      _itemsKey.currentState?.reload();
    }
  }

  void _goHome() => _openTab(0);

  List<Widget> _pages() => [
        HomeScreen(key: _homeKey, onOpenTab: _openTab),
        LedgerScreen(key: _ledgerKey, onBack: _goHome),
        AppPlatform.isDesktop
            ? const DesktopSaleTab()
            : AppTabScreen(title: 'Sale', onBack: _goHome, body: const SaleScreen()),
        AppTabScreen(title: 'Products', onBack: _goHome, body: ItemsScreen(key: _itemsKey)),
        AppTabScreen(title: 'More', onBack: _goHome, body: const MoreScreen()),
      ];

  void _openExtra(String label) {
    final nav = _contentNavKey.currentState;
    if (nav == null) return;
    nav.popUntil((r) => r.isFirst);
    setState(() => _extra = label);
    nav.push(MaterialPageRoute<void>(builder: _extraBuilders[label]!));
  }

  Widget _desktopBuild(BuildContext context) {
    return Scaffold(
      key: rootScaffoldKey,
      backgroundColor: AppColors.lightBackground,
      body: Row(
        children: [
          DesktopSidebar(
            tabs: _items,
            selectedTab: _index,
            onTab: _openTab,
            extras: _extras,
            selectedExtra: _extra,
            onExtra: _openExtra,
          ),
          Expanded(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: _desktopContentMaxWidth),
                child: Navigator(
                  key: _contentNavKey,
                  observers: [_ExtraObserver(() {
                    if (mounted && _extra != null) setState(() => _extra = null);
                  })],
                  onGenerateRoute: (_) => MaterialPageRoute<void>(
                    builder: (_) => ValueListenableBuilder<int>(
                      valueListenable: _indexNotifier,
                      builder: (_, i, __) => IndexedStack(index: i, children: _pages()),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> _handleBack() async {
    final route = ModalRoute.of(context);
    if (route != null && !route.isCurrent) return true;
    if (_index != 0) {
      setState(() => _index = 0);
      _homeKey.currentState?.onTabChanged(true);
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    if (AppPlatform.isDesktop) return _desktopBuild(context);
    return WillPopScope(
      onWillPop: _handleBack,
      child: Scaffold(
        key: rootScaffoldKey,
        resizeToAvoidBottomInset: false,
        backgroundColor: AppColors.lightBackground,
        drawer: const AppSidebar(),
        drawerScrimColor: Colors.black.withValues(alpha: 0.5),
        drawerEdgeDragWidth: 28,
        drawerEnableOpenDragGesture: _index == 0,
        body: Column(
          children: [
            Expanded(child: IndexedStack(index: _index, children: _pages())),
            AppBottomNav(
              currentIndex: _index,
              onTap: _openTab,
              items: _items,
            ),
          ],
        ),
      ),
    );
  }
}

/// Tells the desktop shell when a sidebar page (Profile, Settings...) was
/// closed with its own back button, so the sidebar highlight resets.
class _ExtraObserver extends NavigatorObserver {
  final VoidCallback onClosed;
  _ExtraObserver(this.onClosed);

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    if (previousRoute != null && previousRoute.isFirst) onClosed();
  }
}
