import 'dart:io';
import 'dart:ui' show Size;

import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:window_manager/window_manager.dart';

import 'app_platform.dart';

/// Start-up work that only the Windows/desktop build needs.
/// On Android this does nothing, so the phone app is not affected.
Future<void> initDesktop() async {
  if (!AppPlatform.isDesktop) return;

  // 1) SQLite on desktop (the phone plugin `sqflite` has no Windows version).
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  // Keep the database in the user's own app-data folder (NOT next to the exe),
  // so it survives updates:  C:\Users\<name>\AppData\Roaming\...\databases
  final dir = await getApplicationSupportDirectory();
  final dbDir = Directory('${dir.path}${Platform.pathSeparator}databases');
  if (!await dbDir.exists()) await dbDir.create(recursive: true);
  await databaseFactory.setDatabasesPath(dbDir.path);

  // 2) Window: title, sensible start size, minimum size.
  await windowManager.ensureInitialized();
  await windowManager.waitUntilReadyToShow(
    const WindowOptions(
      title: 'WC Khata',
      size: Size(1280, 800),
      minimumSize: Size(980, 640),
      center: true,
      titleBarStyle: TitleBarStyle.hidden,
      windowButtonVisibility: false,
    ),
    () async {
      await windowManager.show();
      await windowManager.focus();
    },
  );
}
