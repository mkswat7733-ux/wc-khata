import 'package:flutter/material.dart';
import 'package:window_manager/window_manager.dart';

import '../utils/app_platform.dart';

/// Our own Windows title bar: app name + Minimize / Maximize / Close.
/// Drag it to move the window, double-click it to maximize / restore.
class DesktopFrame {
  DesktopFrame._();

  /// Puts the title bar above [child] on desktop; returns [child] on phones.
  static Widget wrap(Widget child) {
    if (!AppPlatform.isDesktop) return child;
    return Column(
      children: [
        const DesktopTitleBar(),
        Expanded(child: child),
      ],
    );
  }
}

class DesktopTitleBar extends StatefulWidget {
  const DesktopTitleBar({super.key});

  @override
  State<DesktopTitleBar> createState() => _DesktopTitleBarState();
}

class _DesktopTitleBarState extends State<DesktopTitleBar> with WindowListener {
  static const Color _bg = Color(0xFF1B3A6B);
  bool _maximized = false;

  @override
  void initState() {
    super.initState();
    windowManager.addListener(this);
    _sync();
  }

  @override
  void dispose() {
    windowManager.removeListener(this);
    super.dispose();
  }

  Future<void> _sync() async {
    try {
      final m = await windowManager.isMaximized();
      if (mounted) setState(() => _maximized = m);
    } catch (_) {}
  }

  @override
  void onWindowMaximize() {
    if (mounted) setState(() => _maximized = true);
  }

  @override
  void onWindowUnmaximize() {
    if (mounted) setState(() => _maximized = false);
  }

  Future<void> _toggleMaximize() async {
    if (await windowManager.isMaximized()) {
      await windowManager.unmaximize();
    } else {
      await windowManager.maximize();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _bg,
      child: SizedBox(
        height: 36,
        child: Row(
          children: [
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onDoubleTap: _toggleMaximize,
                child: DragToMoveArea(
                  child: const Padding(
                    padding: EdgeInsets.only(left: 14),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.storefront_rounded, color: Colors.white, size: 16),
                          SizedBox(width: 8),
                          Text(
                            'WC Khata',
                            style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            _CaptionButton(icon: Icons.remove_rounded, onTap: () => windowManager.minimize()),
            _CaptionButton(
              icon: _maximized ? Icons.filter_none_rounded : Icons.crop_square_rounded,
              iconSize: _maximized ? 14 : 17,
              onTap: _toggleMaximize,
            ),
            _CaptionButton(
              icon: Icons.close_rounded,
              hoverColor: const Color(0xFFE81123),
              onTap: () => windowManager.close(),
            ),
          ],
        ),
      ),
    );
  }
}

class _CaptionButton extends StatefulWidget {
  final IconData icon;
  final double iconSize;
  final Color? hoverColor;
  final VoidCallback onTap;
  const _CaptionButton({required this.icon, required this.onTap, this.iconSize = 17, this.hoverColor});

  @override
  State<_CaptionButton> createState() => _CaptionButtonState();
}

class _CaptionButtonState extends State<_CaptionButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: widget.onTap,
        child: Container(
          width: 46,
          height: 36,
          color: _hover ? (widget.hoverColor ?? Colors.white.withValues(alpha: 0.14)) : Colors.transparent,
          alignment: Alignment.center,
          child: Icon(widget.icon, color: Colors.white, size: widget.iconSize),
        ),
      ),
    );
  }
}
