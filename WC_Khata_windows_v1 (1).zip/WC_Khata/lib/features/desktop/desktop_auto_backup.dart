import 'dart:io';

import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../core/services/backup_service.dart';

/// Windows: keeps an automatic backup of the whole database in
/// `Documents\WC Khata Backups`. One file per day, the newest 30 are kept.
/// The files use the SAME format as the Android backup, so they can be
/// restored on the phone too (and phone backups can be restored here).
class DesktopAutoBackup {
  DesktopAutoBackup._();

  static const int keepDays = 30;
  static const String prefix = 'wc_khata_auto_';

  static Future<Directory> folder() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'WC Khata Backups'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// Creates today's backup if it does not exist yet, then removes old ones.
  static Future<void> runDaily() async {
    final dir = await folder();
    final day = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final file = File(p.join(dir.path, '$prefix$day.json'));
    if (!await file.exists()) {
      final json = await BackupService().createBackupJson();
      await file.writeAsString(json, flush: true);
    }
    await _prune(dir);
  }

  /// Newest first.
  static Future<List<File>> list() async {
    final dir = await folder();
    final files = <File>[];
    await for (final e in dir.list()) {
      if (e is File && p.basename(e.path).startsWith(prefix) && e.path.toLowerCase().endsWith('.json')) {
        files.add(e);
      }
    }
    files.sort((a, b) => p.basename(b.path).compareTo(p.basename(a.path)));
    return files;
  }

  static Future<void> _prune(Directory dir) async {
    final files = await list();
    for (var i = keepDays; i < files.length; i++) {
      try {
        await files[i].delete();
      } catch (_) {}
    }
  }
}
