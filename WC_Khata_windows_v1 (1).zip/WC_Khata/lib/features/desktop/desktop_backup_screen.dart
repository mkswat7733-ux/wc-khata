import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart' show getDatabasesPath;

import '../../app/theme/app_theme.dart';
import '../../core/services/backup_service.dart';
import '../../core/services/data_events.dart';
import '../../core/services/restore_service.dart';
import '../../core/widgets/app_message.dart';
import 'desktop_auto_backup.dart';

/// Windows page: Backup (save a file anywhere you choose) + Restore
/// (from a file, or from one of the automatic daily backups).
/// Backup files are the same format as the Android app's backup.
class DesktopBackupScreen extends StatefulWidget {
  const DesktopBackupScreen({super.key});

  @override
  State<DesktopBackupScreen> createState() => _DesktopBackupScreenState();
}

class _DesktopBackupScreenState extends State<DesktopBackupScreen> {
  bool _busy = false;
  List<File> _auto = [];
  String _dbFolder = '';
  String _autoFolder = '';

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    try {
      final files = await DesktopAutoBackup.list();
      final dir = await DesktopAutoBackup.folder();
      final db = await getDatabasesPath();
      if (!mounted) return;
      setState(() {
        _auto = files;
        _autoFolder = dir.path;
        _dbFolder = db;
      });
    } catch (_) {}
  }

  Future<void> _saveBackup() async {
    setState(() => _busy = true);
    try {
      final json = await BackupService().createBackupJson();
      final stamp = DateFormat('yyyy-MM-dd_HH-mm').format(DateTime.now());
      final path = await FilePicker.platform.saveFile(
        dialogTitle: 'Save WC Khata backup',
        fileName: 'wc_khata_backup_$stamp.json',
        type: FileType.custom,
        allowedExtensions: ['json'],
      );
      if (path == null) return;
      final out = path.toLowerCase().endsWith('.json') ? path : '$path.json';
      await File(out).writeAsString(json, flush: true);
      if (mounted) await AppMessenger.showSuccess(context, 'Backup saved:\n$out');
    } catch (e) {
      if (mounted) await AppMessenger.showError(context, 'Backup failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<bool> _confirm() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Restore backup'),
        content: const Text(
          'All current data in this software will be REPLACED by the selected backup. This cannot be undone. Continue?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.expense),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Restore'),
          ),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _restore(File file) async {
    if (!await _confirm()) return;
    setState(() => _busy = true);
    try {
      await RestoreService().restoreFromFile(file);
      DataEvents.changed();
      if (mounted) {
        await AppMessenger.showSuccess(
          context,
          'Restore complete. If any screen still shows old data, close and open the software once.',
        );
      }
    } on RestoreValidationException catch (e) {
      if (mounted) await AppMessenger.showWarning(context, e.message);
    } catch (e) {
      if (mounted) await AppMessenger.showError(context, 'Restore failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickAndRestore() async {
    final result = await FilePicker.platform.pickFiles(
      dialogTitle: 'Select WC Khata backup (.json)',
      type: FileType.custom,
      allowedExtensions: ['json'],
    );
    final path = result?.files.single.path;
    if (path == null) return;
    await _restore(File(path));
  }

  Future<void> _backupNowToAutoFolder() async {
    setState(() => _busy = true);
    try {
      final dir = await DesktopAutoBackup.folder();
      final stamp = DateFormat('yyyy-MM-dd_HH-mm-ss').format(DateTime.now());
      final json = await BackupService().createBackupJson();
      await File(p.join(dir.path, 'wc_khata_manual_$stamp.json')).writeAsString(json, flush: true);
      await _refresh();
      if (mounted) await AppMessenger.showSuccess(context, 'Backup saved in the backup folder.');
    } catch (e) {
      if (mounted) await AppMessenger.showError(context, 'Backup failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _openFolder(String path) {
    if (path.isEmpty) return;
    try {
      Process.run('explorer', [path]);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(bottom: BorderSide(color: AppColors.lightDivider)),
            ),
            child: const Text('Backup & Restore', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          ),
          if (_busy) const LinearProgressIndicator(minHeight: 3),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: _Panel(
                        icon: Icons.save_alt_rounded,
                        color: AppColors.income,
                        title: 'Save backup',
                        text: 'Save all your data (products, bills, customers, suppliers, cashbook, settings) as one file in any folder or USB drive. Same file type as the Android app.',
                        child: Wrap(spacing: 10, runSpacing: 8, children: [
                          FilledButton.icon(
                            onPressed: _busy ? null : _saveBackup,
                            icon: const Icon(Icons.download_rounded, size: 18),
                            label: const Text('Save backup as...'),
                          ),
                          OutlinedButton.icon(
                            onPressed: _busy ? null : _backupNowToAutoFolder,
                            icon: const Icon(Icons.folder_rounded, size: 18),
                            label: const Text('Backup now (backup folder)'),
                          ),
                        ]),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _Panel(
                        icon: Icons.settings_backup_restore_rounded,
                        color: AppColors.primary,
                        title: 'Restore backup',
                        text: 'Choose a backup file from this PC or from the Android app (.json). Current data will be replaced.',
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(backgroundColor: AppColors.expense),
                          onPressed: _busy ? null : _pickAndRestore,
                          icon: const Icon(Icons.upload_file_rounded, size: 18),
                          label: const Text('Select backup file...'),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _Panel(
                  icon: Icons.history_rounded,
                  color: AppColors.warning,
                  title: 'Automatic backups (daily)',
                  text: 'The software saves a backup by itself once a day and keeps the last ${DesktopAutoBackup.keepDays} days.',
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (_auto.isEmpty)
                        const Text('No automatic backup yet.', style: TextStyle(color: AppColors.lightTextSecondary))
                      else
                        for (final f in _auto.take(10))
                          ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                            leading: const Icon(Icons.description_outlined, size: 20),
                            title: Text(p.basename(f.path)),
                            subtitle: Text('${(f.lengthSync() / 1024).toStringAsFixed(0)} KB'),
                            trailing: TextButton(
                              onPressed: _busy ? null : () => _restore(f),
                              child: const Text('Restore'),
                            ),
                          ),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: () => _openFolder(_autoFolder),
                        icon: const Icon(Icons.folder_open_rounded, size: 18),
                        label: const Text('Open backup folder'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _Panel(
                  icon: Icons.storage_rounded,
                  color: AppColors.catTransport,
                  title: 'Database location',
                  text: 'All data is stored on this PC (offline). Folder:\n$_dbFolder',
                  child: OutlinedButton.icon(
                    onPressed: () => _openFolder(_dbFolder),
                    icon: const Icon(Icons.folder_open_rounded, size: 18),
                    label: const Text('Open data folder'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Panel extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String text;
  final Widget child;
  const _Panel({required this.icon, required this.color, required this.title, required this.text, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.lightDivider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
          ]),
          const SizedBox(height: 10),
          Text(text, style: const TextStyle(color: AppColors.lightTextSecondary, fontSize: 13, height: 1.4)),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}
