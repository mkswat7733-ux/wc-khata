import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme/app_theme.dart';
import '../../core/services/data_events.dart';
import '../../core/utils/amount_limit.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_message.dart';
import '../../data/models/transaction_model.dart';
import '../../data/repositories/account_repository.dart';
import '../../data/repositories/transaction_repository.dart';
import '../items/item_repository.dart';
import '../ledger/ledger_party.dart';
import '../ledger/ledger_repository.dart';
import '../sale/sale_calculator.dart';
import '../sale/sale_invoice_screen.dart';
import '../sale/sale_repository.dart';

/// Windows billing screen (point of sale):
/// products on the left (search / USB barcode scanner), the bill on the right.
class DesktopPosScreen extends StatefulWidget {
  const DesktopPosScreen({super.key});

  @override
  State<DesktopPosScreen> createState() => _DesktopPosScreenState();
}

class _DesktopPosScreenState extends State<DesktopPosScreen> {
  final _itemRepo = ItemRepository();
  final _ledger = LedgerRepository();
  final _saleRepo = SaleRepository();

  final _search = TextEditingController();
  final _searchFocus = FocusNode();
  final _discount = TextEditingController();
  final _paid = TextEditingController();

  List<ItemRecord> _items = [];
  List<LedgerParty> _customers = [];
  final List<SaleLine> _cart = [];

  int? _customerId;
  String _payment = 'cash';
  bool _saving = false;
  bool _loading = true;
  VoidCallback? _unlisten;

  @override
  void initState() {
    super.initState();
    _load();
    _unlisten = DataEvents.listen(() {
      if (mounted) _load();
    });
  }

  @override
  void dispose() {
    _unlisten?.call();
    _search.dispose();
    _searchFocus.dispose();
    _discount.dispose();
    _paid.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final items = await _itemRepo.getItems();
      final parties = await _ledger.getParties();
      if (!mounted) return;
      setState(() {
        _items = items;
        _customers = parties.where((p) => p.type == LedgerPartyType.customer).toList();
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ------------------------------------------------------------ numbers
  double get _subtotal => SaleCalc.r2(_cart.fold<double>(0, (s, l) => s + l.total));
  double get _discountValue {
    final d = double.tryParse(_discount.text.trim()) ?? 0;
    return SaleCalc.r2(d.clamp(0, _subtotal).toDouble());
  }

  double get _total => SaleCalc.r2(_subtotal - _discountValue);
  double get _paidValue {
    if (_payment == 'cash') return _total;
    final v = double.tryParse(_paid.text.trim()) ?? 0;
    return SaleCalc.r2(v.clamp(0, _total).toDouble());
  }

  double get _due => SaleCalc.r2(_total - _paidValue);
  String _money(double v) => CurrencyFormatter.format(v);

  // --------------------------------------------------------------- cart
  void _add(ItemRecord item) {
    if (item.trackStock && item.qty <= 0) {
      AppMessenger.showWarning(context, 'Out of stock: ${item.name}');
      return;
    }
    final i = _cart.indexWhere((l) => l.item.id == item.id);
    setState(() {
      if (i >= 0) {
        _cart[i].qty += 1;
      } else {
        _cart.add(SaleLine(item: item));
      }
    });
  }

  List<ItemRecord> get _filtered {
    final q = _search.text.trim().toLowerCase();
    if (q.isEmpty) return _items;
    return _items
        .where((i) =>
            i.name.toLowerCase().contains(q) ||
            (i.barcode ?? '').toLowerCase() == q ||
            i.category.toLowerCase().contains(q))
        .toList();
  }

  /// Enter in the search box: a scanned barcode, or the only match.
  Future<void> _onSearchSubmit(String text) async {
    final code = text.trim();
    if (code.isEmpty) return;
    ItemRecord? hit;
    try {
      hit = await _saleRepo.findItemByBarcode(code);
    } catch (_) {}
    hit ??= () {
      final f = _filtered;
      return f.length == 1 ? f.first : null;
    }();
    if (hit != null) {
      _add(hit);
      _search.clear();
      setState(() {});
    }
    _searchFocus.requestFocus();
  }

  void _clearBill() {
    setState(() {
      _cart.clear();
      _discount.clear();
      _paid.clear();
      _customerId = null;
      _payment = 'cash';
    });
  }

  String? get _customerName {
    for (final c in _customers) {
      if (c.id == _customerId) return c.name;
    }
    return null;
  }

  // --------------------------------------------------------------- save
  Future<void> _save({required bool openBill}) async {
    if (_saving) return;
    if (_cart.isEmpty) {
      AppMessenger.showWarning(context, 'Add at least one product to the bill.');
      return;
    }
    if (_cart.any((l) => l.qty <= 0)) {
      AppMessenger.showWarning(context, 'Quantity must be more than 0.');
      return;
    }
    if (_payment == 'credit' && _customerId == null) {
      AppMessenger.showWarning(context, 'Select a customer for a credit sale.');
      return;
    }
    final total = _total;
    final paid = _paidValue;
    if (total > AmountLimit.max) {
      AmountLimit.showMessage(context);
      return;
    }

    setState(() => _saving = true);
    try {
      final saved = await _saleRepo.saveSale(
        lines: _cart.map((l) => l.copy()).toList(),
        customerId: _customerId,
        paymentType: _payment,
        paidAmount: paid,
        discountAmount: _discountValue,
      );

      // Same cash-book / customer-ledger posting the phone app does.
      var postingFailed = false;
      try {
        final account = await AccountRepository().getDefaultCashAccount();
        final now = DateTime.now();
        if (_customerId == null && account?.id != null && paid > 0) {
          await TransactionRepository().create(TransactionModel(
            type: TransactionType.income,
            amount: paid,
            accountId: account!.id!,
            date: now,
            createdAt: now,
            updatedAt: now,
            source: 'Sale',
            paymentMethod: _payment,
            note: saved.invoiceNo,
          ));
        }
        if (_customerId != null) {
          if (total > 0) {
            await _ledger.addTransaction(
              partyId: _customerId!,
              type: 'pay',
              amount: total,
              note: 'Sale ${saved.invoiceNo}',
              date: now,
              systemPosted: true,
            );
          }
          if (paid > 0) {
            await _ledger.addTransaction(
              partyId: _customerId!,
              type: 'receive',
              amount: paid,
              note: 'Payment for ${saved.invoiceNo}',
              date: now,
              systemPosted: true,
            );
          }
        }
      } catch (_) {
        postingFailed = true;
      }

      final name = _customerName;
      _clearBill();
      if (!mounted) return;
      if (postingFailed) {
        await AppMessenger.showWarning(
          context,
          'Bill saved, but the cash/khata entry could not be posted. Please check the ledger.',
        );
      }
      if (openBill) {
        await Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => SaleInvoiceScreen(sale: saved, customerName: name)),
        );
      } else if (!postingFailed) {
        await AppMessenger.showSuccess(context, 'Bill ${saved.invoiceNo} saved.');
      }
      if (mounted) _searchFocus.requestFocus();
    } on ArgumentError catch (e) {
      if (mounted) await AppMessenger.showWarning(context, '${e.message}');
    } catch (e) {
      if (mounted) await AppMessenger.showError(context, 'Could not save the bill. Please try again.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  // ----------------------------------------------------------------- UI
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(flex: 11, child: _productsPanel()),
                  const SizedBox(width: 14),
                  Expanded(flex: 10, child: _billPanel()),
                ],
              ),
            ),
    );
  }

  BoxDecoration get _card => BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.lightDivider),
      );

  Widget _productsPanel() {
    final list = _filtered;
    return Container(
      decoration: _card,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _search,
              focusNode: _searchFocus,
              autofocus: true,
              onChanged: (_) => setState(() {}),
              onSubmitted: _onSearchSubmit,
              decoration: InputDecoration(
                isDense: true,
                hintText: 'Search product, or scan barcode and press Enter',
                prefixIcon: const Icon(Icons.search_rounded, size: 20),
                suffixIcon: _search.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close_rounded, size: 18),
                        onPressed: () {
                          _search.clear();
                          setState(() {});
                          _searchFocus.requestFocus();
                        },
                      ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
          _tableHeader(const ['Product', 'Stock', 'Price'], const [5, 3, 3]),
          Expanded(
            child: list.isEmpty
                ? const Center(child: Text('No products found', style: TextStyle(color: AppColors.lightTextSecondary)))
                : ListView.separated(
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.lightDivider),
                    itemBuilder: (_, i) {
                      final it = list[i];
                      final out = it.trackStock && it.qty <= 0;
                      final low = it.trackStock && !out && it.lowStock > 0 && it.qty <= it.lowStock;
                      return InkWell(
                        onTap: () => _add(it),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                          child: Row(children: [
                            Expanded(
                              flex: 5,
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(it.name,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
                                Text(it.category,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: AppColors.lightTextSecondary, fontSize: 11.5)),
                              ]),
                            ),
                            Expanded(
                              flex: 3,
                              child: Text(
                                it.trackStock ? (out ? 'Out of stock' : it.stockText) : '-',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w600,
                                  color: out ? AppColors.expense : (low ? AppColors.warning : AppColors.lightTextPrimary),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 3,
                              child: Text(_money(it.price),
                                  textAlign: TextAlign.right,
                                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                            ),
                          ]),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _tableHeader(List<String> names, List<int> flex) {
    return Container(
      color: const Color(0xFFF2F4F7),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(children: [
        for (var i = 0; i < names.length; i++)
          Expanded(
            flex: flex[i],
            child: Text(names[i],
                textAlign: i == names.length - 1 ? TextAlign.right : TextAlign.left,
                style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: AppColors.lightTextSecondary)),
          ),
      ]),
    );
  }

  Widget _billPanel() {
    return Container(
      decoration: _card,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: Row(children: [
              const Expanded(child: Text('Current bill', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
              TextButton.icon(
                onPressed: _cart.isEmpty ? null : _clearBill,
                icon: const Icon(Icons.delete_sweep_rounded, size: 18),
                label: const Text('Clear'),
              ),
            ]),
          ),
          Container(
            color: const Color(0xFFF2F4F7),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: const Row(children: [
              Expanded(flex: 5, child: Text('Item', style: _hStyle)),
              Expanded(flex: 3, child: Text('Qty', textAlign: TextAlign.center, style: _hStyle)),
              Expanded(flex: 3, child: Text('Price', textAlign: TextAlign.center, style: _hStyle)),
              Expanded(flex: 3, child: Text('Total', textAlign: TextAlign.right, style: _hStyle)),
              SizedBox(width: 34),
            ]),
          ),
          Expanded(
            child: _cart.isEmpty
                ? const Center(
                    child: Text('Click a product to add it to the bill',
                        style: TextStyle(color: AppColors.lightTextSecondary)),
                  )
                : ListView.separated(
                    itemCount: _cart.length,
                    separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.lightDivider),
                    itemBuilder: (_, i) {
                      final l = _cart[i];
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        child: Row(children: [
                          Expanded(
                            flex: 5,
                            child: Text(l.item.name,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                          ),
                          Expanded(
                            flex: 3,
                            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              _MiniBtn(
                                icon: Icons.remove_rounded,
                                onTap: () => setState(() {
                                  if (l.qty > 1) l.qty -= 1;
                                }),
                              ),
                              SizedBox(
                                width: 46,
                                child: _NumField(
                                  key: ValueKey('q${l.item.id}'),
                                  value: l.qty,
                                  onChanged: (v) => setState(() => l.qty = v),
                                ),
                              ),
                              _MiniBtn(icon: Icons.add_rounded, onTap: () => setState(() => l.qty += 1)),
                            ]),
                          ),
                          Expanded(
                            flex: 3,
                            child: Center(
                              child: SizedBox(
                                width: 78,
                                child: _NumField(
                                  key: ValueKey('p${l.item.id}'),
                                  value: l.unitPrice,
                                  onChanged: (v) => setState(() => l.unitPrice = v),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 3,
                            child: Text(_money(l.total),
                                textAlign: TextAlign.right,
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                          ),
                          SizedBox(
                            width: 34,
                            child: IconButton(
                              padding: EdgeInsets.zero,
                              iconSize: 18,
                              color: AppColors.expense,
                              icon: const Icon(Icons.close_rounded),
                              onPressed: () => setState(() => _cart.removeAt(i)),
                            ),
                          ),
                        ]),
                      );
                    },
                  ),
          ),
          const Divider(height: 1, color: AppColors.lightDivider),
          _checkout(),
        ],
      ),
    );
  }

  static const TextStyle _hStyle =
      TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: AppColors.lightTextSecondary);

  Widget _checkout() {
    return Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(children: [
            Expanded(
              flex: 5,
              child: DropdownButtonFormField<int?>(
                value: _customerId,
                isExpanded: true,
                decoration: const InputDecoration(isDense: true, labelText: 'Customer', border: OutlineInputBorder()),
                items: [
                  const DropdownMenuItem<int?>(value: null, child: Text('Walk-in customer')),
                  for (final c in _customers) DropdownMenuItem<int?>(value: c.id, child: Text(c.name, overflow: TextOverflow.ellipsis)),
                ],
                onChanged: (v) => setState(() => _customerId = v),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 4,
              child: SegmentedButton<String>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 'cash', label: Text('Cash')),
                  ButtonSegment(value: 'credit', label: Text('Credit')),
                ],
                selected: {_payment},
                onSelectionChanged: (s) => setState(() => _payment = s.first),
              ),
            ),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _discount,
                onChanged: (_) => setState(() {}),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                decoration: const InputDecoration(isDense: true, labelText: 'Discount', border: OutlineInputBorder()),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _paid,
                enabled: _payment == 'credit',
                onChanged: (_) => setState(() {}),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                decoration: InputDecoration(
                  isDense: true,
                  labelText: _payment == 'credit' ? 'Paid now' : 'Paid (full)',
                  border: const OutlineInputBorder(),
                ),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          _line('Subtotal', _money(_subtotal)),
          if (_discountValue > 0) _line('Discount', '- ${_money(_discountValue)}'),
          _line('Total', _money(_total), big: true),
          if (_payment == 'credit') _line('Remaining (khata)', _money(_due), color: AppColors.expense),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _saving ? null : () => _save(openBill: false),
                icon: const Icon(Icons.save_rounded, size: 18),
                label: const Text('Save'),
                style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: FilledButton.icon(
                onPressed: _saving ? null : () => _save(openBill: true),
                icon: const Icon(Icons.print_rounded, size: 18),
                label: Text(_saving ? 'Saving...' : 'Save & Print bill'),
                style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
              ),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _line(String label, String value, {bool big = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(children: [
        Expanded(
          child: Text(label,
              style: TextStyle(
                  fontSize: big ? 16 : 13,
                  fontWeight: big ? FontWeight.w800 : FontWeight.w600,
                  color: color ?? AppColors.lightTextSecondary)),
        ),
        Text(value,
            style: TextStyle(
                fontSize: big ? 20 : 13.5, fontWeight: FontWeight.w800, color: color ?? AppColors.lightTextPrimary)),
      ]),
    );
  }
}

class _MiniBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _MiniBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(6),
      onTap: onTap,
      child: Container(
        width: 24,
        height: 24,
        decoration: BoxDecoration(
          color: const Color(0xFFF2F4F7),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Icon(icon, size: 16),
      ),
    );
  }
}

/// Small editable number box used for quantity and price in the bill table.
class _NumField extends StatefulWidget {
  final double value;
  final ValueChanged<double> onChanged;
  const _NumField({super.key, required this.value, required this.onChanged});

  @override
  State<_NumField> createState() => _NumFieldState();
}

class _NumFieldState extends State<_NumField> {
  late final TextEditingController _c = TextEditingController(text: _fmt(widget.value));

  static String _fmt(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toString();

  @override
  void didUpdateWidget(covariant _NumField old) {
    super.didUpdateWidget(old);
    if (old.value != widget.value && double.tryParse(_c.text) != widget.value) {
      _c.text = _fmt(widget.value);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: _c,
      textAlign: TextAlign.center,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
      decoration: const InputDecoration(
        isDense: true,
        contentPadding: EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        border: OutlineInputBorder(),
      ),
      onChanged: (t) {
        final v = double.tryParse(t);
        if (v != null && v >= 0) widget.onChanged(v);
      },
    );
  }
}
