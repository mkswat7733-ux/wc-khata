import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../sale/sale_screen.dart';
import 'desktop_pos_screen.dart';

/// Windows "Sale" tab: New Bill (billing screen) + Sales history.
class DesktopSaleTab extends StatelessWidget {
  const DesktopSaleTab({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: AppColors.lightBackground,
        appBar: AppBar(
          backgroundColor: Colors.white,
          toolbarHeight: 0,
          bottom: const TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [
              Tab(text: 'New Bill'),
              Tab(text: 'Sales & History'),
            ],
          ),
        ),
        body: const TabBarView(
          physics: NeverScrollableScrollPhysics(),
          children: [
            DesktopPosScreen(),
            SaleScreen(),
          ],
        ),
      ),
    );
  }
}
