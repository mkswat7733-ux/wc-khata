import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import 'app/app.dart';
import 'app/theme/app_theme.dart';
import 'app/user_preferences_controller.dart';
import 'core/database/app_database.dart';
import 'core/database/database_constants.dart';
import 'core/services/item_image_store.dart';
import 'core/services/ledger_media_store.dart';
import 'core/services/notification_service.dart';
import 'core/utils/app_platform.dart';
import 'core/utils/branding.dart';
import 'core/utils/desktop_init.dart';
import 'core/widgets/desktop_title_bar.dart';
import 'features/desktop/desktop_auto_backup.dart';

/// Runs one optional start-up step. It can never stop the app from opening:
/// a failure or a step that hangs is simply skipped after [seconds].
Future<void> _safe(Future<void> Function() job, {int seconds = 8}) async {
  try {
    await job().timeout(Duration(seconds: seconds));
  } catch (_) {}
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await initDesktop(); // Windows only: SQLite + window setup (no-op on Android)
    await _startup();
  } catch (e, st) {
    // The app data could not be opened. Show the reason on screen instead of
    // hanging on the splash screen.
    runApp(_StartupErrorApp(error: '$e', stack: '$st'));
  }
}

/// Checks that the two things the whole app depends on really work on this
/// phone: saved settings (SharedPreferences) and the database. Returns a list
/// of problems (empty = all fine). Nothing here changes the user's data.
Future<List<String>> _healthCheck() async {
  final problems = <String>[];
  try {
    final prefs = await SharedPreferences.getInstance().timeout(const Duration(seconds: 8));
    await prefs.setBool('health_check', true);
    if (prefs.getBool('health_check') != true) {
      problems.add('Saved settings: a value was written but could not be read back.');
    }
    await prefs.remove('health_check');
  } catch (e) {
    problems.add('Saved settings (SharedPreferences) do not work: $e');
  }
  try {
    final db = await AppDatabase.instance.database;
    final v = await db.rawQuery('PRAGMA user_version');
    final items = await db.rawQuery('SELECT COUNT(*) AS c FROM ${DBConstants.tableItems}');
    final version = v.isNotEmpty ? v.first.values.first : '?';
    final count = items.isNotEmpty ? items.first['c'] : '?';
    // Information only (shown in the report); never a problem by itself.
    _dbInfo = 'database version $version, $count products';
  } catch (e) {
    problems.add('Database does not work: $e');
  }
  return problems;
}

String _dbInfo = '';

Future<void> _startup() async {
  // The version shown on the splash / About screen (same as Play Store).
  await _safe(Branding.loadVersion, seconds: 2);

  // Initialize SQLite once at startup. No Firebase, no network calls -
  // this app works fully offline. This one is required.
  await AppDatabase.instance.database.timeout(const Duration(seconds: 30));

  // If something the app depends on is broken, say exactly what, on screen,
  // instead of opening an app that silently shows no data.
  final problems = await _healthCheck();
  if (problems.isNotEmpty) {
    runApp(_StartupErrorApp(error: problems.join('\n\n'), stack: _dbInfo, onContinue: _continueAnyway));
    return;
  }

  await _launchApp();
}

/// Used by "Continue anyway" on the problem screen.
Future<void> _continueAnyway() => _launchApp();

Future<void> _launchApp() async {
  await _safe(ItemImageStore.init);
  await _safe(LedgerMediaStore.init);

  // Sets up the local notification channel/permissions, then
  // re-schedules every unpaid bill's and active subscription's
  // due-date reminder - cheap, and keeps reminders correct even after
  // a device reboot or a restored backup (see NotificationService).
  // Phone-only for now (the reminders use Android notification channels).
  if (AppPlatform.isAndroid) {
    await _safe(NotificationService.instance.initialize);
    await _safe(NotificationService.instance.resyncAll);
    await _safe(NotificationService.instance.resyncLowStockAlerts);
  }

  // Windows: automatic daily backup into Documents\\WC Khata Backups.
  if (AppPlatform.isDesktop) await _safe(DesktopAutoBackup.runDaily, seconds: 20);

  final themeController = ThemeController();
  await _safe(themeController.load);

  // Loads the user's saved currency + profile photo so
  // CurrencyFormatter.defaultSymbol and the home header avatar are
  // correct from the very first frame, and stay reactive afterwards.
  final userPreferences = UserPreferencesController();
  await _safe(userPreferences.load);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: themeController),
        ChangeNotifierProvider.value(value: userPreferences),
      ],
      child: const LifeApp(),
    ),
  );
}

class _StartupErrorApp extends StatelessWidget {
  final String error;
  final String stack;
  final Future<void> Function()? onContinue;
  const _StartupErrorApp({required this.error, required this.stack, this.onContinue});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      builder: (context, child) => DesktopFrame.wrap(child ?? const SizedBox.shrink()),
      home: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12),
                const Icon(Icons.error_outline_rounded, size: 42, color: Colors.red),
                const SizedBox(height: 12),
                const Text('WC Khata could not start', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text('Version ${Branding.appVersion}. Your data is safe. Please send a screenshot of this screen to the developer.'),
                const SizedBox(height: 14),
                Expanded(
                  child: SingleChildScrollView(
                    child: SelectableText('$error\n\n$stack', style: const TextStyle(fontSize: 11.5)),
                  ),
                ),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: OutlinedButton(onPressed: () => Clipboard.setData(ClipboardData(text: '$error\n\n$stack')), child: const Text('Copy report'))),
                  const SizedBox(width: 10),
                  Expanded(child: FilledButton(onPressed: () => main(), child: const Text('Try again'))),
                ]),
                if (onContinue != null) ...[
                  const SizedBox(height: 8),
                  SizedBox(width: double.infinity, child: TextButton(onPressed: () => onContinue!(), child: const Text('Continue anyway'))),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
