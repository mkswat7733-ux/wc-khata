# WC Khata - Windows (desktop) version

Is project mein ab phone aur Windows dono ka code hai. Phone (Android) ka layout
bilkul pehle jaisa hai; Windows par left side ka permanent sidebar dikhta hai.

## EXE kaise banayein

### Tareeqa A - Apne Windows PC par
1. Flutter install karein (flutter.dev) aur `flutter doctor` mein "Visual Studio - Desktop development with C++" tick hona chahiye.
2. Project folder mein terminal kholein:
   ```
   flutter create --platforms=windows --project-name wc_khata --org com.webdsoft .
   flutter pub get
   flutter run -d windows            (test)
   flutter build windows --release   (exe)
   ```
3. EXE yahan milegi: `build\windows\x64\runner\Release\wc_khata.exe`
   (poora Release folder saath rakhna zaroori hai, sirf exe akeli nahi chalegi).
4. Single Setup.exe chahiye to Inno Setup install karke `windows_installer\installer.iss` compile karein.

### Tareeqa B - GitHub se (Windows PC ki zaroorat nahi)
1. Project ko GitHub repo mein upload karein.
2. Actions tab -> "Build Windows EXE" -> Run workflow.
3. Kuch minutes baad Artifacts mein `WC_Khata_Setup` (Setup.exe) download karein.

## Data kahan save hota hai
`C:\Users\<name>\AppData\Roaming\...\databases` - exe ke saath nahi, isliye update par data safe rehta hai.

## Abhi Windows par kaam NAHI karne wali cheezein (agla step)
- Bluetooth thermal printer (Android native code hai) -> Windows printer / USB se replace hoga
- Camera barcode scanner, OCR, contacts import -> USB barcode scanner (keyboard ki tarah chalta hai) alag se
- WhatsApp share channel, local notification reminders
