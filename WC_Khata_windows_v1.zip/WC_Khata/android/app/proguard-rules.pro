# R8 / ProGuard rules for the release build (minify + shrink are on).

# flutter_local_notifications: scheduled reminders are stored as JSON
# (Gson) and must survive code shrinking, otherwise reminders break
# in release builds only.
-keep class com.dexterous.** { *; }
-keep class com.google.gson.** { *; }
-keepattributes Signature
-keepattributes *Annotation*

# Flutter's optional Play Core (deferred components) classes are not used.
-dontwarn com.google.android.play.core.**

# Picture scanning / text reading (google_mlkit_text_recognition, camera).
# Release builds shrink code (R8); keep ML Kit so text reading still works.
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.internal.mlkit_vision_text_common.** { *; }
-keep class com.google_mlkit_commons.** { *; }
-keep class com.google_mlkit_text_recognition.** { *; }
# Only the Latin script is used; the other scripts are not bundled.
-dontwarn com.google.mlkit.vision.text.chinese.**
-dontwarn com.google.mlkit.vision.text.devanagari.**
-dontwarn com.google.mlkit.vision.text.japanese.**
-dontwarn com.google.mlkit.vision.text.korean.**
