package com.webdsoft.wckhata

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private val channelName = "wc_khata/whatsapp"
    private val fileProviderAuthority = "com.webdsoft.wckhata.fileprovider"
    private var printerBridge: PrinterBridge? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // configureFlutterEngine can run again (engine re-attach); close the old
        // bridge first so its Bluetooth receivers/sockets are never leaked or doubled.
        printerBridge?.dispose()
        printerBridge = PrinterBridge(this, flutterEngine.dartExecutor.binaryMessenger)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "shareReceiptToWhatsApp" -> shareReceiptToWhatsApp(call, result)
                    "shareInvoiceToWhatsApp" -> shareInvoiceToWhatsApp(call, result)
                    "shareInvoiceImageToWhatsApp" -> shareInvoiceImageToWhatsApp(call, result)
                    "saveInvoicePdf" -> saveInvoicePdf(call, result)
                    "sendReceiptSms" -> sendReceiptSms(call, result)
                    "sendReminderSms" -> sendReminderSms(call, result)
                    "sendReminderWhatsApp" -> sendReminderWhatsApp(call, result)
                    else -> result.notImplemented()
                }
            }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        printerBridge?.onActivityResult(requestCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        printerBridge?.onRequestPermissionsResult(requestCode, grantResults)
    }

    override fun onDestroy() {
        printerBridge?.dispose()
        printerBridge = null
        super.onDestroy()
    }

    private fun shareReceiptToWhatsApp(
        call: MethodCall,
        result: MethodChannel.Result,
    ) {
        val path = call.argument<String>("path")
        val phone = call.argument<String>("phone")

        if (phone.isNullOrBlank() || path.isNullOrBlank()) {
            result.success("none")
            return
        }

        val whatsappNumber = normalizeWhatsAppNumber(phone)
        if (whatsappNumber.isBlank()) {
            result.success("none")
            return
        }

        try {
            val file = File(path)
            if (!file.exists() || file.length() == 0L) {
                result.success("none")
                return
            }

            val uri = FileProvider.getUriForFile(
                this@MainActivity,
                fileProviderAuthority,
                file,
            )

            // First try the native SEND flow so the receipt image can be shared.
            // The JID is the international number without +, spaces or punctuation.
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra("jid", "$whatsappNumber@s.whatsapp.net")
                putExtra("address", whatsappNumber)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val packages = listOf("com.whatsapp", "com.whatsapp.w4b")
            for (packageName in packages) {
                sendIntent.setPackage(packageName)
                if (sendIntent.resolveActivity(packageManager) != null) {
                    startActivity(sendIntent)
                    result.success("whatsapp")
                    return
                }
            }

            // Some WhatsApp versions do not honor jid when sharing a file.
            // Fall back to the official wa.me deep link, which opens the exact
            // international number. The user can then attach the prepared card.
            val directUri = Uri.parse("https://wa.me/$whatsappNumber")
            val directIntent = Intent(Intent.ACTION_VIEW, directUri)
            for (packageName in packages) {
                directIntent.setPackage(packageName)
                if (directIntent.resolveActivity(packageManager) != null) {
                    startActivity(directIntent)
                    result.success("whatsapp")
                    return
                }
            }

            result.success("none")
        } catch (_: ActivityNotFoundException) {
            result.success("none")
        } catch (_: Exception) {
            result.success("none")
        }
    }


    private fun shareInvoiceToWhatsApp(
        call: MethodCall,
        result: MethodChannel.Result,
    ) {
        val path = call.argument<String>("path")
        if (path.isNullOrBlank()) { result.success("none"); return }
        try {
            val file = File(path)
            if (!file.exists() || file.length() == 0L) { result.success("none"); return }
            val uri = FileProvider.getUriForFile(this@MainActivity, fileProviderAuthority, file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val packages = listOf("com.whatsapp", "com.whatsapp.w4b")
            for (packageName in packages) {
                intent.setPackage(packageName)
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    result.success("whatsapp")
                    return
                }
            }
            result.success("none")
        } catch (_: Exception) { result.success("none") }
    }


    private fun shareInvoiceImageToWhatsApp(call: MethodCall, result: MethodChannel.Result) {
        val path = call.argument<String>("path")
        if (path.isNullOrBlank()) { result.success("none"); return }
        try {
            val file = File(path)
            if (!file.exists() || file.length() == 0L) { result.success("none"); return }
            val uri = FileProvider.getUriForFile(this@MainActivity, fileProviderAuthority, file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val packages = listOf("com.whatsapp", "com.whatsapp.w4b")
            for (packageName in packages) {
                intent.setPackage(packageName)
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    result.success("whatsapp")
                    return
                }
            }
            result.success("none")
        } catch (_: Exception) { result.success("none") }
    }

    private fun saveInvoicePdf(call: MethodCall, result: MethodChannel.Result) {
        val path = call.argument<String>("path")
        val fileName = call.argument<String>("fileName") ?: "Invoice.pdf"
        if (path.isNullOrBlank()) {
            result.success(null)
            return
        }

        try {
            val source = File(path)
            if (!source.exists() || source.length() == 0L) {
                result.success(null)
                return
            }

            // Android 10+ uses MediaStore, so no storage permission is needed.
            // The RELATIVE_PATH makes the file appear directly inside Downloads.
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val resolver = contentResolver
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/pdf")
                    put(android.provider.MediaStore.Downloads.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                    put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: run {
                        result.success(null)
                        return
                    }

                try {
                    val output = resolver.openOutputStream(uri)
                    if (output == null) {
                        resolver.delete(uri, null, null)
                        result.success(null)
                        return
                    }
                    output.use { out ->
                        source.inputStream().use { input -> input.copyTo(out) }
                    }
                    val published = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
                    }
                    resolver.update(uri, published, null, null)
                    result.success("Downloads/$fileName")
                } catch (_: Exception) {
                    resolver.delete(uri, null, null)
                    result.success(null)
                }
                return
            }

            // Android 9 and below requires the legacy public-storage permission.
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M &&
                checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 4107)
                result.success("permission_required")
                return
            }

            val downloads = android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_DOWNLOADS,
            )
            if (!downloads.exists() && !downloads.mkdirs()) {
                result.success(null)
                return
            }
            val target = File(downloads, fileName)
            source.inputStream().use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
            sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(target)))
            result.success(target.absolutePath)
        } catch (_: Exception) {
            result.success(null)
        }
    }

    private fun sendReceiptSms(
        call: MethodCall,
        result: MethodChannel.Result,
    ) {
        val phone = call.argument<String>("phone")
        val smsText = call.argument<String>("smsText").orEmpty()

        if (phone.isNullOrBlank()) {
            result.success("none")
            return
        }

        try {
            val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:${normalizeSmsNumber(phone)}")
                putExtra("sms_body", smsText)
            }

            if (smsIntent.resolveActivity(packageManager) == null) {
                result.success("none")
                return
            }

            startActivity(smsIntent)
            result.success("sms")
        } catch (_: ActivityNotFoundException) {
            result.success("none")
        } catch (_: Exception) {
            result.success("none")
        }
    }


    private fun sendReminderSms(
        call: MethodCall,
        result: MethodChannel.Result,
    ) {
        val phone = call.argument<String>("phone")
        val smsText = call.argument<String>("smsText").orEmpty()
        if (phone.isNullOrBlank()) {
            result.success("none")
            return
        }
        try {
            val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:${normalizeSmsNumber(phone)}")
                putExtra("sms_body", smsText)
            }
            if (smsIntent.resolveActivity(packageManager) == null) {
                result.success("none")
                return
            }
            startActivity(smsIntent)
            result.success("sms")
        } catch (_: Exception) {
            result.success("none")
        }
    }

    private fun sendReminderWhatsApp(
        call: MethodCall,
        result: MethodChannel.Result,
    ) {
        val phone = call.argument<String>("phone")
        val message = call.argument<String>("message").orEmpty()
        if (phone.isNullOrBlank()) {
            result.success("none")
            return
        }
        val number = normalizeWhatsAppNumber(phone)
        if (number.isBlank()) {
            result.success("none")
            return
        }
        try {
            val uri = Uri.parse("https://wa.me/$number?text=${Uri.encode(message)}")
            val packages = listOf("com.whatsapp", "com.whatsapp.w4b")
            for (packageName in packages) {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage(packageName) }
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    result.success("whatsapp")
                    return
                }
            }
            result.success("none")
        } catch (_: Exception) {
            result.success("none")
        }
    }

    private fun normalizeWhatsAppNumber(raw: String): String {
        var value = raw.trim()
            .replace("+", "")
            .replace(Regex("[^0-9]"), "")

        // Convert international dialing prefix 00XX -> XX.
        if (value.startsWith("00")) {
            value = value.drop(2)
        }

        // Pakistan local mobile format: 03XXXXXXXXX -> 923XXXXXXXXX.
        if (value.length == 11 && value.startsWith("03")) {
            value = "92" + value.drop(1)
        }

        // Pakistan number sometimes arrives without the leading 0: 3XXXXXXXXX.
        if (value.length == 10 && value.startsWith("3")) {
            value = "92$value"
        }

        // Already international Pakistan format: 923XXXXXXXXX.
        return value
    }

    private fun normalizeSmsNumber(raw: String): String {
        return raw.trim().replace(Regex("[^0-9+*#]"), "")
    }
}
