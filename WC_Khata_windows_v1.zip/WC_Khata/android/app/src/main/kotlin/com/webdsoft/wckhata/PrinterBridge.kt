package com.webdsoft.wckhata

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Classic-Bluetooth (SPP / RFCOMM) bridge for thermal receipt + label printers.
 *
 * What changed compared to the first version (all aimed at "printer drops /
 * switches off / does not stay connected"):
 *
 *  - One socket PER printer address (receipt printer and label printer can be
 *    connected at the same time; connecting one no longer kills the other).
 *  - Every Bluetooth operation runs on ONE worker thread, so a connect, a write
 *    and a disconnect can never overlap and corrupt each other.
 *  - The system tells us when the printer link really drops (ACL_DISCONNECTED /
 *    Bluetooth switched off); the dead socket is discarded at once and Flutter
 *    is notified, instead of trusting BluetoothSocket.isConnected (which keeps
 *    saying "true" after the printer powered off).
 *  - A write that fails BEFORE the first byte left the phone reconnects and
 *    retries inside this class. A write that fails half-way is NOT replayed
 *    (that used to print the receipt twice / send a broken ESC/POS stream to
 *    the printer, which is what makes cheap printers hang or reboot).
 *  - Discovery is always cancelled before connecting (scanning while connecting
 *    makes RFCOMM connects fail and slows the printer link badly).
 *  - Sockets are closed gracefully (flush + short wait), never in the middle of
 *    the printer still receiving data.
 */
@SuppressLint("MissingPermission")
class PrinterBridge(private val activity: Activity, messenger: BinaryMessenger) {

    companion object {
        const val REQ_ENABLE_BT = 7101
        const val REQ_PERMISSIONS = 7102
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val CONNECT_PAUSE_MS = 450L
    }

    private val channel = MethodChannel(messenger, "wc_khata/printer")
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val adapter: BluetoothAdapter? =
        (activity.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private val sockets = ConcurrentHashMap<String, BluetoothSocket>()

    private var pendingEnable: MethodChannel.Result? = null
    private var pendingPermissions: MethodChannel.Result? = null
    private var scanReceiver: BroadcastReceiver? = null
    private var bondReceiver: BroadcastReceiver? = null
    private var linkReceiver: BroadcastReceiver? = null

    init {
        channel.setMethodCallHandler { call, result -> onCall(call, result) }
        registerLinkReceiver()
    }

    private fun onCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "isSupported" -> result.success(adapter != null)
            "isEnabled" -> result.success(adapter?.isEnabled == true)
            "hasPermissions" -> result.success(hasPermissions())
            "requestPermissions" -> requestPermissions(result)
            "enable" -> enable(result)
            "pairedDevices" -> result.success(pairedDevices())
            "startScan" -> startScan(result)
            "stopScan" -> { stopScan(); result.success(true) }
            "pair" -> pair(call.argument<String>("address"), result)
            "connect" -> connect(call.argument<String>("address"), result)
            "disconnect" -> disconnect(call.argument<String>("address"), result)
            "isConnected" -> result.success(isConnected(call.argument<String>("address")))
            "connectedAddresses" -> result.success(sockets.keys.toList())
            "write" -> write(
                call.argument<String>("address"),
                call.argument<ByteArray>("bytes"),
                call.argument<Int>("chunk") ?: 512,
                call.argument<Int>("delay") ?: 10,
                call.argument<List<Int>>("marks") ?: emptyList(),
                call.argument<List<Int>>("markDelays") ?: emptyList(),
                result,
            )
            else -> result.notImplemented()
        }
    }

    // ------------------------------------------------------------ permissions

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    private fun hasPermissions(): Boolean = requiredPermissions().all {
        activity.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissions(result: MethodChannel.Result) {
        if (hasPermissions()) { result.success(true); return }
        pendingPermissions?.success(false)
        pendingPermissions = result
        activity.requestPermissions(requiredPermissions(), REQ_PERMISSIONS)
    }

    fun onRequestPermissionsResult(requestCode: Int, grantResults: IntArray): Boolean {
        if (requestCode != REQ_PERMISSIONS) return false
        val ok = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        pendingPermissions?.success(ok)
        pendingPermissions = null
        return true
    }

    // -------------------------------------------------------------- bluetooth

    private fun enable(result: MethodChannel.Result) {
        val bt = adapter
        if (bt == null) { result.success(false); return }
        if (bt.isEnabled) { result.success(true); return }
        if (!hasPermissions()) { result.success(false); return }
        pendingEnable?.success(false)
        pendingEnable = result
        try {
            activity.startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BT)
        } catch (_: Exception) {
            pendingEnable = null
            result.success(false)
        }
    }

    fun onActivityResult(requestCode: Int): Boolean {
        if (requestCode != REQ_ENABLE_BT) return false
        // Bluetooth needs a moment to actually switch on after the user taps Allow.
        main.postDelayed({
            pendingEnable?.success(adapter?.isEnabled == true)
            pendingEnable = null
        }, 600)
        return true
    }

    private fun deviceMap(d: BluetoothDevice): Map<String, Any?> = mapOf(
        "name" to (try { d.name } catch (_: Exception) { null } ?: ""),
        "address" to d.address,
        "paired" to (d.bondState == BluetoothDevice.BOND_BONDED),
    )

    private fun pairedDevices(): List<Map<String, Any?>> =
        try { adapter?.bondedDevices?.map { deviceMap(it) } ?: emptyList() } catch (_: Exception) { emptyList() }

    // ------------------------------------------------- link state monitoring

    /**
     * Android tells us the moment a printer really goes away (powered off,
     * out of range, auto-power-off timer) or Bluetooth is switched off. The
     * dead socket is dropped and Flutter is told, so the next print reconnects
     * cleanly instead of writing into a dead pipe.
     */
    private fun registerLinkReceiver() {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                        val d = deviceFrom(intent) ?: return
                        val s = sockets[d.address] ?: return
                        // Do the close on the worker so it can't race a running write.
                        io.execute {
                            if (sockets[d.address] === s) {
                                sockets.remove(d.address)
                                try { s.close() } catch (_: Exception) {}
                                main.post { channel.invokeMethod("linkLost", d.address) }
                            }
                        }
                    }
                    BluetoothAdapter.ACTION_STATE_CHANGED -> {
                        val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                        if (state == BluetoothAdapter.STATE_TURNING_OFF || state == BluetoothAdapter.STATE_OFF) {
                            io.execute {
                                val lost = sockets.keys.toList()
                                closeAllSockets(graceful = false)
                                main.post { lost.forEach { channel.invokeMethod("linkLost", it) } }
                            }
                        }
                    }
                }
            }
        }
        linkReceiver = receiver
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        activity.registerReceiver(receiver, filter)
    }

    private fun deviceFrom(intent: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    // ------------------------------------------------------------------- scan

    private fun startScan(result: MethodChannel.Result) {
        val bt = adapter
        if (bt == null || !bt.isEnabled || !hasPermissions()) { result.success(false); return }
        stopScan()
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val device = deviceFrom(intent)
                        if (device != null) channel.invokeMethod("deviceFound", deviceMap(device))
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> channel.invokeMethod("scanFinished", null)
                }
            }
        }
        scanReceiver = receiver
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        activity.registerReceiver(receiver, filter)
        result.success(bt.startDiscovery())
    }

    private fun stopScan() {
        try { adapter?.cancelDiscovery() } catch (_: Exception) {}
        scanReceiver?.let { try { activity.unregisterReceiver(it) } catch (_: Exception) {} }
        scanReceiver = null
    }

    // ------------------------------------------------------------------- pair

    private fun pair(address: String?, result: MethodChannel.Result) {
        val bt = adapter
        if (bt == null || address.isNullOrBlank()) { result.success(false); return }
        val device = try { bt.getRemoteDevice(address) } catch (_: Exception) { null }
        if (device == null) { result.success(false); return }
        if (device.bondState == BluetoothDevice.BOND_BONDED) { result.success(true); return }
        stopScan()

        var finished = false
        fun finish(ok: Boolean) {
            if (finished) return
            finished = true
            bondReceiver?.let { try { activity.unregisterReceiver(it) } catch (_: Exception) {} }
            bondReceiver = null
            result.success(ok)
        }

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val d = deviceFrom(intent)
                if (d?.address != address) return
                when (intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR)) {
                    BluetoothDevice.BOND_BONDED -> finish(true)
                    BluetoothDevice.BOND_NONE -> finish(false)
                }
            }
        }
        bondReceiver = receiver
        activity.registerReceiver(receiver, IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED))
        if (!device.createBond()) { finish(false); return }
        // The system PIN dialog (usually 0000 / 1234) is up to the user; give them time.
        main.postDelayed({ finish(device.bondState == BluetoothDevice.BOND_BONDED) }, 60_000)
    }

    // ---------------------------------------------------------------- connect
    // Everything below that touches `sockets` runs on the `io` worker thread.

    private fun isConnected(address: String?): Boolean {
        if (address == null) return sockets.values.any { it.isConnected }
        return sockets[address]?.isConnected == true
    }

    /** Flush + short wait so the printer finishes receiving before the link closes. */
    private fun closeSocket(address: String, graceful: Boolean) {
        val s = sockets.remove(address) ?: return
        if (graceful) {
            try { s.outputStream.flush() } catch (_: Exception) {}
            try { Thread.sleep(150) } catch (_: InterruptedException) {}
        }
        try { s.close() } catch (_: Exception) {}
    }

    private fun closeAllSockets(graceful: Boolean) {
        sockets.keys.toList().forEach { closeSocket(it, graceful) }
    }

    /**
     * Opens (or re-opens) the RFCOMM link to one printer. Tries, in order:
     * secure SPP, insecure SPP, RFCOMM channel 1 (some cheap printers only
     * answer there). A short pause between tries lets the Bluetooth stack
     * release the failed attempt - without it the 2nd/3rd try fail instantly.
     * Throws when every attempt failed.
     */
    private fun openSocket(address: String): BluetoothSocket {
        val bt = adapter ?: throw IOException("No Bluetooth adapter")
        try { bt.cancelDiscovery() } catch (_: Exception) {}
        closeSocket(address, graceful = false)
        val device = bt.getRemoteDevice(address)

        val attempts = listOf<() -> BluetoothSocket>(
            { device.createRfcommSocketToServiceRecord(SPP_UUID) },
            { device.createInsecureRfcommSocketToServiceRecord(SPP_UUID) },
            {
                device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    .invoke(device, 1) as BluetoothSocket
            },
        )
        var last: Exception? = null
        for ((i, make) in attempts.withIndex()) {
            var s: BluetoothSocket? = null
            try {
                s = make()
                s.connect()
                sockets[address] = s
                return s
            } catch (e: Exception) {
                last = e
                try { s?.close() } catch (_: Exception) {}
                if (i < attempts.size - 1) {
                    try { Thread.sleep(CONNECT_PAUSE_MS) } catch (_: InterruptedException) {}
                }
            }
        }
        throw IOException("Could not connect to $address", last)
    }

    private fun connect(address: String?, result: MethodChannel.Result) {
        if (adapter == null || address.isNullOrBlank()) { result.success(false); return }
        stopScan()
        io.execute {
            var ok = false
            try {
                ok = if (sockets[address]?.isConnected == true) true else { openSocket(address); true }
            } catch (_: Exception) {
                closeSocket(address, graceful = false)
            }
            main.post { result.success(ok) }
        }
    }

    private fun disconnect(address: String?, result: MethodChannel.Result) {
        io.execute {
            if (address.isNullOrBlank()) closeAllSockets(graceful = true) else closeSocket(address, graceful = true)
            main.post { result.success(true) }
        }
    }

    // ------------------------------------------------------------------ write

    /** Throws IOException; [progress][0] always holds how many bytes already left the phone. */
    private fun streamOut(
        s: BluetoothSocket, bytes: ByteArray, chunkSize: Int, delayMs: Int,
        marks: List<Int>, markDelays: List<Int>, progress: IntArray,
    ) {
        // Printers sometimes send status bytes back; leaving them unread can stall the link.
        try {
            val input = s.inputStream
            val junk = ByteArray(64)
            while (input.available() > 0) { if (input.read(junk) <= 0) break }
        } catch (_: Exception) {}

        val out = s.outputStream
        // Big writes (up to 16 KB) let a whole 80 mm bill stream out without
        // gaps; RFCOMM itself blocks when the printer's buffer is full.
        val chunk = chunkSize.coerceIn(32, 16384)
        val pause = delayMs.toLong().coerceIn(0, 200)
        var offset = 0
        var mi = 0
        while (offset < bytes.size) {
            // "Rest marks": after a dense band the print head needs time to cool,
            // so the sender pauses there (prevents brown-out / power-off).
            val limit = if (mi < marks.size) minOf(bytes.size, marks[mi]) else bytes.size
            if (limit <= offset) {
                val rest = (markDelays.getOrNull(mi) ?: 0).toLong().coerceIn(0, 1000)
                if (rest > 0) { out.flush(); Thread.sleep(rest) }
                mi++
                continue
            }
            val len = minOf(chunk, limit - offset)
            out.write(bytes, offset, len)
            offset += len
            progress[0] = offset
            // Flush per chunk only when pacing; in fast mode (no pause) the
            // stream is flushed once at the end so data flows continuously.
            if (pause > 0) {
                out.flush()
                Thread.sleep(pause) // let the printer's small buffer empty
            }
        }
        out.flush()
    }

    /**
     * Result map: ok / sent / total.
     *  - ok = true                : the whole job was handed to the printer.
     *  - ok = false, sent == 0    : nothing reached the printer (safe to retry).
     *  - ok = false, sent  > 0    : job broke half-way (do NOT resend - it would print twice).
     */
    private fun write(
        address: String?, bytes: ByteArray?, chunkSize: Int, delayMs: Int,
        marks: List<Int>, markDelays: List<Int>, result: MethodChannel.Result,
    ) {
        if (bytes == null || address.isNullOrBlank()) {
            result.success(mapOf("ok" to false, "sent" to 0, "total" to (bytes?.size ?: 0)))
            return
        }
        io.execute {
            val progress = intArrayOf(0)
            var ok = false
            try {
                try { adapter?.cancelDiscovery() } catch (_: Exception) {}
                var s = sockets[address]
                if (s == null || !s.isConnected) s = openSocket(address)
                try {
                    streamOut(s, bytes, chunkSize, delayMs, marks, markDelays, progress)
                    ok = true
                } catch (e: IOException) {
                    closeSocket(address, graceful = false)
                    if (progress[0] != 0) throw e // half-sent: never replay
                    // Nothing was sent: the link was stale. Reconnect once and retry.
                    val fresh = openSocket(address)
                    streamOut(fresh, bytes, chunkSize, delayMs, marks, markDelays, progress)
                    ok = true
                }
                // Give the printer time to finish what is in its buffer before the next job.
                Thread.sleep((300 + bytes.size / 100).toLong().coerceAtMost(1500))
            } catch (_: Exception) {
                ok = false
                closeSocket(address, graceful = false)
            }
            val sent = progress[0]
            main.post { result.success(mapOf("ok" to ok, "sent" to sent, "total" to bytes.size)) }
        }
    }

    fun dispose() {
        stopScan()
        bondReceiver?.let { try { activity.unregisterReceiver(it) } catch (_: Exception) {} }
        bondReceiver = null
        linkReceiver?.let { try { activity.unregisterReceiver(it) } catch (_: Exception) {} }
        linkReceiver = null
        // Queue the close behind any running job so a print is never cut off.
        try { io.execute { closeAllSockets(graceful = true) } } catch (_: Exception) {}
        io.shutdown()
    }
}
