import 'package:flutter/material.dart';
import '../core/services/pending_notification.dart';
import '../data/repositories/security_settings_repository.dart';
import '../features/notifications/notifications_screen.dart';
import '../features/security/unlock_screen.dart';
import 'routes/root_shell.dart';

/// App launch flow (per spec):
///   if passwordEnabled == false -> HomeScreen (RootShell)
///   else                        -> PasswordUnlockScreen -> RootShell
/// No login/signup/biometric screens exist anywhere in this flow.
///
/// The one exception: if a bill/subscription reminder notification is
/// what brought the app here (see `NotificationService` and
/// [PendingNotification]), the "-> RootShell" step above is replaced
/// by the Notifications screen instead — still gated by the same
/// password check first, exactly like Home would be.
class LaunchGate extends StatelessWidget {
  const LaunchGate({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: SecuritySettingsRepository().isPasswordEnabled(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
            body: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.error_outline_rounded, size: 40, color: Colors.red),
                    const SizedBox(height: 12),
                    const Text('The app data could not be opened.', textAlign: TextAlign.center, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    SelectableText('${snapshot.error}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LaunchGate())),
                      child: const Text('Try again'),
                    ),
                  ],
                ),
              ),
            ),
          );
        }
        if (!snapshot.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return snapshot.data! ? const UnlockScreen() : _resolveDestination();
      },
    );
  }

  Widget _resolveDestination() {
    final payload = PendingNotification.consume();
    if (payload != null) return NotificationsScreen(initialPayload: payload);
    return const RootShell();
  }
}
