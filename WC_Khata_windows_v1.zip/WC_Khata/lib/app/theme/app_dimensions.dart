class AppDimensions {
  AppDimensions._();

  static const double spaceXs = 4;
  static const double spaceSm = 8;
  static const double spaceMd = 16;
  static const double spaceLg = 24;
  static const double spaceXl = 32;

  static const double radiusSm = 10;
  static const double radiusMd = 16;
  static const double radiusLg = 20;
  static const double radiusPill = 100;

  static const double cardElevation = 0; // shadows are custom BoxShadows, not Material elevation
  static const double iconContainerSize = 44;
  static const double bottomNavHeight = 64;
}
