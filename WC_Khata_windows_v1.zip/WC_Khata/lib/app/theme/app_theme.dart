import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'light_theme.dart';
import 'dark_theme.dart';

export 'light_theme.dart';
export 'dark_theme.dart';
export 'app_colors.dart';
export 'app_text_styles.dart';
export 'app_dimensions.dart';

/// Holds the user's theme preference (System / Light / Dark).
/// Persisted locally via SharedPreferences — this is a UI preference,
/// not authentication, so it is fine to store as plain local prefs.
class ThemeController extends ChangeNotifier {
  ThemeMode get mode => ThemeMode.light;

  ThemeData get light => lightTheme;

  /// Dark/system modes are intentionally disabled. The app is light-only.
  Future<void> load() async {}

  Future<void> setMode(ThemeMode mode) async {
    // Kept for compatibility with older screens/settings code.
    notifyListeners();
  }
}
