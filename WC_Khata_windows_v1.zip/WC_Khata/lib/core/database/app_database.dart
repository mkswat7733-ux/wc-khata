import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'database_constants.dart';
import 'database_migrations.dart';

/// Singleton SQLite database. Everything in this app is 100% offline —
/// no Firebase, no REST calls, no cloud sync. All reads/writes go through
/// repositories in data/repositories, never directly from UI widgets.
class AppDatabase {
  AppDatabase._internal();
  static final AppDatabase instance = AppDatabase._internal();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, DBConstants.dbName);
    return openDatabase(
      path,
      version: DBConstants.dbVersion,
      onCreate: _onCreate,
      onUpgrade: DatabaseMigrations.onUpgrade,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onOpen: (db) async {
        // Purge ledger records that have been in Recycle Bin for more than
        // 60 days. This runs whenever the local database is opened.
        final cutoff = DateTime.now().subtract(const Duration(days: 60)).toIso8601String();
        await db.delete(
          DBConstants.tableLedgerTransactions,
          where: 'deleted_at IS NOT NULL AND deleted_at < ?',
          whereArgs: [cutoff],
        );
      },
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    final batch = db.batch();

    // ---------------- Settings / profile ----------------
    batch.execute('''
      CREATE TABLE ${DBConstants.tableProfile} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT,
        address TEXT,
        phone TEXT,
        currency TEXT NOT NULL DEFAULT 'USD',
        start_day TEXT NOT NULL DEFAULT 'Sunday',
        language TEXT NOT NULL DEFAULT 'en',
        photo_path TEXT,
        owner_name TEXT,
        designation TEXT,
        tagline TEXT,
        website TEXT,
        whatsapp TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    // Password is stored ONLY as salted hash — never plain text.
    batch.execute('''
      CREATE TABLE ${DBConstants.tableSecuritySettings} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        password_enabled INTEGER NOT NULL DEFAULT 0,
        password_hash TEXT,
        password_salt TEXT,
        fingerprint_enabled INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL
      )
    ''');

    batch.execute('''
      CREATE TABLE ${DBConstants.tableAppSettings} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        theme_mode TEXT NOT NULL DEFAULT 'system',
        hide_balance INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL
      )
    ''');

    batch.execute('''CREATE TABLE ${DBConstants.tableItemCategories} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL)''');
    batch.execute('''CREATE TABLE ${DBConstants.tableItemUnits} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL)''');
    batch.execute('''CREATE TABLE ${DBConstants.tableItems} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category_id INTEGER, supplier_id INTEGER, unit TEXT NOT NULL, qty REAL NOT NULL DEFAULT 0, low_stock REAL NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0, image_path TEXT, scan_text TEXT, barcode TEXT, purchase_type TEXT, purchase_amount REAL NOT NULL DEFAULT 0, purchase_unit_price REAL NOT NULL DEFAULT 0, purchase_paid REAL NOT NULL DEFAULT 0, purchase_date TEXT, purchase_cash_tx_id INTEGER, track_stock INTEGER NOT NULL DEFAULT 1, outer_unit TEXT, inner_unit TEXT, units_per_outer REAL NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY (category_id) REFERENCES ${DBConstants.tableItemCategories}(id) ON DELETE SET NULL, FOREIGN KEY (supplier_id) REFERENCES ${DBConstants.tableLedgerParties}(id) ON DELETE SET NULL)''');
    batch.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_items_barcode ON ${DBConstants.tableItems}(barcode) WHERE barcode IS NOT NULL AND barcode != ''");
    batch.execute('CREATE INDEX idx_items_category ON ${DBConstants.tableItems}(category_id)');
    batch.execute('''CREATE TABLE ${DBConstants.tableSaleInvoices} (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT NOT NULL UNIQUE, customer_id INTEGER, payment_type TEXT NOT NULL, total REAL NOT NULL, subtotal REAL NOT NULL DEFAULT 0, discount_amount REAL NOT NULL DEFAULT 0, tax_rate REAL NOT NULL DEFAULT 0, tax_amount REAL NOT NULL DEFAULT 0, paid_amount REAL NOT NULL DEFAULT 0, date TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY (customer_id) REFERENCES ${DBConstants.tableLedgerParties}(id) ON DELETE SET NULL)''');
    batch.execute('''CREATE TABLE ${DBConstants.tableSaleItems} (id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, item_id INTEGER NOT NULL, item_name TEXT NOT NULL, qty REAL NOT NULL, unit_price REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0, total REAL NOT NULL, FOREIGN KEY (sale_id) REFERENCES ${DBConstants.tableSaleInvoices}(id) ON DELETE CASCADE, FOREIGN KEY (item_id) REFERENCES ${DBConstants.tableItems}(id) ON DELETE RESTRICT)''');
    batch.execute('CREATE INDEX idx_sale_items_sale ON ${DBConstants.tableSaleItems}(sale_id)');
    batch.execute('CREATE INDEX idx_sale_invoices_date ON ${DBConstants.tableSaleInvoices}(date)');

    // ---------------- Finance ----------------
    batch.execute('''
      CREATE TABLE ${DBConstants.tableAccounts} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        opening_balance REAL NOT NULL DEFAULT 0,
        current_balance REAL NOT NULL DEFAULT 0,
        currency TEXT NOT NULL DEFAULT 'USD',
        notes TEXT,
        icon_key TEXT,
        color_hex TEXT,
        is_active INTEGER NOT NULL DEFAULT 1,
        deleted_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        credit_limit REAL,
        card_type TEXT,
        linked_bank_account_id INTEGER
      )
    ''');

    // Two-level category tree. `parent_id IS NULL` = a main category
    // (e.g. "ABC Restaurant" — a business/source the user defines).
    // `parent_id` set = a sub-category under that main category (e.g.
    // "Electricity Bill"). Both levels are usable from Income AND
    // Expense transactions, which is what lets Reports compute
    // per-main-category profit/loss (income tagged to the main
    // category minus expenses tagged to it or any of its sub-categories).
    // `type` is legacy/unused, kept only so old rows from pre-v3
    // installs still satisfy the NOT NULL constraint.
    batch.execute('''
      CREATE TABLE ${DBConstants.tableCategories} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'general',
        parent_id INTEGER,
        icon_key TEXT,
        color_hex TEXT,
        is_default INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (parent_id) REFERENCES ${DBConstants.tableCategories}(id) ON DELETE CASCADE
      )
    ''');
    batch.execute('CREATE INDEX idx_categories_parent ON ${DBConstants.tableCategories}(parent_id)');

    // Single transaction ledger for income / expense / transfer.
    // type: income | expense | transfer
    // For transfers, to_account_id is populated and the row does not
    // affect reports as income/expense — only balances.
    batch.execute('''
      CREATE TABLE ${DBConstants.tableTransactions} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        account_id INTEGER NOT NULL,
        to_account_id INTEGER,
        category_id INTEGER,
        source TEXT,
        payment_method TEXT,
        frequency TEXT,
        date TEXT NOT NULL,
        note TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (account_id) REFERENCES ${DBConstants.tableAccounts}(id) ON DELETE CASCADE,
        FOREIGN KEY (to_account_id) REFERENCES ${DBConstants.tableAccounts}(id) ON DELETE SET NULL,
        FOREIGN KEY (category_id) REFERENCES ${DBConstants.tableCategories}(id) ON DELETE SET NULL
      )
    ''');
    batch.execute('CREATE INDEX idx_transactions_date ON ${DBConstants.tableTransactions}(date)');
    batch.execute('CREATE INDEX idx_transactions_type ON ${DBConstants.tableTransactions}(type)');
    batch.execute('CREATE INDEX idx_transactions_category ON ${DBConstants.tableTransactions}(category_id)');

    // ---------------- Budgets ----------------
    batch.execute('''
      CREATE TABLE ${DBConstants.tableBudgets} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        period TEXT NOT NULL DEFAULT 'monthly',
        month TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (category_id) REFERENCES ${DBConstants.tableCategories}(id) ON DELETE CASCADE
      )
    ''');

    // ---------------- Savings goals ----------------
    batch.execute('''
      CREATE TABLE ${DBConstants.tableSavingsGoals} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        target_amount REAL NOT NULL,
        saved_amount REAL NOT NULL DEFAULT 0,
        icon_key TEXT,
        color_hex TEXT,
        target_date TEXT,
        notes TEXT,
        is_completed INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');
    batch.execute('''
      CREATE TABLE ${DBConstants.tableGoalActivity} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        goal_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        action TEXT NOT NULL, -- add | withdraw
        date TEXT NOT NULL,
        note TEXT,
        FOREIGN KEY (goal_id) REFERENCES ${DBConstants.tableSavingsGoals}(id) ON DELETE CASCADE
      )
    ''');

    // ---------------- Bills & subscriptions ----------------
    batch.execute('''
      CREATE TABLE ${DBConstants.tableBills} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        amount REAL NOT NULL,
        due_date TEXT NOT NULL,
        repeat_rule TEXT,
        status TEXT NOT NULL DEFAULT 'pending', -- paid | pending | overdue
        reminder_enabled INTEGER NOT NULL DEFAULT 1,
        account_id INTEGER,
        notes TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (account_id) REFERENCES ${DBConstants.tableAccounts}(id) ON DELETE SET NULL
      )
    ''');

    batch.execute('''
      CREATE TABLE ${DBConstants.tableSubscriptions} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        amount REAL NOT NULL,
        billing_cycle TEXT NOT NULL, -- weekly | monthly | yearly
        next_payment_date TEXT NOT NULL,
        account_id INTEGER,
        category_id INTEGER,
        reminder_enabled INTEGER NOT NULL DEFAULT 1,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (account_id) REFERENCES ${DBConstants.tableAccounts}(id) ON DELETE SET NULL,
        FOREIGN KEY (category_id) REFERENCES ${DBConstants.tableCategories}(id) ON DELETE SET NULL
      )
    ''');

    // ---------------- Tasks ----------------
    batch.execute('''
      CREATE TABLE ${DBConstants.tableTasks} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        date TEXT NOT NULL,
        time TEXT,
        priority TEXT NOT NULL DEFAULT 'medium', -- low | medium | high
        status TEXT NOT NULL DEFAULT 'pending', -- pending | completed | overdue
        reminder_enabled INTEGER NOT NULL DEFAULT 0,
        repeat_rule TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');
    batch.execute('CREATE INDEX idx_tasks_date ON ${DBConstants.tableTasks}(date)');

    // ---------------- Daily routine ----------------
    batch.execute('''
      CREATE TABLE ${DBConstants.tableRoutineItems} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        activity TEXT NOT NULL,
        time TEXT NOT NULL,
        repeat_days TEXT NOT NULL DEFAULT 'daily', -- daily | csv of weekday ints
        reminder_enabled INTEGER NOT NULL DEFAULT 0,
        notes TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');
    batch.execute('''
      CREATE TABLE ${DBConstants.tableRoutineCompletions} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        routine_item_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        completed INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (routine_item_id) REFERENCES ${DBConstants.tableRoutineItems}(id) ON DELETE CASCADE
      )
    ''');

    // ---------------- Task items ----------------
    // Items nested under a Task (Tasks > tap a task > add items, each
    // with an estimated price — e.g. task "Car Errands" holding items
    // like "New Bumper"). Marking an item done posts a real Expense
    // transaction (see TaskItemRepository); `transaction_id` lets that
    // be reversed if the item is un-marked later.
    batch.execute('''
      CREATE TABLE ${DBConstants.tableTaskItems} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        estimated_price REAL NOT NULL DEFAULT 0,
        actual_price REAL,
        is_done INTEGER NOT NULL DEFAULT 0,
        account_id INTEGER,
        transaction_id INTEGER,
        created_at TEXT NOT NULL,
        FOREIGN KEY (task_id) REFERENCES ${DBConstants.tableTasks}(id) ON DELETE CASCADE
      )
    ''');
    batch.execute('CREATE INDEX idx_task_items_task ON ${DBConstants.tableTaskItems}(task_id)');

    // ---------------- Cheque Book Management ----------------
    // A cheque is purely a pending instrument until it's cashed —
    // creating one never touches an account balance (see
    // ChequeRepository.cashCheque). `parent_cheque_id` links a Sent
    // cheque created by endorsing ("Transfer") a Receive cheque back
    // to the original one it came from.
    batch.execute('''
      CREATE TABLE ${DBConstants.tableCheques} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        direction TEXT NOT NULL, -- receive | sent
        status TEXT NOT NULL DEFAULT 'pending', -- pending | cashed | canceled | transferred
        cheque_number TEXT NOT NULL,
        bank_name TEXT NOT NULL,
        cheque_date TEXT NOT NULL,
        from_account_id INTEGER NOT NULL,
        to_account_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        transaction_id INTEGER,
        parent_cheque_id INTEGER,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (from_account_id) REFERENCES ${DBConstants.tableAccounts}(id) ON DELETE CASCADE,
        FOREIGN KEY (to_account_id) REFERENCES ${DBConstants.tableAccounts}(id) ON DELETE CASCADE,
        FOREIGN KEY (transaction_id) REFERENCES ${DBConstants.tableTransactions}(id) ON DELETE SET NULL,
        FOREIGN KEY (parent_cheque_id) REFERENCES ${DBConstants.tableCheques}(id) ON DELETE SET NULL
      )
    ''');
    batch.execute('CREATE INDEX idx_cheques_direction_status ON ${DBConstants.tableCheques}(direction, status)');

    // A permanent, independent log — kept even if the cheque row it
    // references is ever removed, so "Cheque History" never loses a
    // past action.
    batch.execute('''
      CREATE TABLE ${DBConstants.tableChequeHistory} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cheque_id INTEGER NOT NULL,
        action TEXT NOT NULL, -- cashed | canceled | transferred
        direction TEXT NOT NULL,
        cheque_number TEXT NOT NULL,
        bank_name TEXT NOT NULL,
        cheque_date TEXT NOT NULL,
        from_account_id INTEGER NOT NULL,
        to_account_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        acted_at TEXT NOT NULL
      )
    ''');
    batch.execute('CREATE INDEX idx_cheque_history_cheque ON ${DBConstants.tableChequeHistory}(cheque_id)');

    // ---------------- Ledger parties ----------------
    batch.execute('''
      CREATE TABLE ${DBConstants.tableLedgerParties} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        type TEXT NOT NULL,
        reminder_date TEXT,
        reminder_amount REAL,
        linked_party_id INTEGER,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');
    batch.execute('CREATE INDEX idx_ledger_parties_type ON ${DBConstants.tableLedgerParties}(type)');
    batch.execute('''
      CREATE TABLE ${DBConstants.tableLedgerTransactions} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        party_id INTEGER NOT NULL,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        note TEXT,
        date TEXT NOT NULL,
        created_at TEXT NOT NULL,
        deleted_at TEXT,
        cash_transaction_id INTEGER,
        voice_path TEXT,
        attachment_path TEXT,
        is_system INTEGER NOT NULL DEFAULT 0,
        item_id INTEGER,
        purchase_id INTEGER,
        FOREIGN KEY (party_id) REFERENCES ${DBConstants.tableLedgerParties}(id) ON DELETE CASCADE
      )
    ''');
    batch.execute('CREATE INDEX idx_ledger_transactions_party ON ${DBConstants.tableLedgerTransactions}(party_id)');
    batch.execute('CREATE INDEX idx_ledger_transactions_date ON ${DBConstants.tableLedgerTransactions}(date)');
    batch.execute('CREATE INDEX idx_ledger_transactions_item ON ${DBConstants.tableLedgerTransactions}(item_id)');
    batch.execute('CREATE INDEX idx_ledger_transactions_purchase ON ${DBConstants.tableLedgerTransactions}(purchase_id)');
    batch.execute('''CREATE TABLE ${DBConstants.tablePurchases} (id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL, item_name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT '', supplier_id INTEGER, purchase_type TEXT NOT NULL DEFAULT 'cash', qty REAL NOT NULL DEFAULT 0, unit_cost REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, paid REAL NOT NULL DEFAULT 0, purchase_date TEXT NOT NULL, note TEXT, cash_tx_id INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''');
    batch.execute('CREATE INDEX idx_purchases_item ON ${DBConstants.tablePurchases}(item_id)');
    batch.execute('CREATE INDEX idx_purchases_date ON ${DBConstants.tablePurchases}(purchase_date)');

    batch.execute('''CREATE TABLE ${DBConstants.tablePurchaseInvoices} (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT NOT NULL, supplier_id INTEGER, payment_type TEXT NOT NULL DEFAULT 'cash', subtotal REAL NOT NULL DEFAULT 0, discount_amount REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, paid_amount REAL NOT NULL DEFAULT 0, date TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY (supplier_id) REFERENCES ${DBConstants.tableLedgerParties}(id) ON DELETE SET NULL)''');
    batch.execute('''CREATE TABLE ${DBConstants.tablePurchaseInvoiceItems} (id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_invoice_id INTEGER NOT NULL, item_id INTEGER NOT NULL, item_name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT '', qty REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0, line_discount REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, FOREIGN KEY (purchase_invoice_id) REFERENCES ${DBConstants.tablePurchaseInvoices}(id) ON DELETE CASCADE)''');
    batch.execute('CREATE INDEX idx_purchase_invoice_items_invoice ON ${DBConstants.tablePurchaseInvoiceItems}(purchase_invoice_id)');
    batch.execute('CREATE INDEX idx_purchase_invoices_date ON ${DBConstants.tablePurchaseInvoices}(date)');

    // ---------------- History ----------------
    batch.execute('''
      CREATE TABLE ${DBConstants.tableActivityHistory} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type TEXT NOT NULL,
        entity_id INTEGER,
        action TEXT NOT NULL,
        description TEXT,
        date TEXT NOT NULL
      )
    ''');

    await batch.commit(noResult: true);
    // No default/pre-defined categories are seeded anymore — the user
    // builds their own main categories + sub-categories from scratch
    // (Finance > Categories).
  }
}
