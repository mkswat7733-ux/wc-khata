import 'package:flutter/material.dart';

/// Single global [NavigatorState] key for the whole app — set as
/// `MaterialApp.navigatorKey` in `LifeApp`. Lets [NotificationService]
/// push a new screen the moment a notification is tapped while the
/// app is already running (foreground or backgrounded-but-alive),
/// where there's no [BuildContext] to hand it.
final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

/// Key of RootShell's Scaffold. The sidebar is that Scaffold's drawer, so
/// it slides over the whole screen (including the bottom nav) and follows
/// the finger. Home opens it with `rootScaffoldKey.currentState?.openDrawer()`.
final GlobalKey<ScaffoldState> rootScaffoldKey = GlobalKey<ScaffoldState>();
