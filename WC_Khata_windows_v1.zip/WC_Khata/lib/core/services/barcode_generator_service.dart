import 'package:shared_preferences/shared_preferences.dart';

/// Controls the optional automatic barcode serial generator.
///
/// The next number is stored as text so very large serials are safe. A number
/// is only advanced after an item has been saved successfully.
class BarcodeGeneratorService {
  BarcodeGeneratorService._();
  static final BarcodeGeneratorService instance = BarcodeGeneratorService._();

  static const _enabledKey = 'barcode_generator_enabled';
  static const _nextKey = 'barcode_generator_next_number';
  static const String defaultStartingNumber = '100000';

  Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_enabledKey) ?? false;
  }

  Future<void> setEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_enabledKey, value);
    if (value && !(prefs.getString(_nextKey)?.isNotEmpty ?? false)) {
      await prefs.setString(_nextKey, defaultStartingNumber);
    }
  }

  Future<String> getNextNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_nextKey) ?? defaultStartingNumber;
  }

  Future<bool> setStartingNumber(String value) async {
    final clean = value.trim();
    if (!RegExp(r'^\d+$').hasMatch(clean)) return false;
    final parsed = BigInt.tryParse(clean);
    if (parsed == null || parsed < BigInt.zero) return false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_nextKey, parsed.toString());
    return true;
  }

  /// Advances the sequence after a successfully saved auto-generated code.
  Future<void> advanceAfterSave(String savedCode) async {
    final clean = savedCode.trim();
    final current = BigInt.tryParse(clean);
    if (current == null) return;
    final prefs = await SharedPreferences.getInstance();
    final next = current + BigInt.one;
    await prefs.setString(_nextKey, next.toString());
  }
}
