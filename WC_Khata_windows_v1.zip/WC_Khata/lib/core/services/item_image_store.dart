import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Keeps item pictures in the app's own permanent storage.
///
/// image_picker returns a file in a temporary cache folder that Android
/// clears at any time, so the picture "disappears" the next day. Every
/// picked image is therefore COPIED into `<app documents>/item_images/`
/// and only that permanent path is saved in the database.
class ItemImageStore {
  ItemImageStore._();

  static Directory? _dir;

  /// Call once at startup (main.dart) so [resolve] can be synchronous.
  static Future<void> init() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'item_images'));
    if (!await dir.exists()) await dir.create(recursive: true);
    _dir = dir;
  }

  static Future<Directory> _ensureDir() async {
    if (_dir == null) await init();
    return _dir!;
  }

  /// Copies a picked / captured image into permanent storage and returns the
  /// new absolute path.
  static Future<String> savePicked(String sourcePath) async {
    final dir = await _ensureDir();
    var ext = p.extension(sourcePath).toLowerCase();
    if (ext.isEmpty || ext.length > 5) ext = '.jpg';
    final name = 'item_${DateTime.now().microsecondsSinceEpoch}$ext';
    final dest = File(p.join(dir.path, name));
    await File(sourcePath).copy(dest.path);
    return dest.path;
  }

  /// The file to show for a stored path, or null when there is no picture.
  /// Also finds the file by name if the app folder location changed.
  static File? resolve(String? stored) {
    if (stored == null || stored.isEmpty) return null;
    final direct = File(stored);
    if (direct.existsSync()) return direct;
    final dir = _dir;
    if (dir != null) {
      final byName = File(p.join(dir.path, p.basename(stored)));
      if (byName.existsSync()) return byName;
    }
    return null;
  }

  /// Deletes a picture, but only if it lives in our own folder.
  static Future<void> delete(String? stored) async {
    if (stored == null || stored.isEmpty) return;
    final dir = _dir;
    if (dir == null) return;
    try {
      final file = File(stored);
      if (p.isWithin(dir.path, file.path) && await file.exists()) {
        await file.delete();
      }
    } catch (_) {}
  }
}
