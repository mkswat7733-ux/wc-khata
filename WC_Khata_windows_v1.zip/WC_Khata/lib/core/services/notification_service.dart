import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../../app/launch_gate.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/utils/currency_formatter.dart';
import '../../data/models/bill_model.dart';
import '../../data/models/subscription_model.dart';
import '../../data/repositories/bill_repository.dart';
import '../../data/repositories/subscription_repository.dart';
import '../../features/ledger/ledger_party.dart';
import '../../features/ledger/ledger_repository.dart';
import '../../features/items/item_repository.dart';
import 'app_navigator.dart';
import 'pending_notification.dart';

/// Local, offline due-date reminders for Bills and Subscriptions.
///
/// Every reminder is scheduled through Android's own alarm scheduler
/// (`zonedSchedule`, backed by `AlarmManager`) — never a Dart `Timer`
/// or anything that depends on the app process staying alive — so a
/// reminder still fires as a normal tray notification while the app
/// is backgrounded or fully closed, and survives a device reboot (see
/// the boot receiver declared in AndroidManifest.xml). Nothing here
/// talks to a server: no Firebase, no push token, no network call.
///
/// [BillRepository] and [SubscriptionRepository] call
/// [scheduleBillNotification]/[scheduleSubscriptionNotification] (and
/// their `cancel*` counterparts) directly from `create`/`update`/
/// `delete`, so every place in the app that adds, edits, pays, or
/// removes a bill or subscription automatically keeps its reminder in
/// sync — there's nothing for any individual screen to remember to do.
///
/// Tapping the resulting notification — whether the app was closed,
/// backgrounded, or already open — always lands on the in-app
/// Notifications screen, going through the password Unlock screen
/// first if one is set (see [PendingNotification], [LaunchGate]).
class NotificationService {
  NotificationService._internal();
  static final NotificationService instance = NotificationService._internal();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  static const _channelId = 'bills_subscriptions';
  static const _channelName = 'Bills & Subscriptions';
  static const _channelDescription = 'Reminders for upcoming bills, subscriptions and customer payments';
  static const _ledgerChannelId = 'ledger_reminders';
  static const _ledgerChannelName = 'Payment Reminders';
  static const _ledgerChannelDescription = 'Customer and supplier payment reminders';

  // Keeps Android notification IDs (32-bit ints) for bills and
  // subscriptions from ever colliding with each other or with any
  // other notification the app might show in future.
  static const _billIdOffset = 100000;
  static const _subscriptionIdOffset = 500000;
  static const _ledgerReminderIdOffset = 900000;
  static const _lowStockIdOffset = 1300000;
  static const _lowStockChannelId = 'low_stock';
  static const _lastViewedKey = 'notifications_last_viewed_at';
  static const _lowStockUnreadKey = 'notifications_low_stock_unread_ids';

  bool _initialized = false;

  /// Sets up the plugin, the notification channel, and device
  /// permissions. Safe to call once at app startup, before `runApp`.
  Future<void> initialize() async {
    if (_initialized) return;

    tz_data.initializeTimeZones();
    try {
      final localTimezone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(localTimezone.identifier));
    } catch (_) {
      // Falls back to whatever default `timezone` already has if the
      // device's IANA zone name can't be resolved — reminders still
      // fire, just on the fallback zone until this succeeds later.
    }

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);

    await _plugin.initialize(
      settings: initSettings,
      onDidReceiveNotificationResponse: _onTap,
    );

    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(const AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: _channelDescription,
      importance: Importance.high,
      showBadge: true,
    ));
    await android?.createNotificationChannel(const AndroidNotificationChannel(
      _ledgerChannelId,
      _ledgerChannelName,
      description: _ledgerChannelDescription,
      importance: Importance.high,
      showBadge: true,
    ));
    // Android 13+ requires this explicit runtime request even though
    // the permission is also declared in AndroidManifest.xml.
    await android?.requestNotificationsPermission();

    // Cold start via a notification tap (app wasn't running at all) —
    // stash the payload now so the Splash → LaunchGate flow can route
    // to it once it knows whether a password needs entering first.
    final launchDetails = await _plugin.getNotificationAppLaunchDetails();
    if (launchDetails?.didNotificationLaunchApp ?? false) {
      PendingNotification.set(launchDetails?.notificationResponse?.payload);
    }

    _initialized = true;
  }

  /// Re-schedules every unpaid bill's and active subscription's
  /// reminder. Cheap (a handful of rows at most) and idempotent — call
  /// once after startup so reminders stay correct even if the device
  /// was reset, the app data was restored, or entries were edited
  /// through some path that predates this sync.
  Future<void> resyncAll() async {
    final bills = await BillRepository().getAll();
    for (final bill in bills) {
      await scheduleBillNotification(bill);
    }
    final subscriptions = await SubscriptionRepository().getAll();
    for (final sub in subscriptions) {
      await scheduleSubscriptionNotification(sub);
    }
    final parties = await LedgerRepository().getParties();
    for (final party in parties) {
      await scheduleLedgerReminder(party);
    }
  }

  void _onTap(NotificationResponse response) {
    final payload = response.payload;
    if (payload == null) return;
    // The app is already running (foreground, or backgrounded but the
    // process is alive) — route right now via the global navigator.
    // Always go through the same LaunchGate password check used on a
    // fresh launch, so a set password is never bypassed just because
    // the app happened to still be in memory.
    PendingNotification.set(payload);
    appNavigatorKey.currentState?.pushAndRemoveUntil(
      AppTransitions.seamless(const LaunchGate()),
      (route) => false,
    );
  }

  // ---------------- Bills ----------------

  int _billNotificationId(int billId) => _billIdOffset + billId;

  /// Schedules (or re-schedules) the one reminder for [bill], always
  /// cancelling any previous one first — so calling this after an
  /// edit, a reminder-toggle, or a due-date change never leaves a
  /// stale notification behind. Fires at 9:00 AM local time on the
  /// bill's due date; does nothing if the reminder is turned off,
  /// there's no id yet, or that time has already passed.
  Future<void> scheduleBillNotification(BillModel bill) async {
    final id = bill.id;
    if (id == null) return;
    await cancelBillNotification(id);
    if (!bill.reminderEnabled) return;

    final due = bill.dueDate;
    final fireAt = DateTime(due.year, due.month, due.day, 9, 0);
    if (fireAt.isBefore(DateTime.now())) return;

    await _schedule(
      id: _billNotificationId(id),
      title: 'Bill Due: ${bill.name}',
      body: 'Your bill of ${CurrencyFormatter.format(bill.amount)} is due today.',
      dateTime: fireAt,
      payload: 'bill:$id',
    );
  }

  Future<void> cancelBillNotification(int billId) => _plugin.cancel(id: _billNotificationId(billId));

  // ---------------- Subscriptions ----------------

  int _subscriptionNotificationId(int subId) => _subscriptionIdOffset + subId;

  /// Same idea as [scheduleBillNotification], for a subscription's
  /// next payment date.
  Future<void> scheduleSubscriptionNotification(SubscriptionModel sub) async {
    final id = sub.id;
    if (id == null) return;
    await cancelSubscriptionNotification(id);
    if (!sub.reminderEnabled || !sub.isActive) return;

    final due = sub.nextPaymentDate;
    final fireAt = DateTime(due.year, due.month, due.day, 9, 0);
    if (fireAt.isBefore(DateTime.now())) return;

    await _schedule(
      id: _subscriptionNotificationId(id),
      title: 'Subscription Due: ${sub.name}',
      body: 'Your subscription payment of ${CurrencyFormatter.format(sub.amount)} is due today.',
      dateTime: fireAt,
      payload: 'subscription:$id',
    );
  }

  Future<void> cancelSubscriptionNotification(int subId) => _plugin.cancel(id: _subscriptionNotificationId(subId));


  // ---------------- Ledger payment reminders ----------------

  int _ledgerReminderNotificationId(int partyId) => _ledgerReminderIdOffset + partyId;

  Future<void> scheduleLedgerReminder(LedgerParty party) async {
    final id = party.id;
    if (id == null) return;
    await cancelLedgerReminder(id);
    final reminderDate = party.reminderDate;
    final amount = party.reminderAmount;
    if (reminderDate == null || amount == null || amount <= 0 || !party.isReceivable) return;

    final fireAt = DateTime(reminderDate.year, reminderDate.month, reminderDate.day, 9, 0);
    if (fireAt.isBefore(DateTime.now())) return;

    await _plugin.zonedSchedule(
      id: _ledgerReminderNotificationId(id),
      title: 'Payment Reminder',
      body: '${party.name} has ${CurrencyFormatter.formatCompact(amount)} pending.',
      scheduledDate: tz.TZDateTime.from(fireAt, tz.local),
      notificationDetails: const NotificationDetails(
        android: AndroidNotificationDetails(
          _ledgerChannelId,
          _ledgerChannelName,
          channelDescription: _ledgerChannelDescription,
          importance: Importance.high,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      payload: 'ledger_party:$id',
    );
  }

  Future<void> cancelLedgerReminder(int partyId) =>
      _plugin.cancel(id: _ledgerReminderNotificationId(partyId));

  /// Number of notification events that have arrived since the user last
  /// opened the Notifications screen. The read timestamp is persistent, so
  /// returning to Home never makes an already-read reminder badge reappear.
  Future<int> getUnreadCount() async {
    final prefs = await SharedPreferences.getInstance();
    final viewedRaw = prefs.getInt(_lastViewedKey);
    final viewedAt = viewedRaw == null ? null : DateTime.fromMillisecondsSinceEpoch(viewedRaw);
    final now = DateTime.now();
    var count = 0;

    final bills = await BillRepository().getAll();
    for (final bill in bills) {
      if (bill.id == null || bill.status == 'paid' || !bill.reminderEnabled) continue;
      final fireAt = DateTime(bill.dueDate.year, bill.dueDate.month, bill.dueDate.day, 9);
      if (!fireAt.isAfter(now) && (viewedAt == null || fireAt.isAfter(viewedAt))) count++;
    }

    final subs = await SubscriptionRepository().getAll();
    for (final sub in subs) {
      if (sub.id == null || !sub.isActive || !sub.reminderEnabled) continue;
      final fireAt = DateTime(sub.nextPaymentDate.year, sub.nextPaymentDate.month, sub.nextPaymentDate.day, 9);
      if (!fireAt.isAfter(now) && (viewedAt == null || fireAt.isAfter(viewedAt))) count++;
    }

    final parties = await LedgerRepository().getParties();
    for (final party in parties) {
      final date = party.reminderDate;
      if (!party.isReceivable || date == null || (party.reminderAmount ?? party.balance.abs()) <= 0) continue;
      final fireAt = DateTime(date.year, date.month, date.day, 9);
      if (!fireAt.isAfter(now) && (viewedAt == null || fireAt.isAfter(viewedAt))) count++;
    }

    count += (prefs.getStringList(_lowStockUnreadKey) ?? const <String>[]).length;
    return count;
  }

  /// Compatibility helper used by older callers.
  Future<int> getDueLedgerReminderCount() => getUnreadCount();

  Future<void> markNotificationsViewed() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_lastViewedKey, DateTime.now().millisecondsSinceEpoch);
    final lowIds = prefs.getStringList(_lowStockUnreadKey) ?? const <String>[];
    for (final raw in lowIds) {
      final id = int.tryParse(raw);
      if (id != null) await _plugin.cancel(id: _lowStockIdOffset + id);
    }
    await prefs.remove(_lowStockUnreadKey);

    // Opening the in-app notification center is the explicit read action.
    // Clear already-due tray notifications too, so Android's launcher/channel
    // badge cannot remain visible after the user has read them in-app.
    final now = DateTime.now();
    final bills = await BillRepository().getAll();
    for (final bill in bills) {
      if (bill.id == null || bill.status == 'paid' || !bill.reminderEnabled) continue;
      final fireAt = DateTime(bill.dueDate.year, bill.dueDate.month, bill.dueDate.day, 9);
      if (!fireAt.isAfter(now)) await cancelBillNotification(bill.id!);
    }
    final subs = await SubscriptionRepository().getAll();
    for (final sub in subs) {
      if (sub.id == null || !sub.isActive || !sub.reminderEnabled) continue;
      final fireAt = DateTime(sub.nextPaymentDate.year, sub.nextPaymentDate.month, sub.nextPaymentDate.day, 9);
      if (!fireAt.isAfter(now)) await cancelSubscriptionNotification(sub.id!);
    }
    final parties = await LedgerRepository().getParties();
    for (final party in parties) {
      final date = party.reminderDate;
      if (party.id == null || !party.isReceivable || date == null) continue;
      final fireAt = DateTime(date.year, date.month, date.day, 9);
      if (!fireAt.isAfter(now)) await cancelLedgerReminder(party.id!);
    }
  }

  Future<void> _markLowStockUnread(int itemId) async {
    final prefs = await SharedPreferences.getInstance();
    final ids = <String>{...(prefs.getStringList(_lowStockUnreadKey) ?? const <String>[])};
    ids.add('$itemId');
    await prefs.setStringList(_lowStockUnreadKey, ids.toList());
  }

  Future<void> _clearLowStockUnread(int itemId) async {
    final prefs = await SharedPreferences.getInstance();
    final ids = <String>{...(prefs.getStringList(_lowStockUnreadKey) ?? const <String>[])};
    ids.remove('$itemId');
    if (ids.isEmpty) {
      await prefs.remove(_lowStockUnreadKey);
    } else {
      await prefs.setStringList(_lowStockUnreadKey, ids.toList());
    }
  }

  Future<void> cancelLowStock(int itemId) async {
    await _plugin.cancel(id: _lowStockIdOffset + itemId);
    await _clearLowStockUnread(itemId);
  }

  Future<void> notifyLowStock({required int itemId, required String itemName, required double qty, required double threshold, required String unit}) async {
    if (!_initialized) return;
    await _markLowStockUnread(itemId);
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(const AndroidNotificationChannel(_lowStockChannelId, 'Low Stock Alerts', description: 'Notifications when product stock is low', importance: Importance.high, showBadge: true));
    await _plugin.show(
      id: _lowStockIdOffset + itemId,
      title: 'Low Stock Alert',
      body: '$itemName is low: ${qty.toStringAsFixed(qty.truncateToDouble() == qty ? 0 : 2)} $unit remaining (alert at ${threshold.toStringAsFixed(threshold.truncateToDouble() == threshold ? 0 : 2)}).',
      notificationDetails: const NotificationDetails(android: AndroidNotificationDetails(_lowStockChannelId, 'Low Stock Alerts', channelDescription: 'Notifications when product stock is low', importance: Importance.high, priority: Priority.high, playSound: true, enableVibration: true)),
      payload: 'item:$itemId',
    );
  }

  /// Keeps the Android low-stock notification in sync after a sale or item
  /// edit. It never creates a new unread event merely because the app was
  /// opened again; a new unread event is created only when stock actually
  /// crosses/updates the alert through a user action.
  Future<void> syncLowStockForItem(ItemRecord item, {bool createEvent = false}) async {
    if (item.lowStock > 0 && item.qty <= item.lowStock) {
      if (createEvent) {
        await notifyLowStock(itemId: item.id, itemName: item.name, qty: item.qty, threshold: item.lowStock, unit: item.unit);
      }
    } else {
      await cancelLowStock(item.id);
    }
  }

  Future<void> resyncLowStockAlerts() async {
    final items = await ItemRepository().getItems();
    for (final item in items) {
      if (item.lowStock <= 0 || item.qty > item.lowStock) {
        await cancelLowStock(item.id);
      }
    }
  }

  // ---------------- Shared scheduling ----------------

  Future<void> _schedule({
    required int id,
    required String title,
    required String body,
    required DateTime dateTime,
    required String payload,
  }) async {
    await _plugin.zonedSchedule(
      id: id,
      title: title,
      body: body,
      scheduledDate: tz.TZDateTime.from(dateTime, tz.local),
      notificationDetails: const NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: _channelDescription,
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      // Fires within a short window even in Doze/idle rather than to
      // the exact minute — deliberately avoids needing the separate
      // SCHEDULE_EXACT_ALARM/"Alarms & reminders" permission, which
      // isn't worth the extra system prompt for a bill/subscription
      // reminder (unlike, say, an alarm clock app).
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      payload: payload,
    );
  }
}
