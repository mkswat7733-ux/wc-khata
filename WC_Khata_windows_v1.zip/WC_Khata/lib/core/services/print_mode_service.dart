import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Settings > "Use External Print Service".
///
///  - OFF (default): the app prints by itself through its own Bluetooth
///    thermal printer system. Nothing changes from before.
///  - ON: the app's own printing system is disabled. Every Print button hands
///    the document to Android's print framework, so the user prints through
///    another print service / app installed on the phone.
class PrintModeService extends ChangeNotifier {
  PrintModeService._();
  static final PrintModeService instance = PrintModeService._();

  static const String _key = 'use_external_print_service';

  bool _external = false;
  bool _loaded = false;

  /// True when printing must go through an external print service.
  bool get external => _external;

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      _external = prefs.getBool(_key) ?? false;
    } catch (_) {}
    notifyListeners();
  }

  Future<void> setExternal(bool value) async {
    _loaded = true;
    _external = value;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_key, value);
    } catch (_) {}
  }
}

/// Sends documents to the Android system print dialog (where the user's own
/// print service is selected). Used only when [PrintModeService.external].
class ExternalPrint {
  ExternalPrint._();

  /// A PNG (e.g. a captured receipt) as a page exactly [paperMm] wide.
  static Future<void> png(Uint8List png, {required int paperMm, String name = 'Receipt'}) async {
    final image = pw.MemoryImage(png);
    final widthPt = paperMm * PdfPageFormat.mm;
    final heightPt = widthPt * image.height! / image.width!;
    final format = PdfPageFormat(widthPt, heightPt, marginAll: 0);
    final doc = pw.Document();
    doc.addPage(
      pw.Page(
        pageFormat: format,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(image, fit: pw.BoxFit.fill),
      ),
    );
    final bytes = await doc.save();
    await Printing.layoutPdf(name: name, format: format, onLayout: (_) async => bytes);
  }

  /// A ready PDF (reports, invoices, cards...).
  static Future<void> pdf(Uint8List pdf, {int? paperMm, String name = 'Document'}) async {
    final format = paperMm == null ? PdfPageFormat.a4 : PdfPageFormat(paperMm * PdfPageFormat.mm, 297 * PdfPageFormat.mm, marginAll: 0);
    await Printing.layoutPdf(name: name, format: format, onLayout: (_) async => pdf);
  }

  /// A label PDF with its exact label size.
  static Future<void> label(Uint8List pdf, {required double widthMm, required double heightMm, String name = 'Label'}) async {
    final format = PdfPageFormat(widthMm * PdfPageFormat.mm, heightMm * PdfPageFormat.mm, marginAll: 0);
    await Printing.layoutPdf(name: name, format: format, onLayout: (_) async => pdf);
  }
}
