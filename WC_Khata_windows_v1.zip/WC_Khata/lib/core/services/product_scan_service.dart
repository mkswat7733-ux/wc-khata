import 'dart:math' as math;

import '../../features/items/item_repository.dart';
import '../database/app_database.dart';
import '../database/database_constants.dart';
import 'item_image_store.dart';
import 'product_text_reader.dart';

/// One possible product for a scanned picture.
class ScanMatch {
  final ItemRecord item;
  final double score; // 0..1
  final int matchedWords;
  final double matchedWeight;
  const ScanMatch(this.item, this.score, this.matchedWords, this.matchedWeight);
}

class ScanResult {
  /// Best matches first (at most 3).
  final List<ScanMatch> ranked;

  /// True when the best match is clear enough to add without asking.
  final bool confident;

  /// The words seen in the camera picture (used to teach the app).
  final Set<String> words;

  const ScanResult(this.ranked, this.confident, this.words);
}

/// Recognises a product from a camera picture, like a barcode.
///
/// Every product keeps the words printed on its picture (`items.scan_text`,
/// read once when the picture is added) plus its name. A scanned picture is
/// read the same way and compared word by word: rare words (the brand, the
/// flavour) count more than common ones. When the app is unsure it asks the
/// user, and the answer is learned so the next scan is automatic.
class ProductScanService {
  ProductScanService._();
  static final ProductScanService instance = ProductScanService._();

  static const int _maxWordsPerProduct = 300;

  static const Set<String> _stop = {
    'the', 'and', 'for', 'with', 'from', 'net', 'ltd', 'pvt', 'limited', 'made', 'best', 'before',
    'use', 'store', 'keep', 'cool', 'dry', 'place', 'mfg', 'exp', 'date', 'batch', 'ingredients',
    'contains', 'product', 'products', 'food', 'pakistan', 'weight', 'free', 'new', 'pack',
    'each', 'per', 'only', 'not', 'are', 'you', 'your', 'this', 'that', 'out', 'all',
  };

  /// Lower-case words of 3+ letters; numbers, short bits and filler are dropped.
  static Set<String> tokenize(String text) {
    final out = <String>{};
    for (final w in text.toLowerCase().split(RegExp(r'[^a-z0-9]+'))) {
      if (w.length < 3) continue;
      if (!RegExp(r'[a-z]').hasMatch(w)) continue;
      final digits = RegExp(r'[0-9]').allMatches(w).length;
      if (digits > 0 && digits / w.length > .4) continue;
      if (_stop.contains(w)) continue;
      out.add(w);
    }
    return out;
  }

  // ----------------------------------------------------------- storage

  Future<Map<int, Set<String>>> _loadAll() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query(DBConstants.tableItems, columns: const ['id', 'scan_text']);
    return {
      for (final r in rows)
        r['id'] as int: ((r['scan_text'] as String?) ?? '').split(' ').where((e) => e.isNotEmpty).toSet(),
    };
  }

  Future<void> _write(int id, Set<String> words) async {
    final db = await AppDatabase.instance.database;
    final list = words.toList();
    if (list.length > _maxWordsPerProduct) list.removeRange(_maxWordsPerProduct, list.length);
    await db.update(DBConstants.tableItems, {'scan_text': list.join(' ')}, where: 'id = ?', whereArgs: [id]);
  }

  /// Saves the words read from a product's picture (replaces the old ones).
  /// An empty text is stored too, so the picture is not read again.
  Future<void> saveText(int itemId, String rawText) async {
    try {
      await _write(itemId, tokenize(rawText));
    } catch (_) {}
  }

  /// Adds the words of a scanned picture to a product the user confirmed.
  Future<void> learn(int itemId, Set<String> words) async {
    if (words.isEmpty) return;
    try {
      final all = await _loadAll();
      final merged = {...?all[itemId], ...words};
      await _write(itemId, merged);
    } catch (_) {}
  }

  /// Reads the picture of every product that has one but has not been read
  /// yet (products added before picture scanning existed). Returns how many
  /// were read. [shouldStop] lets the caller cancel (screen closed).
  Future<int> indexMissing(
    List<ItemRecord> items, {
    void Function(int done, int total)? onProgress,
    bool Function()? shouldStop,
  }) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      DBConstants.tableItems,
      columns: const ['id'],
      where: "scan_text IS NULL AND image_path IS NOT NULL AND image_path != ''",
    );
    final pending = {for (final r in rows) r['id'] as int};
    final todo = items.where((i) => pending.contains(i.id)).toList();
    var done = 0;
    for (final item in todo) {
      if (shouldStop?.call() ?? false) break;
      final file = ItemImageStore.resolve(item.imagePath);
      if (file != null && await file.exists()) {
        try {
          final text = await ProductTextReader.readFullText(file.path);
          await saveText(item.id, text);
        } catch (_) {
          await saveText(item.id, '');
        }
      } else {
        await saveText(item.id, '');
      }
      done++;
      onProgress?.call(done, todo.length);
    }
    return done;
  }

  // ---------------------------------------------------------- matching

  static bool _near(String a, String b) {
    if (a == b) return true;
    if (a.length < 5 || b.length < 5) return false;
    if ((a.length - b.length).abs() > 1) return false;
    // Edit distance <= 1 (one OCR slip such as o/0 or a missing letter).
    final longer = a.length >= b.length ? a : b;
    final shorter = a.length >= b.length ? b : a;
    var i = 0, j = 0, edits = 0;
    while (i < longer.length && j < shorter.length) {
      if (longer[i] == shorter[j]) {
        i++;
        j++;
      } else {
        edits++;
        if (edits > 1) return false;
        if (longer.length == shorter.length) {
          i++;
          j++;
        } else {
          i++;
        }
      }
    }
    return edits + (longer.length - i) + (shorter.length - j) <= 1;
  }

  Future<ScanResult> match(String rawText, List<ItemRecord> items) async {
    final query = tokenize(rawText);
    if (query.isEmpty || items.isEmpty) return ScanResult(const [], false, query);

    final stored = await _loadAll();
    // Each product: its name words (counted double) + words from its picture.
    final docs = <int, Set<String>>{};
    final nameWords = <int, Set<String>>{};
    for (final it in items) {
      final n = tokenize(it.name);
      nameWords[it.id] = n;
      docs[it.id] = {...n, ...?stored[it.id]};
    }

    // How rare each word is across the shop's products.
    final df = <String, int>{};
    for (final d in docs.values) {
      for (final w in d) {
        df[w] = (df[w] ?? 0) + 1;
      }
    }
    final n = items.length;
    double weight(String w) => math.log(1 + n / (df[w] ?? 1));

    // Query words that exist somewhere in the product vocabulary.
    final vocab = df.keys.toList();
    final known = <String, String>{}; // query word -> vocabulary word
    for (final q in query) {
      if (df.containsKey(q)) {
        known[q] = q;
        continue;
      }
      for (final v in vocab) {
        if (_near(q, v)) {
          known[q] = v;
          break;
        }
      }
    }
    if (known.isEmpty) return ScanResult(const [], false, query);
    final qWeight = known.values.fold<double>(0, (a, w) => a + weight(w));

    final scored = <ScanMatch>[];
    for (final it in items) {
      final doc = docs[it.id]!;
      if (doc.isEmpty) continue;
      var matchedW = 0.0;
      var count = 0;
      final matchedVocab = <String>{};
      for (final v in known.values) {
        if (doc.contains(v)) {
          var w = weight(v);
          if (nameWords[it.id]!.contains(v)) w *= 1.5; // a word of the name is strong proof
          matchedW += w;
          count++;
          matchedVocab.add(v);
        }
      }
      if (count == 0) continue;

      // Coverage: how much of the product's strongest words were seen.
      final top = doc.toList()..sort((a, b) => weight(b).compareTo(weight(a)));
      final topWords = top.take(10).toList();
      final topW = topWords.fold<double>(0, (a, w) => a + weight(w));
      final seenTopW = topWords.where(matchedVocab.contains).fold<double>(0, (a, w) => a + weight(w));
      final precision = qWeight > 0 ? math.min(1.0, matchedW / qWeight) : 0.0;
      final coverage = topW > 0 ? seenTopW / topW : 0.0;
      scored.add(ScanMatch(it, 0.65 * precision + 0.35 * coverage, count, matchedW));
    }
    if (scored.isEmpty) return ScanResult(const [], false, query);

    scored.sort((a, b) => b.score.compareTo(a.score));
    final ranked = scored.take(3).toList();
    final best = ranked.first;
    final second = ranked.length > 1 ? ranked[1].score : 0.0;
    final strong = best.matchedWords >= 2 || best.matchedWeight >= 2.0;
    final confident = strong && best.score >= .5 && (best.score - second) >= .15;
    return ScanResult(ranked, confident, query);
  }
}
