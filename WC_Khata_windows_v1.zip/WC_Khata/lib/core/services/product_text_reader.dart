import 'dart:ui' show Rect;

import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// Reads the text printed on a product picture (on the phone, no internet)
/// and picks the most likely product name from it.
///
/// The product name is normally the biggest text on the pack, so the lines
/// with the largest letters win; barcodes, prices, dates and web addresses are
/// skipped. English / Latin letters only.
class ProductTextReader {
  ProductTextReader._();

  static final RegExp _junk = RegExp(
    r'(www\.|\.com|\.pk|http|@|\bmfg\b|\bexp\b|\bbatch\b|\bprice\b|\brs\.?\s*\d|\bnet\s*(wt|weight)\b|\bbarcode\b|\bmrp\b|\bmade in\b|\bcontact\b|\bcall\b)',
    caseSensitive: false,
  );

  /// Returns a product name, or null when no usable text was found.
  static Future<String?> readName(String imagePath) async => (await readBoth(imagePath)).name;

  /// One pass over the picture: the likely product name AND all the text on it
  /// (the text is what picture scanning later recognises the product by).
  static Future<({String? name, String text})> readBoth(String imagePath) async {
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final result = await recognizer.processImage(InputImage.fromFilePath(imagePath));
      return (name: _pickName(result), text: result.text);
    } finally {
      await recognizer.close();
    }
  }

  /// All the text on a picture (used when a product is scanned).
  static Future<String> readFullText(String imagePath) async => (await readBoth(imagePath)).text;

  static String? _pickName(RecognizedText result) {
    final lines = <_Line>[];
    for (final block in result.blocks) {
      for (final line in block.lines) {
        final text = _clean(line.text);
        if (text == null) continue;
        lines.add(_Line(text, line.boundingBox));
      }
    }
    if (lines.isEmpty) return null;

    final tallest = lines.map((l) => l.box.height).reduce((a, b) => a > b ? a : b);
    final big = lines.where((l) => l.box.height >= tallest * .72).toList()..sort((a, b) => a.box.top.compareTo(b.box.top));
    final anchor = big.indexWhere((l) => l.box.height == tallest);
    if (anchor < 0) return null;

    // The biggest line plus its neighbours of similar size (brand + name).
    var from = anchor;
    var to = anchor;
    final gap = tallest * 1.8;
    while (from > 0 && big[from].box.top - big[from - 1].box.bottom <= gap && to - from < 2) {
      from--;
    }
    while (to < big.length - 1 && big[to + 1].box.top - big[to].box.bottom <= gap && to - from < 2) {
      to++;
    }
    var name = big.sublist(from, to + 1).map((l) => l.text).join(' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (name.length > 60) name = name.substring(0, 60).trim();
    if (name.length < 2) return null;
    return _tidyCase(name);
  }

  /// Keeps letters, digits and a few name characters; drops lines that are
  /// mostly numbers or look like addresses, prices or dates.
  static String? _clean(String raw) {
    final t = raw.replaceAll(RegExp(r"[^A-Za-z0-9 &'\-\.]"), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    final letters = RegExp(r'[A-Za-z]').allMatches(t).length;
    if (letters < 3) return null;
    final digits = RegExp(r'[0-9]').allMatches(t).length;
    if (digits / t.length > .4) return null;
    if (_junk.hasMatch(t)) return null;
    return t;
  }

  /// "COCA COLA" -> "Coca Cola". Mixed-case text is left as printed.
  static String _tidyCase(String s) {
    if (s != s.toUpperCase()) return s;
    return s.splitMapJoin(
      RegExp(r'[ \-]'),
      onMatch: (m) => m[0]!,
      onNonMatch: (w) => w.isEmpty ? w : w[0] + w.substring(1).toLowerCase(),
    );
  }
}

class _Line {
  final String text;
  final Rect box;
  const _Line(this.text, this.box);
}
