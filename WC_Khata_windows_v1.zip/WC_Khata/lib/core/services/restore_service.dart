import 'dart:convert';
import 'dart:io';
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../database/database_constants.dart';
import '../database/database_migrations.dart';
import 'backup_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../features/items/item_repository.dart';
import 'unit_repository.dart';

class RestoreValidationException implements Exception {
  final String message;
  RestoreValidationException(this.message);
  @override
  String toString() => message;
}

/// Restores a backup created by BackupService. Runs inside a single
/// SQLite transaction so a corrupt/partial file can never leave the
/// database half-restored — either everything applies or nothing does.
class RestoreService {
  Future<void> restoreFromFile(File file) async {
    final raw = await file.readAsString();
    await restoreFromJson(raw);
  }

  Future<void> restoreFromJson(String raw) async {
    late Map<String, dynamic> parsed;
    try {
      parsed = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      throw RestoreValidationException('This backup is not valid JSON.');
    }

    // Keep support for older backups that used the previous
    // internal app identifier.
    final app = parsed['app'];
    if ((app != 'wc_khata' && app != 'smart_khata_pro' && app != 'ijaz_accounts' && app != 'lifeapp') || parsed['tables'] is! Map) {
      throw RestoreValidationException('This file was not created by WC Khata.');
    }

    final tables = (parsed['tables'] as Map).cast<String, dynamic>();
    final db = await AppDatabase.instance.database;

    // Format 4+ stores only user-made categories/units (built-ins are
    // rebuilt by the app). Older backups stored every row, so they are
    // restored exactly as they were.
    final version = (parsed['backup_version'] as num?)?.toInt() ?? 0;
    final newFormat = version >= 4;
    final removedRaw = parsed['defaults_removed'];
    final removed = <String, Set<String>>{};
    if (removedRaw is Map) {
      for (final e in removedRaw.entries) {
        if (e.value is List) {
          removed[e.key.toString()] = {for (final n in (e.value as List)) n.toString().trim().toLowerCase()};
        }
      }
    }

    await db.transaction((txn) async {
      // Let SQLite check foreign keys at commit time instead of per row.
      await txn.execute('PRAGMA defer_foreign_keys = ON');

      // Only known app tables are touched (a file can never wipe or write
      // any other table). Tables missing from an older backup are left as is.
      final restorable = BackupService.tables.where((t) => tables[t] is List).toList();

      // 1) Delete children first (reverse of the parents-first order).
      for (final table in restorable.reversed) {
        await txn.delete(table);
      }

      // 2) Insert parents first, using only columns that exist in this
      //    version of the database so backups from other versions still load.
      for (final table in restorable) {
        final info = await txn.rawQuery('PRAGMA table_info($table)');
        final columns = info.map((r) => r['name'] as String).toSet();
        final isCat = table == DBConstants.tableItemCategories;
        final isUnit = table == DBConstants.tableItemUnits;

        // New format: first put back the built-ins the user still had.
        if (newFormat && (isCat || isUnit)) {
          final now = DateTime.now().toIso8601String();
          final skip = removed[table] ?? const <String>{};
          final builtIns = isCat ? ItemRepository.builtInCategories : UnitRepository.builtInUnits;
          for (final name in builtIns) {
            if (skip.contains(name.toLowerCase())) continue;
            await txn.insert(table, {'name': name, 'created_at': now}, conflictAlgorithm: ConflictAlgorithm.ignore);
          }
        }

        // Products: re-link the category by NAME (ids change after reinstall).
        Map<String, int>? catIdByName;
        if (newFormat && table == DBConstants.tableItems) {
          final cats = await txn.query(DBConstants.tableItemCategories);
          catIdByName = {for (final c in cats) (c['name'] as String).trim().toLowerCase(): c['id'] as int};
        }

        for (final row in (tables[table] as List)) {
          if (row is! Map) continue;
          final clean = <String, Object?>{
            for (final e in row.entries)
              if (columns.contains(e.key.toString())) e.key.toString(): e.value,
          };
          if (clean.isEmpty) continue;

          if (newFormat && (isCat || isUnit)) {
            // User-made rows get fresh ids so they never clash with built-ins.
            clean.remove('id');
            await txn.insert(table, clean, conflictAlgorithm: ConflictAlgorithm.ignore);
            continue;
          }
          if (catIdByName != null) {
            final name = row['category_name']?.toString().trim().toLowerCase();
            clean['category_id'] = (name == null || name.isEmpty) ? null : catIdByName[name];
          }
          await txn.insert(table, clean, conflictAlgorithm: ConflictAlgorithm.replace);
        }
      }

      // Older backups have no purchase records: rebuild them from the
      // purchase each product carried.
      if (tables[DBConstants.tablePurchases] is! List) {
        await txn.delete(DBConstants.tablePurchases);
        await DatabaseMigrations.backfillPurchases(txn);
      }
    });

    // The lists are now complete, so the app must not seed its starter
    // list again (that would bring back anything the user had deleted).
    try {
      final prefs = await SharedPreferences.getInstance();
      if (tables[DBConstants.tableItemCategories] is List) await prefs.setBool(ItemRepository.categoriesSeededKey, true);
      if (tables[DBConstants.tableItemUnits] is List) await prefs.setBool(UnitRepository.unitsSeededKey, true);
    } catch (_) {}
  }
}
