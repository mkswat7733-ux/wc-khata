import 'package:shared_preferences/shared_preferences.dart';

/// Persists scanner behavior preferences. Auto-close is enabled by default.
class ScannerSettingsService {
  ScannerSettingsService._();
  static final ScannerSettingsService instance = ScannerSettingsService._();

  static const String _autoCloseKey = 'scanner_auto_close';

  Future<bool> getAutoClose() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_autoCloseKey) ?? true;
  }

  Future<void> setAutoClose(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_autoCloseKey, value);
  }
}
