import 'dart:async';
import 'package:audioplayers/audioplayers.dart';

/// Instant scan feedback.
///
/// Both sounds live in dedicated players running in [PlayerMode.lowLatency]
/// (Android SoundPool) and are fully PRE-LOADED by [warmUp]. Playing is then
/// just "stop + resume" on an already-decoded sound, so the beep fires the
/// same moment the barcode is detected instead of re-loading the mp3 on
/// every scan (which was the cause of the delay).
class ScannerSoundService {
  ScannerSoundService._();
  static final ScannerSoundService instance = ScannerSoundService._();

  static const _successAsset = 'sounds/barcodesound.mp3';
  static const _errorAsset = 'sounds/errorsound.mp3';

  AudioPlayer? _success;
  AudioPlayer? _error;
  Future<AudioPlayer>? _successInit;
  Future<AudioPlayer>? _errorInit;

  Future<AudioPlayer> _create(String asset) async {
    final player = AudioPlayer();
    try { await player.setPlayerMode(PlayerMode.lowLatency); } catch (_) {}
    try { await player.setReleaseMode(ReleaseMode.stop); } catch (_) {}
    try { await player.setVolume(1.0); } catch (_) {}
    try { await player.setSource(AssetSource(asset)); } catch (_) {}
    return player;
  }

  Future<AudioPlayer> _player(bool success) {
    if (success) {
      return _successInit ??= _create(_successAsset).then((p) => _success = p);
    }
    return _errorInit ??= _create(_errorAsset).then((p) => _error = p);
  }

  Future<void> _play(bool success, String asset) async {
    try {
      final player = await _player(success);
      try {
        // Pre-loaded sound: restart it immediately.
        await player.stop();
        await player.resume();
      } catch (_) {
        // Fallback if the platform lost the pre-loaded source.
        await player.play(AssetSource(asset), volume: 1.0);
      }
    } catch (_) {
      // Audio feedback must never break scanning.
    }
  }

  /// Call when a scanner screen opens so the first beep is also instant.
  Future<void> warmUp() async { await Future.wait([_player(true), _player(false)]); }

  Future<void> playBarcodeSuccess() => _play(true, _successAsset);
  Future<void> playBarcodeError() => _play(false, _errorAsset);

  Future<void> dispose() async {
    final success = _success;
    final error = _error;
    _success = null;
    _error = null;
    _successInit = null;
    _errorInit = null;
    try { await success?.dispose(); } catch (_) {}
    try { await error?.dispose(); } catch (_) {}
  }
}
