import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import '../database/app_database.dart';
import '../database/database_constants.dart';
import 'data_events.dart';

class UnitRecord {
  final int id;
  final String name;
  const UnitRecord(this.id, this.name);
}

/// The user's own list of units (More > Category/Units). Every unit picker in
/// the app (Product unit, Outer / Inner unit) reads this one list.
///
/// A product stores its unit as plain text, so deleting a unit never touches
/// products that already use it; it only stops being offered in the pickers.
class UnitRepository {
  UnitRepository._();
  static final UnitRepository instance = UnitRepository._();

  static const List<String> builtInUnits = <String>[
    'Piece', 'Box', 'Pack', 'Dozen', 'Pair', 'Bottle', 'Can', 'Bag', 'Carton', 'Set',
    'Roll', 'Tray', 'Sack', 'Kg', 'Gram', 'Ton', 'Litre', 'Millilitre', 'Meter',
    'Centimeter', 'Square Meter', 'Cubic Meter',
  ];

  // The starter list is added only once, so a unit the user deleted never
  // comes back by itself.
  static const String unitsSeededKey = 'item_units_seeded';

  Future<List<UnitRecord>> list() async {
    final db = await AppDatabase.instance.database;
    var rows = await db.query(DBConstants.tableItemUnits, orderBy: 'name COLLATE NOCASE');
    SharedPreferences? prefs;
    try {
      prefs = await SharedPreferences.getInstance();
    } catch (_) {} // the list must still work if saved settings are unavailable
    final alreadySeeded = prefs?.getBool(unitsSeededKey) ?? (prefs == null && rows.isNotEmpty);
    if (!alreadySeeded) {
      if (rows.isEmpty) {
        final now = DateTime.now().toIso8601String();
        final batch = db.batch();
        for (final name in builtInUnits) {
          batch.insert(DBConstants.tableItemUnits, {'name': name, 'created_at': now}, conflictAlgorithm: ConflictAlgorithm.ignore);
        }
        await batch.commit(noResult: true);
        rows = await db.query(DBConstants.tableItemUnits, orderBy: 'name COLLATE NOCASE');
      }
      try {
        await prefs?.setBool(unitsSeededKey, true);
      } catch (_) {}
    }
    return rows.map((r) => UnitRecord(r['id'] as int, r['name'] as String)).toList();
  }

  Future<List<String>> names() async => (await list()).map((e) => e.name).toList();

  Future<bool> _exists(Database db, String name, {int? exceptId}) async {
    final rows = await db.query(
      DBConstants.tableItemUnits,
      columns: const ['id'],
      where: exceptId == null ? 'LOWER(name) = ?' : 'LOWER(name) = ? AND id != ?',
      whereArgs: exceptId == null ? [name.toLowerCase()] : [name.toLowerCase(), exceptId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  /// Adds a unit. Returns false when the name is empty or already exists.
  Future<bool> add(String name) async {
    final clean = name.trim();
    if (clean.isEmpty) return false;
    final db = await AppDatabase.instance.database;
    if (await _exists(db, clean)) return false;
    await list(); // makes sure the starter list was handled first
    await db.insert(DBConstants.tableItemUnits, {'name': clean, 'created_at': DateTime.now().toIso8601String()});
    DataEvents.changed();
    return true;
  }

  /// Used when a new unit name is typed in a picker: keeps the list in sync.
  Future<void> addIfMissing(String name) async {
    try {
      await add(name);
    } catch (_) {}
  }

  /// Renames a unit and the products / purchases that use the old name.
  /// Returns false when the new name is empty or already used by another unit.
  Future<bool> rename(int id, String oldName, String newName) async {
    final clean = newName.trim();
    if (clean.isEmpty) return false;
    final db = await AppDatabase.instance.database;
    if (await _exists(db, clean, exceptId: id)) return false;
    await db.transaction((txn) async {
      await txn.update(DBConstants.tableItemUnits, {'name': clean}, where: 'id = ?', whereArgs: [id]);
      if (oldName != clean) {
        await txn.update(DBConstants.tableItems, {'unit': clean}, where: 'unit = ?', whereArgs: [oldName]);
        await txn.update(DBConstants.tableItems, {'outer_unit': clean}, where: 'outer_unit = ?', whereArgs: [oldName]);
        await txn.update(DBConstants.tableItems, {'inner_unit': clean}, where: 'inner_unit = ?', whereArgs: [oldName]);
        await txn.update(DBConstants.tablePurchases, {'unit': clean}, where: 'unit = ?', whereArgs: [oldName]);
        await txn.update(DBConstants.tablePurchaseInvoiceItems, {'unit': clean}, where: 'unit = ?', whereArgs: [oldName]);
      }
    });
    DataEvents.changed();
    return true;
  }

  Future<void> delete(int id) async {
    final db = await AppDatabase.instance.database;
    await db.delete(DBConstants.tableItemUnits, where: 'id = ?', whereArgs: [id]);
    DataEvents.changed();
  }

  /// unit name (lower case) -> number of products using it.
  Future<Map<String, int>> usage() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('''
      SELECT LOWER(u) AS u, COUNT(*) AS c FROM (
        SELECT unit AS u FROM ${DBConstants.tableItems}
        UNION ALL SELECT outer_unit FROM ${DBConstants.tableItems} WHERE outer_unit IS NOT NULL AND outer_unit != ''
        UNION ALL SELECT inner_unit FROM ${DBConstants.tableItems} WHERE inner_unit IS NOT NULL AND inner_unit != ''
      ) GROUP BY LOWER(u)
    ''');
    return {for (final r in rows) (r['u'] as String): (r['c'] as num).toInt()};
  }
}
