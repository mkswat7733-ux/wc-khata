import 'package:shared_preferences/shared_preferences.dart';

import 'unit_repository.dart';

/// Inner / Outer unit system settings.
///
/// Every business sets its own pair once (Pharmacy: Outer = Box, Inner =
/// Strip / Tablet). When the system is ON the Product and Purchase screens use
/// Outer + Inner quantities instead of one plain unit.
///
/// The user's saved unit names are kept here so they can be re-selected later;
/// a name typed in the selector that is not in the list is added as a new one.
class UnitSystemService {
  UnitSystemService._();
  static final UnitSystemService instance = UnitSystemService._();

  static const _enabledKey = 'unit_system_enabled';
  static const _outerListKey = 'unit_system_outer_list';
  static const _innerListKey = 'unit_system_inner_list';
  static const _defaultOuterKey = 'unit_system_default_outer';
  static const _defaultInnerKey = 'unit_system_default_inner';

  /// Fast, synchronous copy of the "enabled" flag for widgets that cannot await.
  static bool enabledCache = false;

  Future<UnitSystemConfig> load() async {
    final p = await SharedPreferences.getInstance();
    // Outer and Inner pickers both offer the user's one Units list
    // (More > Category/Units).
    final units = await UnitRepository.instance.names();
    final cfg = UnitSystemConfig(
      enabled: p.getBool(_enabledKey) ?? false,
      outerUnits: List<String>.from(units),
      innerUnits: List<String>.from(units),
      defaultOuter: p.getString(_defaultOuterKey),
      defaultInner: p.getString(_defaultInnerKey),
    );
    enabledCache = cfg.enabled;
    return cfg;
  }

  Future<void> save(UnitSystemConfig cfg) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(_enabledKey, cfg.enabled);
    await p.setStringList(_outerListKey, cfg.outerUnits);
    await p.setStringList(_innerListKey, cfg.innerUnits);
    if (cfg.defaultOuter == null) {
      await p.remove(_defaultOuterKey);
    } else {
      await p.setString(_defaultOuterKey, cfg.defaultOuter!);
    }
    if (cfg.defaultInner == null) {
      await p.remove(_defaultInnerKey);
    } else {
      await p.setString(_defaultInnerKey, cfg.defaultInner!);
    }
    enabledCache = cfg.enabled;
  }

  /// Adds [name] to a saved list (case-insensitive, no duplicates) and returns
  /// the list entry that should be used (the existing spelling if it exists).
  static String addTo(List<String> list, String name) {
    final clean = name.trim();
    for (final e in list) {
      if (e.toLowerCase() == clean.toLowerCase()) return e;
    }
    list.add(clean);
    return clean;
  }
}

class UnitSystemConfig {
  final bool enabled;
  final List<String> outerUnits;
  final List<String> innerUnits;
  final String? defaultOuter;
  final String? defaultInner;
  const UnitSystemConfig({
    required this.enabled,
    required this.outerUnits,
    required this.innerUnits,
    required this.defaultOuter,
    required this.defaultInner,
  });
}
