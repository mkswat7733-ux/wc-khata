import 'dart:io';

/// One place that answers "are we running as a desktop (Windows) app?".
class AppPlatform {
  AppPlatform._();

  static bool get isDesktop => Platform.isWindows || Platform.isLinux || Platform.isMacOS;
  static bool get isAndroid => Platform.isAndroid;
}
