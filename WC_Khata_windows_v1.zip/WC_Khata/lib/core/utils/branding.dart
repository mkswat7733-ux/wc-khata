import 'package:package_info_plus/package_info_plus.dart';

/// Fixed brand text. These are constants on purpose: the user can never edit,
/// hide or change them from any setting.
class Branding {
  Branding._();

  /// Footer line printed at the bottom of every 58mm / 80mm receipt.
  static const String poweredBy = 'Powered by WebdSoft Company';

  /// Version shown inside the app (splash, About, sidebar). It is read from
  /// the app itself at startup, so it is always the same version name that
  /// Play Store shows (the part before the "+" in pubspec.yaml `version:`).
  /// The fallback below is used only if reading it ever fails.
  static String appVersion = '1.0.9';

  static Future<void> loadVersion() async {
    try {
      final info = await PackageInfo.fromPlatform();
      if (info.version.trim().isNotEmpty) appVersion = info.version.trim();
    } catch (_) {}
  }
}
