import 'currency_symbols.dart';

/// Converts an amount into receipt wording, e.g.
/// `Five Thousand Two Hundred Fifty Rupees Only` or
/// `One Lakh Twenty Thousand Taka and 50/100 Only`.
///
/// PKR / INR / BDT / NPR / LKR use lakh & crore; every other currency uses
/// thousand / million / billion.
class NumberToWords {
  NumberToWords._();

  static const _ones = <String>[
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen',
  ];
  static const _tens = <String>[
    '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety',
  ];

  static String _below100(int n) {
    if (n < 20) return _ones[n];
    final t = _tens[n ~/ 10];
    final o = _ones[n % 10];
    return o.isEmpty ? t : '$t $o';
  }

  static String _below1000(int n) {
    final h = n ~/ 100;
    final r = n % 100;
    final parts = <String>[];
    if (h > 0) parts.add('${_ones[h]} Hundred');
    if (r > 0) parts.add(_below100(r));
    return parts.join(' ');
  }

  static String _intWords(int n, bool lakh) {
    if (n == 0) return 'Zero';
    final parts = <String>[];
    var rest = n;
    if (lakh) {
      final crore = rest ~/ 10000000;
      rest %= 10000000;
      final lakhs = rest ~/ 100000;
      rest %= 100000;
      final thousand = rest ~/ 1000;
      rest %= 1000;
      if (crore > 0) parts.add('${_intWords(crore, true)} Crore');
      if (lakhs > 0) parts.add('${_below100(lakhs)} Lakh');
      if (thousand > 0) parts.add('${_below100(thousand)} Thousand');
      if (rest > 0) parts.add(_below1000(rest));
    } else {
      final billion = rest ~/ 1000000000;
      rest %= 1000000000;
      final million = rest ~/ 1000000;
      rest %= 1000000;
      final thousand = rest ~/ 1000;
      rest %= 1000;
      if (billion > 0) parts.add('${_below1000(billion)} Billion');
      if (million > 0) parts.add('${_below1000(million)} Million');
      if (thousand > 0) parts.add('${_below1000(thousand)} Thousand');
      if (rest > 0) parts.add(_below1000(rest));
    }
    return parts.join(' ');
  }

  static String amountInWords(double amount, String currencyCode) {
    if (amount.isNaN || amount.isInfinite) return '';
    final cents = (amount.abs() * 100).round();
    final whole = cents ~/ 100;
    final frac = cents % 100;
    final words = _intWords(whole, currencyUsesLakhCrore(currencyCode));
    final name = currencyNameFor(currencyCode);
    if (frac == 0) return '$words $name Only';
    return '$words $name and ${frac.toString().padLeft(2, '0')}/100 Only';
  }
}
