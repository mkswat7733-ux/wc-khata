import 'package:flutter/material.dart';

/// Wraps a tappable card/tile with a subtle press-down scale so it feels
/// tactile — the small "3D press" motion real banking apps use — instead
/// of a flat InkWell splash alone. Purely a motion layer: it still calls
/// [onTap] itself, so nothing else about the child needs to change.
class AnimatedTapScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;

  const AnimatedTapScale({super.key, required this.child, this.onTap});

  @override
  State<AnimatedTapScale> createState() => _AnimatedTapScaleState();
}

class _AnimatedTapScaleState extends State<AnimatedTapScale> {
  double _scale = 1;

  void _setScale(double v) {
    if (mounted) setState(() => _scale = v);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      onTapDown: widget.onTap == null ? null : (_) => _setScale(0.96),
      onTapUp: widget.onTap == null ? null : (_) => _setScale(1),
      onTapCancel: widget.onTap == null ? null : () => _setScale(1),
      child: AnimatedScale(
        scale: _scale,
        duration: const Duration(milliseconds: 110),
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
  }
}
