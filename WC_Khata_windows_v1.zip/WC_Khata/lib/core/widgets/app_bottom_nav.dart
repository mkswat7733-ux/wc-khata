import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../app/theme/app_theme.dart';

/// Describes one destination in [AppBottomNav].
class AppNavItem {
  final IconData icon;
  final IconData activeIcon;
  final String label;

  const AppNavItem({required this.icon, required this.activeIcon, required this.label});
}

/// Modern floating bottom bar: rounded pill-shaped card with a soft
/// layered shadow and thin outline, floating above the screen bottom.
/// A blue gradient "bubble" slides smoothly behind the selected tab,
/// the icon bounces in and the label fades in below it.
class AppBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final List<AppNavItem> items;

  const AppBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.items,
  });

  static double _scaleFor(double screenWidth) => (screenWidth / 390).clamp(0.85, 1.2);

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final scale = _scaleFor(mq.size.width);
    final barHeight = 66.0 * scale;
    const pad = 6.0;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        systemNavigationBarColor: AppColors.lightBackground,
        systemNavigationBarIconBrightness: Brightness.dark,
        systemNavigationBarDividerColor: Colors.transparent,
        systemNavigationBarContrastEnforced: false,
      ),
      child: Container(
        color: AppColors.lightBackground,
        padding: EdgeInsets.fromLTRB(14, 8, 14, 10 + mq.viewPadding.bottom),
        child: Container(
          height: barHeight,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: AppColors.lightDivider.withValues(alpha: 0.9)),
            boxShadow: [
              BoxShadow(color: Colors.black.withValues(alpha: 0.12), blurRadius: 24, offset: const Offset(0, 10)),
              BoxShadow(color: AppColors.primary.withValues(alpha: 0.10), blurRadius: 14, offset: const Offset(0, 4)),
              BoxShadow(color: Colors.white.withValues(alpha: 0.9), blurRadius: 4, offset: const Offset(0, -1)),
            ],
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final itemWidth = (constraints.maxWidth - pad * 2) / items.length;
              return Stack(
                children: [
                  AnimatedPositioned(
                    duration: const Duration(milliseconds: 380),
                    curve: Curves.easeOutBack,
                    left: pad + currentIndex * itemWidth,
                    top: pad,
                    bottom: pad,
                    width: itemWidth,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFF4C8DFF), AppColors.primary],
                        ),
                        borderRadius: BorderRadius.circular(26),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primary.withValues(alpha: 0.40),
                            blurRadius: 14,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: pad),
                    child: Row(
                      children: List.generate(items.length, (i) {
                        return Expanded(
                          child: _NavButton(
                            item: items[i],
                            selected: i == currentIndex,
                            scale: scale,
                            onTap: () {
                              if (i != currentIndex) HapticFeedback.selectionClick();
                              onTap(i);
                            },
                          ),
                        );
                      }),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final AppNavItem item;
  final bool selected;
  final double scale;
  final VoidCallback onTap;

  const _NavButton({
    required this.item,
    required this.selected,
    required this.scale,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = selected ? Colors.white : AppColors.lightTextSecondary;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedScale(
            scale: selected ? 1.12 : 1.0,
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeOutBack,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 280),
              transitionBuilder: (child, animation) => ScaleTransition(
                scale: animation,
                child: FadeTransition(opacity: animation, child: child),
              ),
              child: Icon(
                selected ? item.activeIcon : item.icon,
                key: ValueKey(selected),
                color: color,
                size: 24 * scale,
              ),
            ),
          ),
          SizedBox(height: 3 * scale),
          AnimatedDefaultTextStyle(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            style: AppTextStyles.caption.copyWith(
              color: color,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              fontSize: 10.5 * scale,
            ),
            child: Text(item.label, maxLines: 1, softWrap: false, overflow: TextOverflow.clip),
          ),
        ],
      ),
    );
  }
}
