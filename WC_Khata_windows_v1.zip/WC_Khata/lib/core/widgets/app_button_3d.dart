import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';

/// A rounded, filled button with real depth — a soft ambient shadow
/// plus a colored glow underneath, and a press-down scale — instead of
/// Material's flat FilledButton. Meant to replace every "Add",
/// "Save", "Submit" style action button across the app with one
/// consistent, tactile "3D button" language (the same visual family as
/// [AnimatedTapScale] cards elsewhere).
///
/// Usage: `AppButton3D(label: 'Add', icon: Icons.add, onPressed: ...)`
class AppButton3D extends StatefulWidget {
  const AppButton3D({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.color,
    this.expand = false,
    this.outlined = false,
    this.compact = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;

  /// Defaults to [AppColors.primary].
  final Color? color;

  /// Stretch to fill the available width (for a full-width action row).
  final bool expand;

  /// A lighter, tinted-background variant for secondary actions —
  /// keeps the same press/shadow motion without competing visually
  /// with a primary button on the same screen.
  final bool outlined;

  /// Compact sizing for toolbar/dialog actions.
  final bool compact;

  @override
  State<AppButton3D> createState() => _AppButton3DState();
}

class _AppButton3DState extends State<AppButton3D> {
  double _pressed = 0;

  @override
  Widget build(BuildContext context) {
    final color = widget.color ?? AppColors.primary;
    final enabled = widget.onPressed != null;
    final depth = 6 * (1 - _pressed) + 2;

    final content = Row(
      mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (widget.icon != null) ...[
          Icon(widget.icon, size: 18, color: widget.outlined ? color : Colors.white),
          const SizedBox(width: AppDimensions.spaceSm),
        ],
        Text(
          widget.label,
          style: AppTextStyles.bodyMedium.copyWith(
            color: widget.outlined ? color : Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );

    return Opacity(
      opacity: enabled ? 1 : 0.5,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: enabled ? (_) => setState(() => _pressed = 1) : null,
        onTapUp: enabled ? (_) => setState(() => _pressed = 0) : null,
        onTapCancel: enabled ? () => setState(() => _pressed = 0) : null,
        onTap: widget.onPressed,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          curve: Curves.easeOut,
          width: widget.expand ? double.infinity : null,
          padding: EdgeInsets.symmetric(horizontal: widget.compact ? 14 : AppDimensions.spaceLg, vertical: widget.compact ? 9 : 13),
          transform: Matrix4.translationValues(0, _pressed * 2, 0),
          decoration: BoxDecoration(
            color: widget.outlined ? color.withValues(alpha: 0.12) : color,
            borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
            border: widget.outlined ? Border.all(color: color.withValues(alpha: 0.35)) : null,
            boxShadow: [
                    BoxShadow(color: color.withValues(alpha: widget.outlined ? 0.16 : 0.35), blurRadius: depth * (widget.outlined ? 1.5 : 2.2), offset: Offset(0, depth * 0.9)),
                    BoxShadow(color: Colors.black.withValues(alpha: widget.outlined ? 0.08 : 0.12), blurRadius: depth, offset: Offset(0, depth * 0.5)),
                  ],
          ),
          child: content,
        ),
      ),
    );
  }
}
