import 'dart:async';

import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../services/app_navigator.dart';

/// The kind of message a dialog shows.
enum AppMessageType { success, warning, error }

/// Drop-in replacement for `ScaffoldMessenger.of(context)` used across the app.
///
/// Every message is shown in a proper dialog with an OK button, in one of
/// three styles:
///
///  * **Completed** (green check)  - the work was done: saved, deleted, sent...
///  * **Warning** (amber triangle) - the user must fix something: a missing
///    or wrong value, nothing selected, out of stock...
///  * **Error** (red)              - something failed: could not save / print...
///
/// Existing code keeps calling `showSnackBar(SnackBar(content: Text(...)))`;
/// the style is chosen from the wording (see [_classify]). New code can call
/// [showSuccess], [showWarning] or [showError] directly to be exact.
class AppMessenger {
  AppMessenger._(this._context);
  final BuildContext _context;

  static bool _dialogOpen = false;
  static AppMessageType? _currentType;
  static BuildContext? _dialogContext;

  static AppMessenger of(BuildContext context) => AppMessenger._(context);

  void hideCurrentSnackBar() {}

  void showSnackBar(SnackBar snackBar) {
    final content = snackBar.content;
    String? text;
    if (content is Text) {
      text = content.data ?? content.textSpan?.toPlainText();
    }
    if (text == null || text.trim().isEmpty) return;
    final message = text.trim();
    // A very short snackbar (under a second) is a quick "tick" such as
    // "Soap added" while scanning many items: no dialog for those.
    final quick = snackBar.duration.inMilliseconds <= 1000;
    final type = _classify(message, quick: quick);
    if (type == null) return;
    final BuildContext? ctx = _context.mounted ? _context : appNavigatorKey.currentContext;
    if (ctx == null) return;
    _show(ctx, type, message);
  }

  // ------------------------------------------------------- classification

  /// Partly done: the main work succeeded but a side step failed.
  static final RegExp _partial = RegExp(r"saved, but|done, but|added, but|, but .*(could not|couldn't|failed)", caseSensitive: false);

  /// Something broke.
  static final RegExp _errorWords = RegExp(
    r"could not|couldn't|unable|failed|fail\b|error|went wrong|crash|"
    r"not connected|disconnected|bluetooth is off|turn on bluetooth",
    caseSensitive: false,
  );

  /// The user has to correct or choose something.
  static final RegExp _warningWords = RegExp(
    r"\bplease\b|enter |select |choose |must |required|needs |need to |at least|already|invalid|"
    r"cannot|can't|not available|is not |isn't|no longer|maximum|too many|too short|too long|missing|"
    r"out of stock|no more stock|still loading|cancelled|canceled|greater than|different|"
    r"\bno [\w/ ]{0,30}found|not found|has no |\bno (sms|phone|product|supplier|customer)|"
    r"available on|only available|add or scan|permission",
    caseSensitive: false,
  );

  /// The work is done.
  static final RegExp _successWords = RegExp(
    r"saved|restored|deleted|removed|changed|added|updated|activated|is now active|sent to|sent\.|"
    r"complete|success|created|copied|shared|exported|printed|recorded|posted|paid|renamed|set as|applied|imported",
    caseSensitive: false,
  );

  /// Returns the style for a message, or null when nothing should be shown.
  static AppMessageType? _classify(String text, {bool quick = false}) {
    final t = text.toLowerCase();
    // Hand-off to another app ("Opening SMS for ...") needs no dialog.
    if (t.startsWith('opening ')) return null;
    // Printing finished ("Receipt sent to the printer."): the paper coming out
    // is the confirmation, so no "Completed" dialog. Failures still show.
    if (RegExp(r'sent to (the )?printer').hasMatch(t) && !_errorWords.hasMatch(t)) return null;
    if (_partial.hasMatch(t)) return AppMessageType.warning;
    if (_errorWords.hasMatch(t)) return AppMessageType.error;
    if (_warningWords.hasMatch(t)) return AppMessageType.warning;
    if (_successWords.hasMatch(t)) return quick ? null : AppMessageType.success;
    // Unknown wording: show it as a warning rather than claim success or failure.
    return AppMessageType.warning;
  }

  // --------------------------------------------------------------- dialogs

  /// Green "Completed" dialog (closes by itself after a moment, or on OK).
  static Future<void> showSuccess(BuildContext context, String message) => _show(context, AppMessageType.success, message);

  /// Amber "Warning" dialog.
  static Future<void> showWarning(BuildContext context, String message) => _show(context, AppMessageType.warning, message);

  /// Red "Error" dialog.
  static Future<void> showError(BuildContext context, String message) => _show(context, AppMessageType.error, message);

  static void _dismissCurrent() {
    final c = _dialogContext;
    if (c != null && c.mounted) Navigator.of(c).pop();
  }

  static Future<void> _show(BuildContext context, AppMessageType type, String message) async {
    if (_dialogOpen) {
      // A "Completed" dialog gives way to a warning or error that follows it.
      if (_currentType == AppMessageType.success && type != AppMessageType.success) {
        _dismissCurrent();
        for (var i = 0; i < 10 && _dialogOpen; i++) {
          await Future<void>.delayed(const Duration(milliseconds: 40));
        }
        if (!context.mounted) return;
      } else {
        return;
      }
    }

    final Color color;
    final IconData icon;
    final String title;
    switch (type) {
      case AppMessageType.success:
        color = AppColors.income;
        icon = Icons.check_circle_rounded;
        title = 'Completed';
        break;
      case AppMessageType.warning:
        color = AppColors.warning;
        icon = Icons.warning_amber_rounded;
        title = 'Warning';
        break;
      case AppMessageType.error:
        color = AppColors.expense;
        icon = Icons.error_outline_rounded;
        title = 'Error';
        break;
    }

    _dialogOpen = true;
    _currentType = type;
    Timer? autoClose;
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) {
          _dialogContext = ctx;
          if (type == AppMessageType.success) {
            autoClose ??= Timer(const Duration(milliseconds: 2000), _dismissCurrent);
          }
          return Dialog(
            backgroundColor: Colors.white,
            insetPadding: const EdgeInsets.symmetric(horizontal: 32),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(color: color.withValues(alpha: 0.12), shape: BoxShape.circle),
                    child: Icon(icon, color: color, size: 30),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    title,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 14, height: 1.4, color: AppColors.lightTextSecondary),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(ctx).pop(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: color,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: const Text('OK', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    } finally {
      autoClose?.cancel();
      _dialogContext = null;
      _currentType = null;
      _dialogOpen = false;
    }
  }
}
