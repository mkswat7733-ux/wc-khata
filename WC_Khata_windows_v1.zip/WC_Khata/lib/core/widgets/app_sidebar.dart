import '../utils/branding.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../app/theme/app_theme.dart';
import '../../app/user_preferences_controller.dart';
import '../routing/app_transitions.dart';
import '../../features/profile/profile_screen.dart';
import '../../features/settings/settings_screen.dart';
import '../../features/security/security_screen.dart';
import '../../features/backup/backup_screen.dart';
import '../../features/backup/restore_screen.dart';
import '../../features/recycle_bin/recycle_bin_screen.dart';

/// App sidebar, used as the `drawer:` of RootShell's Scaffold.
///
/// Being a real Scaffold drawer it slides in over the whole screen
/// (above the bottom nav), leaves Home visible underneath, can be
/// opened with an edge swipe and dragged open/closed with the finger.
/// The items still reveal in a staggered cascade every time it opens.
class AppSidebar extends StatefulWidget {
  const AppSidebar({super.key});

  @override
  State<AppSidebar> createState() => _AppSidebarState();
}

class _AppSidebarState extends State<AppSidebar> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  static const _tiles = [
    (icon: Icons.person_rounded, color: AppColors.primary, label: 'Profile'),
    (icon: Icons.settings_rounded, color: AppColors.catTransport, label: 'Settings'),
    (icon: Icons.lock_rounded, color: AppColors.warning, label: 'Security'),
    (icon: Icons.restore_from_trash_rounded, color: AppColors.expense, label: 'Recycle Bin'),
    (icon: Icons.cloud_upload_rounded, color: AppColors.catHealth, label: 'Backup'),
    (icon: Icons.cloud_download_rounded, color: AppColors.catEntertainment, label: 'Restore'),
  ];

  static final _screenBuilders = <String, WidgetBuilder>{
    'Profile': (_) => const ProfileScreen(),
    'Settings': (_) => const SettingsScreen(),
    'Security': (_) => const SecurityScreen(),
    'Recycle Bin': (_) => const RecycleBinScreen(),
    'Backup': (_) => const BackupScreen(),
    'Restore': (_) => const RestoreScreen(),
  };

  static double _scaleFor(double screenWidth) => (screenWidth / 390).clamp(0.85, 1.12);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Animation<double> _stagger(int index, {double start = 0.0}) {
    final begin = (start + index * 0.07).clamp(0.0, 1.0);
    final end = (begin + 0.45).clamp(0.0, 1.0);
    return CurvedAnimation(parent: _controller, curve: Interval(begin, end, curve: Curves.easeOutCubic));
  }

  @override
  Widget build(BuildContext context) {
    const isDark = false;
    final prefs = context.watch<UserPreferencesController>();
    final hasPhoto = prefs.photoPath != null && File(prefs.photoPath!).existsSync();
    final screenWidth = MediaQuery.of(context).size.width;
    final scale = _scaleFor(screenWidth);

    return Drawer(
      width: screenWidth * 0.78,
      backgroundColor: AppColors.lightSurface,
      elevation: 16,
      shadowColor: Colors.black.withValues(alpha: 0.5),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(AppDimensions.radiusLg)),
      ),
      clipBehavior: Clip.antiAlias,
      child: SafeArea(
        top: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _SidebarHeader(hasPhoto: hasPhoto, photoPath: prefs.photoPath, scale: scale, reveal: _stagger(0)),
            Expanded(
              child: ListView(
                padding: EdgeInsets.symmetric(
                  horizontal: AppDimensions.spaceSm * scale,
                  vertical: AppDimensions.spaceMd * scale,
                ),
                children: [
                  for (int i = 0; i < _tiles.length; i++)
                    _SidebarTile(
                      icon: _tiles[i].icon,
                      color: _tiles[i].color,
                      label: _tiles[i].label,
                      scale: scale,
                      isDark: isDark,
                      reveal: _stagger(i + 1, start: 0.08),
                      screenBuilder: _screenBuilders[_tiles[i].label]!,
                    ),
                ],
              ),
            ),
            FadeTransition(
              opacity: _stagger(_tiles.length + 1, start: 0.08),
              child: Padding(
                padding: EdgeInsets.all(AppDimensions.spaceMd * scale),
                child: Text(
                  'WC Khata · Version ${Branding.appVersion}',
                  textAlign: TextAlign.center,
                  style: AppTextStyles.caption.copyWith(
                    color: AppColors.lightTextSecondary,
                    fontSize: 12 * scale,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SidebarHeader extends StatelessWidget {
  final bool hasPhoto;
  final String? photoPath;
  final double scale;
  final Animation<double> reveal;
  const _SidebarHeader({required this.hasPhoto, required this.photoPath, required this.scale, required this.reveal});

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: reveal,
      child: SlideTransition(
        position: reveal.drive(Tween(begin: const Offset(0, -0.15), end: Offset.zero)),
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(
            AppDimensions.spaceLg * scale,
            AppDimensions.spaceLg * scale + MediaQuery.of(context).padding.top,
            AppDimensions.spaceLg * scale,
            AppDimensions.spaceLg * scale + 4,
          ),
          decoration: const BoxDecoration(
            color: Color(0xFF234A86),
            boxShadow: [
              BoxShadow(color: Colors.black38, blurRadius: 14, offset: Offset(0, 6)),
              BoxShadow(color: Colors.black12, blurRadius: 24, offset: Offset(0, 10)),
            ],
          ),
          child: Row(
            children: [
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.3), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: CircleAvatar(
                  radius: 28 * scale,
                  backgroundColor: Colors.white.withValues(alpha: 0.22),
                  backgroundImage: hasPhoto ? FileImage(File(photoPath!)) : null,
                  child: hasPhoto ? null : Icon(Icons.person_rounded, color: Colors.white, size: 28 * scale),
                ),
              ),
              SizedBox(width: AppDimensions.spaceMd * scale),
              Expanded(
                child: Text(
                  'WC Khata',
                  style: TextStyle(color: Colors.white, fontSize: 17 * scale, fontWeight: FontWeight.w700),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// One sidebar row — a small 3D-ish raised icon chip, a label, and a
/// chevron — fading and sliding in on its own staggered slice of the
/// sidebar's shared reveal timeline.
class _SidebarTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final double scale;
  final bool isDark;
  final Animation<double> reveal;
  final WidgetBuilder screenBuilder;

  const _SidebarTile({
    required this.icon,
    required this.color,
    required this.label,
    required this.scale,
    required this.isDark,
    required this.reveal,
    required this.screenBuilder,
  });

  @override
  Widget build(BuildContext context) {
    final textColor = isDark ? AppColors.darkTextPrimary : AppColors.lightTextPrimary;
    return FadeTransition(
      opacity: reveal,
      child: SlideTransition(
        position: reveal.drive(Tween(begin: const Offset(-0.25, 0), end: Offset.zero)),
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 4 * scale),
          child: Material(
            color: isDark ? AppColors.darkBackground : AppColors.lightBackground,
            borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
            elevation: 0,
            child: InkWell(
              borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
              onTap: () {
                // Pops this sidebar route first (matching how it was
                // pushed — see AppSidebar.route), then opens the
                // destination screen on top of Home.
                final nav = Navigator.of(context);
                final page = screenBuilder(context);
                nav.pop();
                nav.push(AppTransitions.slideFromRight(page));
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
                  boxShadow: isDark
                      ? null
                      : [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 6, offset: const Offset(0, 2))],
                ),
                padding: EdgeInsets.symmetric(
                  horizontal: AppDimensions.spaceSm * scale,
                  vertical: AppDimensions.spaceSm * scale,
                ),
                child: Row(
                  children: [
                    Container(
                      width: 36 * scale,
                      height: 36 * scale,
                      decoration: BoxDecoration(color: color.withValues(alpha: 0.15), shape: BoxShape.circle),
                      child: Icon(icon, color: color, size: 17 * scale),
                    ),
                    SizedBox(width: AppDimensions.spaceSm * scale),
                    Expanded(
                      child: Text(
                        label,
                        style: AppTextStyles.bodyMedium.copyWith(fontSize: 14.5 * scale, color: textColor),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Icon(Icons.chevron_right_rounded, size: 18 * scale, color: isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
