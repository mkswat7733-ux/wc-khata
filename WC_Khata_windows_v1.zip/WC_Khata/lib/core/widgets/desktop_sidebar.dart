import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/theme/app_theme.dart';
import '../../app/user_preferences_controller.dart';
import '../utils/branding.dart';
import 'app_bottom_nav.dart' show AppNavItem;

/// Permanent left sidebar used by the Windows (desktop) build.
/// Top block = the 5 main tabs, second block = Profile, Settings, Security,
/// Recycle Bin, Backup, Restore (the same items as the phone drawer).
class DesktopSidebar extends StatelessWidget {
  final List<AppNavItem> tabs;
  final int selectedTab;
  final ValueChanged<int> onTab;

  final List<({IconData icon, String label})> extras;
  final String? selectedExtra;
  final ValueChanged<String> onExtra;

  const DesktopSidebar({
    super.key,
    required this.tabs,
    required this.selectedTab,
    required this.onTab,
    required this.extras,
    required this.selectedExtra,
    required this.onExtra,
  });

  static const double width = 250;
  static const Color _bg = Color(0xFF234A86);

  @override
  Widget build(BuildContext context) {
    final prefs = context.watch<UserPreferencesController>();
    final photo = prefs.photoPath;
    final hasPhoto = photo != null && File(photo).existsSync();

    return Container(
      width: width,
      color: _bg,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 20, 18, 16),
              child: Row(children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: Colors.white.withValues(alpha: 0.22),
                  backgroundImage: hasPhoto ? FileImage(File(photo)) : null,
                  child: hasPhoto ? null : const Icon(Icons.person_rounded, color: Colors.white, size: 26),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text('WC Khata',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                ),
              ]),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                children: [
                  for (var i = 0; i < tabs.length; i++)
                    _Tile(
                      icon: (selectedTab == i && selectedExtra == null) ? tabs[i].activeIcon : tabs[i].icon,
                      label: tabs[i].label,
                      selected: selectedTab == i && selectedExtra == null,
                      onTap: () => onTab(i),
                    ),
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                    child: Divider(color: Colors.white24, height: 1),
                  ),
                  for (final e in extras)
                    _Tile(
                      icon: e.icon,
                      label: e.label,
                      selected: selectedExtra == e.label,
                      onTap: () => onExtra(e.label),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Text('Version ${Branding.appVersion}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white60, fontSize: 12)),
            ),
          ],
        ),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _Tile({required this.icon, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Material(
        color: selected ? Colors.white : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          hoverColor: Colors.white.withValues(alpha: 0.10),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(children: [
              Icon(icon, size: 22, color: selected ? DesktopSidebar._bg : Colors.white),
              const SizedBox(width: 12),
              Expanded(
                child: Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: selected ? DesktopSidebar._bg : Colors.white,
                      fontSize: 15,
                      fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                    )),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
