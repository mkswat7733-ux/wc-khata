import 'package:flutter/material.dart';

/// A one-shot fade + gentle upward-slide entrance, staggered by [index].
/// Wrap any section/card with this to give a screen the smooth, "content
/// eases into place" motion seen in polished banking apps — no extra
/// animation package needed, just a plain AnimationController.
///
/// Usage: wrap sibling sections with increasing [index] (0, 1, 2, ...)
/// and they'll cascade in one after another instead of popping in at once.
class FadeSlideIn extends StatefulWidget {
  final Widget child;
  final int index;
  final Duration baseDelay;
  final Duration duration;

  const FadeSlideIn({
    super.key,
    required this.child,
    this.index = 0,
    this.baseDelay = const Duration(milliseconds: 70),
    this.duration = const Duration(milliseconds: 420),
  });

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: widget.duration);
    final curved = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _fade = curved;
    _slide = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero).animate(curved);
    // Fires once per State — a pull-to-refresh rebuilds via Consumer but
    // doesn't recreate this State, so the entrance never replays on
    // refresh, only on the screen's first appearance.
    Future.delayed(widget.baseDelay * widget.index, () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}
