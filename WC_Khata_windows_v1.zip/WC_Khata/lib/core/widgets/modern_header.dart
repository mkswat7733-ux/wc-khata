import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import 'app_glass_icon_button.dart';

/// The same solid dark-green, rounded-bottom, shadowed header shape
/// used on Home and Finance — reused here so every tab's top feels
/// like one connected app rather than a patchwork of different styles.
///
/// Kept deliberately shorter than before — smaller title, tighter
/// padding — so it reads as a header bar, not a hero section, on
/// screens that also have their own content to show right below it.
/// [bottom] is for embedding something like a TabBar right under the
/// title, already styled to sit correctly on the dark background.
///
/// [onBack] adds a glass back-chip on the left. Pass `Navigator.pop`
/// for a screen that was pushed onto the stack, or a callback that
/// switches the bottom-nav tab back to Home for a root tab (Finance,
/// Tasks) that has no real "back" in the navigation stack.
class ModernHeader extends StatelessWidget implements PreferredSizeWidget {
  const ModernHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.bottom,
    this.trailing,
    this.onBack,
    this.backIcon = Icons.arrow_back_rounded,
  });

  final String title;
  final String? subtitle;
  final PreferredSizeWidget? bottom;
  final Widget? trailing;
  final VoidCallback? onBack;

  /// Defaults to a back arrow. Pass `Icons.close_rounded` on a screen
  /// presented as a bottom-sheet-style form (opened via
  /// AppTransitions.slideFromBottom) — visually "dismiss" reads better
  /// than "back" once a screen slides up over everything else.
  final IconData backIcon;

  static const double _titleFontSize = 19;
  static const double _vPad = AppDimensions.spaceSm;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        // Plain bar, no colored/gradient fill — white in light mode,
        // black in dark mode — matches the rest of the app's flat,
        // UBL-style top bar.
        color: AppColors.barBackground(isDark),
        border: Border(bottom: BorderSide(color: isDark ? AppColors.darkDivider : AppColors.lightDivider)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            AppDimensions.spaceMd,
            _vPad,
            AppDimensions.spaceMd,
            bottom != null ? AppDimensions.spaceXs : AppDimensions.spaceSm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  if (onBack != null) ...[
                    AppGlassIconButton(icon: backIcon, scale: 0.82, onTap: onBack!),
                    const SizedBox(width: AppDimensions.spaceSm),
                  ],
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: TextStyle(color: AppColors.barText(isDark), fontSize: _titleFontSize, fontWeight: FontWeight.w700),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (subtitle != null) ...[
                          const SizedBox(height: 2),
                          Text(
                            subtitle!,
                            style: AppTextStyles.body.copyWith(
                              color: isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary,
                              fontSize: 12,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (trailing != null) trailing!,
                ],
              ),
              if (bottom != null) bottom!,
            ],
          ),
        ),
      ),
    );
  }

  // Only meaningful when used directly as a Scaffold's appBar; when
  // embedded in a plain Column (as every current call site does) this
  // is simply unused.
  @override
  Size get preferredSize => Size.fromHeight(
        56 + (subtitle != null ? 16 : 0) + (bottom?.preferredSize.height ?? 0),
      );
}
