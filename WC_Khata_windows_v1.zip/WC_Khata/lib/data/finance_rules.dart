/// Single source of truth for what is (and is not) a business EXPENSE.
///
/// Profit / Loss = (sale price - cost price of every sold item)
///                 minus running expenses.
///
/// The cost price is already inside the sale profit, so money that only
/// moves because of stock or khata is NOT an expense:
///  * 'Purchase'         - stock bought (cost price)
///  * 'Supplier Payment' - money paid to a supplier
///  * 'Customer Refund'  - money given back to a customer
/// These still hit the Cashbook (cash really left), they just never reduce
/// profit. Any cash row created from a ledger entry is excluded as well.
class FinanceRules {
  FinanceRules._();

  static const String purchase = 'Purchase';
  static const String supplierPayment = 'Supplier Payment';
  static const String customerRefund = 'Customer Refund';
  static const String ledgerReceive = 'Ledger Receive';

  static const List<String> nonOperatingSources = [purchase, supplierPayment, customerRefund];

  /// SQL condition that keeps only real running expenses/transactions.
  /// [idColumn] / [sourceColumn] let callers pass a table alias (t.id ...).
  static String operatingOnlySql({String idColumn = 'id', String sourceColumn = 'source'}) {
    final list = nonOperatingSources.map((e) => "'$e'").join(', ');
    return "COALESCE($sourceColumn, '') NOT IN ($list) "
        "AND $idColumn NOT IN (SELECT cash_transaction_id FROM ledger_transactions WHERE cash_transaction_id IS NOT NULL)";
  }
}
