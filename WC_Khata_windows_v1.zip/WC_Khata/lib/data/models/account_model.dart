class AccountModel {
  final int? id;
  final String name;
  final String type; // cash | bank | wallet | savings | digital | credit_card | custom
  final double openingBalance;
  final double currentBalance;
  final String currency;
  final String? notes;
  final String? iconKey;
  final String? colorHex;
  final bool isActive;
  // Null = not deleted. Set = the account is in the Recycle Bin: hidden
  // from Accounts and every picker across the app, restorable but
  // never permanently erasable from inside the app.
  final DateTime? deletedAt;
  final DateTime createdAt;
  final DateTime updatedAt;
  // Only applies to type == 'credit_card' — a standalone account with
  // a spending ceiling, independent of any Bank account. [cardType]
  // and [linkedBankAccountId] are unused by new cards (kept only so
  // any card created under an earlier version of this feature still
  // reads back fine); a credit card only ever needs a name and a limit.
  final double? creditLimit;
  final String? cardType;
  final int? linkedBankAccountId;

  const AccountModel({
    this.id,
    required this.name,
    required this.type,
    required this.openingBalance,
    required this.currentBalance,
    this.currency = 'USD',
    this.notes,
    this.iconKey,
    this.colorHex,
    this.isActive = true,
    this.deletedAt,
    required this.createdAt,
    required this.updatedAt,
    this.creditLimit,
    this.cardType,
    this.linkedBankAccountId,
  });

  bool get isDeleted => deletedAt != null;

  /// How much is left to spend on this credit card right now —
  /// [currentBalance] IS the available amount (whatever it started
  /// with at creation, going down with every purchase and back up
  /// whenever it's paid down via Add Money or a Transfer in). Only
  /// meaningful for [type] == 'credit_card'.
  double get availableCredit => currentBalance;

  AccountModel copyWith({
    int? id,
    String? name,
    String? type,
    double? openingBalance,
    double? currentBalance,
    String? currency,
    String? notes,
    String? iconKey,
    String? colorHex,
    bool? isActive,
    DateTime? deletedAt,
    bool clearDeletedAt = false,
    DateTime? updatedAt,
    double? creditLimit,
    String? cardType,
    int? linkedBankAccountId,
  }) {
    return AccountModel(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      openingBalance: openingBalance ?? this.openingBalance,
      currentBalance: currentBalance ?? this.currentBalance,
      currency: currency ?? this.currency,
      notes: notes ?? this.notes,
      iconKey: iconKey ?? this.iconKey,
      colorHex: colorHex ?? this.colorHex,
      isActive: isActive ?? this.isActive,
      deletedAt: clearDeletedAt ? null : (deletedAt ?? this.deletedAt),
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      creditLimit: creditLimit ?? this.creditLimit,
      cardType: cardType ?? this.cardType,
      linkedBankAccountId: linkedBankAccountId ?? this.linkedBankAccountId,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'type': type,
      'opening_balance': openingBalance,
      'current_balance': currentBalance,
      'currency': currency,
      'notes': notes,
      'icon_key': iconKey,
      'color_hex': colorHex,
      'is_active': isActive ? 1 : 0,
      'deleted_at': deletedAt?.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'credit_limit': creditLimit,
      'card_type': cardType,
      'linked_bank_account_id': linkedBankAccountId,
    };
  }

  factory AccountModel.fromMap(Map<String, dynamic> map) {
    return AccountModel(
      id: map['id'] as int?,
      name: map['name'] as String,
      type: map['type'] as String,
      openingBalance: (map['opening_balance'] as num).toDouble(),
      currentBalance: (map['current_balance'] as num).toDouble(),
      currency: map['currency'] as String? ?? 'USD',
      notes: map['notes'] as String?,
      iconKey: map['icon_key'] as String?,
      colorHex: map['color_hex'] as String?,
      isActive: (map['is_active'] as int? ?? 1) == 1,
      deletedAt: map['deleted_at'] != null ? DateTime.parse(map['deleted_at'] as String) : null,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
      creditLimit: (map['credit_limit'] as num?)?.toDouble(),
      cardType: map['card_type'] as String?,
      linkedBankAccountId: map['linked_bank_account_id'] as int?,
    );
  }

  // Equality by id — without this, every DropdownButtonFormField in
  // the app that picks an AccountModel (Add Transaction, Transfer,
  // Credit Card's Bank picker, etc.) falls back to Dart's default
  // identity equality. That's fragile the moment two different
  // AccountModel instances for the same row end up being compared
  // (e.g. a selected value computed from one list snapshot, checked
  // against items built from another) — Flutter's Dropdown then
  // throws "zero or 2+ items with the same value" even though, to the
  // user, it's obviously the same account. Comparing by id makes that
  // comparison correct everywhere, permanently.
  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    // Guards two different not-yet-saved accounts (id still null)
    // from being treated as equal to each other.
    return other is AccountModel && id != null && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
