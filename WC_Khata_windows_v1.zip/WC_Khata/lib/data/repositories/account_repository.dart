import '../../core/services/data_events.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../models/account_model.dart';

class AccountRepository {
  Future<Database> get _db async => AppDatabase.instance.database;

  /// Every normal read excludes soft-deleted (Recycle Bin) accounts —
  /// those only ever come back via [getDeleted]. [activeOnly] further
  /// narrows to accounts the user has marked Active (the ones usable
  /// for new transactions, transfers, etc.); the Accounts screen itself
  /// passes `activeOnly: false` so Inactive accounts still show there.
  Future<List<AccountModel>> getAll({bool activeOnly = true}) async {
    final db = await _db;
    final conditions = <String>['deleted_at IS NULL'];
    final args = <Object?>[];
    if (activeOnly) {
      conditions.add('is_active = ?');
      args.add(1);
    }
    final rows = await db.query(
      DBConstants.tableAccounts,
      where: conditions.join(' AND '),
      whereArgs: args,
      orderBy: 'created_at ASC',
    );
    return rows.map(AccountModel.fromMap).toList();
  }

  /// Accounts currently in the Recycle Bin, most recently deleted first.
  Future<List<AccountModel>> getDeleted() async {
    final db = await _db;
    final rows = await db.query(
      DBConstants.tableAccounts,
      where: 'deleted_at IS NOT NULL',
      orderBy: 'deleted_at DESC',
    );
    return rows.map(AccountModel.fromMap).toList();
  }

  /// Every account that has ever existed — active, inactive, and even
  /// soft-deleted (Recycle Bin) — with no filtering at all. Used only
  /// to build an id → name lookup for History/Reports, so an old
  /// transaction still shows the right account name even if that
  /// account was later deactivated or deleted.
  Future<Map<int, AccountModel>> getAllForLookup() async {
    final db = await _db;
    final rows = await db.query(DBConstants.tableAccounts);
    final accounts = rows.map(AccountModel.fromMap).toList();
    return {for (final a in accounts) if (a.id != null) a.id!: a};
  }

  Future<AccountModel?> getById(int id) async {
    final db = await _db;
    final rows = await db.query(DBConstants.tableAccounts, where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return AccountModel.fromMap(rows.first);
  }

  /// Cash/Bank/Wallet money you actually have — excludes Person (a
  /// debt relationship, not cash in hand — see [getReceivablePayableTotals])
  /// and Credit Card (money you'd be borrowing, not money you have).
  /// The app has one money account only: Cash. This is intentionally
  /// hidden from the UI; the row is an internal balance ledger used to
  /// keep all cash-in/cash-out operations atomic.
  Future<AccountModel?> getDefaultCashAccount() async {
    final db = await _db;
    final rows = await db.query(
      DBConstants.tableAccounts,
      where: "type = 'cash' AND is_active = 1 AND deleted_at IS NULL",
      orderBy: 'created_at ASC',
      limit: 1,
    );
    if (rows.isNotEmpty) return AccountModel.fromMap(rows.first);

    final now = DateTime.now();
    final id = await db.insert(DBConstants.tableAccounts, {
      'name': 'Cash',
      'type': 'cash',
      'opening_balance': 0.0,
      'current_balance': 0.0,
      'currency': 'PKR',
      'notes': 'WC Khata default cash balance',
      'is_active': 1,
      'deleted_at': null,
      'created_at': now.toIso8601String(),
      'updated_at': now.toIso8601String(),
    });
    return getById(id);
  }

  Future<double> getAvailableBalance() async {
    final db = await _db;
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(current_balance), 0) as total FROM ${DBConstants.tableAccounts} '
      "WHERE is_active = 1 AND deleted_at IS NULL AND type = 'cash'",
    );
    return (result.first['total'] as num).toDouble();
  }

  /// Sum of every Credit Card's own balance (see
  /// AccountModel.availableCredit) — kept separate everywhere it's
  /// shown, since it's borrowed money, not money you actually have.
  Future<double> getCreditCardTotal() async {
    final db = await _db;
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(current_balance), 0) as total FROM ${DBConstants.tableAccounts} '
      "WHERE is_active = 1 AND deleted_at IS NULL AND type = 'credit_card'",
    );
    return (result.first['total'] as num).toDouble();
  }

  Future<int> create(AccountModel account) async {
    try {
    final db = await _db;
    return db.insert(DBConstants.tableAccounts, account.toMap());
      } finally {
      DataEvents.changed();
    }
  }

  Future<void> update(AccountModel account) async {
    try {
    final db = await _db;
    await db.update(
      DBConstants.tableAccounts,
      account.toMap(),
      where: 'id = ?',
      whereArgs: [account.id],
    );
      } finally {
      DataEvents.changed();
    }
  }

  Future<void> delete(int id) async {
    try {
    final db = await _db;
    await db.delete(DBConstants.tableAccounts, where: 'id = ?', whereArgs: [id]);
      } finally {
      DataEvents.changed();
    }
  }

  /// Soft delete — moves the account to the Recycle Bin instead of
  /// erasing it. It disappears from Accounts and every picker (getAll
  /// always excludes it) but its past transactions stay in History.
  Future<void> softDelete(int id) async {
    try {
    final db = await _db;
    await db.update(
      DBConstants.tableAccounts,
      {'deleted_at': DateTime.now().toIso8601String()},
      where: 'id = ?',
      whereArgs: [id],
    );
      } finally {
      DataEvents.changed();
    }
  }

  /// Restores an account out of the Recycle Bin. There is no permanent
  /// delete from the bin — restore is the only action available there.
  Future<void> restore(int id) async {
    try {
    final db = await _db;
    await db.update(
      DBConstants.tableAccounts,
      {'deleted_at': null},
      where: 'id = ?',
      whereArgs: [id],
    );
      } finally {
      DataEvents.changed();
    }
  }

  Future<void> setActive(int id, bool isActive) async {
    try {
    final db = await _db;
    await db.update(
      DBConstants.tableAccounts,
      {'is_active': isActive ? 1 : 0, 'updated_at': DateTime.now().toIso8601String()},
      where: 'id = ?',
      whereArgs: [id],
    );
      } finally {
      DataEvents.changed();
    }
  }

  /// Applies a signed delta to an account's balance inside the caller's
  /// transaction context (pass the same [Transaction] used for the
  /// related transaction insert so balance + ledger stay atomic).
  Future<void> applyBalanceDelta(DatabaseExecutor exec, int accountId, double delta) async {
    try {
    await exec.rawUpdate(
      'UPDATE ${DBConstants.tableAccounts} SET current_balance = current_balance + ?, updated_at = ? WHERE id = ?',
      [delta, DateTime.now().toIso8601String(), accountId],
    );
      } finally {
      DataEvents.changed();
    }
  }
}
