import 'package:sqflite/sqflite.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../../core/services/notification_service.dart';
import '../models/bill_model.dart';
import '../models/transaction_model.dart';
import 'transaction_repository.dart';

class BillRepository {
  final TransactionRepository _txRepo = TransactionRepository();

  Future<Database> get _db async => AppDatabase.instance.database;

  Future<List<BillModel>> getAll() async {
    final db = await _db;
    final rows = await db.query(DBConstants.tableBills, orderBy: 'due_date ASC');
    return rows.map(BillModel.fromMap).toList();
  }

  /// Inserts the bill, then schedules its due-date reminder (see
  /// [NotificationService]) now that it has a real id.
  Future<int> create(BillModel bill) async {
    final db = await _db;
    final id = await db.insert(DBConstants.tableBills, bill.toMap());
    await NotificationService.instance.scheduleBillNotification(
      BillModel.fromMap({...bill.toMap(), 'id': id}),
    );
    return id;
  }

  /// Updates the bill, then re-schedules its reminder — covers a
  /// changed due date, a toggled reminder switch, or anything else
  /// that changes when/whether it should fire.
  Future<void> update(BillModel bill) async {
    final db = await _db;
    await db.update(DBConstants.tableBills, bill.toMap(), where: 'id = ?', whereArgs: [bill.id]);
    await NotificationService.instance.scheduleBillNotification(bill);
  }

  /// Deletes the bill and cancels its reminder — also what
  /// [payBill] relies on to clean up a paid bill's notification.
  Future<void> delete(int id) async {
    final db = await _db;
    await db.delete(DBConstants.tableBills, where: 'id = ?', whereArgs: [id]);
    await NotificationService.instance.cancelBillNotification(id);
  }

  /// Pays a bill for real: posts a proper Expense transaction against
  /// [accountId] (so the account balance, History, Reports, and
  /// Transactions all pick it up exactly like any other expense), then
  /// removes the bill entirely — so it disappears from the Bills list
  /// and from the "payable" total the moment it's paid. The bill only
  /// ever lives on as that one Expense transaction, permanently, the
  /// same way every other piece of spending does.
  /// [amount] lets the payer override the bill's saved amount at
  /// payment time (e.g. the actual electricity bill came in higher or
  /// lower than what was entered when the bill was added). Falls back
  /// to the bill's own amount when not provided.
  Future<void> payBill(BillModel bill, {required int accountId, double? amount}) async {
    final now = DateTime.now();
    await _txRepo.create(TransactionModel(
      type: TransactionType.expense,
      amount: amount ?? bill.amount,
      accountId: accountId,
      note: 'Bill Payment: ${bill.name}',
      date: now,
      createdAt: now,
      updatedAt: now,
    ));
    await delete(bill.id!);
  }
}
