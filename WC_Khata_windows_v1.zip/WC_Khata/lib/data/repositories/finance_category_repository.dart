import 'package:sqflite/sqflite.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';

class FinanceCategory {
  final int id;
  final String name;
  final String? iconKey;
  final String? colorHex;
  const FinanceCategory({required this.id, required this.name, this.iconKey, this.colorHex});
}

class FinanceCategoryRepository {
  Future<Database> get _db async => AppDatabase.instance.database;

  Future<List<FinanceCategory>> getExpenseCategories() async {
    final db = await _db;
    final rows = await db.query(DBConstants.tableCategories, where: 'parent_id IS NULL', orderBy: 'name COLLATE NOCASE ASC');
    return rows.map((r) => FinanceCategory(id: r['id'] as int, name: r['name'] as String, iconKey: r['icon_key'] as String?, colorHex: r['color_hex'] as String?)).toList();
  }

  Future<int> create(String name, {String? iconKey, String? colorHex}) async {
    final db = await _db;
    final now = DateTime.now().toIso8601String();
    return db.insert(DBConstants.tableCategories, {
      'name': name.trim(), 'type': 'expense', 'parent_id': null,
      'icon_key': iconKey ?? 'payments_rounded', 'color_hex': colorHex,
      'is_default': 0, 'created_at': now,
    });
  }

  Future<bool> exists(String name, {int? excludeId}) async {
    final db = await _db;
    final rows = await db.query(
      DBConstants.tableCategories,
      columns: ['id'],
      where: 'parent_id IS NULL AND LOWER(name) = ?${excludeId != null ? ' AND id != ?' : ''}',
      whereArgs: [name.trim().toLowerCase(), if (excludeId != null) excludeId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<void> update(int id, String name) async {
    final db = await _db;
    await db.update(
      DBConstants.tableCategories,
      {'name': name.trim()},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> delete(int id) async {
    final db = await _db;
    await db.update(DBConstants.tableTransactions, {'category_id': null}, where: 'category_id = ?', whereArgs: [id]);
    await db.delete(DBConstants.tableCategories, where: 'id = ?', whereArgs: [id]);
  }
}
