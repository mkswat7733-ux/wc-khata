import '../../core/services/data_events.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../finance_rules.dart';
import '../models/transaction_model.dart';
import 'account_repository.dart';

class TransactionRepository {
  final AccountRepository _accountRepository = AccountRepository();

  Future<Database> get _db async => AppDatabase.instance.database;

  /// Creates a transaction and updates the affected account balance(s)
  /// atomically. Income adds to the account, expense subtracts, and a
  /// transfer moves money between two accounts without touching reports.
  Future<int> create(TransactionModel tx) async {
    try {
    _ensureWithinLimit(tx.amount);
    final db = await _db;
    late int insertedId;
    await db.transaction((txn) async {
      insertedId = await txn.insert(DBConstants.tableTransactions, tx.toMap());
      await _applyDelta(txn, tx, reverse: false);
    });
    return insertedId;
      } finally {
      DataEvents.changed();
    }
  }

  /// Last line of defence: no screen can store more than 1 Crore.
  static const double maxAmount = 10000000.0;
  void _ensureWithinLimit(double amount) {
    if (!amount.isFinite || amount > maxAmount) {
      throw ArgumentError.value(amount, 'amount', 'Amount must not exceed 1 crore (10,000,000).');
    }
  }

  Future<void> update(TransactionModel oldTx, TransactionModel newTx) async {
    try {
    _ensureWithinLimit(newTx.amount);
    final db = await _db;
    await db.transaction((txn) async {
      // Reverse the old effect, apply the new one, then persist the row.
      await _applyDelta(txn, oldTx, reverse: true);
      await txn.update(
        DBConstants.tableTransactions,
        newTx.toMap(),
        where: 'id = ?',
        whereArgs: [oldTx.id],
      );
      await _applyDelta(txn, newTx, reverse: false);
    });
      } finally {
      DataEvents.changed();
    }
  }

  Future<void> delete(TransactionModel tx) async {
    try {
    final db = await _db;
    await db.transaction((txn) async {
      await _applyDelta(txn, tx, reverse: true);
      await txn.delete(DBConstants.tableTransactions, where: 'id = ?', whereArgs: [tx.id]);
    });
      } finally {
      DataEvents.changed();
    }
  }

  Future<TransactionModel?> getById(int id) async {
    final db = await _db;
    final rows = await db.query(DBConstants.tableTransactions, where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return TransactionModel.fromMap(rows.first);
  }

  Future<void> _applyDelta(DatabaseExecutor exec, TransactionModel tx, {required bool reverse}) async {
    final sign = reverse ? -1 : 1;
    switch (tx.type) {
      case TransactionType.income:
        await _accountRepository.applyBalanceDelta(exec, tx.accountId, tx.amount * sign);
        break;
      case TransactionType.expense:
        await _accountRepository.applyBalanceDelta(exec, tx.accountId, -tx.amount * sign);
        break;
      case TransactionType.transfer:
        await _accountRepository.applyBalanceDelta(exec, tx.accountId, -tx.amount * sign);
        if (tx.toAccountId != null) {
          await _accountRepository.applyBalanceDelta(exec, tx.toAccountId!, tx.amount * sign);
        }
        break;
      case TransactionType.personSend:
        // A Send on a Person ledger means you gave money/value to them.
        // Their positive balance therefore grows: they owe you more.
        await _accountRepository.applyBalanceDelta(exec, tx.accountId, tx.amount * sign);
        break;
      case TransactionType.personReceive:
        // A Receive on a Person ledger means you received money/value from
        // them. Their balance moves down: an existing receivable is reduced
        // or a payable grows.
        await _accountRepository.applyBalanceDelta(exec, tx.accountId, -tx.amount * sign);
        break;
    }
  }

  Future<List<TransactionModel>> getAll({
    TransactionType? type,
    DateTime? from,
    DateTime? to,
    int? accountId,
    int? categoryId,
    int limit = 200,
    int offset = 0,
    bool excludePurchases = false,
  }) async {
    final db = await _db;
    final where = <String>[];
    final args = <Object?>[];

    if (type != null) {
      where.add('type = ?');
      args.add(type.value);
    }
    if (from != null) {
      where.add('date >= ?');
      args.add(from.toIso8601String());
    }
    if (to != null) {
      where.add('date <= ?');
      args.add(to.toIso8601String());
    }
    if (accountId != null) {
      where.add('(account_id = ? OR to_account_id = ?)');
      args.addAll([accountId, accountId]);
    }
    if (categoryId != null) {
      where.add('category_id = ?');
      args.add(categoryId);
    }
    if (excludePurchases) {
      // Stock purchases, supplier payments and customer refunds (or any
      // cash row created from a ledger entry) are not running expenses.
      where.add(FinanceRules.operatingOnlySql());
    }

    final rows = await db.query(
      DBConstants.tableTransactions,
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'date DESC, id DESC',
      limit: limit,
      offset: offset,
    );
    return rows.map(TransactionModel.fromMap).toList();
  }

  /// Money moved to/from Person accounts specifically, within a date
  /// range — "given" is what you transferred to a person (adds to what
  /// they owe you), "taken" is what you transferred out of a person's
  /// account (adds to what you owe them). Powers the Transfers section
  /// of Reports.
  Future<({double given, double taken})> personActivityInRange(DateTime from, DateTime to) async {
    final db = await _db;
    final givenRows = await db.rawQuery(
      '''
      SELECT COALESCE(SUM(t.amount), 0) as total FROM ${DBConstants.tableTransactions} t
      JOIN ${DBConstants.tableAccounts} a ON a.id = t.to_account_id
      WHERE t.type = 'transfer' AND a.type = 'person' AND t.date >= ? AND t.date <= ?
      ''',
      [from.toIso8601String(), to.toIso8601String()],
    );
    final takenRows = await db.rawQuery(
      '''
      SELECT COALESCE(SUM(t.amount), 0) as total FROM ${DBConstants.tableTransactions} t
      JOIN ${DBConstants.tableAccounts} a ON a.id = t.account_id
      WHERE t.type = 'transfer' AND a.type = 'person' AND t.date >= ? AND t.date <= ?
      ''',
      [from.toIso8601String(), to.toIso8601String()],
    );
    return (
      given: (givenRows.first['total'] as num).toDouble(),
      taken: (takenRows.first['total'] as num).toDouble(),
    );
  }

  Future<double> sumByTypeInRange(TransactionType type, DateTime from, DateTime to) async {
    final db = await _db;
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(amount), 0) as total FROM ${DBConstants.tableTransactions} '
      'WHERE type = ? AND date >= ? AND date <= ?',
      [type.value, from.toIso8601String(), to.toIso8601String()],
    );
    return (result.first['total'] as num).toDouble();
  }

  /// Expenses that reduce PROFIT: running costs only. Stock purchases,
  /// supplier payments and customer refunds are excluded because the cost of goods is already
  /// subtracted inside each sale's profit (sale price - cost price), so
  /// counting them again would understate profit.
  Future<double> sumOperatingExpenseInRange(DateTime from, DateTime to) async {
    final db = await _db;
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(amount), 0) as total FROM ${DBConstants.tableTransactions} '
      "WHERE type = 'expense' AND date >= ? AND date <= ? "
      'AND ${FinanceRules.operatingOnlySql()}',
      [from.toIso8601String(), to.toIso8601String()],
    );
    return (result.first['total'] as num).toDouble();
  }

  Future<List<Map<String, Object?>>> categoryBreakdown(
    TransactionType type,
    DateTime from,
    DateTime to,
  ) async {
    final db = await _db;
    return db.rawQuery(
      '''
      SELECT c.id as category_id, c.name as category_name, c.icon_key as icon_key,
             parent.name as parent_name,
             COALESCE(SUM(t.amount), 0) as total
      FROM ${DBConstants.tableTransactions} t
      JOIN ${DBConstants.tableCategories} c ON c.id = t.category_id
      LEFT JOIN ${DBConstants.tableCategories} parent ON parent.id = c.parent_id
      WHERE t.type = ? AND t.date >= ? AND t.date <= ?
      GROUP BY c.id
      ORDER BY total DESC
      ''',
      [type.value, from.toIso8601String(), to.toIso8601String()],
    );
  }

  /// Rolls income and expense up to the **main category** — a
  /// sub-category's amounts count against its parent — so each row is
  /// "how much did this business/source bring in vs cost". This is
  /// what powers the Profit/Loss-per-category report.
  Future<List<Map<String, Object?>>> categoryProfitLoss(DateTime from, DateTime to) async {
    final db = await _db;
    return db.rawQuery(
      '''
      SELECT
        COALESCE(parent.id, c.id) as main_id,
        COALESCE(parent.name, c.name) as main_name,
        COALESCE(parent.icon_key, c.icon_key) as icon_key,
        t.type as tx_type,
        COALESCE(SUM(t.amount), 0) as total
      FROM ${DBConstants.tableTransactions} t
      JOIN ${DBConstants.tableCategories} c ON c.id = t.category_id
      LEFT JOIN ${DBConstants.tableCategories} parent ON parent.id = c.parent_id
      WHERE t.date >= ? AND t.date <= ? AND t.type IN ('income', 'expense')
      GROUP BY main_id, t.type
      ''',
      [from.toIso8601String(), to.toIso8601String()],
    );
  }
}
