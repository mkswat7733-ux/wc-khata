import '../../core/utils/branding.dart';
import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/widgets/modern_header.dart';

class AboutScreen extends StatefulWidget {
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Animation<double> _reveal(int index) => CurvedAnimation(
        parent: _controller,
        curve: Interval((index * 0.12).clamp(0.0, 0.70), ((index * 0.12) + 0.35).clamp(0.0, 1.0), curve: Curves.easeOutCubic),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'About', onBack: () => Navigator.pop(context)),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(AppDimensions.spaceMd),
              children: [
                _animated(0, _heroCard()),
                const SizedBox(height: AppDimensions.spaceMd),
                _animated(1, _infoCard(Icons.verified_rounded, AppColors.income, 'Version', 'WC Khata ${Branding.appVersion}')),
                const SizedBox(height: AppDimensions.spaceSm),
                _animated(2, _infoCard(Icons.offline_bolt_rounded, AppColors.primary, 'Privacy', 'Your accounting records stay on this device and work offline.')),
                const SizedBox(height: AppDimensions.spaceSm),
                _animated(3, _infoCard(Icons.auto_awesome_rounded, AppColors.catEntertainment, 'Built for simplicity', 'Fast, clean and easy financial management for everyday use.')),
                const SizedBox(height: AppDimensions.spaceLg),
                _animated(4, Center(child: Text('© 2026 Webdsoft Company Private Limited', style: AppTextStyles.caption.copyWith(color: AppColors.lightTextSecondary)))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _animated(int index, Widget child) {
    final a = _reveal(index);
    return FadeTransition(
      opacity: a,
      child: SlideTransition(position: a.drive(Tween(begin: const Offset(0, 0.12), end: Offset.zero)), child: child),
    );
  }

  Widget _heroCard() => Container(
        padding: const EdgeInsets.all(AppDimensions.spaceLg),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: 0.065), blurRadius: 11, offset: const Offset(0, 4)),
            BoxShadow(color: Colors.white.withValues(alpha: 0.55), blurRadius: 3, offset: const Offset(-1, -1)),
          ],
        ),
        child: Column(
          children: [
            ClipRRect(borderRadius: BorderRadius.circular(20), child: Image.asset('assets/icons/app_icon.png', width: 84, height: 84)),
            const SizedBox(height: AppDimensions.spaceMd),
            const Text('WC Khata', style: AppTextStyles.h2),
            const SizedBox(height: 5),
            Text('Simple. Smart. Complete.', style: AppTextStyles.body.copyWith(color: AppColors.lightTextSecondary)),
          ],
        ),
      );

  Widget _infoCard(IconData icon, Color color, String title, String text) => Container(
        padding: const EdgeInsets.all(AppDimensions.spaceMd),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.065), blurRadius: 11, offset: const Offset(0, 4))],
        ),
        child: Row(children: [
          Container(width: 42, height: 42, decoration: BoxDecoration(color: color.withValues(alpha: 0.11), shape: BoxShape.circle), child: Icon(icon, color: color, size: 20)),
          const SizedBox(width: AppDimensions.spaceMd),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: AppTextStyles.bodyMedium.copyWith(fontWeight: FontWeight.w700)), const SizedBox(height: 3), Text(text, style: AppTextStyles.caption.copyWith(color: AppColors.lightTextSecondary))])),
        ]),
      );
}
