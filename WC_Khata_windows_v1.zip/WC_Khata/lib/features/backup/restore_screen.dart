import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../app/theme/app_theme.dart';
import '../../core/services/restore_service.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/modern_header.dart';
import '../../core/widgets/app_message.dart';

class RestoreScreen extends StatefulWidget {
  const RestoreScreen({super.key});

  @override
  State<RestoreScreen> createState() => _RestoreScreenState();
}

class _RestoreScreenState extends State<RestoreScreen> {
  final _service = RestoreService();
  bool _restoring = false;

  Future<bool> _confirmRestore() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Restore Backup'),
        content: const Text(
          'This will replace all current data on this device with the contents of the selected backup. This cannot be undone. Continue?',
        ),
        actions: [
          AppButton3D(label: 'Cancel', outlined: true, compact: true, onPressed: () => Navigator.pop(ctx, false)),
          AppButton3D(label: 'Restore', color: AppColors.expense, compact: true, onPressed: () => Navigator.pop(ctx, true)),
        ],
      ),
    );
    return confirmed == true;
  }

  Future<void> _pickAndRestore() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
    );
    if (result == null || result.files.single.path == null) return;
    if (!await _confirmRestore()) return;

    setState(() => _restoring = true);
    try {
      await _service.restoreFromFile(File(result.files.single.path!));
      if (mounted) {
        AppMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Restore complete. Please restart the app.')),
        );
      }
    } on RestoreValidationException catch (e) {
      if (mounted) AppMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } catch (e) {
      if (mounted) AppMessenger.of(context).showSnackBar(SnackBar(content: Text('Restore failed: $e')));
    } finally {
      if (mounted) setState(() => _restoring = false);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Restore Backup', onBack: () => Navigator.pop(context)),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(AppDimensions.spaceMd),
              children: [
                _card(
                  icon: Icons.folder_open_rounded,
                  title: 'Restore from backup file',
                  description: 'Choose a WC Khata JSON backup saved on this device.',
                  buttonLabel: _restoring ? 'Restoring...' : 'Select Backup File',
                  buttonIcon: Icons.find_in_page,
                  onPressed: _restoring ? null : _pickAndRestore,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _card({
    required IconData icon,
    required String title,
    required String description,
    required String buttonLabel,
    required IconData buttonIcon,
    required VoidCallback? onPressed,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppDimensions.spaceLg),
      decoration: BoxDecoration(
        color: AppColors.lightSurface,
        borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: .065), blurRadius: 11, offset: const Offset(0, 4)),
          BoxShadow(color: Colors.white.withValues(alpha: .70), blurRadius: 3, offset: const Offset(-1, -1)),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, size: 40, color: AppColors.primary),
          const SizedBox(height: AppDimensions.spaceMd),
          Text(title, style: AppTextStyles.h3, textAlign: TextAlign.center),
          const SizedBox(height: 4),
          Text(description, textAlign: TextAlign.center, style: AppTextStyles.caption.copyWith(color: AppColors.lightTextSecondary)),
          const SizedBox(height: AppDimensions.spaceLg),
          AppButton3D(
            label: buttonLabel,
            icon: buttonIcon,
            expand: true,
            onPressed: onPressed,
          ),
        ],
      ),
    );
  }
}
