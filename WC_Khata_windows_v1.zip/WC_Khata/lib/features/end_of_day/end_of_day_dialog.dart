import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../app/theme/app_theme.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/utils/currency_formatter.dart';
import '../../data/repositories/profile_repository.dart';
import '../printer/printer_gate.dart';
import 'end_of_day_pdf.dart';
import 'end_of_day_report.dart';
import 'end_of_day_service.dart';

/// The End of Day card.
///
///  * AUTOMATIC (12 AM): a finished day is waiting. The card cannot be
///    dismissed and has an "End Of Day" button - tapping it closes the day and
///    a fresh new day starts. Returns `true` when the day was closed.
///  * VIEW ONLY ([viewOnly], opened from the Home top bar): shows today so far
///    with Print / Download / Share. It has no End Of Day button and closes
///    nothing - the day always ends by itself at 12 AM.
class EndOfDayDialog extends StatefulWidget {
  final EndOfDayReport report;
  final bool viewOnly;
  const EndOfDayDialog({super.key, required this.report, this.viewOnly = false});

  static Future<bool?> show(BuildContext context, EndOfDayReport report, {bool viewOnly = false}) {
    return showDialog<bool>(
      context: context,
      barrierDismissible: viewOnly,
      barrierColor: Colors.black.withValues(alpha: .55),
      builder: (_) => PopScope(canPop: viewOnly, child: EndOfDayDialog(report: report, viewOnly: viewOnly)),
    );
  }

  @override
  State<EndOfDayDialog> createState() => _EndOfDayDialogState();
}

class _EndOfDayDialogState extends State<EndOfDayDialog> {
  static const MethodChannel _native = MethodChannel('wc_khata/whatsapp');
  static const _navy = Color(0xFF1B3C78);
  static const _navyLight = Color(0xFF2B5DAF);
  static const _green = Color(0xFF15803D);

  String? _busy; // 'print' | 'download' | 'share' | 'close'
  String? _status;
  bool _statusIsError = false;
  String _business = '';
  bool _closed = false;
  DateTime? _closedAt;
  Timer? _autoClose;

  EndOfDayReport get r => widget.report;

  @override
  void initState() {
    super.initState();
    ProfileRepository().getOrCreate().then((p) {
      if (!mounted) return;
      final n = p.name?.trim() ?? '';
      if (n.isNotEmpty) setState(() => _business = n);
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _autoClose?.cancel();
    super.dispose();
  }

  void _setStatus(String text, {bool error = false}) {
    if (!mounted) return;
    setState(() {
      _status = text;
      _statusIsError = error;
    });
  }

  Future<void> _run(String key, Future<void> Function() job) async {
    if (_busy != null) return;
    setState(() {
      _busy = key;
      _status = null;
    });
    try {
      await job();
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  // ----------------------------------------------------------------- print
  Future<void> _print() => _run('print', () async {
        if (!await PrinterGate.ensure(context)) return;
        try {
          final bytes = await EndOfDayPdf.build(r);
          await ThermalPrinterService.instance.printPdf(bytes);
          _setStatus('End of Day sent to the printer.');
        } on PrinterException catch (e) {
          _setStatus(e.message, error: true);
        } catch (_) {
          _setStatus('Could not print. Please try again.', error: true);
        }
      });

  // -------------------------------------------------------------- download
  Future<void> _download() => _run('download', () async {
        try {
          final Uint8List bytes = await EndOfDayPdf.build(r);
          final name = EndOfDayPdf.fileName(r);
          // The user picks WHERE to save (same "Save as" dialog as invoices).
          try {
            final path = await FilePicker.platform.saveFile(
              dialogTitle: 'Save End of Day report',
              fileName: name,
              type: FileType.custom,
              allowedExtensions: const ['pdf'],
              bytes: bytes,
            );
            if (path == null) {
              _setStatus('Save cancelled.');
            } else {
              _setStatus('End of Day card saved.');
            }
            return;
          } catch (_) {
            // fall through to the Downloads folder
          }
          final dir = await getTemporaryDirectory();
          final file = File('${dir.path}/$name');
          await file.writeAsBytes(bytes, flush: true);
          final saved = await _native.invokeMethod<String>('saveInvoicePdf', {'path': file.path, 'fileName': name});
          switch (saved) {
            case null:
              _setStatus('Could not save PDF. Please try again.', error: true);
            case 'permission_required':
              _setStatus('Storage permission is required. Please allow it and tap Download again.', error: true);
            default:
              _setStatus('Saved in Downloads.');
          }
        } catch (_) {
          _setStatus('Could not save PDF. Please try again.', error: true);
        }
      });

  // ----------------------------------------------------------------- share
  Future<void> _share() => _run('share', () async {
        try {
          final Uint8List bytes = await EndOfDayPdf.build(r);
          final dir = await getTemporaryDirectory();
          final file = File('${dir.path}/${EndOfDayPdf.fileName(r)}');
          await file.writeAsBytes(bytes, flush: true);
          await Share.shareXFiles([XFile(file.path, mimeType: 'application/pdf')], text: 'End of Day - ${DateFormat('dd MMM yyyy').format(r.day)}');
        } catch (_) {
          _setStatus('Could not share. Please try again.', error: true);
        }
      });

  // ------------------------------------------------------------ end of day
  Future<void> _closeDay() => _run('close', () async {
        try {
          await EndOfDayService.instance.closeDay(r);
          if (!mounted) return;
          setState(() {
            _closed = true;
            _closedAt = DateTime.now();
            _status = null;
          });
          HapticFeedback.mediumImpact();
          _autoClose = Timer(const Duration(milliseconds: 2600), () {
            if (mounted) Navigator.of(context).pop(true);
          });
        } catch (_) {
          _setStatus('Could not close the day. Please try again.', error: true);
        }
      });

  // -------------------------------------------------------------------- UI
  String _money(double v) => CurrencyFormatter.format(v);

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.symmetric(horizontal: 16 * s, vertical: 24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 440),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28 * s),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .25), blurRadius: 30, offset: const Offset(0, 14))],
          ),
          clipBehavior: Clip.antiAlias,
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 320),
            switchInCurve: Curves.easeOutBack,
            transitionBuilder: (child, anim) => FadeTransition(opacity: anim, child: ScaleTransition(scale: Tween(begin: .94, end: 1.0).animate(anim), child: child)),
            child: _closed ? _successView(s) : _reportView(s),
          ),
        ),
      ),
    );
  }

  /// Shown right after the day is closed.
  Widget _successView(double s) {
    final started = _closedAt ?? DateTime.now();
    return Padding(
      key: const ValueKey('closed'),
      padding: EdgeInsets.fromLTRB(22 * s, 30 * s, 22 * s, 22 * s),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: 1),
          duration: const Duration(milliseconds: 650),
          curve: Curves.elasticOut,
          builder: (_, v, child) => Transform.scale(scale: v, child: child),
          child: Container(
            width: 84 * s,
            height: 84 * s,
            decoration: BoxDecoration(
              color: _green.withValues(alpha: .12),
              shape: BoxShape.circle,
              border: Border.all(color: _green.withValues(alpha: .35), width: 2),
            ),
            child: Icon(Icons.check_rounded, color: _green, size: 48 * s),
          ),
        ),
        SizedBox(height: 18 * s),
        Text('Day Closed', style: TextStyle(fontSize: 24 * s, fontWeight: FontWeight.w900, color: AppColors.lightTextPrimary)),
        SizedBox(height: 4 * s),
        Text(
          r.periodLabel == null ? DateFormat('EEEE, dd MMM yyyy').format(r.day) : '${DateFormat('dd MMM yyyy').format(r.day)} - ${r.periodLabel}',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 11.5 * s, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary),
        ),
        SizedBox(height: 16 * s),
        Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 13 * s),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [_navy, _navyLight], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(18 * s),
          ),
          child: Row(children: [
            Container(
              width: 38 * s,
              height: 38 * s,
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: .16), shape: BoxShape.circle),
              child: Icon(Icons.wb_sunny_rounded, color: Colors.white, size: 21 * s),
            ),
            SizedBox(width: 11 * s),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('New Day Started', style: TextStyle(color: Colors.white, fontSize: 15 * s, fontWeight: FontWeight.w900)),
                SizedBox(height: 2 * s),
                Text(DateFormat('dd MMM yyyy, hh:mm a').format(started), style: TextStyle(color: Colors.white.withValues(alpha: .8), fontSize: 10.5 * s, fontWeight: FontWeight.w600)),
              ]),
            ),
          ]),
        ),
        SizedBox(height: 16 * s),
        SizedBox(
          width: double.infinity,
          height: 48 * s,
          child: ElevatedButton(
            onPressed: () {
              _autoClose?.cancel();
              Navigator.of(context).pop(true);
            },
            style: ElevatedButton.styleFrom(
              elevation: 0,
              backgroundColor: _green,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14 * s)),
            ),
            child: Text('Done', style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w900)),
          ),
        ),
      ]),
    );
  }

  Widget _reportView(double s) {
    return SingleChildScrollView(
      key: const ValueKey('report'),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
              _header(s),
              Padding(
                padding: EdgeInsets.fromLTRB(16 * s, 16 * s, 16 * s, 8 * s),
                child: Column(children: [
                  _netCard(s),
                  SizedBox(height: 10 * s),
                  Row(children: [
                    Expanded(child: _tile(s, 'Today Sale', _money(r.sales), Icons.point_of_sale_rounded, AppColors.primary)),
                    SizedBox(width: 10 * s),
                    Expanded(child: _tile(s, 'Expense', _money(r.expense), Icons.shopping_bag_outlined, AppColors.expense)),
                  ]),
                  SizedBox(height: 10 * s),
                  Row(children: [
                    Expanded(child: _tile(s, 'Today Pay', _money(r.paid), Icons.north_east_rounded, const Color(0xFFEA580C))),
                    SizedBox(width: 10 * s),
                    Expanded(child: _tile(s, 'Today Receive', _money(r.received), Icons.south_west_rounded, AppColors.income)),
                  ]),
                ]),
              ),
              AnimatedSize(
                duration: const Duration(milliseconds: 200),
                child: _status == null
                    ? const SizedBox(width: double.infinity)
                    : Padding(
                        padding: EdgeInsets.fromLTRB(18 * s, 2 * s, 18 * s, 0),
                        child: Row(children: [
                          Icon(_statusIsError ? Icons.error_outline_rounded : Icons.check_circle_rounded, size: 15 * s, color: _statusIsError ? AppColors.expense : _green),
                          SizedBox(width: 6 * s),
                          Expanded(child: Text(_status!, style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w700, color: _statusIsError ? AppColors.expense : _green))),
                        ]),
                      ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(16 * s, 12 * s, 16 * s, 16 * s),
                child: Column(children: [
                  Row(children: [
                    Expanded(child: _button(s, 'Print', Icons.print_rounded, Colors.black, Colors.white, _print, busyKey: 'print')),
                    SizedBox(width: 8 * s),
                    Expanded(child: _button(s, 'Download', Icons.download_rounded, Colors.white, Colors.black, _download, busyKey: 'download', outlined: true)),
                    SizedBox(width: 8 * s),
                    Expanded(child: _button(s, 'Share', Icons.share_rounded, const Color(0xFF2B5DAF), Colors.white, _share, busyKey: 'share')),
                  ]),
                  if (!widget.viewOnly) ...[
                    SizedBox(height: 10 * s),
                    SizedBox(
                      width: double.infinity,
                      child: _button(s, 'End Of Day', Icons.check_rounded, _green, Colors.white, _closeDay, busyKey: 'close'),
                    ),
                  ],
                ]),
              ),
            ]),
    );
  }

  Widget _header(double s) => Container(
        width: double.infinity,
        padding: EdgeInsets.fromLTRB(18 * s, 18 * s, 18 * s, 18 * s),
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [_navy, _navyLight], begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        child: Row(children: [
          Container(
            width: 46 * s,
            height: 46 * s,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .16), shape: BoxShape.circle),
            child: Icon(Icons.nights_stay_rounded, color: Colors.white, size: 24 * s),
          ),
          SizedBox(width: 12 * s),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('End of Day', style: TextStyle(color: Colors.white, fontSize: 19 * s, fontWeight: FontWeight.w900)),
              SizedBox(height: 2 * s),
              Text(DateFormat('EEEE, dd MMM yyyy').format(r.day), style: TextStyle(color: Colors.white.withValues(alpha: .85), fontSize: 11.5 * s, fontWeight: FontWeight.w600)),
              if (r.periodLabel != null)
                Text(r.periodLabel!, style: TextStyle(color: Colors.white.withValues(alpha: .75), fontSize: 10.5 * s, fontWeight: FontWeight.w700)),
              if (_business.isNotEmpty)
                Text(_business, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withValues(alpha: .65), fontSize: 10 * s, fontWeight: FontWeight.w600)),
            ]),
          ),
          if (widget.viewOnly)
            InkWell(
              customBorder: const CircleBorder(),
              onTap: _busy != null ? null : () => Navigator.of(context).pop(false),
              child: Padding(
                padding: EdgeInsets.all(6 * s),
                child: Icon(Icons.close_rounded, color: Colors.white, size: 22 * s),
              ),
            ),
        ]),
      );

  Widget _netCard(double s) {
    final loss = r.isLoss;
    final color = loss ? AppColors.expense : AppColors.income;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 13 * s),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .09),
        borderRadius: BorderRadius.circular(18 * s),
        border: Border.all(color: color.withValues(alpha: .35)),
      ),
      child: Row(children: [
        Container(
          width: 40 * s,
          height: 40 * s,
          decoration: BoxDecoration(color: color.withValues(alpha: .15), shape: BoxShape.circle),
          child: Icon(loss ? Icons.trending_down_rounded : Icons.trending_up_rounded, color: color, size: 22 * s),
        ),
        SizedBox(width: 11 * s),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(loss ? 'Today Loss' : 'Today Profit', style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextSecondary)),
            SizedBox(height: 2 * s),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(_money(loss ? r.loss : r.profit), style: TextStyle(fontSize: 22 * s, fontWeight: FontWeight.w900, color: color)),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _tile(double s, String label, String value, IconData icon, Color color) => Container(
        padding: EdgeInsets.all(12 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18 * s),
          border: Border.all(color: AppColors.lightCardBorder),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .045), blurRadius: 10 * s, offset: Offset(0, 4 * s))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 28 * s,
              height: 28 * s,
              decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(9 * s)),
              child: Icon(icon, size: 16 * s, color: color),
            ),
            SizedBox(width: 7 * s),
            Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextSecondary))),
          ]),
          SizedBox(height: 9 * s),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value, style: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w900, color: color)),
          ),
        ]),
      );

  Widget _button(double s, String text, IconData icon, Color bg, Color fg, VoidCallback onTap, {required String busyKey, bool outlined = false}) {
    final busy = _busy == busyKey;
    final disabled = _busy != null;
    return SizedBox(
      height: 48 * s,
      child: ElevatedButton(
        onPressed: disabled ? null : onTap,
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: bg,
          foregroundColor: fg,
          disabledBackgroundColor: bg.withValues(alpha: busy ? 1 : .55),
          disabledForegroundColor: fg.withValues(alpha: busy ? 1 : .6),
          padding: EdgeInsets.symmetric(horizontal: 6 * s),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14 * s),
            side: outlined ? BorderSide(color: Colors.black.withValues(alpha: .22), width: 1.2) : BorderSide.none,
          ),
        ),
        child: busy
            ? SizedBox(width: 18 * s, height: 18 * s, child: CircularProgressIndicator(strokeWidth: 2.2, color: fg))
            : FittedBox(
                fit: BoxFit.scaleDown,
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(icon, size: 16 * s),
                  SizedBox(width: 4 * s),
                  Text(text, style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w900)),
                ]),
              ),
      ),
    );
  }
}
