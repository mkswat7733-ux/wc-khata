import 'package:intl/intl.dart';

/// Snapshot of one business day (or the part of a day between two closings),
/// used by the End of Day popup, the PDF card and the saved closing history.
class EndOfDayReport {
  /// The period this report covers. A normal day is 12:00 AM -> 11:59 PM; if
  /// the user closes the day early the period is shorter.
  final DateTime from;
  final DateTime to;
  final double sales;
  final double expense;
  final double profit;
  final double loss;

  /// Money paid out through the ledger today (payments made to suppliers).
  final double paid;

  /// Money received through the ledger today (collected from customers).
  final double received;

  final int invoiceCount;
  final int cashSales;
  final int creditSales;
  final double availableBalance;
  final DateTime generatedAt;
  final DateTime? closedAt;

  const EndOfDayReport({
    required this.from,
    required this.to,
    required this.sales,
    required this.expense,
    required this.profit,
    required this.loss,
    required this.paid,
    required this.received,
    required this.invoiceCount,
    required this.cashSales,
    required this.creditSales,
    required this.availableBalance,
    required this.generatedAt,
    this.closedAt,
  });

  bool get isLoss => loss > 0;

  /// Calendar day the period belongs to.
  DateTime get day => DateTime(from.year, from.month, from.day);

  /// True when the report covers the whole 12 AM - 11:59 PM day.
  bool get isFullDay =>
      from.hour == 0 &&
      from.minute == 0 &&
      from.second == 0 &&
      to.year == from.year &&
      to.month == from.month &&
      to.day == from.day &&
      to.hour == 23 &&
      to.minute == 59;

  /// "12:00 AM - 03:30 PM" for early closings, `null` for full days.
  String? get periodLabel {
    if (isFullDay) return null;
    final f = DateFormat('hh:mm a');
    return '${f.format(from)} - ${f.format(to)}';
  }

  /// Unique id used by the history list.
  String get id => from.toIso8601String();

  /// Positive = profit, negative = loss.
  double get net => profit - loss;

  EndOfDayReport copyWith({DateTime? closedAt}) => EndOfDayReport(
        from: from,
        to: to,
        sales: sales,
        expense: expense,
        profit: profit,
        loss: loss,
        paid: paid,
        received: received,
        invoiceCount: invoiceCount,
        cashSales: cashSales,
        creditSales: creditSales,
        availableBalance: availableBalance,
        generatedAt: generatedAt,
        closedAt: closedAt ?? this.closedAt,
      );

  Map<String, dynamic> toJson() => {
        'from': from.toIso8601String(),
        'to': to.toIso8601String(),
        'sales': sales,
        'expense': expense,
        'profit': profit,
        'loss': loss,
        'paid': paid,
        'received': received,
        'invoiceCount': invoiceCount,
        'cashSales': cashSales,
        'creditSales': creditSales,
        'availableBalance': availableBalance,
        'generatedAt': generatedAt.toIso8601String(),
        'closedAt': closedAt?.toIso8601String(),
      };

  factory EndOfDayReport.fromJson(Map<String, dynamic> j) {
    double d(String k) => (j[k] as num?)?.toDouble() ?? 0;
    int i(String k) => (j[k] as num?)?.toInt() ?? 0;
    // Older saved reports only had a 'day'.
    final legacyDay = DateTime.tryParse(j['day']?.toString() ?? '');
    final from = DateTime.tryParse(j['from']?.toString() ?? '') ??
        (legacyDay == null ? DateTime.now() : DateTime(legacyDay.year, legacyDay.month, legacyDay.day));
    final to = DateTime.tryParse(j['to']?.toString() ?? '') ?? DateTime(from.year, from.month, from.day, 23, 59, 59, 999);
    return EndOfDayReport(
      from: from,
      to: to,
      sales: d('sales'),
      expense: d('expense'),
      profit: d('profit'),
      loss: d('loss'),
      paid: d('paid'),
      received: d('received'),
      invoiceCount: i('invoiceCount'),
      cashSales: i('cashSales'),
      creditSales: i('creditSales'),
      availableBalance: d('availableBalance'),
      generatedAt: DateTime.tryParse(j['generatedAt']?.toString() ?? '') ?? DateTime.now(),
      closedAt: DateTime.tryParse(j['closedAt']?.toString() ?? ''),
    );
  }
}
