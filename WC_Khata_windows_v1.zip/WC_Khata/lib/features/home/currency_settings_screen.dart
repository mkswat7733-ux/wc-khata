import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../app/theme/app_theme.dart';
import '../../app/user_preferences_controller.dart';
import '../../core/utils/currency_symbols.dart';
import '../../core/widgets/modern_header.dart';
import '../../data/repositories/profile_repository.dart';
import '../../core/widgets/app_message.dart';

class CurrencySettingsScreen extends StatefulWidget {
  const CurrencySettingsScreen({super.key});

  @override
  State<CurrencySettingsScreen> createState() => _CurrencySettingsScreenState();
}

class _CurrencySettingsScreenState extends State<CurrencySettingsScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animation;

  @override
  void initState() {
    super.initState();
    _animation = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();
  }

  @override
  void dispose() {
    _animation.dispose();
    super.dispose();
  }

  Future<void> _select(BuildContext context, String code) async {
    final repo = ProfileRepository();
    final profile = await repo.getOrCreate();
    final updated = profile.copyWith(currency: code);
    await repo.save(updated);
    if (context.mounted) {
      context.read<UserPreferencesController>().applyProfile(updated);
      AppMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Currency changed to $code')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final current = context.watch<UserPreferencesController>().currencyCode;
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Currency', subtitle: 'Choose your default currency', onBack: () => Navigator.pop(context)),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(AppDimensions.spaceMd),
              itemCount: kCurrencies.length,
              separatorBuilder: (_, __) => const SizedBox(height: AppDimensions.spaceSm),
              itemBuilder: (context, index) {
                final info = kCurrencies[index];
                final code = info.code;
                final symbol = info.symbol;
                final selected = code == current;
                final start = (index * 0.07).clamp(0.0, 0.7);
                final end = (start + 0.30).clamp(0.0, 1.0);
                final animation = CurvedAnimation(
                  parent: _animation,
                  curve: Interval(start, end, curve: Curves.easeOutCubic),
                );
                return FadeTransition(
                  opacity: animation,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.08),
                      end: Offset.zero,
                    ).animate(animation),
                    child: Material(
                  color: AppColors.lightSurface,
                  borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
                  child: InkWell(
                    onTap: selected ? null : () => _select(context, code),
                    borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
                        border: Border.all(color: selected ? AppColors.primary.withValues(alpha: 0.5) : Colors.transparent),
                        boxShadow: [
                          BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 10, offset: const Offset(0, 4)),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 42, height: 42, alignment: Alignment.center,
                            decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: 0.10), shape: BoxShape.circle),
                            child: Text(symbol, style: AppTextStyles.bodyMedium.copyWith(color: AppColors.primary, fontWeight: FontWeight.w700)),
                          ),
                          const SizedBox(width: AppDimensions.spaceMd),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('${info.flag}  $code', style: AppTextStyles.bodyMedium.copyWith(fontWeight: FontWeight.w700)),
                                Text(info.name, style: AppTextStyles.caption),
                              ],
                            ),
                          ),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 220),
                            width: 22,
                            height: 22,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: selected
                                    ? AppColors.primary
                                    : AppColors.lightTextSecondary.withValues(alpha: .45),
                                width: 2,
                              ),
                            ),
                            child: selected
                                ? Center(
                                    child: Container(
                                      width: 10,
                                      height: 10,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: AppColors.primary,
                                      ),
                                    ),
                                  )
                                : null,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
