import '../../core/services/data_events.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/utils/app_platform.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/services/app_navigator.dart';
import '../../core/services/notification_service.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/widgets/responsive.dart';
import '../notifications/notifications_screen.dart';
import '../more/expenses_screen.dart';
import 'home_controller.dart';
import '../end_of_day/end_of_day_dialog.dart';
import '../end_of_day/end_of_day_service.dart';
import '../../core/widgets/app_message.dart';

/// Main dashboard: balance card, today's sales/expenses, quick actions,
/// and today's profit/loss summary.
class HomeScreen extends StatefulWidget {
  /// Lets quick actions jump to another bottom-nav tab (1 Ledger,
  /// 2 Sale, 3 Items).
  final ValueChanged<int>? onOpenTab;

  const HomeScreen({super.key, this.onOpenTab});

  @override
  State<HomeScreen> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin, WidgetsBindingObserver {
  late final HomeController _controller;
  late final AnimationController _revealController;
  bool _isBalanceVisible = false;
  int _notificationCount = 0;
  bool _drawerOpen = false;

  // ---- End of Day (day closing at 12 AM) ----
  Timer? _eodTimer;
  VoidCallback? _unlistenData;
  bool _eodBusy = false;
  bool _tabActive = true;
  String? _eodCheckedDay; // last calendar day we found nothing to close

  /// Size factor from the screen width: <1 on small phones, >1 on large.
  double _s = 1.0;

  static const _navy = Color(0xFF1B3C78);
  static const _navyLight = Color(0xFF2B5DAF);

  @override
  void initState() {
    super.initState();
    _controller = HomeController();
    _controller.load();
    _unlistenData = DataEvents.listen(() { if (mounted) _controller.refresh(); });
    WidgetsBinding.instance.addObserver(this);
    // Cheap in-memory check every 20 s: the database is only touched once the
    // calendar day actually changes (i.e. right after 12 AM).
    _eodTimer = Timer.periodic(const Duration(seconds: 20), (_) => checkEndOfDay());
    WidgetsBinding.instance.addPostFrameCallback((_) => checkEndOfDay());
    _refreshNotificationCount();
    _revealController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..forward();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _eodTimer?.cancel();
    _unlistenData?.call();
    _revealController.dispose();
    _controller.dispose();
    super.dispose();
  }

  void replayEntrance() => _revealController.forward(from: 0);

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) checkEndOfDay();
  }

  /// Called by RootShell when the user switches bottom-nav tabs, so the popup
  /// only ever appears over Home and never interrupts a sale in progress.
  void onTabChanged(bool active) {
    _tabActive = active;
    if (active) checkEndOfDay();
  }

  /// Top-bar End of Day button. Normally it only SHOWS today's card (Print /
  /// Download / Share) - there is no End Of Day button on it, because the day
  /// ends by itself at 12 AM. If a finished day is still waiting to be closed,
  /// that day's card is shown instead, with the End Of Day button.
  Future<void> _manualEndOfDay() async {
    if (_eodBusy || !mounted) return;
    _eodBusy = true;
    try {
      final pending = await EndOfDayService.instance.pendingPeriod();
      final period = pending ?? await EndOfDayService.instance.currentPeriod();
      final report = await EndOfDayService.instance.build(from: period.from, to: period.to);
      if (!mounted) return;
      final closed = await EndOfDayDialog.show(context, report, viewOnly: pending == null);
      if (closed == true) await _controller.refresh();
    } catch (_) {
      if (mounted) {
        AppMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(content: Text('Could not open End of Day. Please try again.')));
      }
    } finally {
      _eodBusy = false;
    }
  }

  static String _dayKey(DateTime d) => '${d.year}-${d.month}-${d.day}';

  /// Shows the End of Day popup when a finished day is waiting to be closed.
  Future<void> checkEndOfDay() async {
    if (_eodBusy || !_tabActive || !mounted) return;
    final todayKey = _dayKey(DateTime.now());
    if (_eodCheckedDay == todayKey) return;
    final route = ModalRoute.of(context);
    if (route != null && !route.isCurrent) return;
    _eodBusy = true;
    try {
      while (mounted && _tabActive) {
        final current = ModalRoute.of(context);
        if (current != null && !current.isCurrent) return;
        final period = await EndOfDayService.instance.pendingPeriod();
        if (!mounted) return;
        if (period == null) {
          _eodCheckedDay = todayKey;
          return;
        }
        final report = await EndOfDayService.instance.build(from: period.from, to: period.to);
        if (!mounted) return;
        final closed = await EndOfDayDialog.show(context, report);
        if (closed != true) return;
        await _controller.refresh();
      }
    } catch (_) {
      // Never let day-closing problems break the Home screen.
    } finally {
      _eodBusy = false;
    }
  }

  /// Refreshes dashboard totals after ledger/customer payments change.
  Future<void> refreshLedgerTotals() => _controller.refresh();

  Animation<double> _stagger(int index) {
    final begin = (index * 0.14).clamp(0.0, 0.70);
    final end = (begin + 0.34).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _revealController,
      curve: Interval(begin, end, curve: Curves.easeOutCubic),
    );
  }

  Widget _reveal(int index, Widget child) {
    final anim = _stagger(index);
    return FadeTransition(
      opacity: anim,
      child: SlideTransition(
        position: anim.drive(Tween(begin: const Offset(0, 0.06), end: Offset.zero)),
        child: child,
      ),
    );
  }

  /// Opens the Expenses screen and refreshes the dashboard totals on return.
  Future<void> _openExpenses() async {
    await Navigator.push(context, AppTransitions.seamless(const ExpensesScreen()));
    if (mounted) await _controller.refresh();
  }

  void _openSidebar() => rootScaffoldKey.currentState?.openDrawer();

  Future<void> _refreshNotificationCount() async {
    try {
      final count = await NotificationService.instance.getUnreadCount();
      if (mounted) setState(() => _notificationCount = count);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    _s = (MediaQuery.of(context).size.width / 390).clamp(0.82, 1.2);
    return ChangeNotifierProvider.value(
      value: _controller,
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
          statusBarBrightness: Brightness.light,
          systemStatusBarContrastEnforced: false,
        ),
        child: Scaffold(
          backgroundColor: AppColors.lightBackground,
          onDrawerChanged: (isOpen) {
            if (mounted) setState(() => _drawerOpen = isOpen);
          },
          body: Consumer<HomeController>(
            builder: (context, c, _) {
              if (c.isLoading) {
                return Column(
                  children: [
                    _buildAppBar(context),
                    const Expanded(child: Center(child: CircularProgressIndicator())),
                  ],
                );
              }
              return Column(
                children: [
                  _buildAppBar(context),
                  Expanded(
                    child: RefreshIndicator(
                      color: AppColors.primary,
                      onRefresh: _controller.refresh,
                      child: ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: EdgeInsets.fromLTRB(14 * _s, 12 * _s, 14 * _s, 20 * _s),
                        children: [
                          _reveal(0, _buildBalanceCard(c)),
                          SizedBox(height: 10 * _s),
                          _reveal(1, _buildTodayRow(c)),
                          SizedBox(height: 18 * _s),
                          _reveal(2, _sectionLabel('QUICK ACTIONS')),
                          SizedBox(height: 10 * _s),
                          _reveal(3, _buildQuickActions()),
                          SizedBox(height: 18 * _s),
                          _reveal(4, _buildTodayProfitLoss(c)),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- top bar

  Widget _buildAppBar(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: AppColors.lightDivider)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppDimensions.spaceMd,
            vertical: AppDimensions.spaceSm,
          ),
          child: SizedBox(
            height: 45,
            child: Row(
              children: [
                if (!AppPlatform.isDesktop) ...[
                  AppGlassIconButton(
                    icon: Icons.menu_rounded,
                    iconColor: Colors.black,
                    rotationTurns: _drawerOpen ? 0.25 : 0.0,
                    onTap: _openSidebar,
                  ),
                  const SizedBox(width: 12),
                ],
                const Expanded(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'WC Khata',
                      maxLines: 1,
                      style: TextStyle(
                        color: AppColors.lightTextPrimary,
                        fontSize: 19,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Tooltip(
                  message: 'End of Day',
                  child: AppGlassIconButton(
                    icon: Icons.event_available_rounded,
                    iconColor: const Color(0xFF15803D),
                    onTap: _manualEndOfDay,
                  ),
                ),
                const SizedBox(width: 10),
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    AppGlassIconButton(
                      icon: Icons.notifications_none_rounded,
                      iconColor: Colors.black,
                      onTap: () async {
                        await Navigator.push(
                          context,
                          AppTransitions.slideFromTop(const NotificationsScreen()),
                        );
                        await _refreshNotificationCount();
                      },
                    ),
                    if (_notificationCount > 0)
                      Positioned(
                        right: -2,
                        top: -3,
                        child: Container(
                          constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                          padding: const EdgeInsets.symmetric(horizontal: 5),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: const Color(0xFFE53935),
                            borderRadius: BorderRadius.circular(99),
                            border: Border.all(color: Colors.white, width: 1.5),
                          ),
                          child: Text(
                            _notificationCount > 99 ? '99+' : '$_notificationCount',
                            style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Padding(
      padding: EdgeInsets.only(left: 4 * _s),
      child: Text(
        text,
        style: TextStyle(
          color: const Color(0xFF475467),
          fontSize: 12 * _s,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.1,
        ),
      ),
    );
  }

  // ------------------------------------------------------------ balance card

  Widget _amountText(String value, {required double size, FontWeight weight = FontWeight.w800, Color color = Colors.white}) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 260),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeInCubic,
      transitionBuilder: (child, animation) => FadeTransition(opacity: animation, child: child),
      child: _isBalanceVisible
          ? AutoSizeText(
              value,
              key: ValueKey('v_$value'),
              style: TextStyle(color: color, fontSize: size, fontWeight: weight, letterSpacing: -0.3),
            )
          : Text(
              '******',
              key: const ValueKey('hidden'),
              style: TextStyle(color: color.withValues(alpha: 0.8), fontSize: size * 0.8, fontWeight: weight, letterSpacing: 2),
            ),
    );
  }

  String _signed(double v) =>
      v < 0 ? '-${CurrencyFormatter.formatCompact(v.abs())}' : CurrencyFormatter.formatCompact(v);

  Widget _buildBalanceCard(HomeController c) {
    final s = _s;
    final double cash = c.cashbookBalance;
    // Net = Cashbook + Receivable - Payable
    final double net = cash + c.receivableTotal - c.payableTotal;
    final Color cashColor = cash < 0 ? const Color(0xFFFF6B6B) : Colors.white;
    final Color netColor = net < 0 ? const Color(0xFFFF8A80) : const Color(0xFF69F0AE);
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(14 * s),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_navy, _navyLight],
        ),
        borderRadius: BorderRadius.circular(22 * s),
        border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
        boxShadow: [
          BoxShadow(color: _navy.withValues(alpha: 0.30), blurRadius: 16 * s, offset: Offset(0, 8 * s)),
          BoxShadow(color: Colors.black.withValues(alpha: 0.10), blurRadius: 6, offset: const Offset(0, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36 * s,
                height: 36 * s,
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.14), shape: BoxShape.circle),
                child: Icon(Icons.account_balance_wallet_outlined, color: Colors.white, size: 18 * s),
              ),
              SizedBox(width: 10 * s),
              Expanded(
                child: Text(
                  'AVAILABLE BALANCE',
                  maxLines: 1,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.85),
                    fontSize: 11 * s,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
              InkWell(
                onTap: () => setState(() => _isBalanceVisible = !_isBalanceVisible),
                borderRadius: BorderRadius.circular(20),
                child: Padding(
                  padding: EdgeInsets.all(5 * s),
                  child: Icon(
                    _isBalanceVisible ? Icons.visibility_rounded : Icons.visibility_off_rounded,
                    color: Colors.white,
                    size: 18 * s,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 10 * s),
          SizedBox(
            height: 36 * s,
            child: Align(
              alignment: Alignment.centerLeft,
              child: _amountText(_signed(cash), size: 28 * s, color: cashColor),
            ),
          ),
          SizedBox(height: 10 * s),
          Row(
            children: [
              Expanded(
                child: _balanceTile(
                  label: 'Receivable',
                  amount: c.receivableTotal,
                  icon: Icons.arrow_downward_rounded,
                  iconColor: const Color(0xFF69F0AE),
                  onTap: () => widget.onOpenTab?.call(1),
                ),
              ),
              SizedBox(width: 10 * s),
              Expanded(
                child: _balanceTile(
                  label: 'Payable',
                  amount: c.payableTotal,
                  icon: Icons.arrow_upward_rounded,
                  iconColor: const Color(0xFFFF8A80),
                  onTap: () => widget.onOpenTab?.call(1),
                ),
              ),
            ],
          ),
          SizedBox(height: 10 * s),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 10 * s),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(15 * s),
              border: Border.all(color: Colors.white.withValues(alpha: 0.10)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'NET BALANCE',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.9),
                          fontSize: 11 * s,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.8,
                        ),
                      ),
                      SizedBox(height: 2 * s),
                      Text(
                        'Cashbook + Receivable - Payable',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.6),
                          fontSize: 9.5 * s,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 8 * s),
                Flexible(
                  child: SizedBox(
                    height: 24 * s,
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: _amountText(_signed(net), size: 18 * s, color: netColor),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _balanceTile({
    required String label,
    required double amount,
    required IconData icon,
    required Color iconColor,
    VoidCallback? onTap,
  }) {
    final s = _s;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 9 * s),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(15 * s),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: iconColor, size: 14 * s),
              SizedBox(width: 5 * s),
              Text(
                label,
                style: TextStyle(color: Colors.white.withValues(alpha: 0.85), fontSize: 11.5 * s, fontWeight: FontWeight.w500),
              ),
            ],
          ),
          SizedBox(height: 5 * s),
          SizedBox(
            height: 20 * s,
            child: Align(
              alignment: Alignment.centerLeft,
              child: _amountText(CurrencyFormatter.formatCompact(amount), size: 14.5 * s, weight: FontWeight.w700),
            ),
          ),
        ],
      ),
      ),
    );
  }

  // ------------------------------------------------------------- today cards

  Widget _buildTodayRow(HomeController c) {
    return Row(
      children: [
        Expanded(
          child: _todayCard(
            label: 'Today Sales',
            amount: c.todaySales,
            icon: Icons.point_of_sale_rounded,
            color: AppColors.primary,
            amountColor: AppColors.lightTextPrimary,
            onTap: () => widget.onOpenTab?.call(2),
          ),
        ),
        SizedBox(width: 10 * _s),
        Expanded(
          child: _todayCard(
            label: 'Today Expenses',
            amount: c.todayExpense,
            icon: Icons.receipt_long_rounded,
            color: AppColors.expense,
            amountColor: AppColors.expense,
            onTap: _openExpenses,
          ),
        ),
      ],
    );
  }

  /// Icon + label on the first line, the amount on its own full-width
  /// line underneath. A long amount therefore gets the whole card width
  /// and, if it is still too long, shrinks its font (never wraps, never
  /// overflows, never gets cut off).
  Widget _todayCard({
    required String label,
    required double amount,
    required IconData icon,
    required Color color,
    required Color amountColor,
    VoidCallback? onTap,
  }) {
    final s = _s;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
      padding: EdgeInsets.fromLTRB(12 * s, 10 * s, 12 * s, 10 * s),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 10 * s, offset: Offset(0, 4 * s)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30 * s,
                height: 30 * s,
                decoration: BoxDecoration(color: color.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(10 * s)),
                child: Icon(icon, color: color, size: 16 * s),
              ),
              SizedBox(width: 8 * s),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 11.5 * s, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
          SizedBox(height: 8 * s),
          SizedBox(
            width: double.infinity,
            child: AutoSizeText(
              CurrencyFormatter.formatCompact(amount),
              style: TextStyle(color: amountColor, fontSize: 16 * s, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
      ),
    );
  }

  // ----------------------------------------------------------- quick actions

  Widget _buildQuickActions() {
    void openTab(int i) => widget.onOpenTab?.call(i);
    return Row(
      children: [
        Expanded(
          child: _QuickAction3D(
            label: 'Customer',
            icon: Icons.person_add_alt_1_rounded,
            color: const Color(0xFF1B3C78),
            scale: _s,
            onTap: () => openTab(1),
          ),
        ),
        Expanded(
          child: _QuickAction3D(
            label: 'Sale POS',
            icon: Icons.shopping_cart_rounded,
            color: const Color(0xFF059669),
            scale: _s,
            onTap: () => openTab(2),
          ),
        ),
        Expanded(
          child: _QuickAction3D(
            label: 'Add Product',
            icon: Icons.inventory_2_rounded,
            color: const Color(0xFF6366F1),
            scale: _s,
            onTap: () => openTab(3),
          ),
        ),
        Expanded(
          child: _QuickAction3D(
            label: 'Expense',
            icon: Icons.attach_money_rounded,
            color: const Color(0xFFDC2626),
            scale: _s,
            onTap: _openExpenses,
          ),
        ),
      ],
    );
  }

  // ------------------------------------------------------------ today's profit & loss

  Widget _buildTodayProfitLoss(HomeController c) {
    final s = _s;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Todays Profit & Loss',
          style: TextStyle(
            color: AppColors.lightTextPrimary,
            fontSize: 15 * s,
            fontWeight: FontWeight.w900,
          ),
        ),
        SizedBox(height: 10 * s),
        Row(
          children: [
            Expanded(
              child: _profitLossTextCard(
                label: 'Profit',
                amount: c.todayProfit,
                color: const Color(0xFF16A34A),
              ),
            ),
            SizedBox(width: 10 * s),
            Expanded(
              child: _profitLossTextCard(
                label: 'Loss',
                amount: c.todayLoss,
                color: AppColors.expense,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _profitLossTextCard({
    required String label,
    required double amount,
    required Color color,
  }) {
    final s = _s;
    return Container(
      padding: EdgeInsets.fromLTRB(12 * s, 11 * s, 12 * s, 12 * s),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 10 * s,
            offset: Offset(0, 4 * s),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: color,
              fontSize: 12 * s,
              fontWeight: FontWeight.w800,
            ),
          ),
          SizedBox(height: 8 * s),
          AutoSizeText(
            CurrencyFormatter.formatCompact(amount),
            maxLines: 1,
            style: TextStyle(
              color: color,
              fontSize: 17 * s,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

/// White square card with a solid "edge" underneath and a soft shadow so
/// it looks like a raised 3D key; presses down when tapped. The icon is
/// drawn in its own full color. Everything scales with [scale].
class _QuickAction3D extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color color;
  final double scale;
  final VoidCallback onTap;

  const _QuickAction3D({
    required this.label,
    required this.icon,
    required this.color,
    required this.scale,
    required this.onTap,
  });

  @override
  State<_QuickAction3D> createState() => _QuickAction3DState();
}

class _QuickAction3DState extends State<_QuickAction3D> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final s = widget.scale;
    final face = 54 * s;
    final depth = 5 * s;
    final radius = 18 * s;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _pressed = true),
      onTapCancel: () => setState(() => _pressed = false),
      onTapUp: (_) => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: face,
            height: face + depth,
            child: Stack(
              children: [
                // Solid lower edge + drop shadow (the "thickness").
                Positioned(
                  left: 0,
                  right: 0,
                  top: depth,
                  height: face,
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFD3D9E4),
                      borderRadius: BorderRadius.circular(radius),
                      boxShadow: [
                        BoxShadow(color: Colors.black.withValues(alpha: 0.15), blurRadius: 10 * s, offset: Offset(0, 6 * s)),
                      ],
                    ),
                  ),
                ),
                // White top face.
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 90),
                  curve: Curves.easeOut,
                  left: 0,
                  right: 0,
                  top: _pressed ? depth - 2 : 0,
                  height: face,
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.white, Color(0xFFF4F6FA)],
                      ),
                      borderRadius: BorderRadius.circular(radius),
                      border: Border.all(color: Colors.white, width: 1.5),
                    ),
                    child: Icon(widget.icon, color: widget.color, size: 26 * s),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 6 * s),
          Text(
            widget.label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 11.5 * s, fontWeight: FontWeight.w800),
          ),
        ],
      ),
    );
  }
}
