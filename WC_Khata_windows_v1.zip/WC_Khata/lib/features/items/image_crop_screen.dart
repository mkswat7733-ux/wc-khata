import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/app_message.dart';
import '../../core/widgets/app_tab_screen.dart';

/// Crop screen shown right after a product picture is picked.
///
/// The picture is shown whole with a crop frame on top: drag a corner (or an
/// edge in Free mode) to resize it, drag inside it to move it. Free / 1:1 /
/// 4:3 / 3:4 shapes, Reset, and a Done button at the bottom.
///
/// Pops with the path of the cropped picture (a temporary PNG), or null when
/// the user goes back without cropping.
class ImageCropScreen extends StatefulWidget {
  final String path;
  const ImageCropScreen({super.key, required this.path});

  @override
  State<ImageCropScreen> createState() => _ImageCropScreenState();
}

enum _Grab { none, move, tl, tr, bl, br, left, top, right, bottom }

class _ImageCropScreenState extends State<ImageCropScreen> {
  static const double _minSide = 56; // smallest crop frame, in screen pixels
  static const double _slop = 28; // finger reach around a handle
  static const double _maxOutSide = 1200; // longest side of the saved picture

  static const _ratioLabels = ['Free', '1:1', '4:3', '3:4'];
  static const List<double?> _ratios = [null, 1.0, 4 / 3, 3 / 4];

  ui.Image? _image;
  bool _failed = false;
  bool _saving = false;

  /// Crop frame as fractions (0..1) of the picture, so it survives re-layout.
  Rect _n = const Rect.fromLTRB(.06, .06, .94, .94);
  int _ratioIndex = 0;

  Rect _bounds = Rect.zero; // where the picture is drawn on screen
  _Grab _grab = _Grab.none;
  Rect _startRect = Rect.zero;
  Offset _startPos = Offset.zero;

  double? get _ratio => _ratios[_ratioIndex];

  /// clamp that returns a double and never throws when the limits cross.
  static double _cl(double v, double lo, double hi) => v < lo ? lo : (v > hi ? hi : v);

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _image?.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final bytes = await File(widget.path).readAsBytes();
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      codec.dispose();
      if (!mounted) {
        frame.image.dispose();
        return;
      }
      setState(() => _image = frame.image);
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  // ------------------------------------------------------- coordinates

  Rect get _screenRect => Rect.fromLTRB(
        _bounds.left + _n.left * _bounds.width,
        _bounds.top + _n.top * _bounds.height,
        _bounds.left + _n.right * _bounds.width,
        _bounds.top + _n.bottom * _bounds.height,
      );

  void _setScreenRect(Rect r) {
    if (_bounds.width <= 0 || _bounds.height <= 0) return;
    setState(() {
      _n = Rect.fromLTRB(
        _cl((r.left - _bounds.left) / _bounds.width, 0, 1),
        _cl((r.top - _bounds.top) / _bounds.height, 0, 1),
        _cl((r.right - _bounds.left) / _bounds.width, 0, 1),
        _cl((r.bottom - _bounds.top) / _bounds.height, 0, 1),
      );
    });
  }

  // ---------------------------------------------------------- gestures

  _Grab _hit(Offset pos, Rect r) {
    if ((pos - r.topLeft).distance < _slop) return _Grab.tl;
    if ((pos - r.topRight).distance < _slop) return _Grab.tr;
    if ((pos - r.bottomLeft).distance < _slop) return _Grab.bl;
    if ((pos - r.bottomRight).distance < _slop) return _Grab.br;
    if (_ratio == null) {
      final inX = pos.dx > r.left && pos.dx < r.right;
      final inY = pos.dy > r.top && pos.dy < r.bottom;
      if (inX && (pos.dy - r.top).abs() < _slop / 1.5) return _Grab.top;
      if (inX && (pos.dy - r.bottom).abs() < _slop / 1.5) return _Grab.bottom;
      if (inY && (pos.dx - r.left).abs() < _slop / 1.5) return _Grab.left;
      if (inY && (pos.dx - r.right).abs() < _slop / 1.5) return _Grab.right;
    }
    if (r.contains(pos)) return _Grab.move;
    return _Grab.none;
  }

  void _onPanStart(DragStartDetails d) {
    _startRect = _screenRect;
    _startPos = d.localPosition;
    _grab = _hit(d.localPosition, _startRect);
  }

  void _onPanUpdate(DragUpdateDetails d) {
    if (_grab == _Grab.none) return;
    final delta = d.localPosition - _startPos;
    final r = _startRect;
    final b = _bounds;
    switch (_grab) {
      case _Grab.move:
        final dx = _cl(delta.dx, b.left - r.left, b.right - r.right);
        final dy = _cl(delta.dy, b.top - r.top, b.bottom - r.bottom);
        _setScreenRect(r.shift(Offset(dx, dy)));
        break;
      case _Grab.left:
        _setScreenRect(Rect.fromLTRB(_cl(r.left + delta.dx, b.left, r.right - _minSide), r.top, r.right, r.bottom));
        break;
      case _Grab.right:
        _setScreenRect(Rect.fromLTRB(r.left, r.top, _cl(r.right + delta.dx, r.left + _minSide, b.right), r.bottom));
        break;
      case _Grab.top:
        _setScreenRect(Rect.fromLTRB(r.left, _cl(r.top + delta.dy, b.top, r.bottom - _minSide), r.right, r.bottom));
        break;
      case _Grab.bottom:
        _setScreenRect(Rect.fromLTRB(r.left, r.top, r.right, _cl(r.bottom + delta.dy, r.top + _minSide, b.bottom)));
        break;
      case _Grab.tl:
      case _Grab.tr:
      case _Grab.bl:
      case _Grab.br:
        _setScreenRect(_dragCorner(r, delta));
        break;
      case _Grab.none:
        break;
    }
  }

  void _onPanEnd(DragEndDetails d) => _grab = _Grab.none;

  Rect _dragCorner(Rect r, Offset delta) {
    final b = _bounds;
    final left = _grab == _Grab.tl || _grab == _Grab.bl;
    final top = _grab == _Grab.tl || _grab == _Grab.tr;
    final anchor = Offset(left ? r.right : r.left, top ? r.bottom : r.top);
    final moved = Offset(
      _cl((left ? r.left : r.right) + delta.dx, b.left, b.right),
      _cl((top ? r.top : r.bottom) + delta.dy, b.top, b.bottom),
    );
    final ratio = _ratio;
    if (ratio == null) {
      final x1 = left ? math.min(moved.dx, anchor.dx - _minSide) : anchor.dx;
      final x2 = left ? anchor.dx : math.max(moved.dx, anchor.dx + _minSide);
      final y1 = top ? math.min(moved.dy, anchor.dy - _minSide) : anchor.dy;
      final y2 = top ? anchor.dy : math.max(moved.dy, anchor.dy + _minSide);
      return Rect.fromLTRB(x1, y1, x2, y2);
    }
    // Locked shape: keep the opposite corner fixed and follow the finger.
    var w = (moved.dx - anchor.dx).abs();
    var h = (moved.dy - anchor.dy).abs();
    if (h == 0 || w / h > ratio) {
      w = h * ratio;
    } else {
      h = w / ratio;
    }
    final maxW = left ? anchor.dx - b.left : b.right - anchor.dx;
    final maxH = top ? anchor.dy - b.top : b.bottom - anchor.dy;
    w = math.min(w, math.min(maxW, maxH * ratio));
    w = math.max(w, _minSide);
    h = w / ratio;
    return Rect.fromLTRB(
      left ? anchor.dx - w : anchor.dx,
      top ? anchor.dy - h : anchor.dy,
      left ? anchor.dx : anchor.dx + w,
      top ? anchor.dy : anchor.dy + h,
    );
  }

  // ------------------------------------------------------------ shapes

  void _pickRatio(int index) {
    setState(() => _ratioIndex = index);
    final ratio = _ratios[index];
    if (ratio == null || _bounds.width <= 0) return;
    final r = _screenRect;
    double w, h;
    if (r.width / r.height > ratio) {
      h = r.height;
      w = h * ratio;
    } else {
      w = r.width;
      h = w / ratio;
    }
    final c = r.center;
    var next = Rect.fromCenter(center: c, width: w, height: h);
    final b = _bounds;
    final dx = next.left < b.left ? b.left - next.left : (next.right > b.right ? b.right - next.right : 0.0);
    final dy = next.top < b.top ? b.top - next.top : (next.bottom > b.bottom ? b.bottom - next.bottom : 0.0);
    next = next.shift(Offset(dx, dy));
    _setScreenRect(next);
  }

  void _reset() {
    setState(() {
      _ratioIndex = 0;
      _n = const Rect.fromLTRB(.06, .06, .94, .94);
    });
  }

  // -------------------------------------------------------------- done

  Future<void> _done() async {
    final img = _image;
    if (img == null || _saving) return;
    setState(() => _saving = true);
    try {
      final iw = img.width.toDouble();
      final ih = img.height.toDouble();
      final src = Rect.fromLTRB(_n.left * iw, _n.top * ih, _n.right * iw, _n.bottom * ih);
      final scale = math.min(1.0, _maxOutSide / math.max(src.width, src.height));
      final outW = math.max(1, (src.width * scale).round());
      final outH = math.max(1, (src.height * scale).round());

      final recorder = ui.PictureRecorder();
      final canvas = Canvas(recorder);
      canvas.drawImageRect(
        img,
        src,
        Rect.fromLTWH(0, 0, outW.toDouble(), outH.toDouble()),
        Paint()
          ..filterQuality = FilterQuality.high
          ..isAntiAlias = true,
      );
      final picture = recorder.endRecording();
      final out = await picture.toImage(outW, outH);
      final data = await out.toByteData(format: ui.ImageByteFormat.png);
      out.dispose();
      picture.dispose();
      if (data == null) throw StateError('no data');

      final dir = await getTemporaryDirectory();
      final file = File(p.join(dir.path, 'crop_${DateTime.now().microsecondsSinceEpoch}.png'));
      await file.writeAsBytes(data.buffer.asUint8List(), flush: true);
      if (mounted) Navigator.pop(context, file.path);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not crop the image. Please try again.')));
      }
    }
  }

  // ------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    return AppTabScreen(
      title: 'Crop Image',
      onBack: () => Navigator.pop(context),
      body: Column(
        children: [
          Expanded(child: _canvas()),
          _controls(),
        ],
      ),
    );
  }

  Widget _canvas() {
    return Container(
      color: const Color(0xFF111418),
      width: double.infinity,
      child: _failed
          ? const Center(child: Text('Could not open this image.', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)))
          : _image == null
              ? const Center(child: CircularProgressIndicator())
              : LayoutBuilder(builder: (context, c) {
                  final area = Size(c.maxWidth, c.maxHeight);
                  const pad = 18.0;
                  final iw = _image!.width.toDouble();
                  final ih = _image!.height.toDouble();
                  final fit = math.min((area.width - pad * 2) / iw, (area.height - pad * 2) / ih);
                  final w = iw * fit;
                  final h = ih * fit;
                  _bounds = Rect.fromCenter(center: Offset(area.width / 2, area.height / 2), width: w, height: h);
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onPanStart: _onPanStart,
                    onPanUpdate: _onPanUpdate,
                    onPanEnd: _onPanEnd,
                    child: Stack(
                      children: [
                        Positioned.fromRect(
                          rect: _bounds,
                          child: RawImage(image: _image, fit: BoxFit.fill, filterQuality: FilterQuality.medium),
                        ),
                        Positioned.fill(
                          child: CustomPaint(painter: _CropPainter(bounds: _bounds, rect: _screenRect, showEdges: _ratio == null)),
                        ),
                      ],
                    ),
                  );
                }),
    );
  }

  Widget _controls() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.lightDivider))),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                for (var i = 0; i < _ratioLabels.length; i++) ...[
                  _chip(_ratioLabels[i], _ratioIndex == i, () => _pickRatio(i)),
                  const SizedBox(width: 8),
                ],
                const Spacer(),
                TextButton.icon(
                  onPressed: _saving ? null : _reset,
                  icon: const Icon(Icons.restart_alt_rounded, size: 18),
                  label: const Text('Reset'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            AppButton3D(
              label: _saving ? 'Saving...' : 'Done',
              icon: Icons.check_rounded,
              expand: true,
              onPressed: (_image == null || _saving) ? null : _done,
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(String label, bool selected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.lightBackground,
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: selected ? AppColors.primary : AppColors.lightDivider),
        ),
        child: Text(
          label,
          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: selected ? Colors.white : AppColors.lightTextPrimary),
        ),
      ),
    );
  }
}

class _CropPainter extends CustomPainter {
  final Rect bounds;
  final Rect rect;
  final bool showEdges;

  const _CropPainter({required this.bounds, required this.rect, required this.showEdges});

  @override
  void paint(Canvas canvas, Size size) {
    // Dim everything outside the crop frame.
    final outer = Path()..addRect(bounds);
    final inner = Path()..addRect(rect);
    canvas.drawPath(Path.combine(PathOperation.difference, outer, inner), Paint()..color = Colors.black.withValues(alpha: .58));

    // Frame.
    canvas.drawRect(
      rect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..color = Colors.white,
    );

    // Rule-of-thirds grid.
    final grid = Paint()
      ..strokeWidth = .8
      ..color = Colors.white.withValues(alpha: .55);
    for (var i = 1; i <= 2; i++) {
      final x = rect.left + rect.width * i / 3;
      final y = rect.top + rect.height * i / 3;
      canvas.drawLine(Offset(x, rect.top), Offset(x, rect.bottom), grid);
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), grid);
    }

    // Corner handles (L shapes) and, in Free mode, edge handles.
    final handle = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5
      ..strokeCap = StrokeCap.square
      ..color = Colors.white;
    const len = 24.0;
    final l = rect.left, t = rect.top, r = rect.right, b = rect.bottom;
    canvas.drawPath(Path()..moveTo(l, t + len)..lineTo(l, t)..lineTo(l + len, t), handle);
    canvas.drawPath(Path()..moveTo(r - len, t)..lineTo(r, t)..lineTo(r, t + len), handle);
    canvas.drawPath(Path()..moveTo(l, b - len)..lineTo(l, b)..lineTo(l + len, b), handle);
    canvas.drawPath(Path()..moveTo(r - len, b)..lineTo(r, b)..lineTo(r, b - len), handle);
    if (showEdges) {
      final cx = rect.center.dx, cy = rect.center.dy;
      canvas.drawLine(Offset(cx - 14, t), Offset(cx + 14, t), handle);
      canvas.drawLine(Offset(cx - 14, b), Offset(cx + 14, b), handle);
      canvas.drawLine(Offset(l, cy - 14), Offset(l, cy + 14), handle);
      canvas.drawLine(Offset(r, cy - 14), Offset(r, cy + 14), handle);
    }
  }

  @override
  bool shouldRepaint(covariant _CropPainter old) => old.rect != rect || old.bounds != bounds || old.showEdges != showEdges;
}
