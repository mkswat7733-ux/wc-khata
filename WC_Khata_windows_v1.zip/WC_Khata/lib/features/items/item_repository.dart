import '../../core/services/data_events.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/utils/unit_math.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';

class ItemRecord {
  final int id;
  final String name;
  final int? categoryId;
  final String category;
  final String unit;
  final double qty;
  final double lowStock;
  final double price;
  final String? imagePath;
  final String? barcode;
  final int? supplierId;
  final String? purchaseType;
  final double purchaseAmount;
  final double purchaseUnitPrice;
  final double purchasePaid;
  final DateTime? purchaseDate;
  /// false = "I do not manage quantity": no stock count, no low-stock alert,
  /// and sales never block or reduce anything for this product.
  final bool trackStock;

  /// Inner / Outer unit system. When [hasUnitSystem] the stock, cost price and
  /// sale price are all stored per INNER unit ([unit] is the inner unit name),
  /// and [unitsPerOuter] inner units make one outer unit (1 Box = 10 Strips).
  final String? outerUnit;
  final String? innerUnit;
  final double unitsPerOuter;

  const ItemRecord({
    required this.id,
    required this.name,
    required this.categoryId,
    required this.category,
    required this.unit,
    required this.qty,
    required this.lowStock,
    required this.price,
    required this.imagePath,
    required this.barcode,
    required this.supplierId,
    required this.purchaseType,
    required this.purchaseAmount,
    this.purchaseUnitPrice = 0,
    required this.purchasePaid,
    required this.purchaseDate,
    this.trackStock = true,
    this.outerUnit,
    this.innerUnit,
    this.unitsPerOuter = 1,
  });

  bool get hasUnitSystem =>
      (outerUnit ?? '').trim().isNotEmpty && (innerUnit ?? '').trim().isNotEmpty && unitsPerOuter > 0;

  /// Name of the unit [qty], [price] and the cost price are counted in.
  String get baseUnit => hasUnitSystem ? innerUnit! : unit;

  /// Stock as text: "50 Box 5 Strip" with the unit system, "12 Piece" without.
  String get stockText {
    if (hasUnitSystem) return UnitMath.describe(qty, unitsPerOuter, outerUnit!, innerUnit!);
    return '${UnitMath.fmt(qty, dp: 2)} $unit';
  }
}

class ItemCategory {
  final int id;
  final String name;
  const ItemCategory(this.id, this.name);
}

class ItemRepository {
  static const List<String> builtInCategories = <String>[
    'General',
    'Grocery',
    'Food & Beverages',
    'Clothing',
    'Electronics',
    'Cosmetics',
    'Pharmacy',
    'Stationery',
    'Hardware',
    'Home & Kitchen',
    'Mobile & Accessories',
    'Other',
  ];

  Future<List<ItemRecord>> getItems() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('''
      SELECT i.*, c.name AS category_name
      FROM ${DBConstants.tableItems} i
      LEFT JOIN ${DBConstants.tableItemCategories} c ON c.id=i.category_id
      ORDER BY i.created_at DESC
    ''');
    return rows.map((r) => ItemRecord(
      id: r['id'] as int,
      name: r['name'] as String,
      categoryId: r['category_id'] as int?,
      category: (r['category_name'] as String?) ?? 'General',
      unit: r['unit'] as String,
      qty: (r['qty'] as num).toDouble(),
      lowStock: (r['low_stock'] as num).toDouble(),
      price: (r['price'] as num).toDouble(),
      imagePath: r['image_path'] as String?,
      barcode: r['barcode'] as String?,
      supplierId: r['supplier_id'] as int?,
      purchaseType: r['purchase_type'] as String?,
      purchaseAmount: (r['purchase_amount'] as num?)?.toDouble() ?? 0,
      purchaseUnitPrice: (r['purchase_unit_price'] as num?)?.toDouble() ?? 0,
      purchasePaid: (r['purchase_paid'] as num?)?.toDouble() ?? 0,
      purchaseDate: r['purchase_date'] == null ? null : DateTime.tryParse(r['purchase_date'] as String),
      trackStock: ((r['track_stock'] as num?) ?? 1) != 0,
      outerUnit: r['outer_unit'] as String?,
      innerUnit: r['inner_unit'] as String?,
      unitsPerOuter: (r['units_per_outer'] as num?)?.toDouble() ?? 1,
    )).toList();
  }

  Future<ItemRecord?> getItemById(int id) async {
    final all = await getItems();
    for (final item in all) {
      if (item.id == id) return item;
    }
    return null;
  }

  /// The product that owns this barcode / QR value, or null.
  Future<ItemRecord?> getItemByBarcode(String barcode) async {
    final clean = barcode.trim();
    if (clean.isEmpty) return null;
    for (final item in await getItems()) {
      if ((item.barcode ?? '').trim() == clean) return item;
    }
    return null;
  }

  // The starter categories are added only once, so categories the user
  // deleted never come back by themselves.
  static const String categoriesSeededKey = 'item_categories_seeded';

  Future<List<ItemCategory>> getCategories() async {
    final db = await AppDatabase.instance.database;
    var rows = await db.query(DBConstants.tableItemCategories, orderBy: 'name COLLATE NOCASE');
    SharedPreferences? prefs;
    try {
      prefs = await SharedPreferences.getInstance();
    } catch (_) {} // the list must still work if saved settings are unavailable
    final alreadySeeded = prefs?.getBool(categoriesSeededKey) ?? (prefs == null && rows.isNotEmpty);
    if (!alreadySeeded) {
      if (rows.isEmpty) {
        final now = DateTime.now().toIso8601String();
        for (final name in builtInCategories) {
          await db.insert(DBConstants.tableItemCategories, {'name': name, 'created_at': now}, conflictAlgorithm: ConflictAlgorithm.ignore);
        }
        rows = await db.query(DBConstants.tableItemCategories, orderBy: 'name COLLATE NOCASE');
      }
      try {
        await prefs?.setBool(categoriesSeededKey, true);
      } catch (_) {}
    }
    return rows.map((r) => ItemCategory(r['id'] as int, r['name'] as String)).toList();
  }

  /// category id -> number of products in it.
  Future<Map<int, int>> categoryUsage() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('SELECT category_id AS id, COUNT(*) AS c FROM ${DBConstants.tableItems} WHERE category_id IS NOT NULL GROUP BY category_id');
    return {for (final r in rows) (r['id'] as int): (r['c'] as num).toInt()};
  }

  /// Renames a category. Returns false when the name is empty or taken.
  Future<bool> renameCategory(int id, String name) async {
    final clean = name.trim();
    if (clean.isEmpty) return false;
    final db = await AppDatabase.instance.database;
    final dup = await db.query(DBConstants.tableItemCategories, columns: const ['id'], where: 'LOWER(name) = ? AND id != ?', whereArgs: [clean.toLowerCase(), id], limit: 1);
    if (dup.isNotEmpty) return false;
    await db.update(DBConstants.tableItemCategories, {'name': clean}, where: 'id = ?', whereArgs: [id]);
    DataEvents.changed();
    return true;
  }

  /// Adds a category. Returns false when the name is empty or already exists.
  Future<bool> addCategoryChecked(String name) async {
    final clean = name.trim();
    if (clean.isEmpty) return false;
    final db = await AppDatabase.instance.database;
    final dup = await db.query(DBConstants.tableItemCategories, columns: const ['id'], where: 'LOWER(name) = ?', whereArgs: [clean.toLowerCase()], limit: 1);
    if (dup.isNotEmpty) return false;
    await getCategories(); // makes sure the starter list was handled first
    await db.insert(DBConstants.tableItemCategories, {'name': clean, 'created_at': DateTime.now().toIso8601String()});
    DataEvents.changed();
    return true;
  }

  /// Deletes a category. Its products are kept and show as "General"
  /// (category_id is set to NULL by the foreign key).
  Future<void> deleteCategory(int id) async {
    final db = await AppDatabase.instance.database;
    await db.update(DBConstants.tableItems, {'category_id': null}, where: 'category_id = ?', whereArgs: [id]);
    await db.delete(DBConstants.tableItemCategories, where: 'id = ?', whereArgs: [id]);
    DataEvents.changed();
  }

  Future<List<Map<String, Object?>>> getSuppliers() async {
    final db = await AppDatabase.instance.database;
    return db.query(DBConstants.tableLedgerParties, where: 'type = ?', whereArgs: ['supplier'], orderBy: 'name COLLATE NOCASE');
  }

  Future<bool> barcodeExists(String barcode, {int? excludingId}) async {
    final db = await AppDatabase.instance.database;
    final clean = barcode.trim();
    if (clean.isEmpty) return false;
    final rows = await db.query(
      DBConstants.tableItems,
      columns: const ['id'],
      where: excludingId == null ? 'barcode = ?' : 'barcode = ? AND id != ?',
      whereArgs: excludingId == null ? [clean] : [clean, excludingId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<int> addCategory(String name) async {
    try {
    final db = await AppDatabase.instance.database;
    return db.insert(DBConstants.tableItemCategories, {'name': name.trim(), 'created_at': DateTime.now().toIso8601String()});
      } finally {
      DataEvents.changed();
    }
  }

  /// Adds a product only. Buying stock is done on the Purchases screen, which
  /// also sets the cost price, so a new product starts with cost 0.
  Future<int> addItem({
    required String name,
    required int? categoryId,
    required String unit,
    required double qty,
    required double lowStock,
    required double price,
    String? imagePath,
    String? barcode,
    bool trackStock = true,
    String? outerUnit,
    String? innerUnit,
    double unitsPerOuter = 1,
  }) async {
    try {
      final db = await AppDatabase.instance.database;
      final now = DateTime.now().toIso8601String();
      return await db.insert(DBConstants.tableItems, {
        'name': name.trim(),
        'category_id': categoryId,
        'unit': unit,
        'qty': trackStock ? qty : 0,
        'low_stock': trackStock ? lowStock : 0,
        'price': price,
        'image_path': imagePath,
        'barcode': barcode?.trim().isEmpty == true ? null : barcode?.trim(),
        'track_stock': trackStock ? 1 : 0,
        'outer_unit': outerUnit,
        'inner_unit': innerUnit,
        'units_per_outer': unitsPerOuter > 0 ? unitsPerOuter : 1,
        'purchase_amount': 0,
        'purchase_unit_price': 0,
        'purchase_paid': 0,
        'created_at': now,
        'updated_at': now,
      });
    } finally {
      DataEvents.changed();
    }
  }

  /// Edits the product itself. Cost price and purchase history are never
  /// touched here - they belong to the Purchases screen.
  Future<void> updateItem({
    required int id,
    required String name,
    required int? categoryId,
    required String unit,
    double? qty, // null = leave the stock exactly as it is (stock only moves via Purchases / Sales)
    required double lowStock,
    required double price,
    String? imagePath,
    String? barcode,
    bool trackStock = true,
    String? outerUnit,
    String? innerUnit,
    double unitsPerOuter = 1,
  }) async {
    try {
      final db = await AppDatabase.instance.database;
      await db.update(DBConstants.tableItems, {
        'name': name.trim(),
        'category_id': categoryId,
        'unit': unit,
        if (!trackStock) 'qty': 0 else if (qty != null) 'qty': qty,
        'low_stock': trackStock ? lowStock : 0,
        'price': price,
        'image_path': imagePath,
        'barcode': barcode?.trim().isEmpty == true ? null : barcode?.trim(),
        'track_stock': trackStock ? 1 : 0,
        'outer_unit': outerUnit,
        'inner_unit': innerUnit,
        'units_per_outer': unitsPerOuter > 0 ? unitsPerOuter : 1,
        'updated_at': DateTime.now().toIso8601String(),
      }, where: 'id = ?', whereArgs: [id]);
      // Keep the product's name on its purchase history in step.
      await db.update(DBConstants.tablePurchases, {'item_name': name.trim(), 'unit': unit}, where: 'item_id = ?', whereArgs: [id]);
    } finally {
      DataEvents.changed();
    }
  }

  Future<void> deleteItem(int id) async {
    try {
    final db = await AppDatabase.instance.database;
    await db.delete(DBConstants.tableItems, where: 'id = ?', whereArgs: [id]);
      } finally {
      DataEvents.changed();
    }
  }
}
