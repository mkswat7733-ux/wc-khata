import '../../core/utils/currency_formatter.dart';
import '../../core/services/data_events.dart';
import '../../core/services/item_image_store.dart';
import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import 'new_item_screen.dart';
import 'item_repository.dart';
import 'barcode_label_screen.dart';
import 'label_batch_screen.dart';
import 'stock_in_report_screen.dart';
import 'stock_out_report_screen.dart';
import 'purchase_invoice_screen.dart';
import '../purchase_bill/select_supplier_screen.dart';
import '../purchase_bill/purchase_bill_repository.dart';
import '../sale/sale_invoice_screen.dart';
import '../ledger/ledger_repository.dart';
import '../../core/widgets/app_bottom_sheet.dart';
import '../purchases/purchase_repository.dart';
import '../../core/widgets/app_message.dart';

class ItemsScreen extends StatefulWidget {
  const ItemsScreen({super.key});
  @override State<ItemsScreen> createState() => ItemsScreenState();
}

class ItemsScreenState extends State<ItemsScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _animationController;
  final _repo = ItemRepository();
  List<ItemRecord> _items = [];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(vsync: this, duration: const Duration(milliseconds: 850))..forward();
    _loadItems();
    _unlistenData = DataEvents.listen(() { if (mounted) _loadItems(); });
  }

  VoidCallback? _unlistenData;

  /// Called by the root shell whenever the Products tab is opened (stock
  /// changes after sales, purchases and edits).
  void reload() => _loadItems();

  Future<void> _loadItems() async {
    final items = await _repo.getItems();
    if (mounted) setState(() => _items = items);
  }

  @override void dispose() { _unlistenData?.call(); _animationController.dispose(); super.dispose(); }

  Animation<double> _reveal(int index) {
    final begin = (index * .08).clamp(0.0, .55);
    return CurvedAnimation(parent: _animationController, curve: Interval(begin, (begin + .42).clamp(0.0, 1.0), curve: Curves.easeOutCubic));
  }

  Future<void> _edit(ItemRecord item) async {
    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => NewItemScreen(item: item)));
    if (saved == true) _loadItems();
  }

  void _label(ItemRecord item) {
    if ((item.barcode ?? '').trim().isEmpty) {
      AppMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('This product has no barcode. Add or scan one first.')));
      return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => BarcodeLabelScreen(item: item)));
  }

  /// Latest purchase receipt of this product (from a purchase bill or from
  /// the older single-product purchases, whichever is newer).
  Future<void> _view(ItemRecord item) async {
    final old = await PurchaseRepository().latestForItem(item.id);
    final billRepo = PurchaseBillRepository();
    final bill = await billRepo.latestBillRefForItem(item.id);
    if (!mounted) return;
    if (old == null && bill == null) {
      AppMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('No purchase receipt for this product yet. Use New Purchase to add one.')));
      return;
    }
    if (bill != null && (old == null || bill.date.isAfter(old.date))) {
      final saved = await billRepo.getById(bill.id);
      final supplierId = saved?.customerId;
      final supplier = supplierId == null ? null : await LedgerRepository().getPartyById(supplierId);
      if (!mounted || saved == null) return;
      await Navigator.push<bool>(context, MaterialPageRoute<bool>(builder: (_) => SaleInvoiceScreen(sale: saved, customerName: supplier?.name, isPurchaseBill: true)));
    } else if (old != null) {
      await Navigator.push<bool>(context, MaterialPageRoute<bool>(builder: (_) => PurchaseInvoiceScreen(purchase: old)));
    }
    if (mounted) _loadItems();
  }

  Future<void> _addProduct() async {
    final added = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const NewItemScreen()));
    if (added == true) _loadItems();
  }

  /// New Purchase: pick the supplier, then the products (quantity, cost and
  /// retail price are asked in a popup), then the bill is saved. Stock, prices,
  /// supplier ledger and Cashbook are all updated by the bill.
  Future<void> _newPurchase() async {
    await Navigator.push<void>(context, MaterialPageRoute(builder: (_) => const SelectSupplierScreen()));
    if (mounted) _loadItems();
  }

  Future<void> _openStockIn() async {
    await Navigator.push<void>(context, MaterialPageRoute(builder: (_) => const StockInReportScreen()));
    if (mounted) _loadItems();
  }

  Future<void> _openStockOut() async {
    await Navigator.push<void>(context, MaterialPageRoute(builder: (_) => const StockOutReportScreen()));
    if (mounted) _loadItems();
  }

  Future<void> _delete(ItemRecord item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Text('Delete Product?', style: TextStyle(fontWeight: FontWeight.w800)),
        content: Text('Delete "${item.name}" from your products?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE53935)), onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirmed != true) return;
    await _repo.deleteItem(item.id);
    if (mounted) {
      setState(() => _items.removeWhere((e) => e.id == item.id));
      AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Product deleted.')));
    }
  }

  /// Tap on a product: Edit / Label / View / Delete.
  void _openActions(ItemRecord item) {
    showAppBottomSheet<void>(
      context: context,
      builder: (ctx) {
        final s = (MediaQuery.sizeOf(ctx).width / 390).clamp(.82, 1.2).toDouble();
        Widget action(String text, IconData icon, Color color, VoidCallback onTap) => Expanded(
              child: Material(
                color: color.withValues(alpha: .10),
                borderRadius: BorderRadius.circular(14 * s),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14 * s),
                  onTap: () {
                    Navigator.pop(ctx);
                    onTap();
                  },
                  child: Container(
                    height: 74 * s,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: color.withValues(alpha: .22))),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(icon, color: color, size: 24 * s),
                      SizedBox(height: 5 * s),
                      Text(text, style: TextStyle(color: color, fontSize: 12 * s, fontWeight: FontWeight.w800)),
                    ]),
                  ),
                ),
              ),
            );
        return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(item.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 16 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
          SizedBox(height: 14 * s),
          Row(children: [
            action('Edit', Icons.edit_rounded, const Color(0xFF1976D2), () => _edit(item)),
            SizedBox(width: 10 * s),
            action('Label', Icons.label_rounded, AppColors.primary, () => _label(item)),
            SizedBox(width: 10 * s),
            action('View', Icons.receipt_long_rounded, const Color(0xFF12805C), () => _view(item)),
          ]),
          SizedBox(height: 10 * s),
          Material(
            color: const Color(0xFFE53935).withValues(alpha: .10),
            borderRadius: BorderRadius.circular(14 * s),
            child: InkWell(
              borderRadius: BorderRadius.circular(14 * s),
              onTap: () {
                Navigator.pop(ctx);
                _delete(item);
              },
              child: Container(
                height: 46 * s,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: const Color(0xFFE53935).withValues(alpha: .22))),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.delete_outline_rounded, color: const Color(0xFFE53935), size: 20 * s),
                  SizedBox(width: 6 * s),
                  Text('Delete', style: TextStyle(color: const Color(0xFFE53935), fontSize: 12.5 * s, fontWeight: FontWeight.w800)),
                ]),
              ),
            ),
          ),
        ]);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.of(context).size.width / 390).clamp(.82, 1.2);
    return Padding(
      padding: EdgeInsets.fromLTRB(14 * s, 14 * s, 14 * s, 10 * s),
      child: Column(children: [
        FadeTransition(opacity: _reveal(0), child: _summaryCards(s)),
        SizedBox(height: 10 * s),
        FadeTransition(opacity: _reveal(0), child: _stockButtons(s)),
        SizedBox(height: 10 * s),
        Expanded(child: FadeTransition(opacity: _reveal(1), child: _itemsContainer(s))),
        SizedBox(height: 10 * s),
        FadeTransition(opacity: _reveal(1), child: _bottomButtons(s)),
      ]),
    );
  }

  Widget _summaryCards(double s) => Row(children: [
    Expanded(child: _summaryCard(s, 'Total Products', '${_items.length}', AppColors.primary)),
    SizedBox(width: 10 * s),
    Expanded(child: _summaryCard(s, 'Total Supplier', '${_items.map((e) => e.supplierId).whereType<int>().toSet().length}', const Color(0xFF7C3AED))),
  ]);

  /// Small card: name on top, count below. No icon.
  Widget _summaryCard(double s, String title, String value, Color accent) => Container(
    width: double.infinity,
    padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 8 * s),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: AppColors.lightCardBorder, width: 1.2), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .045), blurRadius: 8 * s, offset: Offset(0, 3 * s))]),
    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: accent, fontSize: 11 * s, fontWeight: FontWeight.w800)),
      SizedBox(height: 2 * s),
      Text(value, style: TextStyle(color: accent, fontSize: 16 * s, fontWeight: FontWeight.w800)),
    ]),
  );

  /// Stock In Report (solid green, down arrow) and Stock Out Report (solid red, up arrow).
  Widget _stockButtons(double s) => Row(children: [
    Expanded(child: _WideButton(scale: s, label: 'Stock In Report', icon: Icons.arrow_downward_rounded, solid: const Color(0xFF16A34A), onTap: _openStockIn)),
    SizedBox(width: 10 * s),
    Expanded(child: _WideButton(scale: s, label: 'Stock Out Report', icon: Icons.arrow_upward_rounded, solid: const Color(0xFFDC2626), onTap: _openStockOut)),
  ]);

  /// New Purchase (left) and Add Product (right), below the products list.
  Widget _bottomButtons(double s) => Column(mainAxisSize: MainAxisSize.min, children: [
    Row(children: [
      Expanded(child: _WideButton(scale: s, label: 'New Purchase', icon: Icons.add_rounded, colors: const [Color(0xFFFBBF24), Color(0xFFF59E0B)], onTap: _newPurchase)),
      SizedBox(width: 10 * s),
      Expanded(child: _WideButton(scale: s, label: 'Add Product', icon: Icons.add_rounded, colors: const [Color(0xFF4C8DFF), AppColors.primary], onTap: _addProduct)),
    ]),
    SizedBox(height: 8 * s),
    _WideButton(scale: s, label: 'Print Labels (Multiple)', icon: Icons.label_rounded, solid: const Color(0xFF111827), onTap: _printLabels),
  ]);

  Future<void> _printLabels() async {
    await Navigator.push<void>(context, MaterialPageRoute(builder: (_) => const LabelBatchScreen()));
    if (mounted) _loadItems();
  }

  Widget _itemsContainer(double s) => Container(
    width: double.infinity,
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20 * s), border: Border.all(color: AppColors.lightCardBorder, width: 1.2), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .055), blurRadius: 14 * s, offset: Offset(0, 5 * s))]),
    clipBehavior: Clip.antiAlias,
    child: Stack(children: [
      Column(children: [
        Expanded(
          child: _items.isEmpty
              ? _emptyState(s)
              : ListView.builder(
                  padding: EdgeInsets.fromLTRB(8 * s, 4 * s, 8 * s, 8 * s),
                  physics: const ClampingScrollPhysics(),
                  itemCount: _items.length,
                  itemBuilder: (context, index) {
                    final a = _reveal(index + 2);
                    return FadeTransition(
                      opacity: a,
                      child: SlideTransition(
                        position: a.drive(Tween(begin: const Offset(0, .04), end: Offset.zero)),
                        child: _itemTile(s, _items[index]),
                      ),
                    );
                  },
                ),
        ),
      ]),
    ]),
  );

  Widget _emptyState(double s) => Center(child: Padding(padding: EdgeInsets.only(bottom: 50 * s), child: Column(mainAxisSize: MainAxisSize.min, children: [Container(width: 64 * s, height: 64 * s, decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), shape: BoxShape.circle), child: Icon(Icons.inventory_2_outlined, color: AppColors.primary, size: 31 * s)), SizedBox(height: 10 * s), Text('No products yet', style: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)), SizedBox(height: 4 * s), Text('Tap Add Product to add your first product', style: TextStyle(fontSize: 11 * s, color: AppColors.lightTextSecondary))])));

  /// One product row, Digi Khata style: small image, name + quantity on the
  /// left, the main (retail) price on the right. Tap opens Edit / Label / View.
  Widget _itemTile(double s, ItemRecord item) {
    final picked = ItemImageStore.resolve(item.imagePath);
    final out = item.trackStock && item.qty <= 0;
    final low = item.trackStock && !out && item.lowStock > 0 && item.qty <= item.lowStock;
    final qtyColor = out ? const Color(0xFFDC2626) : (low ? const Color(0xFFF59E0B) : AppColors.lightTextSecondary);
    return Material(
      color: Colors.white,
      child: InkWell(
        onTap: () => _openActions(item),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 6 * s, vertical: 9 * s),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
          child: Row(children: [
            Container(
              width: 44 * s,
              height: 44 * s,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(11 * s), border: Border.all(color: AppColors.lightCardBorder)),
              child: picked != null
                  ? Image.file(picked, fit: BoxFit.contain)
                  : Icon(Icons.inventory_2_outlined, color: AppColors.primary, size: 21 * s),
            ),
            SizedBox(width: 11 * s),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 13.5 * s, fontWeight: FontWeight.w800)),
                SizedBox(height: 3 * s),
                Text(
                  item.trackStock ? (out ? 'Out of stock' : item.stockText) : 'Quantity not managed',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: qtyColor, fontSize: 11 * s, fontWeight: FontWeight.w700),
                ),
              ]),
            ),
            SizedBox(width: 8 * s),
            ConstrainedBox(
              constraints: BoxConstraints(maxWidth: 120 * s),
              child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
                Text('${CurrencyFormatter.label} ${_money(item.price)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppColors.primary, fontSize: 14 * s, fontWeight: FontWeight.w900)),
                if (item.hasUnitSystem) Text('/ ${item.baseUnit}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 10 * s, fontWeight: FontWeight.w700)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  String _money(double value) => value.truncateToDouble() == value ? value.toInt().toString() : value.toStringAsFixed(2);
}

/// Full-width rounded button used for Stock In / Stock Out / New Purchase /
/// Add Product.
class _WideButton extends StatelessWidget {
  final double scale;
  final String label;
  final IconData icon;
  final List<Color> colors;
  final Color? solid; // full flat colour (no gradient) when set
  final VoidCallback onTap;
  const _WideButton({required this.scale, required this.label, required this.icon, this.colors = const [], this.solid, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14 * scale),
          child: Container(
            height: 46 * scale,
            decoration: BoxDecoration(
              color: solid,
              gradient: solid != null ? null : LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors),
              borderRadius: BorderRadius.circular(14 * scale),
              boxShadow: [BoxShadow(color: (solid ?? colors.last).withValues(alpha: .32), blurRadius: 10 * scale, offset: Offset(0, 4 * scale))],
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, color: Colors.white, size: 19 * scale),
              SizedBox(width: 5 * scale),
              Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white, fontSize: 12.5 * scale, fontWeight: FontWeight.w800))),
            ]),
          ),
        ),
      );
}
