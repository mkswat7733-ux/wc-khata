import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../app/theme/app_theme.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/widgets/app_message.dart';
import '../../data/repositories/profile_repository.dart';
import '../printer/printer_gate.dart';
import '../settings/label_designer_screen.dart';
import '../settings/label_sizes.dart';
import '../settings/template_service.dart';
import 'item_repository.dart';

/// Print labels for many products in ONE job: tick the products, set how many
/// labels each needs, and print. Each product's label uses the active label
/// template (size, text sizes, what is shown).
class LabelBatchScreen extends StatefulWidget {
  /// Product ids that start ticked.
  final Set<int> preselected;
  const LabelBatchScreen({super.key, this.preselected = const {}});

  @override
  State<LabelBatchScreen> createState() => _LabelBatchScreenState();
}

class _LabelBatchScreenState extends State<LabelBatchScreen> {
  static const int _maxLabels = 500;

  final _search = TextEditingController();
  final Map<int, int> _copies = {}; // ticked product id -> labels
  List<ItemRecord> _items = [];
  DocumentTemplate? _template;
  String _business = 'Business Name';
  bool _loading = true;
  bool _printing = false;
  int _done = 0, _total = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final items = await ItemRepository().getItems();
    final t = await TemplateService.instance.active(TemplateKind.label);
    final p = await ProfileRepository().getOrCreate();
    if (!mounted) return;
    setState(() {
      _items = items;
      _template = t;
      final n = p.name?.trim() ?? '';
      if (n.isNotEmpty) _business = n;
      for (final i in items) {
        if (widget.preselected.contains(i.id) && _hasCode(i)) _copies[i.id] = 1;
      }
      _loading = false;
    });
  }

  bool _hasCode(ItemRecord i) => (i.barcode ?? '').trim().isNotEmpty;

  List<ItemRecord> get _shown {
    final q = _search.text.trim().toLowerCase();
    if (q.isEmpty) return _items;
    return _items.where((i) => i.name.toLowerCase().contains(q) || (i.barcode ?? '').toLowerCase().contains(q)).toList();
  }

  int get _labelCount => _copies.values.fold(0, (a, b) => a + b);

  void _toast(String m) {
    if (!mounted) return;
    AppMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  void _toggle(ItemRecord i) {
    if (!_hasCode(i)) {
      _toast('This product has no barcode. Add or scan one first.');
      return;
    }
    setState(() {
      if (_copies.containsKey(i.id)) {
        _copies.remove(i.id);
      } else {
        _copies[i.id] = 1;
      }
    });
  }

  void _selectAll() {
    setState(() {
      for (final i in _shown) {
        if (_hasCode(i)) _copies.putIfAbsent(i.id, () => 1);
      }
    });
  }

  void _clear() => setState(_copies.clear);

  /// Labels = stock quantity (at least 1) for every ticked product.
  void _useStock() {
    setState(() {
      for (final i in _items) {
        if (_copies.containsKey(i.id)) {
          _copies[i.id] = i.qty.isFinite ? i.qty.round().clamp(1, 99) : 1;
        }
      }
    });
  }

  Future<void> _design() async {
    final t = _template;
    if (t == null) return;
    final r = await Navigator.push<DocumentTemplate>(context, MaterialPageRoute(builder: (_) => LabelDesignerScreen(template: t)));
    if (r != null) await _load();
  }

  Future<void> _print() async {
    final t = _template;
    if (_printing || t == null || _copies.isEmpty) return;
    if (_labelCount > _maxLabels) {
      _toast('Too many labels in one job. Keep it under $_maxLabels.');
      return;
    }
    if (!await PrinterGate.ensureLabel(context)) return;
    final chosen = _items.where((i) => _copies.containsKey(i.id)).toList();
    setState(() {
      _printing = true;
      _done = 0;
      _total = _labelCount;
    });
    try {
      final doc = pw.Document();
      final counts = <int>[];
      for (final i in chosen) {
        doc.addPage(LabelPdf.page(template: t, business: _business, product: i.name, code: (i.barcode ?? '').trim(), price: i.price));
        counts.add(_copies[i.id] ?? 1);
      }
      final bytes = Uint8List.fromList(await doc.save());
      await ThermalPrinterService.instance.printLabelPdf(
        bytes,
        widthMm: t.labelWidthMm,
        heightMm: t.labelHeightMm,
        pageCopies: counts,
        onProgress: (d, total) {
          if (mounted) setState(() => _done = d);
        },
      );
      _toast('$_total label${_total == 1 ? '' : 's'} sent to the label printer.');
    } on PrinterException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('Could not print the labels.');
    } finally {
      if (mounted) setState(() => _printing = false);
    }
  }

  // ------------------------------------------------------------------- ui

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        SafeArea(
          bottom: false,
          child: Container(
            height: 60 * s,
            padding: EdgeInsets.symmetric(horizontal: 12 * s),
            decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
            child: Row(children: [
              AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
              Expanded(child: Center(child: Text('Print Labels', style: TextStyle(fontSize: 18 * s, fontWeight: FontWeight.w900)))),
              SizedBox(width: 42 * s),
            ]),
          ),
        ),
        if (_loading)
          const Expanded(child: Center(child: CircularProgressIndicator()))
        else ...[
          _templateCard(s),
          _searchRow(s),
          Expanded(child: _shown.isEmpty ? _empty(s) : _list(s)),
          _bottomBar(s),
        ],
      ]),
    );
  }

  Widget _templateCard(double s) {
    final t = _template!;
    String n(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);
    final sample = _items.where((i) => _copies.containsKey(i.id)).toList();
    final first = sample.isEmpty ? null : sample.first;
    return Container(
      margin: EdgeInsets.fromLTRB(12 * s, 10 * s, 12 * s, 0),
      padding: EdgeInsets.all(10 * s),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18 * s), border: Border.all(color: AppColors.lightCardBorder)),
      child: Row(children: [
        Container(
          width: 120 * s,
          height: 82 * s,
          decoration: BoxDecoration(color: const Color(0xFFE9EDF2), borderRadius: BorderRadius.circular(12 * s)),
          padding: EdgeInsets.all(6 * s),
          child: FittedBox(
            fit: BoxFit.contain,
            child: LabelPreview(
              template: t,
              business: _business,
              product: first?.name ?? 'SAMPLE PRODUCT',
              code: (first?.barcode ?? '1234567890'),
              price: first?.price ?? 250,
            ),
          ),
        ),
        SizedBox(width: 11 * s),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13.5 * s, fontWeight: FontWeight.w900)),
            SizedBox(height: 2 * s),
            Text('${n(t.labelWidthMm)} × ${n(t.labelHeightMm)} mm', style: TextStyle(fontSize: 11 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w700)),
            SizedBox(height: 7 * s),
            SizedBox(
              height: 32 * s,
              child: OutlinedButton.icon(
                onPressed: _design,
                icon: Icon(Icons.tune_rounded, size: 15 * s),
                label: Text('Design label', style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w900)),
                style: OutlinedButton.styleFrom(padding: EdgeInsets.symmetric(horizontal: 10 * s), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10 * s))),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _searchRow(double s) => Padding(
        padding: EdgeInsets.fromLTRB(12 * s, 10 * s, 12 * s, 4 * s),
        child: Column(children: [
          TextField(
            controller: _search,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'Search product or barcode...',
              prefixIcon: const Icon(Icons.search_rounded, size: 20),
              filled: true,
              fillColor: Colors.white,
              contentPadding: EdgeInsets.symmetric(vertical: 10 * s),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(13 * s), borderSide: BorderSide(color: AppColors.lightCardBorder)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13 * s), borderSide: BorderSide(color: AppColors.lightCardBorder)),
            ),
          ),
          SizedBox(height: 7 * s),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              _chip(s, Icons.done_all_rounded, 'Select all', _selectAll),
              SizedBox(width: 7 * s),
              _chip(s, Icons.deselect_rounded, 'Clear', _copies.isEmpty ? null : _clear),
              SizedBox(width: 7 * s),
              _chip(s, Icons.inventory_rounded, 'Labels = stock qty', _copies.isEmpty ? null : _useStock),
            ]),
          ),
        ]),
      );

  Widget _chip(double s, IconData icon, String text, VoidCallback? onTap) => ActionChip(
        onPressed: onTap,
        avatar: Icon(icon, size: 15 * s, color: onTap == null ? Colors.grey : AppColors.primary),
        label: Text(text, style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w800)),
        backgroundColor: Colors.white,
        side: BorderSide(color: AppColors.lightCardBorder),
      );

  Widget _empty(double s) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.inventory_2_outlined, size: 38 * s, color: AppColors.lightTextSecondary),
          SizedBox(height: 8 * s),
          Text('No products found', style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w800)),
        ]),
      );

  Widget _list(double s) {
    final list = _shown;
    return ListView.builder(
      padding: EdgeInsets.fromLTRB(12 * s, 4 * s, 12 * s, 10 * s),
      itemCount: list.length,
      itemBuilder: (_, k) => _row(s, list[k]),
    );
  }

  Widget _row(double s, ItemRecord i) {
    final has = _hasCode(i);
    final on = _copies.containsKey(i.id);
    final c = _copies[i.id] ?? 1;
    return Opacity(
      opacity: has ? 1 : .5,
      child: Container(
        margin: EdgeInsets.only(bottom: 7 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15 * s),
          border: Border.all(color: on ? AppColors.primary.withValues(alpha: .55) : AppColors.lightCardBorder, width: on ? 1.5 : 1),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(15 * s),
          onTap: () => _toggle(i),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10 * s, vertical: 8 * s),
            child: Row(children: [
              Icon(on ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, color: on ? AppColors.primary : Colors.grey, size: 24 * s),
              SizedBox(width: 9 * s),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(i.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800)),
                  SizedBox(height: 2 * s),
                  Text(
                    has ? '${i.barcode}  •  ${CurrencyFormatter.label} ${i.price.truncateToDouble() == i.price ? i.price.toInt() : i.price.toStringAsFixed(2)}' : 'No barcode',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 10.5 * s, color: has ? AppColors.lightTextSecondary : AppColors.expense, fontWeight: FontWeight.w600),
                  ),
                ]),
              ),
              if (on) ...[
                _step(s, Icons.remove_rounded, c > 1 ? () => setState(() => _copies[i.id] = c - 1) : null),
                SizedBox(width: 30 * s, child: Center(child: Text('$c', style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w900)))),
                _step(s, Icons.add_rounded, c < 99 ? () => setState(() => _copies[i.id] = c + 1) : null),
              ],
            ]),
          ),
        ),
      ),
    );
  }

  Widget _step(double s, IconData icon, VoidCallback? onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9 * s),
        child: Container(
          width: 30 * s,
          height: 30 * s,
          decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: onTap == null ? .04 : .10), borderRadius: BorderRadius.circular(9 * s)),
          child: Icon(icon, size: 18 * s, color: onTap == null ? Colors.grey : AppColors.primary),
        ),
      );

  Widget _bottomBar(double s) {
    final n = _copies.length, m = _labelCount;
    return Container(
      padding: EdgeInsets.fromLTRB(14 * s, 9 * s, 14 * s, 10 * s),
      decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.lightDivider))),
      child: SafeArea(
        top: false,
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text('$n product${n == 1 ? '' : 's'}', style: TextStyle(fontSize: 11 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w700)),
              Text(_printing ? 'Printing $_done / $_total' : '$m label${m == 1 ? '' : 's'}', style: TextStyle(fontSize: 16 * s, fontWeight: FontWeight.w900)),
            ]),
          ),
          SizedBox(
            height: 48 * s,
            child: FilledButton.icon(
              onPressed: (_printing || n == 0) ? null : _print,
              icon: _printing
                  ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.print_rounded),
              label: Text(_printing ? 'Printing...' : 'Print Labels', style: const TextStyle(fontWeight: FontWeight.w900)),
              style: FilledButton.styleFrom(backgroundColor: Colors.black, padding: EdgeInsets.symmetric(horizontal: 20 * s), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14 * s))),
            ),
          ),
        ]),
      ),
    );
  }
}
