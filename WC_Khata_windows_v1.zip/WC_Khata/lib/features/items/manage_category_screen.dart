import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import 'item_repository.dart';
import '../../core/widgets/app_message.dart';

class ManageCategoryScreen extends StatefulWidget {
  const ManageCategoryScreen({super.key});
  @override State<ManageCategoryScreen> createState() => _ManageCategoryScreenState();
}
class _ManageCategoryScreenState extends State<ManageCategoryScreen> {
  final _repo = ItemRepository(); List<ItemCategory> _categories = [];
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async { final c=await _repo.getCategories(); if(mounted)setState(()=>_categories=c); }
  Future<void> _add() async {
    final controller=TextEditingController();
    final name=await showDialog<String>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Add Category'),content:TextField(controller:controller,autofocus:true,decoration:const InputDecoration(hintText:'Category name')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,controller.text.trim()),child:const Text('Add'))]));
    controller.dispose(); if(name==null||name.isEmpty)return; try{await _repo.addCategory(name);await _load();}catch(_){if(mounted)AppMessenger.of(context).showSnackBar(const SnackBar(content:Text('Category already exists.')));}
  }
  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:AppColors.lightBackground,appBar:AppBar(title:const Text('Manage Category'),leading:IconButton(icon:const Icon(Icons.arrow_back_rounded),onPressed:()=>Navigator.pop(context)),actions:[IconButton(onPressed:_add,icon:const Icon(Icons.add_rounded))]),body:ListView.separated(padding:const EdgeInsets.all(16),itemCount:_categories.length,separatorBuilder:(_,__)=>const SizedBox(height:8),itemBuilder:(context,i)=>Material(color:Colors.white,borderRadius:BorderRadius.circular(16),child:ListTile(shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)),leading:const CircleAvatar(child:Icon(Icons.category_rounded)),title:Text(_categories[i].name),trailing:const Icon(Icons.chevron_right_rounded),onTap:()=>Navigator.pop(context,_categories[i])))));
}
