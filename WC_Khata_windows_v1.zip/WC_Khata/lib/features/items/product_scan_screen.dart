import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../app/theme/app_theme.dart';
import '../../core/services/item_image_store.dart';
import '../../core/services/product_scan_service.dart';
import '../../core/services/product_text_reader.dart';
import '../../core/services/scanner_sound_service.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/app_message.dart';
import '../../core/widgets/app_tab_screen.dart';
import 'item_repository.dart';

/// Scan a product by its picture, like a barcode.
///
/// The phone camera opens; take a photo of the front of the pack. The words on
/// the pack are read and compared with the products. A clear match is returned
/// at once (the screen closes with that product). When the app is unsure it
/// shows the likely products to tap; the answer is learned for next time.
///
/// Pops with the chosen [ItemRecord], or null.
class ProductScanScreen extends StatefulWidget {
  final List<ItemRecord> items;
  const ProductScanScreen({super.key, required this.items});

  @override
  State<ProductScanScreen> createState() => _ProductScanScreenState();
}

class _ProductScanScreenState extends State<ProductScanScreen> {
  final ImagePicker _picker = ImagePicker();
  bool _busy = false;
  bool _disposed = false;
  bool _firstOpen = true;
  int _indexDone = 0;
  int _indexTotal = 0;

  @override
  void initState() {
    super.initState();
    unawaited(ScannerSoundService.instance.warmUp());
    _learnExistingPictures();
    // The camera opens straight away: one tap from the bill to the photo.
    WidgetsBinding.instance.addPostFrameCallback((_) => _takePhoto());
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  /// Products added before picture scanning existed: read their pictures once,
  /// in the background, so they can be recognised too.
  Future<void> _learnExistingPictures() async {
    try {
      await ProductScanService.instance.indexMissing(
        widget.items,
        onProgress: (done, total) {
          if (mounted) {
            setState(() {
              _indexDone = done;
              _indexTotal = total;
            });
          }
        },
        shouldStop: () => _disposed,
      );
    } catch (_) {}
    if (mounted) setState(() => _indexTotal = 0);
  }

  void _toast(String msg) {
    if (!mounted) return;
    AppMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(milliseconds: 1800)));
  }

  // -------------------------------------------------------------- scan

  Future<void> _takePhoto() async {
    if (_busy || !mounted) return;
    XFile? shot;
    try {
      shot = await _picker.pickImage(source: ImageSource.camera, imageQuality: 90, maxWidth: 1800);
    } catch (_) {
      _toast('Camera could not be opened. Please allow camera permission.');
      return;
    }
    if (!mounted) return;
    if (shot == null) {
      // Cancelled the camera. Right after opening, that means "I do not want
      // to scan": go back. Later it just stays here so the user can retry.
      if (_firstOpen) Navigator.pop(context);
      _firstOpen = false;
      return;
    }
    _firstOpen = false;
    await _process(shot.path);
  }

  Future<void> _process(String path) async {
    setState(() => _busy = true);
    try {
      var text = '';
      try {
        text = await ProductTextReader.readFullText(path);
      } catch (_) {}
      try {
        await File(path).delete();
      } catch (_) {}
      if (!mounted) return;

      final result = await ProductScanService.instance.match(text, widget.items);
      if (!mounted) return;

      if (result.confident) {
        unawaited(ScannerSoundService.instance.playBarcodeSuccess());
        Navigator.pop(context, result.ranked.first.item);
        return;
      }
      unawaited(ScannerSoundService.instance.playBarcodeError());
      if (result.words.isEmpty) {
        _toast('No text found. Take the photo closer to the front of the product.');
      } else if (result.ranked.isEmpty) {
        await _chooseFromAll(result.words);
      } else {
        await _showCandidates(result);
      }
    } catch (_) {
      _toast('Could not scan. Please try again.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _choose(ItemRecord item, Set<String> words) async {
    // Learn: next time this picture is recognised without asking.
    await ProductScanService.instance.learn(item.id, words);
    unawaited(ScannerSoundService.instance.playBarcodeSuccess());
    if (mounted) Navigator.pop(context, item);
  }

  Future<void> _showCandidates(ScanResult result) async {
    final picked = await showModalBottomSheet<Object>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.lightDivider, borderRadius: BorderRadius.circular(9)))),
              const SizedBox(height: 14),
              const Text('Which product is this?', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              const Text('Tap the right one. Next time it will be recognised automatically.',
                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary)),
              const SizedBox(height: 10),
              for (final m in result.ranked) _ProductTile(item: m.item, onTap: () => Navigator.pop(ctx, m.item)),
              const SizedBox(height: 6),
              OutlinedButton.icon(
                onPressed: () => Navigator.pop(ctx, 'all'),
                icon: const Icon(Icons.search_rounded),
                label: const Text('Not here? Choose from all products'),
              ),
            ],
          ),
        ),
      ),
    );
    if (!mounted) return;
    if (picked is ItemRecord) {
      await _choose(picked, result.words);
    } else if (picked == 'all') {
      await _chooseFromAll(result.words);
    }
  }

  Future<void> _chooseFromAll(Set<String> words) async {
    final picked = await showModalBottomSheet<ItemRecord>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => _PickerSheet(items: widget.items),
    );
    if (picked != null && mounted) await _choose(picked, words);
  }

  // ------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    return AppTabScreen(
      title: 'Scan Product',
      onBack: () => Navigator.pop(context),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            if (_indexTotal > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), borderRadius: BorderRadius.circular(99)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const SizedBox(width: 13, height: 13, child: CircularProgressIndicator(strokeWidth: 2)),
                  const SizedBox(width: 8),
                  Text('Learning your products $_indexDone/$_indexTotal', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
                ]),
              ),
            const Spacer(),
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), shape: BoxShape.circle),
              child: _busy
                  ? const Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator(strokeWidth: 3))
                  : const Icon(Icons.image_search_rounded, size: 44, color: AppColors.primary),
            ),
            const SizedBox(height: 18),
            Text(
              _busy ? 'Reading the product...' : 'Take a photo of the product',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            const Text(
              'Keep the front of the pack (name and brand) in the photo. The app finds the product and adds it, like a barcode.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12.5, height: 1.4, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary),
            ),
            const Spacer(),
            SafeArea(
              top: false,
              child: AppButton3D(
                label: _busy ? 'Please wait...' : 'Take Photo',
                icon: Icons.photo_camera_rounded,
                expand: true,
                onPressed: _busy ? null : _takePhoto,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProductTile extends StatelessWidget {
  final ItemRecord item;
  final VoidCallback onTap;
  const _ProductTile({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final img = ItemImageStore.resolve(item.imagePath);
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(children: [
          Container(
            width: 52,
            height: 52,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(color: AppColors.lightBackground, borderRadius: BorderRadius.circular(13)),
            child: img != null ? Image.file(img, fit: BoxFit.contain) : const Icon(Icons.inventory_2_rounded, color: AppColors.primary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text(CurrencyFormatter.formatCompact(item.price), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary)),
            ]),
          ),
          const Icon(Icons.chevron_right_rounded, color: AppColors.lightTextSecondary),
        ]),
      ),
    );
  }
}

/// Search + pick from all products (when no suggestion was right).
class _PickerSheet extends StatefulWidget {
  final List<ItemRecord> items;
  const _PickerSheet({required this.items});

  @override
  State<_PickerSheet> createState() => _PickerSheetState();
}

class _PickerSheetState extends State<_PickerSheet> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final q = _q.trim().toLowerCase();
    final list = q.isEmpty ? widget.items : widget.items.where((e) => e.name.toLowerCase().contains(q)).toList();
    final height = MediaQuery.sizeOf(context).height * .78;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
      child: SizedBox(
        height: height,
        child: Column(
          children: [
            const SizedBox(height: 12),
            Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.lightDivider, borderRadius: BorderRadius.circular(9))),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: Align(alignment: Alignment.centerLeft, child: Text('Choose the product', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                onChanged: (v) => setState(() => _q = v),
                decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Search product'),
              ),
            ),
            const SizedBox(height: 6),
            Expanded(
              child: list.isEmpty
                  ? const Center(child: Text('No product found', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary)))
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: list.length,
                      itemBuilder: (_, i) => _ProductTile(item: list[i], onTap: () => Navigator.pop(context, list[i])),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
