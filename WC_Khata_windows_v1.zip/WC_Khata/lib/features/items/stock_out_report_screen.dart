import 'package:flutter/material.dart';
import '../reports/report_repository.dart';
import '../reports/reports_screen.dart';

/// Stock Out Report: every product sold on a sale invoice (invoice, product,
/// customer, quantity, rate, amount) with From / To dates, search, Save /
/// Share / Print.
class StockOutReportScreen extends StatelessWidget {
  const StockOutReportScreen({super.key});

  @override
  Widget build(BuildContext context) => const ReportsScreen(
        initialType: ReportType.stockOut,
        singleType: true,
        title: 'Stock Out Report',
      );
}
