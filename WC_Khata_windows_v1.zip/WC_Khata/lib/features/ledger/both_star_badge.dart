import 'package:flutter/material.dart';

/// Golden star shown next to a party who is BOTH customer and supplier.
class BothStarBadge extends StatelessWidget {
  final double size;
  const BothStarBadge({super.key, this.size = 18});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: 'Customer & Supplier',
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: const Color(0xFFFFB300).withValues(alpha: .45), blurRadius: size * .55, spreadRadius: size * .02)],
        ),
        child: ShaderMask(
          blendMode: BlendMode.srcIn,
          shaderCallback: (rect) => const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFF3B0), Color(0xFFFFC107), Color(0xFFD48806)],
            stops: [0, .5, 1],
          ).createShader(rect),
          child: Icon(Icons.star_rounded, size: size, color: Colors.white),
        ),
      ),
    );
  }
}
