import 'package:flutter/foundation.dart';
import 'ledger_party.dart';
import 'ledger_repository.dart';

/// State for the Ledger screen: the customer / supplier lists, the active
/// tab and the search query.
///
/// The top Payable / Receivable totals always add up BOTH customers and
/// suppliers, whichever tab is open. The list only shows the active tab.
enum LedgerTab { customer, supplier, both }

class LedgerController extends ChangeNotifier {
  List<LedgerParty> _parties = const [];
  final LedgerRepository _repo = LedgerRepository();
  LedgerTab _tab = LedgerTab.customer;
  String _query = '';

  LedgerTab get tab => _tab;
  String get query => _query;

  /// Customer tab: customers only (not shared with a supplier row).
  List<LedgerParty> get customers => _parties.where((p) => p.type == LedgerPartyType.customer && p.linkedPartyId == null).toList();

  /// Supplier tab: suppliers only.
  List<LedgerParty> get suppliers => _parties.where((p) => p.type == LedgerPartyType.supplier && p.linkedPartyId == null).toList();

  /// Both tab: one entry per person (the customer row, whose balance is
  /// already netted against the linked supplier row = one khata).
  List<LedgerParty> get bothParties => _parties.where((p) => p.type == LedgerPartyType.customer && p.linkedPartyId != null).toList();

  int get customerCount => customers.length;
  int get supplierCount => suppliers.length;
  int get bothCount => bothParties.length;

  /// Customers + suppliers who owe us.
  Iterable<LedgerParty> get _balancePositions => _parties.where((p) => p.linkedPartyId == null || p.type == LedgerPartyType.customer);

  double get receivableTotal =>
      _balancePositions.where((p) => p.isReceivable).fold(0.0, (sum, p) => sum + p.balance.abs());

  /// Customers + suppliers we owe, counted once when the same person has both roles.
  double get payableTotal =>
      _balancePositions.where((p) => p.isPayable).fold(0.0, (sum, p) => sum + p.balance.abs());

  /// Parties of the active tab that match the search box.
  List<LedgerParty> get visibleParties {
    final q = _query.trim().toLowerCase();
    final list = _tab == LedgerTab.customer ? customers : (_tab == LedgerTab.supplier ? suppliers : bothParties);
    if (q.isEmpty) return list;
    return list
        .where((p) => p.name.toLowerCase().contains(q) || (p.phone ?? '').toLowerCase().contains(q))
        .toList();
  }

  /// Parties with an open balance - the ones a reminder makes sense for.
  List<LedgerParty> get remindable => _parties.where((p) => p.isReceivable).toList();

  Future<void> load() async {
    _parties = await _repo.getParties();
    notifyListeners();
  }

  void setParties(List<LedgerParty> parties) {
    _parties = parties;
    notifyListeners();
  }

  void setTab(LedgerTab t) {
    if (t == _tab) return;
    _tab = t;
    notifyListeners();
  }

  void setQuery(String q) {
    _query = q;
    notifyListeners();
  }
}
