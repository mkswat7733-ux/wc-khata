import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import 'both_star_badge.dart';
import 'ledger_party.dart';
import 'ledger_repository.dart';
import '../../core/widgets/app_message.dart';

/// Add a new party, or edit an existing one when [editing] is given.
/// The user picks the type here: Customer, Supplier or Both.
///
/// Pops `true` after adding. In edit mode pops the id (int) of the party row
/// the caller should keep showing.
class NewPartyScreen extends StatefulWidget {
  final LedgerPartyType type;
  final LedgerParty? editing;
  final String? initialName;
  final String? initialPhone;
  final PartyRole? initialRole;
  const NewPartyScreen({super.key, required this.type, this.editing, this.initialName, this.initialPhone, this.initialRole});

  @override
  State<NewPartyScreen> createState() => _NewPartyScreenState();
}

class _NewPartyScreenState extends State<NewPartyScreen> {
  final _repository = LedgerRepository();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _saving = false;
  late PartyRole _role;

  bool get _isEdit => widget.editing != null;

  @override
  void initState() {
    super.initState();
    final e = widget.editing;
    if (e != null) {
      _role = e.role;
      _nameController.text = e.name;
      _phoneController.text = e.phone ?? '';
    } else {
      _role = widget.initialRole ?? (widget.type == LedgerPartyType.customer ? PartyRole.customer : PartyRole.supplier);
      _nameController.text = widget.initialName ?? '';
      _phoneController.text = widget.initialPhone ?? '';
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving || !(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _saving = true);
    try {
      final phone = _phoneController.text.trim();
      if (_isEdit) {
        final keepId = await _repository.updateParty(
          partyId: widget.editing!.id!,
          name: _nameController.text,
          phone: phone.isEmpty ? null : phone,
          role: _role,
        );
        if (!mounted) return;
        Navigator.of(context).pop(keepId);
        return;
      }
      if (phone.isNotEmpty) {
        final roles = _role == PartyRole.both
            ? [LedgerPartyType.customer, LedgerPartyType.supplier]
            : [_role == PartyRole.customer ? LedgerPartyType.customer : LedgerPartyType.supplier];
        for (final t in roles) {
          final existing = await _repository.findPartyByPhone(phone: phone, type: t);
          if (existing != null) {
            if (mounted) _message('This ${t == LedgerPartyType.customer ? 'Customer' : 'Supplier'} is already added.');
            return;
          }
        }
      }
      await _repository.addParty(
        name: _nameController.text.trim(),
        phone: phone.isEmpty ? null : phone,
        type: widget.type,
        role: _role,
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on StateError catch (e) {
      if (mounted) _message(e.message);
    } catch (_) {
      if (mounted) _message('Could not save. Please try again.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _message(String value) {
    AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(value)));
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        SafeArea(bottom: false, child: Container(
          height: 58 * s,
          padding: EdgeInsets.symmetric(horizontal: 14 * s),
          decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
          child: Row(children: [
            AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
            Expanded(child: Center(child: Text(_isEdit ? 'Edit Details' : 'New Party', style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 19 * s, fontWeight: FontWeight.w700)))),
            SizedBox(width: 42 * s),
          ]),
        )),
        Expanded(child: SingleChildScrollView(
          padding: EdgeInsets.all(14 * s),
          child: Form(key: _formKey, child: Column(children: [
            _roleSelector(s),
            SizedBox(height: 14 * s),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16 * s),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20 * s), border: Border.all(color: AppColors.lightCardBorder, width: 1.2), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .05), blurRadius: 12 * s, offset: Offset(0, 5 * s))]),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _field(s, controller: _nameController, label: 'Name', hint: 'Enter name', icon: Icons.person_outline_rounded, validator: (v) => (v ?? '').trim().isEmpty ? 'Please enter a name' : null),
                SizedBox(height: 14 * s),
                _field(s, controller: _phoneController, label: 'Phone Number', hint: 'Enter phone number', icon: Icons.phone_outlined, keyboardType: TextInputType.phone),
              ]),
            ),
            SizedBox(height: 18 * s),
            SizedBox(width: double.infinity, height: 50 * s, child: FilledButton(
              onPressed: _saving ? null : _save,
              style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15 * s))),
              child: _saving ? SizedBox(width: 20 * s, height: 20 * s, child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(_isEdit ? 'Save Changes' : 'Save', style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800)),
            )),
          ])),
        )),
      ]),
    );
  }

  Widget _roleSelector(double s) {
    Widget chip(PartyRole r, String label, IconData icon) {
      final sel = _role == r;
      final gold = r == PartyRole.both;
      final accent = gold ? const Color(0xFFD48806) : AppColors.primary;
      return Expanded(child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => _role = r),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: EdgeInsets.symmetric(vertical: 11 * s),
          decoration: BoxDecoration(
            color: sel ? accent.withValues(alpha: .10) : AppColors.lightBackground,
            borderRadius: BorderRadius.circular(14 * s),
            border: Border.all(color: sel ? accent : AppColors.lightCardBorder, width: sel ? 1.6 : 1.2),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            gold ? BothStarBadge(size: 22 * s) : Icon(icon, size: 21 * s, color: sel ? accent : AppColors.lightTextSecondary),
            SizedBox(height: 5 * s),
            Text(label, style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w800, color: sel ? accent : AppColors.lightTextSecondary)),
          ]),
        ),
      ));
    }

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16 * s),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20 * s), border: Border.all(color: AppColors.lightCardBorder, width: 1.2), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .05), blurRadius: 12 * s, offset: Offset(0, 5 * s))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Type', style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 12.5 * s, fontWeight: FontWeight.w700)),
        SizedBox(height: 9 * s),
        Row(children: [
          chip(PartyRole.customer, 'Customer', Icons.person_rounded),
          SizedBox(width: 9 * s),
          chip(PartyRole.supplier, 'Supplier', Icons.local_shipping_rounded),
          SizedBox(width: 9 * s),
          chip(PartyRole.both, 'Both', Icons.star_rounded),
        ]),
        if (_role == PartyRole.both) ...[
          SizedBox(height: 9 * s),
          Text('Will appear in both Customer and Supplier lists (sales, add product, ledger).', style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 10.5 * s)),
        ],
      ]),
    );
  }

  Widget _field(double s, {required TextEditingController controller, required String label, required String hint, required IconData icon, TextInputType? keyboardType, String? Function(String?)? validator}) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 12.5 * s, fontWeight: FontWeight.w700)),
      SizedBox(height: 7 * s),
      TextFormField(
        controller: controller, keyboardType: keyboardType, validator: validator,
        style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 13.5 * s),
        decoration: InputDecoration(
          hintText: hint, hintStyle: TextStyle(color: AppColors.lightTextSecondary, fontSize: 12.5 * s), prefixIcon: Icon(icon, color: AppColors.primary, size: 20 * s),
          filled: true, fillColor: AppColors.lightBackground,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14 * s), borderSide: const BorderSide(color: AppColors.lightCardBorder)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14 * s), borderSide: const BorderSide(color: AppColors.lightCardBorder)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14 * s), borderSide: const BorderSide(color: AppColors.primary, width: 1.4)),
        ),
      ),
    ]);
  }
}
