import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../../app/theme/app_colors.dart';
import '../../app/user_preferences_controller.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../core/widgets/animated_tap_scale.dart';
import '../../data/models/profile_model.dart';
import '../../data/repositories/profile_repository.dart';
import 'ledger_party.dart';
import 'money_receipt_card.dart';
import 'ledger_repository.dart';
import 'payment_entry_screen.dart';
import 'thermal_payment_receipt.dart';
import '../../core/widgets/app_message.dart';
import '../../core/services/ledger_media_store.dart';

class PaymentReceiptScreen extends StatefulWidget {
  final LedgerParty party;
  final LedgerTransaction transaction;

  const PaymentReceiptScreen({
    super.key,
    required this.party,
    required this.transaction,
  });

  @override
  State<PaymentReceiptScreen> createState() => _PaymentReceiptScreenState();
}

class _PaymentReceiptScreenState extends State<PaymentReceiptScreen> {
  final LedgerRepository _repository = LedgerRepository();
  final GlobalKey _receiptKey = GlobalKey();
  bool _sharing = false;
  bool _deleting = false;
  final AudioPlayer _player = AudioPlayer();
  bool _playing = false;

  ProfileModel? _profile;

  bool get _isReceive => widget.party.uiIsReceive(widget.transaction.type);

  @override
  void initState() {
    super.initState();
    _loadProfile();
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _toggleVoice() async {
    final file = LedgerMediaStore.resolve(widget.transaction.voicePath);
    if (file == null) {
      _showMessage('This voice note could not be found.');
      return;
    }
    try {
      if (_playing) {
        await _player.pause();
        setState(() => _playing = false);
      } else {
        await _player.play(DeviceFileSource(file.path));
        setState(() => _playing = true);
      }
    } catch (_) {
      _showMessage('Could not play this voice note.');
    }
  }

  Widget _voiceChip(double s) {
    return GestureDetector(
      onTap: _toggleVoice,
      child: Container(
        margin: EdgeInsets.only(top: 14 * s),
        padding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 10 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16 * s),
          border: Border.all(color: AppColors.lightCardBorder),
        ),
        child: Row(
          children: [
            Container(
              width: 36 * s,
              height: 36 * s,
              decoration: BoxDecoration(color: _green, shape: BoxShape.circle),
              child: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 22 * s),
            ),
            SizedBox(width: 10 * s),
            Expanded(
              child: Text(
                _playing ? 'Playing voice note...' : 'Play voice note',
                style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary),
              ),
            ),
            Icon(Icons.mic_rounded, color: _green, size: 20 * s),
          ],
        ),
      ),
    );
  }

  Future<void> _loadProfile() async {
    try {
      final profile = await ProfileRepository().getOrCreate();
      if (mounted) setState(() => _profile = profile);
    } catch (_) {
      // The receipt still renders with default business details.
    }
  }

  /// Done / back: return to the party's ledger. `true` tells the ledger
  /// screen to reload so the khata balance and the new entry show up.
  void _done() => Navigator.of(context).pop(true);

  // Accent follows the receipt: green for Receive, red for Pay.
  Color get _green => MoneyReceiptCard.accentFor(_isReceive);
  Color get _greenDark => MoneyReceiptCard.accentDarkFor(_isReceive);

  // Share buttons: WhatsApp brand green, SMS in the Google Messages blue.
  static const Color _whatsappGreen = Color(0xFF25D366);
  static const Color _smsBlue = Color(0xFF1A73E8);

  @override
  Widget build(BuildContext context) {
    final scale = (MediaQuery.sizeOf(context).width / 390).clamp(0.78, 1.14).toDouble();
    final currencyCode = context.watch<UserPreferencesController>().currencyCode;
    // The green (Receive) / red (Pay) colour lives INSIDE the receipt
    // container only; the page itself stays plain.
    final gradient = _isReceive
        ? const [Color(0xFF0A9A4E), Color(0xFF6CCB97), Color(0xFFDFF5E8)]
        : const [Color(0xFFD92D20), Color(0xFFF3908A), Color(0xFFFBE0DE)];
    return PopScope(
      // The system back button / swipe also behaves like "Done" so the ledger
      // is always refreshed after a payment.
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _done();
      },
      // Same top bar as every other screen of the app.
      child: AppTabScreen(
        title: _isReceive ? 'Money Receipt' : 'Payment Voucher',
        onBack: _done,
        trailing: AppGlassIconButton(
          icon: Icons.delete_outline_rounded,
          iconColor: AppColors.expense,
          onTap: _deleting ? () {} : _delete,
        ),
        body: DecoratedBox(
          decoration: const BoxDecoration(color: AppColors.lightBackground),
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.fromLTRB(16 * scale, 16 * scale, 16 * scale, 28 * scale),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // The receipt card sits inside ONE container. The green/red
                // background is this container's own background; the buttons
                // are placed below it.
                Container(
                  padding: EdgeInsets.all(14 * scale),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: gradient,
                      stops: const [0.0, 0.55, 1.0],
                    ),
                    borderRadius: BorderRadius.circular(22 * scale),
                    border: Border.all(color: _green.withValues(alpha: .35)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: .16),
                        blurRadius: 22 * scale,
                        offset: Offset(0, 10 * scale),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12 * scale),
                    child: FittedBox(
                      fit: BoxFit.fitWidth,
                      child: RepaintBoundary(
                        key: _receiptKey,
                        child: MoneyReceiptCard(
                          profile: _profile,
                          party: widget.party,
                          transaction: widget.transaction,
                          isReceive: _isReceive,
                          currencyCode: currencyCode,
                        ),
                      ),
                    ),
                  ),
                ),
                if (LedgerMediaStore.resolve(widget.transaction.voicePath) != null) _voiceChip(scale),
                SizedBox(height: 22 * scale),
                Row(
                  children: [
                    Expanded(child: _actionButton(scale, Icons.receipt_long_rounded, '58mm Bill Receipt  |  Print', const Color(0xFF111111), _open58mm)),
                  ],
                ),
                SizedBox(height: 8 * scale),
                Row(
                  children: [
                    Expanded(child: _actionButton(scale, Icons.edit_rounded, 'Edit', const Color(0xFF111111), _edit)),
                    SizedBox(width: 8 * scale),
                    Expanded(child: _actionButton(scale, Icons.sms_rounded, 'SMS', _smsBlue, _sendSms)),
                    SizedBox(width: 8 * scale),
                    Expanded(child: _actionButton(scale, Icons.chat_rounded, 'WhatsApp', _whatsappGreen, _share)),
                  ],
                ),
                SizedBox(height: 12 * scale),
                _doneButton(scale),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _doneButton(double s) {
    return AnimatedTapScale(
      onTap: _done,
      child: Container(
        height: 54 * s,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18 * s),
          gradient: LinearGradient(colors: [_green, _greenDark]),
          boxShadow: [
            BoxShadow(
              color: _green.withValues(alpha: .35),
              blurRadius: 14 * s,
              offset: Offset(0, 6 * s),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle_rounded, color: Colors.white, size: 22 * s),
            SizedBox(width: 9 * s),
            Text(
              'Done',
              style: TextStyle(color: Colors.white, fontSize: 17 * s, fontWeight: FontWeight.w900),
            ),
          ],
        ),
      ),
    );
  }

  Widget _actionButton(double s, IconData icon, String label, Color color, VoidCallback onTap) {
    return AnimatedTapScale(
      onTap: onTap,
      child: Container(
        height: 48 * s,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16 * s),
          boxShadow: [BoxShadow(color: color.withValues(alpha: .20), blurRadius: 10 * s, offset: Offset(0, 4 * s))],
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: Colors.white, size: 18 * s),
          SizedBox(width: 7 * s),
          Text(label, style: TextStyle(color: Colors.white, fontSize: 13 * s, fontWeight: FontWeight.w900)),
        ]),
      ),
    );
  }

  /// 58mm bill-style receipt (preview + print), next to the existing card.
  void _open58mm() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PaymentThermalReceiptScreen(
          party: widget.party,
          transaction: widget.transaction,
          isReceive: _isReceive,
          profile: _profile,
        ),
      ),
    );
  }

  Future<void> _edit() async {
    final updated = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => PaymentEntryScreen(
          party: widget.party,
          isReceive: _isReceive,
          transaction: widget.transaction,
        ),
      ),
    );
    if (updated == true && mounted) {
      final fresh = await _repository.getTransactionById(widget.transaction.id);
      if (fresh != null && mounted) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => PaymentReceiptScreen(party: widget.party, transaction: fresh)));
      }
    }
  }

  Future<Uint8List?> _captureReceipt() async {
    // The receipt is rendered inside a RepaintBoundary. Wait until Flutter has
    // completed the current frame before asking the render object for pixels;
    // otherwise toImage() can be called while the boundary still needs paint
    // and the share action fails with a generic "could not create receipt" error.
    for (var attempt = 0; attempt < 3; attempt++) {
      await WidgetsBinding.instance.endOfFrame;

      final renderObject = _receiptKey.currentContext?.findRenderObject();
      if (renderObject is! RenderRepaintBoundary || !renderObject.attached) {
        continue;
      }

      if (!renderObject.hasSize || renderObject.size.isEmpty) {
        continue;
      }

      if (renderObject.debugNeedsPaint) {
        continue;
      }

      try {
        // The card is laid out 400px wide, so 3x gives a crisp 1200px image
        // that is still light enough for WhatsApp and older Android devices.
        final image = await renderObject.toImage(pixelRatio: 3.0);
        final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
        image.dispose();

        final bytes = byteData?.buffer.asUint8List();
        if (bytes != null && bytes.isNotEmpty) {
          return bytes;
        }
      } catch (_) {
        // A transient paint/layout state can happen after navigation or a
        // rebuild. Retry on the next frame instead of failing immediately.
      }
    }

    return null;
  }

  Future<String?> _phoneNumber() async {
    final phone = widget.party.phone?.trim();
    if (phone == null || phone.isEmpty) {
      if (mounted) _showMessage('This customer/supplier has no phone number.');
      return null;
    }
    return phone;
  }

  Future<void> _share() async {
    if (_sharing) return;
    setState(() => _sharing = true);
    try {
      final phone = await _phoneNumber();
      if (phone == null) return;

      if (!Platform.isAndroid) {
        if (mounted) {
          _showMessage('Direct WhatsApp is available on Android. Please use SMS on this device.');
        }
        return;
      }

      final bytes = await _captureReceipt();
      if (bytes == null) {
        if (mounted) _showMessage('Could not create the receipt image.');
        return;
      }

      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/wc_khata_receipt_${widget.transaction.id}.png');
      await file.writeAsBytes(bytes, flush: true);

      String result = 'none';
      try {
        result = await const MethodChannel('wc_khata/whatsapp')
                .invokeMethod<String>(
              'shareReceiptToWhatsApp',
              <String, dynamic>{
                'path': file.path,
                'phone': phone,
              },
            ) ??
            'none';
      } on PlatformException {
        result = 'none';
      }

      if (!mounted) return;
      if (result == 'whatsapp') {
        _showMessage('Opening WhatsApp for ${widget.party.name}.');
      } else {
        _showMessage(
          'WhatsApp could not open for this number. Please use the SMS button instead.',
        );
      }
    } catch (_) {
      if (mounted) {
        _showMessage(
          'WhatsApp could not open for this number. Please use the SMS button instead.',
        );
      }
    } finally {
      if (mounted) setState(() => _sharing = false);
    }
  }

  Future<void> _sendSms() async {
    if (_sharing) return;
    setState(() => _sharing = true);
    try {
      final phone = await _phoneNumber();
      if (phone == null) return;

      if (Platform.isAndroid) {
        String result = 'none';
        try {
          result = await const MethodChannel('wc_khata/whatsapp')
                  .invokeMethod<String>(
                'sendReceiptSms',
                <String, dynamic>{
                  'phone': phone,
                  'smsText': _buildSmsText(),
                },
              ) ??
              'none';
        } on PlatformException {
          result = 'none';
        }

        if (!mounted) return;
        if (result == 'sms') {
          _showMessage('Opening SMS for ${widget.party.name}.');
        } else {
          _showMessage('No SMS app is available on this device.');
        }
        return;
      }

      if (mounted) {
        _showMessage('SMS is available on Android devices.');
      }
    } finally {
      if (mounted) setState(() => _sharing = false);
    }
  }

  String _buildSmsText() {
    final date = DateFormat('dd MMM yyyy, hh:mm a').format(widget.transaction.date);
    final amount = CurrencyFormatter.formatCompact(widget.transaction.amount);
    final note = widget.transaction.note?.trim();
    final business = _profile?.name?.trim();
    final lines = <String>[
      '${(business == null || business.isEmpty) ? 'WC Khata' : business} - ${_isReceive ? 'Money Receipt' : 'Payment Voucher'}',
      '${_isReceive ? 'Received from' : 'Paid to'}: ${widget.party.name}',
      'Amount: $amount',
      'Date: $date',
      if (note != null && note.isNotEmpty) 'Note: $note',
      'Powered by WebdSoft Company',
    ];
    return lines.join('\n');
  }

  Future<void> _delete() async {
    if (_deleting) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete transaction?'),
        content: const Text('This receipt will move to Recycle Bin and can be restored for 60 days.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: AppColors.expense), onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirmed != true) return;
    setState(() => _deleting = true);
    try {
      await _repository.deleteTransaction(widget.transaction.id);
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => _deleting = false);
        _showMessage('Could not delete this transaction.');
      }
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;
    AppMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}
