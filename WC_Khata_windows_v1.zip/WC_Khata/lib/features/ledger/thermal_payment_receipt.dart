import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../app/theme/app_theme.dart';
import '../../app/user_preferences_controller.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/utils/branding.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/utils/number_to_words.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/app_message.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../data/models/profile_model.dart';
import '../../data/repositories/profile_repository.dart';
import '../printer/printer_gate.dart';
import '../printer/receipt_settings.dart';
import '../sale/bill_paper.dart';
import '../sale/thermal_receipt.dart';
import 'ledger_party.dart';
import 'ledger_repository.dart';

/// The 58mm bill-style version of the Money Receipt / Payment Voucher.
/// Pure black on white, laid out at the same design width as the sale
/// receipt, so what is previewed is exactly what the thermal printer gets.
/// Logo, margins, text size and footer text come from [ReceiptSettings]
/// (the same Customize Receipt settings as the sale receipt).
class ThermalPaymentReceipt extends StatelessWidget {
  final ProfileModel? profile;
  final LedgerParty party;
  final LedgerTransaction transaction;
  final bool isReceive;
  final String currencyCode;
  final BillPaper paper;
  final ReceiptSettings? design;

  /// Khata balance before and after this entry (null = not known yet, the
  /// balance rows are then left out).
  final double? previousBalance;
  final double? dueBalance;

  const ThermalPaymentReceipt({
    super.key,
    required this.profile,
    required this.party,
    required this.transaction,
    required this.isReceive,
    required this.currencyCode,
    this.paper = BillPaper.mm58,
    this.design,
    this.previousBalance,
    this.dueBalance,
  });

  static String? _clean(String? v) {
    final t = v?.trim();
    return (t == null || t.isEmpty) ? null : t;
  }

  String get _number => '${isReceive ? 'MR' : 'PV'}-${transaction.id.toString().padLeft(5, '0')}';

  @override
  Widget build(BuildContext context) {
    final d = design ?? ReceiptSettingsService.instance.value;
    final BillPaper p = paper.isThermal ? paper : BillPaper.mm58;
    final double f = p.fontBase * d.fontScale;
    final double mmPx = ThermalReceipt.pxPerMm(p);
    final FontWeight base = d.bold ? FontWeight.w800 : FontWeight.w600;

    final business = _clean(profile?.name) ?? 'WC Khata';
    final address = d.showAddress ? _clean(profile?.address) : null;
    final phone = d.showPhone ? _clean(profile?.phone) : null;
    final header = d.headerText.trim();
    final note = _clean(transaction.note);
    final isSupplier = party.type == LedgerPartyType.supplier;
    final amount = CurrencyFormatter.formatCompact(transaction.amount);

    return Container(
      width: ThermalReceipt.widthFor(p),
      color: Colors.white,
      padding: EdgeInsets.fromLTRB(d.marginLeft * mmPx, d.marginTop * mmPx, d.marginRight * mmPx, d.marginBottom * mmPx),
      child: DefaultTextStyle(
        style: TextStyle(color: Colors.black, fontSize: f, height: 1.3, fontWeight: base),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (d.hasLogo) _logo(d, p),
            if (d.showBusinessName)
              Text(business, textAlign: TextAlign.center, style: TextStyle(fontSize: f + 4.5, fontWeight: FontWeight.w900, height: 1.2)),
            if (address != null)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Text(address, textAlign: TextAlign.center, style: TextStyle(fontSize: f - 1.5)),
              ),
            if (phone != null)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text('Tel: $phone', textAlign: TextAlign.center, style: TextStyle(fontSize: f - 1.5)),
              ),
            if (header.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Text(header, textAlign: TextAlign.center, style: TextStyle(fontSize: f - 1, fontWeight: FontWeight.w800)),
              ),
            const SizedBox(height: 8),
            const _Dash(),
            const SizedBox(height: 6),
            Text(
              isReceive ? 'MONEY RECEIPT' : 'PAYMENT VOUCHER',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: f + 1.5, fontWeight: FontWeight.w900, letterSpacing: 1),
            ),
            const SizedBox(height: 6),
            _kv(isReceive ? 'Receipt No' : 'Voucher No', _number, f - 0.5, d),
            _kv('Date', DateFormat('dd MMM yyyy, hh:mm a').format(transaction.date), f - 0.5, d),
            _kv(isSupplier ? 'Supplier' : 'Customer', party.name, f - 0.5, d),
            if (_clean(party.phone) != null) _kv('Phone', party.phone!.trim(), f - 0.5, d),
            _kv('Payment', 'Cash', f - 0.5, d),
            const SizedBox(height: 6),
            const _Dash(),
            const SizedBox(height: 6),
            Text(
              isReceive ? 'AMOUNT RECEIVED' : 'AMOUNT PAID',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: f - 0.5, fontWeight: FontWeight.w900, letterSpacing: .6),
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: const BoxDecoration(border: Border.symmetric(horizontal: BorderSide(color: Colors.black, width: 1.4))),
              child: Align(
                alignment: Alignment.center,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(amount, style: TextStyle(fontSize: f + 6, fontWeight: FontWeight.w900)),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              NumberToWords.amountInWords(transaction.amount, currencyCode),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: f - 1, fontWeight: FontWeight.w700),
            ),
            if (note != null) ...[
              const SizedBox(height: 6),
              _kv('Note', note, f - 0.5, d),
            ],
            if (previousBalance != null && dueBalance != null) ...[
              const SizedBox(height: 6),
              const _Dash(),
              const SizedBox(height: 4),
              _balanceRow('Previous Balance', previousBalance!, f, d),
              _kv(isReceive ? 'Received' : 'Paid', amount, f, d, shrink: true),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 5),
                decoration: const BoxDecoration(border: Border.symmetric(horizontal: BorderSide(color: Colors.black, width: 1.4))),
                child: _balanceRow('DUE', dueBalance!, f + 1, d, bold: true),
              ),
            ],
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: _signLine(isReceive ? 'Customer' : 'Receiver', f)),
              SizedBox(width: 14),
              Expanded(child: _signLine('Signature', f)),
            ]),
            const SizedBox(height: 8),
            const _Dash(),
            const SizedBox(height: 8),
            // Fixed footer: always printed, cannot be edited or hidden.
            Padding(
              padding: const EdgeInsets.only(top: 3),
              child: Text(Branding.poweredBy, textAlign: TextAlign.center, style: TextStyle(fontSize: f - 2.5)),
            ),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }

  /// "label ........ amount" (no extra caption line).
  Widget _balanceRow(String label, double value, double size, ReceiptSettings d, {bool bold = false}) {
    return _kv(label, CurrencyFormatter.formatCompact(value.abs()), size, d, bold: bold, shrink: true);
  }

  Widget _signLine(String label, double f) => Column(children: [
        Container(height: 1, color: Colors.black),
        const SizedBox(height: 2),
        Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: f - 2, fontWeight: FontWeight.w700)),
      ]);

  Widget _logo(ReceiptSettings d, BillPaper p) {
    const k = 2.4;
    const o = 128 * (1 - k);
    const bw = ColorFilter.matrix(<double>[
      0.299 * k, 0.587 * k, 0.114 * k, 0, o,
      0.299 * k, 0.587 * k, 0.114 * k, 0, o,
      0.299 * k, 0.587 * k, 0.114 * k, 0, o,
      0, 0, 0, 1, 0,
    ]);
    final align = switch (d.logoAlign) {
      0 => Alignment.centerLeft,
      2 => Alignment.centerRight,
      _ => Alignment.center,
    };
    Widget img = Image.file(
      File(d.logoPath!),
      fit: BoxFit.contain,
      gaplessPlayback: true,
      filterQuality: FilterQuality.high,
      errorBuilder: (_, __, ___) => const SizedBox.shrink(),
    );
    if (d.logoHighContrast) img = ColorFiltered(colorFilter: bw, child: img);
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Align(
        alignment: align,
        child: FractionallySizedBox(
          widthFactor: d.logoWidthPct / 100,
          child: ConstrainedBox(constraints: BoxConstraints(maxHeight: ThermalReceipt.widthFor(p) * .55), child: img),
        ),
      ),
    );
  }

  Widget _kv(String label, String value, double size, ReceiptSettings d, {bool bold = false, bool shrink = false}) {
    final style = TextStyle(fontSize: size, fontWeight: bold || d.bold ? FontWeight.w900 : FontWeight.w700);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1.5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: style),
          const SizedBox(width: 8),
          Expanded(
            child: shrink
                ? Align(
                    alignment: Alignment.centerRight,
                    child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text(value, style: style)),
                  )
                : Text(value, textAlign: TextAlign.end, style: style),
          ),
        ],
      ),
    );
  }
}

class _Dash extends StatelessWidget {
  const _Dash();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final count = (constraints.maxWidth / 6).floor();
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(count, (_) => Container(width: 3, height: 1.2, color: Colors.black)),
        );
      },
    );
  }
}

/// Preview + Print of the 58mm Money Receipt / Payment Voucher.
class PaymentThermalReceiptScreen extends StatefulWidget {
  final LedgerParty party;
  final LedgerTransaction transaction;
  final bool isReceive;
  final ProfileModel? profile;

  const PaymentThermalReceiptScreen({
    super.key,
    required this.party,
    required this.transaction,
    required this.isReceive,
    this.profile,
  });

  @override
  State<PaymentThermalReceiptScreen> createState() => _PaymentThermalReceiptScreenState();
}

class _PaymentThermalReceiptScreenState extends State<PaymentThermalReceiptScreen> {
  final GlobalKey _key = GlobalKey();
  ProfileModel? _profile;
  bool _printing = false;
  double? _prevBalance;
  double? _dueBalance;

  @override
  void initState() {
    super.initState();
    _profile = widget.profile;
    _init();
  }

  Future<void> _init() async {
    try {
      await ReceiptSettingsService.instance.load();
    } catch (_) {}
    if (_profile == null) {
      try {
        _profile = await ProfileRepository().getOrCreate();
      } catch (_) {}
    }
    try {
      final b = await LedgerRepository().getBalanceAround(widget.party, widget.transaction.id);
      if (b != null) {
        _prevBalance = b.before;
        _dueBalance = b.after;
      }
    } catch (_) {}
    if (mounted) setState(() {});
  }

  Future<void> _print() async {
    if (_printing) return;
    if (!await PrinterGate.ensure(context)) return;
    setState(() => _printing = true);
    try {
      await Future<void>.delayed(const Duration(milliseconds: 120));
      final boundary = _key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) throw StateError('Receipt is not ready.');
      final ui.Image image = await boundary.toImage(pixelRatio: 3.5);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (data == null) throw StateError('Could not create receipt image.');
      await ThermalPrinterService.instance.printPng(data.buffer.asUint8List(), paperMm: BillPaper.mm58.mm);
    } on PrinterException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Could not print the receipt. Please try again.');
    } finally {
      if (mounted) setState(() => _printing = false);
    }
  }

  void _snack(String msg) {
    if (!mounted) return;
    AppMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final currencyCode = context.watch<UserPreferencesController>().currencyCode;
    return AppTabScreen(
      title: widget.isReceive ? '58mm Money Receipt' : '58mm Payment Voucher',
      onBack: () => Navigator.pop(context),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppColors.lightDivider),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .10), blurRadius: 14, offset: const Offset(0, 6))],
                ),
                child: RepaintBoundary(
                  key: _key,
                  child: ThermalPaymentReceipt(
                    profile: _profile,
                    party: widget.party,
                    transaction: widget.transaction,
                    isReceive: widget.isReceive,
                    currencyCode: currencyCode,
                    previousBalance: _prevBalance,
                    dueBalance: _dueBalance,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            AppButton3D(
              label: _printing ? 'Printing...' : 'Print 58mm Receipt',
              icon: Icons.print_rounded,
              expand: true,
              onPressed: _printing ? null : _print,
            ),
          ],
        ),
      ),
    );
  }
}
