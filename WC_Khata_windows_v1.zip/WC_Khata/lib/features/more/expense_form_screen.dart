import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../data/models/transaction_model.dart';
import '../../data/repositories/account_repository.dart';
import '../../data/repositories/finance_category_repository.dart';
import '../../data/repositories/transaction_repository.dart';
import 'expense_categories_screen.dart';
import 'add_category_screen.dart';
import '../../core/widgets/app_message.dart';
import '../../core/utils/amount_limit.dart';

class ExpenseFormScreen extends StatefulWidget {
  final TransactionModel? existing;

  const ExpenseFormScreen({super.key, this.existing});

  @override
  State<ExpenseFormScreen> createState() => _ExpenseFormScreenState();
}

class _ExpenseFormScreenState extends State<ExpenseFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amount = TextEditingController();
  final _note = TextEditingController();
  final _source = TextEditingController();
  final _accountRepo = AccountRepository();
  final _catRepo = FinanceCategoryRepository();
  final _txRepo = TransactionRepository();

  int? _cashAccountId;
  List<FinanceCategory> _categories = [];
  FinanceCategory? _category;
  DateTime _date = DateTime.now();
  bool _saving = false;

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    _source.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final cash = await _accountRepo.getDefaultCashAccount();
    final cats = await _catRepo.getExpenseCategories();
    final old = widget.existing;

    FinanceCategory? selected;
    if (old?.categoryId != null) {
      for (final c in cats) {
        if (c.id == old!.categoryId) {
          selected = c;
          break;
        }
      }
    }

    if (!mounted) return;

    setState(() {
      _cashAccountId = cash?.id;
      _categories = cats;
      _category = selected;

      if (old != null) {
        _amount.text = old.amount.toStringAsFixed(2);
        _note.text = old.note ?? '';
        _source.text = old.source ?? '';
        _date = old.date;
      }
    });
  }

  Future<void> _openCategories() async {
    await Navigator.push(
      context,
      AppTransitions.seamless(const ExpenseCategoriesScreen()),
    );
    await _load();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    if (_cashAccountId == null) {
      AppMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cash account is not available.')),
      );
      return;
    }

    setState(() => _saving = true);

    try {
      final now = DateTime.now();
      final tx = TransactionModel(
        id: widget.existing?.id,
        type: TransactionType.expense,
        amount: double.parse(_amount.text.trim()),
        accountId: _cashAccountId!,
        categoryId: _category?.id,
        source: _source.text.trim().isEmpty
            ? (_category?.name ?? 'Expense')
            : _source.text.trim(),
        paymentMethod: 'Cash',
        date: _date,
        note: widget.existing?.note,
        createdAt: widget.existing?.createdAt ?? now,
        updatedAt: now,
      );

      if (_editing) {
        await _txRepo.update(widget.existing!, tx);
      } else {
        await _txRepo.create(tx);
      }

      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (_) {
      if (!mounted) return;
      AppMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not save expense.')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _openCategoryPicker() async {
    if (_categories.isEmpty) {
      final saved = await Navigator.push(
        context,
        AppTransitions.seamless(const AddCategoryScreen()),
      );
      if (saved == true) await _load();
      return;
    }

    final selected = await showModalBottomSheet<FinanceCategory>(
      context: context,
      isScrollControlled: true,
      enableDrag: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        final height = MediaQuery.of(sheetContext).size.height;

        return SafeArea(
          top: false,
          child: Container(
            constraints: BoxConstraints(maxHeight: height * .7),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(32),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(height: 12),
                Container(
                  width: 72,
                  height: 6,
                  decoration: BoxDecoration(
                    color: Color(0xFFE3E7EE),
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                ),
                const SizedBox(height: 22),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 32),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Select Category',
                      style: TextStyle(
                        color: Color(0xFF111827),
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Flexible(
                  child: ListView.separated(
                    shrinkWrap: true,
                    padding: const EdgeInsets.only(bottom: 12),
                    itemCount: _categories.length,
                    separatorBuilder: (_, __) => const Divider(
                      height: 1,
                      thickness: 1,
                      color: Color(0xFFE1E4E8),
                    ),
                    itemBuilder: (_, index) {
                      final category = _categories[index];
                      final isSelected = category.id == _category?.id;

                      return Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () => Navigator.pop(sheetContext, category),
                          child: SizedBox(
                            height: 62,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 32),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      category.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: const Color(0xFF111827),
                                        fontSize: 17,
                                        fontWeight: isSelected
                                            ? FontWeight.w900
                                            : FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                  if (isSelected)
                                    const Icon(
                                      Icons.check_rounded,
                                      color: AppColors.primary,
                                      size: 22,
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (selected != null && mounted) {
      setState(() => _category = selected);
    }
  }

  InputDecoration _dec(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: AppColors.primary),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.lightCardBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.lightCardBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.primary, width: 1.4),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.of(context).size.width / 390).clamp(0.86, 1.18);
    final canSave = _cashAccountId != null;

    return AppTabScreen(
      title: _editing ? 'Edit Expense' : 'Add Expense',
      onBack: () => Navigator.pop(context),
      body: !canSave
          ? const Center(child: Text('Cash account is not available.'))
          : Form(
              key: _formKey,
              child: ListView(
                padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 28 * s),
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Category',
                        style: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w900),
                      ),
                      TextButton(
                        onPressed: _openCategories,
                        child: Text(
                          'Manage Categories',
                          style: TextStyle(fontSize: 12.5 * s, color: AppColors.primary, fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),

                  FormField<FinanceCategory>(
                    initialValue: _category,
                    validator: (value) => value == null ? 'Select a category' : null,
                    builder: (field) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          InkWell(
                            onTap: _openCategoryPicker,
                            borderRadius: BorderRadius.circular(16 * s),
                            child: Container(
                              height: 58 * s,
                              padding: EdgeInsets.symmetric(horizontal: 16 * s),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16 * s),
                                border: Border.all(
                                  color: field.hasError
                                      ? AppColors.expense
                                      : AppColors.lightCardBorder,
                                  width: field.hasError ? 1.4 : 1,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: .035),
                                    blurRadius: 10 * s,
                                    offset: Offset(0, 4 * s),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      _category?.name ?? 'Select Category',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 14 * s,
                                        fontWeight: _category == null ? FontWeight.w500 : FontWeight.w800,
                                        color: _category == null
                                            ? AppColors.lightTextSecondary
                                            : AppColors.lightTextPrimary,
                                      ),
                                    ),
                                  ),
                                  Icon(
                                    Icons.keyboard_arrow_down_rounded,
                                    color: AppColors.lightTextSecondary,
                                    size: 24 * s,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          if (field.hasError)
                            Padding(
                              padding: EdgeInsets.only(left: 12 * s, top: 5 * s),
                              child: Text(
                                field.errorText!,
                                style: TextStyle(
                                  color: AppColors.expense,
                                  fontSize: 11 * s,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                        ],
                      );
                    },
                  ),

                  SizedBox(height: 12 * s),

                  TextFormField(
                    controller: _source,
                    decoration: _dec('Expense Title', Icons.label_important_outline_rounded),
                  ),

                  SizedBox(height: 12 * s),

                  TextFormField(
                    controller: _amount,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: const [MaxAmountFormatter()],
                    decoration: _dec('Enter Amount', Icons.payments_rounded),
                    validator: (value) {
                      final amount = double.tryParse(value?.trim() ?? '');
                      if (amount != null && amount > AmountLimit.max) return AmountLimit.message;
                      return amount == null || amount <= 0 ? 'Enter a valid amount' : null;
                    },
                  ),

                  SizedBox(height: 12 * s),

                  Text(
                    'Date',
                    style: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w900),
                  ),
                  SizedBox(height: 7 * s),
                  InkWell(
                    onTap: () async {
                      final d = await showDatePicker(
                        context: context,
                        initialDate: _date,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                      );
                      if (d != null && mounted) {
                        setState(() => _date = d);
                      }
                    },
                    borderRadius: BorderRadius.circular(16 * s),
                    child: Container(
                      height: 54 * s,
                      padding: EdgeInsets.symmetric(horizontal: 14 * s),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16 * s),
                        border: Border.all(color: AppColors.lightCardBorder),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.calendar_month_rounded, color: AppColors.primary, size: 20 * s),
                          SizedBox(width: 10 * s),
                          Expanded(
                            child: Text(
                              '${_date.day}/${_date.month}/${_date.year}',
                              style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w800),
                            ),
                          ),
                          Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.lightTextSecondary, size: 20 * s),
                        ],
                      ),
                    ),
                  ),

                  SizedBox(height: 22 * s),

                  SizedBox(
                    height: 54 * s,
                    child: FilledButton.icon(
                      onPressed: _saving ? null : _save,
                      icon: _saving
                          ? SizedBox(
                              width: 20 * s,
                              height: 20 * s,
                              child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : const Icon(Icons.check_rounded),
                      label: Text(
                        _editing ? 'Update Expense' : 'Save Expense',
                        style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w900),
                      ),
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.expense,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17 * s)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
