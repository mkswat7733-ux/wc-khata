import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/modern_header.dart';
import '../../data/repositories/bill_repository.dart';
import '../../data/repositories/subscription_repository.dart';
import '../../core/services/notification_service.dart';
import '../../features/items/item_repository.dart';
import '../../features/purchases/purchases_screen.dart';
import '../../features/ledger/ledger_party.dart';
import '../../features/ledger/ledger_repository.dart';
import '../../features/ledger/party_detail_screen.dart';
import '../../core/widgets/app_message.dart';

enum _ReminderType { bill, subscription, ledger, lowStock }

class _ReminderItem {
  final _ReminderType type;
  final int id;
  final String title;
  final double amount;
  final DateTime dueDate;
  const _ReminderItem({
    required this.type,
    required this.id,
    required this.title,
    required this.amount,
    required this.dueDate,
  });

  String get payload => type == _ReminderType.bill
      ? 'bill:$id'
      : type == _ReminderType.subscription
          ? 'subscription:$id'
          : type == _ReminderType.ledger
              ? 'ledger_party:$id'
              : 'item:$id';
}

/// Only reminders whose due date has arrived are shown here. Future
/// reminders remain hidden until the due date morning notification fires.
const _lookAheadDays = 0;

/// Real notifications list — every unpaid Bill and active Subscription
/// that's overdue or due within [_lookAheadDays] days, the same set
/// `NotificationService` schedules background reminders for. Opened
/// from Home's bell icon, or by tapping one of those reminder
/// notifications (see `NotificationService`, `PendingNotification`,
/// `LaunchGate`) — in which case [initialPayload] highlights the
/// specific bill/subscription that fired it.
///
/// Tapping any item here goes to its Bills or Subscriptions screen —
/// there's nothing to mark "read"; the list itself just reflects
/// what's currently due.
class NotificationsScreen extends StatefulWidget {
  final String? initialPayload;
  const NotificationsScreen({super.key, this.initialPayload});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  bool _loading = true;
  List<_ReminderItem> _items = const [];

  @override
  void initState() {
    super.initState();
    // Opening this screen is the explicit read action. The persistent
    // timestamp makes the Home badge stay cleared when the user returns.
    NotificationService.instance.markNotificationsViewed();
    _load();
  }

  Future<void> _load() async {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final tomorrow = today.add(const Duration(days: 1));

    final bills = await BillRepository().getAll();
    final subs = await SubscriptionRepository().getAll();
    final parties = await LedgerRepository().getParties();
    final inventory = await ItemRepository().getItems();

    // Only reminders whose due date has actually arrived are shown here.
    // Future reminders stay scheduled in Android and remain hidden until
    // the morning of their due date.
    final items = <_ReminderItem>[
      for (final b in bills)
        if (b.id != null && b.status != 'paid' && b.reminderEnabled && b.dueDate.isBefore(tomorrow))
          _ReminderItem(type: _ReminderType.bill, id: b.id!, title: b.name, amount: b.amount, dueDate: b.dueDate),
      for (final s in subs)
        if (s.id != null && s.isActive && s.reminderEnabled && s.nextPaymentDate.isBefore(tomorrow))
          _ReminderItem(type: _ReminderType.subscription, id: s.id!, title: s.name, amount: s.amount, dueDate: s.nextPaymentDate),
      for (final p in parties)
        if (p.id != null && p.isReceivable && p.reminderDate != null && p.reminderDate!.isBefore(tomorrow) && (p.reminderAmount ?? p.balance.abs()) > 0)
          _ReminderItem(type: _ReminderType.ledger, id: p.id!, title: p.name, amount: p.reminderAmount ?? p.balance.abs(), dueDate: p.reminderDate!),
      for (final item in inventory)
        if (item.lowStock > 0 && item.qty <= item.lowStock)
          _ReminderItem(type: _ReminderType.lowStock, id: item.id, title: item.name, amount: item.qty, dueDate: now),
    ]..sort((a, b) => a.dueDate.compareTo(b.dueDate));

    if (!mounted) return;
    setState(() {
      _items = items;
      _loading = false;
    });
  }

  String _dueLabel(_ReminderItem item) {
    if (item.type == _ReminderType.lowStock) return item.amount <= 0 ? 'Out of stock' : 'Stock is low';
    final due = item.dueDate;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final dueDay = DateTime(due.year, due.month, due.day);
    final diff = dueDay.difference(today).inDays;
    if (diff < 0) {
      final overdueDays = -diff;
      return 'Overdue by $overdueDays day${overdueDays == 1 ? '' : 's'}';
    }
    if (diff == 0) return 'Due today';
    if (diff == 1) return 'Due tomorrow';
    return 'Due in $diff days';
  }

  Future<void> _openItem(_ReminderItem item) async {
    if (item.type == _ReminderType.ledger) {
      final party = await LedgerRepository().getPartyById(item.id);
      if (!mounted || party == null) return;
      await Navigator.of(context).push(AppTransitions.slideFromRight(PartyDetailScreen(party: party)));
    } else if (item.type == _ReminderType.lowStock) {
      // Low stock alert -> open Purchases with that product selected so it can be restocked.
      final inventory = await ItemRepository().getItems();
      ItemRecord? target;
      for (final e in inventory) { if (e.id == item.id) { target = e; break; } }
      if (!mounted) return;
      if (target == null) {
        AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('This product no longer exists.')));
        await _load();
        return;
      }
      await Navigator.of(context).push(MaterialPageRoute<bool>(builder: (_) => PurchasesScreen(initialItemId: target!.id)));
      if (mounted) await _load(); // stock may have changed -> refresh the list
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Notifications', onBack: () => Navigator.pop(context)),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _items.isEmpty
                    ? _EmptyState(isDark: isDark)
                    : ListView.separated(
                        padding: const EdgeInsets.all(AppDimensions.spaceMd),
                        itemCount: _items.length,
                        separatorBuilder: (_, __) => const SizedBox(height: AppDimensions.spaceSm),
                        itemBuilder: (context, i) {
                          final item = _items[i];
                          final overdue = item.dueDate.isBefore(DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day));
                          final highlighted = widget.initialPayload != null && widget.initialPayload == item.payload;
                          return _AnimatedReminderTile(
                            index: i,
                            item: item,
                            dueLabel: _dueLabel(item),
                            overdue: overdue,
                            highlighted: highlighted,
                            isDark: isDark,
                            onTap: () => _openItem(item),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class _AnimatedReminderTile extends StatefulWidget {
  final int index;
  final _ReminderItem item;
  final String dueLabel;
  final bool overdue;
  final bool highlighted;
  final bool isDark;
  final VoidCallback onTap;

  const _AnimatedReminderTile({
    required this.index, required this.item, required this.dueLabel,
    required this.overdue, required this.highlighted, required this.isDark,
    required this.onTap,
  });

  @override
  State<_AnimatedReminderTile> createState() => _AnimatedReminderTileState();
}

class _AnimatedReminderTileState extends State<_AnimatedReminderTile>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _slide = Tween<Offset>(begin: const Offset(0, .10), end: Offset.zero).animate(_fade);
    Future<void>.delayed(Duration(milliseconds: 90 * widget.index), () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _fade,
    child: SlideTransition(
      position: _slide,
      child: _ReminderTile(
        item: widget.item, dueLabel: widget.dueLabel, overdue: widget.overdue,
        highlighted: widget.highlighted, isDark: widget.isDark, onTap: widget.onTap,
      ),
    ),
  );
}

class _ReminderTile extends StatelessWidget {
  final _ReminderItem item;
  final String dueLabel;
  final bool overdue;
  final bool highlighted;
  final bool isDark;
  final VoidCallback onTap;

  const _ReminderTile({
    required this.item,
    required this.dueLabel,
    required this.overdue,
    required this.highlighted,
    required this.isDark,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final statusColor = (overdue || item.type == _ReminderType.lowStock) ? AppColors.expense : AppColors.warning;
    final cardColor = isDark ? AppColors.darkSurface : AppColors.lightSurface;
    return Material(
      color: cardColor,
      borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(AppDimensions.spaceMd),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
            border: Border.all(
              color: AppColors.expense.withValues(alpha: highlighted ? 0.48 : 0.16),
              width: highlighted ? 1.1 : 0.8,
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.expense.withValues(alpha: highlighted ? 0.22 : 0.10),
                blurRadius: highlighted ? 18 : 13,
                spreadRadius: highlighted ? 1 : 0,
                offset: const Offset(0, 5),
              ),
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.055),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  item.type == _ReminderType.bill
                      ? Icons.receipt_long_rounded
                      : item.type == _ReminderType.subscription
                          ? Icons.repeat_rounded
                          : item.type == _ReminderType.lowStock
                              ? Icons.inventory_2_rounded
                              : Icons.account_balance_wallet_rounded,
                  color: statusColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: AppDimensions.spaceMd),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.title, style: AppTextStyles.bodyMedium, maxLines: 1, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 3),
                    Text(
                      dueLabel,
                      style: AppTextStyles.caption.copyWith(color: statusColor, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: AppDimensions.spaceSm),
              Text(item.type == _ReminderType.lowStock ? 'Qty ${item.amount.truncateToDouble() == item.amount ? item.amount.toInt() : item.amount.toStringAsFixed(2)}' : CurrencyFormatter.format(item.amount), style: AppTextStyles.bodyMedium),
              const SizedBox(width: 4),
              Icon(Icons.chevron_right_rounded, color: isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final bool isDark;
  const _EmptyState({required this.isDark});

  @override
  Widget build(BuildContext context) {
    final secondary = isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.spaceLg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.notifications_none_rounded, size: 56, color: secondary.withValues(alpha: 0.5)),
            const SizedBox(height: AppDimensions.spaceMd),
            Text('No notifications yet', style: AppTextStyles.body.copyWith(color: secondary)),
            const SizedBox(height: 6),
            Text(
              "You'll see bills and subscriptions here as they come due.",
              textAlign: TextAlign.center,
              style: AppTextStyles.caption.copyWith(color: secondary),
            ),
          ],
        ),
      ),
    );
  }
}
