import 'package:flutter/material.dart';
import '../../core/routing/app_transitions.dart';
import 'register_screen.dart';

class _OnboardPage {
  final String image;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  const _OnboardPage({
    required this.image,
    required this.title,
    required this.subtitle,
    required this.gradient,
  });
}

const _pages = <_OnboardPage>[
  _OnboardPage(
    image: 'assets/images/onboarding_1.png',
    title: 'Welcome to WC Khata',
    subtitle: 'Your complete shop manager. Run sales, stock, khata and cash from one simple app, even without internet.',
    gradient: [Color(0xFF1E4FC4), Color(0xFF2F6FED), Color(0xFF5B8CFF)],
  ),
  _OnboardPage(
    image: 'assets/images/onboarding_2.png',
    title: 'Customer & Supplier Khata',
    subtitle: 'Know exactly who owes you and whom you owe. Record every payment and share a neat money receipt in one tap.',
    gradient: [Color(0xFF0B7A45), Color(0xFF12A15B), Color(0xFF3CD08A)],
  ),
  _OnboardPage(
    image: 'assets/images/onboarding_3.png',
    title: 'Fast Sales & Invoices',
    subtitle: 'Create a bill in seconds. Scan barcodes, apply discounts and print on your thermal printer or share on WhatsApp.',
    gradient: [Color(0xFF5B2EBF), Color(0xFF7C4DFF), Color(0xFF9F7BFF)],
  ),
  _OnboardPage(
    image: 'assets/images/onboarding_4.png',
    title: 'Reports & Safe Backup',
    subtitle: 'See your daily cash, profit and expenses clearly as PDF reports, and keep a backup so your records are never lost.',
    gradient: [Color(0xFFC25A00), Color(0xFFF08A1C), Color(0xFFFFB454)],
  ),
  _OnboardPage(
    image: 'assets/images/onboarding_5.png',
    title: 'Use Your Own Currency',
    subtitle: 'Work in Rupees, Taka, Dirham, Dollar or any currency you like. Every amount in the app follows your choice.',
    gradient: [Color(0xFF0F6B67), Color(0xFF12A59D), Color(0xFF4FD1C5)],
  ),
];

/// First-launch onboarding: five modern illustrated slides, then Register.
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> with SingleTickerProviderStateMixin {
  final _controller = PageController();
  late final AnimationController _float;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _float = AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    _float.dispose();
    super.dispose();
  }

  bool get _isLast => _index == _pages.length - 1;

  void _goRegister() {
    Navigator.of(context).pushReplacement(
      AppTransitions.seamless(const RegisterScreen()),
    );
  }

  void _next() {
    if (_isLast) {
      _goRegister();
      return;
    }
    _controller.nextPage(
      duration: const Duration(milliseconds: 420),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final page = _pages[_index];
    return Scaffold(
      body: AnimatedContainer(
        duration: const Duration(milliseconds: 450),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: page.gradient,
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              _topBar(),
              Expanded(
                child: PageView.builder(
                  controller: _controller,
                  itemCount: _pages.length,
                  onPageChanged: (i) => setState(() => _index = i),
                  itemBuilder: (context, i) => _illustration(i),
                ),
              ),
              _bottomSheet(page),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 16, 0),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(9),
            child: Image.asset('assets/icons/app_icon.png', width: 32, height: 32),
          ),
          const SizedBox(width: 10),
          const Text(
            'WC Khata',
            style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800),
          ),
          const Spacer(),
          AnimatedOpacity(
            duration: const Duration(milliseconds: 200),
            opacity: _isLast ? 0 : 1,
            child: TextButton(
              onPressed: _isLast ? null : _goRegister,
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.white.withValues(alpha: 0.18),
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
                minimumSize: const Size(0, 34),
              ),
              child: const Text('Skip', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _illustration(int i) {
    return AnimatedBuilder(
      animation: Listenable.merge([_controller, _float]),
      builder: (context, child) {
        double delta = 0;
        if (_controller.hasClients && _controller.position.haveDimensions) {
          delta = (_controller.page ?? _index.toDouble()) - i;
        } else {
          delta = (_index - i).toDouble();
        }
        final visible = (1 - delta.abs()).clamp(0.0, 1.0);
        final bob = (Curves.easeInOut.transform(_float.value) - 0.5) * 14;
        return Opacity(
          opacity: (0.35 + 0.65 * visible).clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(delta * -40, bob),
            child: Transform.scale(scale: 0.86 + 0.14 * visible, child: child),
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 0, 10, 4),
        child: Image.asset(_pages[i].image, fit: BoxFit.contain),
      ),
    );
  }

  Widget _bottomSheet(_OnboardPage page) {
    final bottom = MediaQuery.of(context).padding.bottom;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(26, 24, 26, 20 + bottom),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(36)),
        boxShadow: [BoxShadow(color: Color(0x33000000), blurRadius: 24, offset: Offset(0, -6))],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            transitionBuilder: (child, animation) => FadeTransition(
              opacity: animation,
              child: SlideTransition(
                position: Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero).animate(animation),
                child: child,
              ),
            ),
            child: Column(
              key: ValueKey(_index),
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  page.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xFF0F1B3D),
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    height: 1.2,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  page.subtitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xFF5C6A8A),
                    fontSize: 14.5,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_pages.length, (i) {
              final active = i == _index;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 26 : 8,
                height: 8,
                decoration: BoxDecoration(
                  color: active ? page.gradient[1] : const Color(0xFFD7DDEB),
                  borderRadius: BorderRadius.circular(8),
                ),
              );
            }),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                gradient: LinearGradient(colors: [page.gradient.first, page.gradient[1]]),
                boxShadow: [
                  BoxShadow(
                    color: page.gradient.first.withValues(alpha: 0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(30),
                  onTap: _next,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _isLast ? 'Get Started' : 'Next',
                        style: const TextStyle(color: Colors.white, fontSize: 16.5, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(width: 8),
                      Icon(_isLast ? Icons.check_rounded : Icons.arrow_forward_rounded, color: Colors.white, size: 21),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
