import 'dart:async';

import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../settings/label_sizes.dart';
import '../settings/template_service.dart';
import 'connect_printer_screen.dart';
import 'margin_editor.dart';

/// More > Printer > Label Printer.
/// Works with a dual printer (receipts + labels on the same device) or with a
/// separate label printer, in TSPL / ESC-POS / ZPL / CPCL, gap / black mark /
/// continuous labels, with test label and calibration.
class LabelPrinterScreen extends StatelessWidget {
  /// Opened from a label Print button: pop(true) after Continue so the
  /// original print can go ahead.
  final bool returnOnReady;
  const LabelPrinterScreen({super.key, this.returnOnReady = false});

  @override
  Widget build(BuildContext context) => AppTabScreen(
        title: 'Label Printer',
        onBack: () => Navigator.pop(context, false),
        body: LabelPrinterPanel(returnOnReady: returnOnReady),
      );
}

/// The label printer settings without any app bar (used by the Printer
/// Settings tabs and by [LabelPrinterScreen]).
class LabelPrinterPanel extends StatefulWidget {
  final bool returnOnReady;
  const LabelPrinterPanel({super.key, this.returnOnReady = false});

  @override
  State<LabelPrinterPanel> createState() => _LabelPrinterPanelState();
}

class _LabelPrinterPanelState extends State<LabelPrinterPanel> {
  final svc = ThermalPrinterService.instance;

  bool _loading = true;
  String? _busy; // which action is running: test | calibrate | connect
  String? _error;
  String? _info;
  bool _linked = false;
  double _w = 50, _h = 30;
  DocumentTemplate? _tpl; // active label template (its margins are edited here)

  @override
  void initState() {
    super.initState();
    svc.addListener(_refresh);
    _init();
  }

  @override
  void dispose() {
    svc.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _init() async {
    await svc.load();
    try {
      final t = await TemplateService.instance.active(TemplateKind.label);
      _w = t.labelWidthMm;
      _h = t.labelHeightMm;
      _tpl = t;
    } catch (_) {}
    final linked = await svc.isLabelPrinterLinked();
    if (!mounted) return;
    setState(() {
      _loading = false;
      _linked = linked;
    });
  }

  Future<void> _run(String key, Future<void> Function() job, {String? success}) async {
    if (_busy != null) return;
    setState(() {
      _busy = key;
      _error = null;
      _info = null;
    });
    try {
      await job();
      if (mounted && success != null) setState(() => _info = success);
    } on PrinterException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Something went wrong. Please try again.');
    }
    final linked = await svc.isLabelPrinterLinked();
    if (mounted) {
      setState(() {
        _busy = null;
        _linked = linked;
      });
    }
  }

  Future<bool> _prepareBluetooth() async {
    if (!await svc.isSupported()) {
      setState(() => _error = 'This phone does not support Bluetooth.');
      return false;
    }
    if (!await svc.hasPermissions() && !await svc.requestPermissions()) {
      setState(() => _error = 'Please allow the Bluetooth permission, then try again.');
      return false;
    }
    if (!await svc.isBluetoothOn() && !await svc.enableBluetooth()) {
      setState(() => _error = 'Bluetooth was not turned on. Please turn it on and try again.');
      return false;
    }
    return true;
  }

  Future<void> _pickPrinter() async {
    setState(() {
      _error = null;
      _info = null;
    });
    if (!await _prepareBluetooth() || !mounted) return;
    final d = await showModalBottomSheet<PrinterDevice>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _DeviceSheet(),
    );
    if (d == null || !mounted) return;
    await _run('connect', () async {
      if (!d.paired && !await svc.pair(d)) {
        throw const PrinterException('Pairing failed. Turn the printer on and accept the pairing request (PIN is usually 0000 or 1234).');
      }
      if (!await svc.connectLabelPrinter(d)) {
        throw const PrinterException('Could not connect. Make sure the printer is on and not connected to another phone.');
      }
    }, success: 'Label printer connected. Print a test label to check size and darkness.');
  }

  Future<void> _openReceiptPrinter() async {
    await Navigator.push<bool>(context, AppTransitions.seamless<bool>(const ConnectPrinterScreen()));
    await svc.load();
    final linked = await svc.isLabelPrinterLinked();
    if (mounted) setState(() => _linked = linked);
  }

  /// Margins live in the active label template, so the label designer, the
  /// preview and the printed label all use the same numbers.
  Future<void> _setMargins(double l, double r, double t, double b) async {
    final tpl = _tpl;
    if (tpl == null) return;
    final next = tpl.copyWith(labelMarginL: l, labelMarginR: r, labelMarginT: t, labelMarginB: b);
    setState(() => _tpl = next);
    await TemplateService.instance.save(next);
  }

  Future<void> _autoMargins() async {
    final tpl = _tpl;
    if (tpl == null) return;
    final next = tpl.copyWith(labelMarginL: -1, labelMarginR: -1, labelMarginT: -1, labelMarginB: -1);
    setState(() => _tpl = next);
    await TemplateService.instance.save(next);
  }

  Widget _marginCard() {
    final tpl = _tpl!;
    final m = LabelMargins.of(tpl);
    return _card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _heading('Label margins', 'Empty space between the label edge and its content. Saved in the active label template (${tpl.name}).'),
        Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 110),
            child: FittedBox(
              fit: BoxFit.contain,
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.lightDivider),
                  boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 8, offset: Offset(0, 3))],
                ),
                child: LabelPreview(template: tpl, price: 250),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        MarginEditor(
          left: m.left,
          right: m.right,
          top: m.top,
          bottom: m.bottom,
          maxSide: LabelMargins.maxSide(tpl.labelWidthMm),
          maxVertical: LabelMargins.maxVertical(tpl.labelHeightMm),
          onChanged: _setMargins,
          resetLabel: 'Auto',
          onReset: m.isAuto ? null : _autoMargins,
          caption: m.isAuto ? 'Automatic: fits the label size.' : 'Custom margins. Tap Auto to go back to automatic.',
        ),
      ]),
    );
  }

  Future<void> _test() => _run('test', () => svc.printLabelTest(widthMm: _w, heightMm: _h), success: 'Test label sent to the printer.');

  Future<void> _calibrate() => _run('calibrate', () => svc.calibrateLabels(widthMm: _w, heightMm: _h), success: 'Calibration command sent. The printer will feed a few labels.');

  Future<void> _forget() => _run('forget', () => svc.forgetLabelPrinter(), success: 'Label printer removed.');

  // ------------------------------------------------------------------- ui

  @override
  Widget build(BuildContext context) => _loading ? const Center(child: CircularProgressIndicator()) : _body();

  Widget _card({required Widget child}) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.lightCardBorder),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: child,
      );

  Widget _heading(String t, [String? sub]) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(t, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
          if (sub != null) ...[
            const SizedBox(height: 3),
            Text(sub, style: const TextStyle(fontSize: 12, color: AppColors.lightTextSecondary, height: 1.35)),
          ],
          const SizedBox(height: 10),
        ],
      );

  Widget _chips(List<String> labels, int selected, ValueChanged<int> onTap) => Row(
        children: [
          for (var i = 0; i < labels.length; i++) ...[
            if (i > 0) const SizedBox(width: 6),
            Expanded(
              child: GestureDetector(
                onTap: () => onTap(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: selected == i ? AppColors.primary : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: selected == i ? AppColors.primary : AppColors.lightDivider, width: 1.2),
                  ),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(labels[i], style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: selected == i ? Colors.white : AppColors.lightTextPrimary)),
                  ),
                ),
              ),
            ),
          ],
        ],
      );

  Widget _message(String text, Color color, IconData icon) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withValues(alpha: .3)),
        ),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w600, height: 1.35))),
        ]),
      );

  String _n(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);

  Widget _body() {
    final same = svc.labelSamePrinter;
    final has = svc.hasLabelPrinter;
    final statusColor = _linked ? AppColors.income : AppColors.expense;
    final busy = _busy != null;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
      children: [
        // ---- status
        _card(
          child: Row(children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), shape: BoxShape.circle),
              child: const Icon(Icons.label_rounded, color: AppColors.primary, size: 26),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(has ? (svc.labelName ?? 'Label Printer') : 'No label printer', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
                const SizedBox(height: 2),
                Text(has ? (same ? 'Same as receipt printer (dual printer)' : 'Separate label printer') : (same ? 'Receipt printer is not connected yet' : 'Select a label printer below'), style: const TextStyle(fontSize: 12, color: AppColors.lightTextSecondary)),
                if (has) ...[
                  const SizedBox(height: 7),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(color: statusColor.withValues(alpha: .12), borderRadius: BorderRadius.circular(20)),
                    child: Text(_busy == 'connect' ? 'Connecting...' : (_linked ? 'Connected' : 'Not connected (connects when printing)'), style: TextStyle(color: statusColor, fontWeight: FontWeight.w800, fontSize: 11.5)),
                  ),
                ],
              ]),
            ),
          ]),
        ),

        // ---- which printer
        const SizedBox(height: 14),
        _card(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _heading('Printer', 'Dual printer: one device prints receipts and labels. Otherwise connect a separate label printer.'),
            _chips(const ['Same as receipt printer', 'Separate label printer'], same ? 0 : 1, (i) => busy ? null : svc.setLabelSamePrinter(i == 0)),
            const SizedBox(height: 12),
            if (same)
              AppButton3D(
                label: svc.hasSavedPrinter ? 'Receipt printer settings' : 'Connect Printer',
                icon: Icons.bluetooth_searching_rounded,
                outlined: svc.hasSavedPrinter,
                expand: true,
                onPressed: busy ? null : _openReceiptPrinter,
              )
            else
              AppButton3D(
                label: _busy == 'connect' ? 'Connecting...' : (svc.labelAddress == null ? 'Select Label Printer' : 'Change Label Printer'),
                icon: Icons.bluetooth_searching_rounded,
                outlined: svc.labelAddress != null,
                expand: true,
                onPressed: busy ? null : _pickPrinter,
              ),
          ]),
        ),

        // ---- label size
        const SizedBox(height: 14),
        _card(
          child: Row(children: [
            const Icon(Icons.straighten_rounded, color: AppColors.primary),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Label size: ${_n(_w)} x ${_n(_h)} mm', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
                const SizedBox(height: 2),
                const Text('Taken from the active label template (More > Invoice/Label Settings > Label).', style: TextStyle(fontSize: 11.5, color: AppColors.lightTextSecondary, height: 1.3)),
              ]),
            ),
          ]),
        ),

        // ---- margins
        if (_tpl != null) ...[
          const SizedBox(height: 14),
          _marginCard(),
        ],

        // ---- media
        const SizedBox(height: 14),
        _card(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _heading('Label type', 'How the printer finds the start of the next label.'),
            _chips([for (final m in LabelMedia.values) m.title], svc.labelMedia.index, (i) => svc.setLabelMedia(LabelMedia.values[i])),
            if (svc.labelMedia != LabelMedia.continuous) ...[
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: Text(svc.labelMedia == LabelMedia.gap ? 'Gap between labels' : 'Black mark height', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.lightTextPrimary))),
                _stepButton(Icons.remove_rounded, () => svc.setLabelGap(svc.labelGapMm - .5)),
                SizedBox(width: 64, child: Center(child: Text('${_n(svc.labelGapMm)} mm', style: const TextStyle(fontWeight: FontWeight.w800)))),
                _stepButton(Icons.add_rounded, () => svc.setLabelGap(svc.labelGapMm + .5)),
              ]),
            ],
          ]),
        ),

        // ---- language
        const SizedBox(height: 14),
        _card(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _heading('Printer language', 'TSPL works with most label printers (Xprinter, Gprinter, TSC, Munbyn, HPRT). If nothing prints, try ESC/POS, then ZPL or CPCL.'),
            _chips([for (final l in LabelLanguage.values) l.title], svc.labelLanguage.index, (i) => svc.setLabelLanguage(LabelLanguage.values[i])),
          ]),
        ),

        // ---- quality
        const SizedBox(height: 14),
        _card(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _heading('Print quality'),
            const Text('Resolution', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.lightTextPrimary)),
            const SizedBox(height: 6),
            _chips(const ['203 dpi (most printers)', '300 dpi'], svc.labelDpi == 300 ? 1 : 0, (i) => svc.setLabelDpi(i == 1 ? 300 : 203)),
            const SizedBox(height: 12),
            Row(children: [
              const Expanded(child: Text('Darkness', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.lightTextPrimary))),
              Text('${svc.labelDensity}', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
            ]),
            Slider(min: 1, max: 15, divisions: 14, value: svc.labelDensity.toDouble(), onChanged: (v) => svc.setLabelDensity(v.round())),
            Row(children: [
              const Expanded(child: Text('Speed', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.lightTextPrimary))),
              Text('${svc.labelSpeed}', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
            ]),
            Slider(min: 1, max: 5, divisions: 4, value: svc.labelSpeed.toDouble(), onChanged: (v) => svc.setLabelSpeed(v.round())),
            const SizedBox(height: 10),
            const Text('Sending speed', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.lightTextPrimary)),
            const SizedBox(height: 2),
            const Text('If labels print wrongly, stop half-way or the printer switches off, choose Safe.', style: TextStyle(fontSize: 11.5, color: AppColors.lightTextSecondary)),
            const SizedBox(height: 6),
            _chips(const ['Fast', 'Normal', 'Safe'], svc.printSpeed, (i) => svc.setPrintSpeed(i)),
            const SizedBox(height: 12),
            Row(children: [
              const Expanded(child: Text('Shift right / left', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.lightTextPrimary))),
              _stepButton(Icons.remove_rounded, () => svc.setLabelOffsetX(svc.labelOffsetX - .5)),
              SizedBox(width: 64, child: Center(child: Text('${_n(svc.labelOffsetX)} mm', style: const TextStyle(fontWeight: FontWeight.w800)))),
              _stepButton(Icons.add_rounded, () => svc.setLabelOffsetX(svc.labelOffsetX + .5)),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              const Expanded(child: Text('Shift up / down', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.lightTextPrimary))),
              _stepButton(Icons.remove_rounded, () => svc.setLabelOffsetY(svc.labelOffsetY - .5)),
              SizedBox(width: 64, child: Center(child: Text('${_n(svc.labelOffsetY)} mm', style: const TextStyle(fontWeight: FontWeight.w800)))),
              _stepButton(Icons.add_rounded, () => svc.setLabelOffsetY(svc.labelOffsetY + .5)),
            ]),
            const Padding(
              padding: EdgeInsets.only(top: 4, bottom: 2),
              child: Text('Print a test label, then shift until the border sits evenly on all four sides.', style: TextStyle(fontSize: 11.5)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Rotate 180°', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Use if the label prints upside down.', style: TextStyle(fontSize: 11.5)),
              value: svc.labelRotate,
              onChanged: svc.setLabelRotate,
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Invert black / white', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Use if the label prints as a black block or negative.', style: TextStyle(fontSize: 11.5)),
              value: svc.labelInvert,
              onChanged: svc.setLabelInvert,
            ),
          ]),
        ),

        if (_error != null) _message(_error!, AppColors.expense, Icons.error_outline_rounded),
        if (_info != null) _message(_info!, AppColors.income, Icons.check_circle_outline_rounded),

        // ---- actions
        const SizedBox(height: 18),
        if (has) ...[
          AppButton3D(label: _busy == 'test' ? 'Printing...' : 'Print Test Label', icon: Icons.print_rounded, expand: true, onPressed: busy ? null : _test),
          const SizedBox(height: 10),
          AppButton3D(label: _busy == 'calibrate' ? 'Calibrating...' : 'Calibrate Labels', icon: Icons.tune_rounded, outlined: true, expand: true, onPressed: busy ? null : _calibrate),
          if (!same) ...[
            const SizedBox(height: 10),
            AppButton3D(label: 'Forget Label Printer', icon: Icons.bluetooth_disabled_rounded, outlined: true, color: AppColors.expense, expand: true, onPressed: busy ? null : _forget),
          ],
          if (widget.returnOnReady) ...[
            const SizedBox(height: 10),
            AppButton3D(label: 'Continue', icon: Icons.arrow_forward_rounded, expand: true, onPressed: () => Navigator.pop(context, true)),
          ],
        ],
      ],
    );
  }

  Widget _stepButton(IconData icon, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: AppColors.primary, size: 20),
        ),
      );
}

/// Bottom sheet that lists paired + nearby Bluetooth devices.
class _DeviceSheet extends StatefulWidget {
  const _DeviceSheet();

  @override
  State<_DeviceSheet> createState() => _DeviceSheetState();
}

class _DeviceSheetState extends State<_DeviceSheet> {
  final svc = ThermalPrinterService.instance;
  final List<PrinterDevice> _devices = [];
  bool _scanning = false;
  StreamSubscription<PrinterDevice>? _foundSub;
  StreamSubscription<void>? _doneSub;

  @override
  void initState() {
    super.initState();
    _foundSub = svc.onDeviceFound.listen(_onFound);
    _doneSub = svc.onScanFinished.listen((_) {
      if (mounted) setState(() => _scanning = false);
    });
    _load();
  }

  @override
  void dispose() {
    _foundSub?.cancel();
    _doneSub?.cancel();
    svc.stopScan();
    super.dispose();
  }

  Future<void> _load() async {
    final paired = await svc.pairedDevices();
    if (!mounted) return;
    setState(() {
      _devices
        ..clear()
        ..addAll(paired);
      _scanning = true;
    });
    final started = await svc.startScan();
    if (mounted && !started) setState(() => _scanning = false);
  }

  void _onFound(PrinterDevice d) {
    if (!mounted) return;
    final i = _devices.indexWhere((e) => e.address == d.address);
    setState(() {
      if (i >= 0) {
        _devices[i] = PrinterDevice(name: d.name.isNotEmpty ? d.name : _devices[i].name, address: d.address, paired: d.paired || _devices[i].paired);
      } else {
        _devices.add(d);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final paired = _devices.where((d) => d.paired).toList();
    final nearby = _devices.where((d) => !d.paired).toList();
    Widget tile(PrinterDevice d) => ListTile(
          leading: Icon(d.paired ? Icons.print_rounded : Icons.bluetooth_rounded, color: AppColors.primary),
          title: Text(d.displayName, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(d.address, style: const TextStyle(fontSize: 11.5)),
          trailing: d.paired ? null : const Text('Pair', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800)),
          onTap: () => Navigator.pop(context, d),
        );
    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(maxHeight: height * .75),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 10),
          Container(width: 60, height: 5, decoration: BoxDecoration(color: const Color(0xFFE3E7EE), borderRadius: BorderRadius.circular(10))),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 12, 6),
            child: Row(children: [
              const Expanded(child: Text('Select label printer', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
              if (_scanning)
                const Padding(padding: EdgeInsets.all(8), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.2)))
              else
                TextButton.icon(onPressed: _load, icon: const Icon(Icons.refresh_rounded, size: 18), label: const Text('Rescan')),
            ]),
          ),
          Flexible(
            child: ListView(shrinkWrap: true, children: [
              if (paired.isNotEmpty) const Padding(padding: EdgeInsets.fromLTRB(20, 4, 20, 2), child: Text('Paired printers', style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.lightTextSecondary, fontSize: 12.5))),
              for (final d in paired) tile(d),
              if (nearby.isNotEmpty) const Padding(padding: EdgeInsets.fromLTRB(20, 8, 20, 2), child: Text('Nearby devices', style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.lightTextSecondary, fontSize: 12.5))),
              for (final d in nearby) tile(d),
              if (_devices.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(28),
                  child: Center(child: Text(_scanning ? 'Searching for printers...' : 'No devices found. Turn the printer on and tap Rescan.', textAlign: TextAlign.center, style: const TextStyle(color: AppColors.lightTextSecondary))),
                ),
              const SizedBox(height: 12),
            ]),
          ),
        ]),
      ),
    );
  }
}
