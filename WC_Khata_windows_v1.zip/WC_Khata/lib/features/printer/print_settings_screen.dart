import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/services/print_mode_service.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/app_tab_screen.dart';
import 'connect_printer_screen.dart';
import 'label_printer_screen.dart';
import 'receipt_designer_screen.dart';

/// More > Printer. One place for both printers:
///  - Receipt printer (thermal 58 / 80 mm): connect, paper, width, speed, battery protection,
///    (receipt design lives in More > Invoice/Label Settings > 58/80mm Receipt)
///  - Label printer (or a dual printer): size source, label type, language, quality, alignment
class PrintSettingsScreen extends StatefulWidget {
  /// 0 = Receipt, 1 = Label.
  final int initialTab;
  const PrintSettingsScreen({super.key, this.initialTab = 0});

  @override
  State<PrintSettingsScreen> createState() => _PrintSettingsScreenState();
}

class _PrintSettingsScreenState extends State<PrintSettingsScreen> {
  final svc = ThermalPrinterService.instance;
  late int _tab = widget.initialTab;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    svc.addListener(_refresh);
    PrintModeService.instance.addListener(_refresh);
    Future.wait([svc.load(), PrintModeService.instance.load()]).then((_) {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  void dispose() {
    svc.removeListener(_refresh);
    PrintModeService.instance.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return AppTabScreen(
      title: 'Printer Settings',
      onBack: () => Navigator.pop(context),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : PrintModeService.instance.external
              ? _externalNotice()
              : Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
                child: _statusRow(),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: _tabs(),
              ),
              Expanded(
                child: IndexedStack(
                  index: _tab,
                  children: const [
                    _ReceiptPanel(),
                    LabelPrinterPanel(),
                  ],
                ),
              ),
            ]),
    );
  }

  /// Shown instead of the app's printer screens while the external print
  /// service is ON: the app's own printing system cannot be used.
  Widget _externalNotice() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.lightDivider),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), shape: BoxShape.circle),
                child: const Icon(Icons.print_disabled_rounded, color: AppColors.primary),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text('App printer is off', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
              ),
            ]),
            const SizedBox(height: 12),
            const Text(
              'External Print Service is ON, so this app\'s own printing system cannot be used. '
              'When you tap Print, the Android print screen opens and the document is printed through the print service you have installed.',
              style: TextStyle(color: AppColors.lightTextSecondary, height: 1.45, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),
            const Text(
              'To use the app\'s own printer again, turn OFF  Settings > External Print Service.',
              style: TextStyle(fontWeight: FontWeight.w800, height: 1.45),
            ),
          ]),
        ),
      ],
    );
  }

  Widget _statusRow() {
    final receiptOn = svc.connected;
    final hasReceipt = svc.hasSavedPrinter;
    final hasLabel = svc.hasLabelPrinter;
    return Row(children: [
      Expanded(child: _statusCard(Icons.receipt_long_rounded, 'Receipt', hasReceipt ? (svc.printerName ?? 'Printer') : 'Not set up', hasReceipt ? (receiptOn ? 'Connected' : 'Saved') : null, receiptOn)),
      const SizedBox(width: 10),
      Expanded(child: _statusCard(Icons.label_rounded, 'Label', hasLabel ? (svc.labelName ?? 'Printer') : 'Not set up', hasLabel ? (svc.labelSamePrinter ? 'Dual printer' : 'Separate') : null, hasLabel)),
    ]);
  }

  Widget _statusCard(IconData icon, String title, String name, String? badge, bool good) {
    final color = good ? AppColors.income : AppColors.lightTextSecondary;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.lightCardBorder),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Row(children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), shape: BoxShape.circle),
          child: Icon(icon, color: AppColors.primary, size: 20),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 11, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w700)),
            Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
            if (badge != null)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Row(children: [
                  Container(width: 7, height: 7, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
                  const SizedBox(width: 5),
                  Text(badge, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: color)),
                ]),
              ),
          ]),
        ),
      ]),
    );
  }

  Widget _tabs() {
    Widget tab(int i, IconData icon, String text) {
      final sel = _tab == i;
      return Expanded(
        child: GestureDetector(
          onTap: () => setState(() => _tab = i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(vertical: 11),
            decoration: BoxDecoration(
              color: sel ? Colors.white : Colors.transparent,
              borderRadius: BorderRadius.circular(11),
              boxShadow: sel ? const [BoxShadow(color: Color(0x14000000), blurRadius: 6, offset: Offset(0, 2))] : null,
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, size: 18, color: sel ? AppColors.primary : AppColors.lightTextSecondary),
              const SizedBox(width: 6),
              Text(text, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: sel ? AppColors.lightTextPrimary : AppColors.lightTextSecondary)),
            ]),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: const Color(0xFFF0F2F5), borderRadius: BorderRadius.circular(14)),
      child: Row(children: [
        tab(0, Icons.receipt_long_rounded, 'Receipt Printer'),
        tab(1, Icons.label_rounded, 'Label Printer'),
      ]),
    );
  }
}

/// Receipt (thermal) printer settings.
class _ReceiptPanel extends StatefulWidget {
  const _ReceiptPanel();

  @override
  State<_ReceiptPanel> createState() => _ReceiptPanelState();
}

class _ReceiptPanelState extends State<_ReceiptPanel> {
  final svc = ThermalPrinterService.instance;
  bool _testing = false;
  bool _reconnecting = false;
  String? _error;
  String? _info;

  @override
  void initState() {
    super.initState();
    svc.addListener(_refresh);
  }

  @override
  void dispose() {
    svc.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _connectFlow() async {
    await Navigator.push<bool>(context, AppTransitions.seamless<bool>(const ConnectPrinterScreen(returnOnReady: true)));
    await svc.load();
    if (mounted) setState(() {});
  }

  Future<void> _change() async {
    await svc.forget();
    if (!mounted) return;
    await _connectFlow();
  }

  Future<void> _reconnect() async {
    setState(() {
      _reconnecting = true;
      _error = null;
      _info = null;
    });
    final ok = await svc.silentReconnect();
    if (!mounted) return;
    setState(() {
      _reconnecting = false;
      if (!ok) _error = 'Could not connect. Turn on the printer and Bluetooth, then try again.';
    });
  }

  Future<void> _test() async {
    setState(() {
      _testing = true;
      _error = null;
      _info = null;
    });
    try {
      await svc.printTest();
      if (mounted) setState(() => _info = 'Test page sent. Check that the border is complete on both sides.');
    } on PrinterException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Test print failed. Please try again.');
    }
    if (mounted) setState(() => _testing = false);
  }

  Future<void> _disconnect() async {
    await svc.forget();
    if (mounted) setState(() {});
  }

  // ------------------------------------------------------------------- ui

  Widget _card(String title, String? sub, Widget child, {IconData? icon}) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.lightCardBorder),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            if (icon != null) ...[Icon(icon, size: 18, color: AppColors.primary), const SizedBox(width: 7)],
            Expanded(child: Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary))),
          ]),
          if (sub != null) ...[
            const SizedBox(height: 3),
            Text(sub, style: const TextStyle(fontSize: 12, color: AppColors.lightTextSecondary, height: 1.35)),
          ],
          const SizedBox(height: 11),
          child,
        ]),
      );

  Widget _chips(List<String> labels, int selected, ValueChanged<int> onTap) => Row(children: [
        for (var i = 0; i < labels.length; i++) ...[
          if (i > 0) const SizedBox(width: 7),
          Expanded(
            child: GestureDetector(
              onTap: () => onTap(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                padding: const EdgeInsets.symmetric(vertical: 11),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: selected == i ? AppColors.primary : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: selected == i ? AppColors.primary : AppColors.lightDivider, width: 1.2),
                ),
                child: Text(labels[i], style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: selected == i ? Colors.white : AppColors.lightTextPrimary)),
              ),
            ),
          ),
        ],
      ]);

  Widget _message(String text, Color color, IconData icon) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withValues(alpha: .3)),
        ),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w600, height: 1.35))),
        ]),
      );

  // ---- modern layout helpers -------------------------------------------

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 6, 4, 8),
        child: Text(t.toUpperCase(), style: const TextStyle(fontSize: 11, letterSpacing: .8, fontWeight: FontWeight.w900, color: AppColors.lightTextSecondary)),
      );

  Widget _panel(List<Widget> children) => Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.lightCardBorder),
        ),
        child: Column(children: children),
      );

  Widget _divider() => const Divider(height: 1, thickness: 1, color: AppColors.lightDivider);

  /// 58 / 80 mm paper roll picker drawn as two little paper strips.
  Widget _paperPicker(int mm) {
    Widget roll(int v, String title, String sub) {
      final sel = mm == v;
      return Expanded(
        child: GestureDetector(
          onTap: () => svc.setPaper(v),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            decoration: BoxDecoration(
              color: sel ? AppColors.primary.withValues(alpha: .08) : Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: sel ? AppColors.primary : AppColors.lightDivider, width: sel ? 1.6 : 1),
            ),
            child: Row(children: [
              Container(
                width: v == 80 ? 34 : 24,
                height: 38,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(3),
                  border: Border.all(color: sel ? AppColors.primary : AppColors.lightTextSecondary, width: 1.2),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  for (var k = 0; k < 4; k++)
                    Container(margin: const EdgeInsets.symmetric(vertical: 2.5, horizontal: 4), height: 2, color: (sel ? AppColors.primary : AppColors.lightTextSecondary).withValues(alpha: .6)),
                ]),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: sel ? AppColors.primary : AppColors.lightTextPrimary)),
                  Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary)),
                ]),
              ),
              if (sel) const Icon(Icons.check_circle_rounded, size: 18, color: AppColors.primary),
            ]),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(children: [
        roll(58, '58 mm', 'Small / pocket'),
        const SizedBox(width: 10),
        roll(80, '80 mm', 'Counter printer'),
      ]),
    );
  }

  Widget _speedTile(int i, IconData icon, String title, String sub, {String? badge}) {
    final sel = svc.printSpeed == i;
    return InkWell(
      onTap: () => svc.setPrintSpeed(i),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(color: (sel ? AppColors.primary : AppColors.lightTextSecondary).withValues(alpha: .12), shape: BoxShape.circle),
            child: Icon(icon, size: 20, color: sel ? AppColors.primary : AppColors.lightTextSecondary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
                if (badge != null) ...[
                  const SizedBox(width: 7),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(color: AppColors.income.withValues(alpha: .14), borderRadius: BorderRadius.circular(99)),
                    child: Text(badge, style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w900, color: AppColors.income)),
                  ),
                ],
              ]),
              const SizedBox(height: 2),
              Text(sub, style: const TextStyle(fontSize: 11.5, height: 1.3, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
            ]),
          ),
          Icon(sel ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: sel ? AppColors.primary : AppColors.lightDivider),
        ]),
      ),
    );
  }

  Widget _switchTile(String title, String sub, bool value, ValueChanged<bool> onChanged) => Padding(
        padding: const EdgeInsets.fromLTRB(14, 6, 8, 6),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800)),
              Text(sub, style: const TextStyle(fontSize: 11.5, height: 1.3, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
            ]),
          ),
          Switch.adaptive(value: value, activeColor: AppColors.primary, onChanged: onChanged),
        ]),
      );

  Widget _linkTile(IconData icon, String title, String sub, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: AppColors.primary, size: 21),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
                Text(sub, style: const TextStyle(fontSize: 11.5, height: 1.3, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
              ]),
            ),
            const Icon(Icons.chevron_right_rounded, color: AppColors.lightTextSecondary),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final saved = svc.hasSavedPrinter;
    final connected = svc.connected;
    if (!saved) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
        children: [
          _card(
            'No receipt printer',
            'Connect a Bluetooth thermal printer (58 mm or 80 mm) to print receipts, reports and invoices.',
            AppButton3D(label: 'Connect Printer', icon: Icons.bluetooth_searching_rounded, expand: true, onPressed: _connectFlow),
            icon: Icons.print_disabled_rounded,
          ),
        ],
      );
    }

    final mm = svc.paperMm;
    final minDots = ThermalPrinterService.minDots(mm).toDouble();
    final maxDots = ThermalPrinterService.maxDots(mm).toDouble();
    final dots = svc.printDots.toDouble().clamp(minDots, maxDots).toDouble();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
      children: [
        // ---- printer
        _panel([
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(children: [
              Row(children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), borderRadius: BorderRadius.circular(14)),
                  child: const Icon(Icons.print_rounded, color: AppColors.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(svc.printerName ?? 'Printer', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 3),
                    Row(children: [
                      Container(width: 8, height: 8, decoration: BoxDecoration(color: connected ? AppColors.income : AppColors.lightTextSecondary, shape: BoxShape.circle)),
                      const SizedBox(width: 6),
                      Flexible(child: Text(connected ? 'Connected and ready' : 'Not connected. Connects when you print', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary))),
                    ]),
                  ]),
                ),
              ]),
              const SizedBox(height: 12),
              if (!connected)
                AppButton3D(label: _reconnecting ? 'Connecting...' : 'Reconnect', icon: Icons.bluetooth_connected_rounded, expand: true, onPressed: _reconnecting ? null : _reconnect)
              else
                AppButton3D(label: _testing ? 'Printing...' : 'Print Test Page', icon: Icons.print_rounded, expand: true, onPressed: _testing ? null : _test),
            ]),
          ),
        ]),
        if (_error != null) _message(_error!, AppColors.expense, Icons.error_outline_rounded),
        if (_info != null) _message(_info!, AppColors.income, Icons.check_circle_outline_rounded),

        // ---- paper
        _sectionTitle('Paper roll'),
        _panel([_paperPicker(mm)]),

        // ---- speed
        _sectionTitle('Print speed'),
        _panel([
          _speedTile(0, Icons.bolt_rounded, 'Fast', 'Full speed on 58 mm and 80 mm. The whole bill goes to the printer in one piece, no waiting.', badge: 'DEFAULT'),
          _divider(),
          _speedTile(1, Icons.speed_rounded, 'Normal', 'Balanced. Small pauses, for printers that miss some lines in Fast.'),
          _divider(),
          _speedTile(2, Icons.shield_rounded, 'Safe', 'Slowest and gentlest. Only if the printer switches off or stops half-way.'),
        ]),

        // ---- receipt look
        _sectionTitle('Receipt look'),
        _panel([
          _linkTile(Icons.receipt_long_rounded, 'Receipt design & margins', 'Logo, margins, header, footer and text size for 58 mm / 80 mm bills.', () => Navigator.push(context, AppTransitions.seamless(const ReceiptDesignerScreen()))),
        ]),

        // ---- advanced
        _sectionTitle('Advanced'),
        _panel([
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
            child: Row(children: [
              const Expanded(child: Text('Print width', style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800))),
              Text('${dots.round()} dots', style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.primary)),
              TextButton(onPressed: () => svc.setPrintDots(mm, ThermalPrinterService.defaultDots(mm)), child: const Text('Reset', style: TextStyle(fontWeight: FontWeight.w800))),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Slider(value: dots, min: minDots, max: maxDots, divisions: ((maxDots - minDots) / 8).round(), onChanged: (v) => svc.setPrintDots(mm, v.round())),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(14, 0, 14, 10),
            child: Text('Receipt narrow? Increase. Right side cut off? Decrease. Then print a test page.', style: TextStyle(fontSize: 11.5, height: 1.3, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
          ),
          _divider(),
          _switchTile('Fast text print (58 & 80 mm)', 'Prints bills with the printer\'s own font: instant, no step-by-step. Bills with a logo or Urdu text print as a picture.', svc.textFastPrint, svc.setTextFastPrint),
          _divider(),
          _switchTile('Battery protection', 'Used in Normal and Safe. Fast mode never waits.', svc.powerSafe, svc.setPowerSafe),
          _divider(),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
            child: const Text('Print mode', style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _chips(const ['Standard', 'Compatible'], svc.printMode, svc.setPrintMode),
              const SizedBox(height: 6),
              const Text('Use Compatible only if the printer prints garbage or blank paper.', style: TextStyle(fontSize: 11.5, height: 1.3, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),

        AppButton3D(label: 'Change Printer', icon: Icons.swap_horiz_rounded, outlined: true, expand: true, onPressed: _change),
        const SizedBox(height: 10),
        AppButton3D(label: 'Disconnect', icon: Icons.bluetooth_disabled_rounded, outlined: true, color: AppColors.expense, expand: true, onPressed: _disconnect),
      ],
    );
  }
}
