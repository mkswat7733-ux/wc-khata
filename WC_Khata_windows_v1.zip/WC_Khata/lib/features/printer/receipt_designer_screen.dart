import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import '../../app/theme/app_theme.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/utils/branding.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/widgets/app_message.dart';
import '../../data/repositories/profile_repository.dart';
import '../items/item_repository.dart';
import '../sale/bill_context.dart';
import '../sale/bill_paper.dart';
import '../sale/sale_repository.dart';
import '../sale/thermal_receipt.dart';
import '../settings/template_service.dart';
import 'margin_editor.dart';
import 'printer_gate.dart';
import 'receipt_settings.dart';

/// Full-screen Customize Receipt (opened from the sale receipt screen).
/// The same designer also lives inside More > Invoice/Label Settings >
/// "58/80mm Receipt" tab as [ReceiptDesignerPanel] (embedded: true).
class ReceiptDesignerScreen extends StatelessWidget {
  const ReceiptDesignerScreen({super.key});

  @override
  Widget build(BuildContext context) => const ReceiptDesignerPanel();
}

/// The receipt design system: live preview that stays on top, then logo,
/// margins, header, details, footer and text size. Every change is saved at
/// once and is used by the receipt preview, the printer and the shared
/// receipt PDF.
///
/// [embedded] = true: no app bar / Scaffold (it sits inside a tab of another
/// screen), no "Done" button.
class ReceiptDesignerPanel extends StatefulWidget {
  final bool embedded;
  const ReceiptDesignerPanel({super.key, this.embedded = false});

  @override
  State<ReceiptDesignerPanel> createState() => _ReceiptDesignerPanelState();
}

class _ReceiptDesignerPanelState extends State<ReceiptDesignerPanel> with WidgetsBindingObserver {
  final store = ReceiptSettingsService.instance;
  final GlobalKey _captureKey = GlobalKey();

  late final TextEditingController _header;
  late final TextEditingController _footer;
  late final TextEditingController _footer2;

  BillPaper _paper = BillPaper.mm58;
  BillContext? _bill;
  bool _busy = false;
  bool _guides = true;
  int _tab = 0;
  bool _forPrint = false; // the fixed footer line is hidden on screen, printed on paper

  ReceiptSettings get d => store.value;

  // The parent Scaffold resizes for the keyboard and then reports a zero
  // keyboard inset to its body, so MediaQuery cannot be trusted in here. The
  // real inset comes from the window itself.
  bool _keyboardOpen = false;

  @override
  void didChangeMetrics() {
    final views = WidgetsBinding.instance.platformDispatcher.views;
    final open = views.isNotEmpty && views.first.viewInsets.bottom > 0;
    if (open != _keyboardOpen && mounted) setState(() => _keyboardOpen = open);
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _header = TextEditingController(text: d.headerText);
    _footer = TextEditingController(text: d.footerText);
    _footer2 = TextEditingController(text: d.footerText2);
    store.addListener(_onStore);
    store.load().then((_) {
      if (!mounted) return;
      _header.text = d.headerText;
      _footer.text = d.footerText;
      _footer2.text = d.footerText2;
      setState(() {});
    });
    _paper = BillPaper.fromThermalMm(ThermalPrinterService.instance.paperMm);
    _loadSample();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    store.removeListener(_onStore);
    _header.dispose();
    _footer.dispose();
    _footer2.dispose();
    super.dispose();
  }

  void _onStore() {
    if (mounted) setState(() {});
  }

  void _set(ReceiptSettings next) => store.update(next);

  void _toast(String m) {
    if (!mounted) return;
    AppMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  /// A sample sale built with the shop's real name / address / phone.
  Future<void> _loadSample() async {
    String? name, address, phone;
    try {
      final p = await ProfileRepository().getOrCreate();
      name = p.name?.trim();
      address = p.address?.trim();
      phone = p.phone?.trim();
    } catch (_) {}
    String? clean(String? v) => (v == null || v.isEmpty) ? null : v;

    ItemRecord item(int id, String n, double price) => ItemRecord(
          id: id,
          name: n,
          categoryId: null,
          category: '',
          unit: 'pcs',
          qty: 100,
          lowStock: 0,
          price: price,
          imagePath: null,
          barcode: null,
          supplierId: null,
          purchaseType: null,
          purchaseAmount: 0,
          purchasePaid: 0,
          purchaseDate: null,
        );

    final lines = [
      SaleLine(item: item(1, 'Sample Product One', 250), qty: 2),
      SaleLine(item: item(2, 'Sample Product Two', 120), qty: 1),
      SaleLine(item: item(3, 'Sample Product Three', 75.5), qty: 4),
    ];
    final subtotal = lines.fold<double>(0, (s, l) => s + l.total);
    final sale = SavedSale(
      id: 0,
      invoiceNo: 'INV-0001',
      total: subtotal,
      paid: subtotal,
      paymentType: 'cash',
      date: DateTime.now(),
      customerId: null,
      lines: lines,
      subtotal: subtotal,
    );
    if (!mounted) return;
    setState(() {
      _bill = BillContext(
        sale: sale,
        businessName: clean(name) ?? 'WC Khata',
        address: clean(address),
        phone: clean(phone),
        customerName: 'Walk-in Customer',
        invoiceId: 'INV-0001',
      );
    });
  }

  // ----------------------------------------------------------------- actions

  Future<void> _pickLogo() async {
    try {
      final path = await TemplateService.instance.pickLogo();
      if (path == null) return;
      _set(d.copyWith(logoPath: path, showLogo: true));
    } catch (_) {
      _toast('Could not load the logo. Please try another image.');
    }
  }

  Future<void> _useBusinessPhoto() async {
    try {
      final p = await ProfileRepository().getOrCreate();
      final path = p.photoPath?.trim() ?? '';
      if (path.isEmpty) {
        _toast('No business photo found in your profile. Choose a logo instead.');
        return;
      }
      _set(d.copyWith(logoPath: path, showLogo: true));
    } catch (_) {
      _toast('Could not read your business profile.');
    }
  }

  Future<void> _testPrint() async {
    if (_busy || _bill == null) return;
    if (!await PrinterGate.ensure(context)) return;
    setState(() {
      _busy = true;
      _forPrint = true;
      _guides = false; // guides are outside the capture, but keep the preview clean while printing
    });
    try {
      await WidgetsBinding.instance.endOfFrame;
      await Future<void>.delayed(const Duration(milliseconds: 120));
      final boundary = _captureKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) throw StateError('Receipt is not ready.');
      final ui.Image image = await boundary.toImage(pixelRatio: 3.5);
      final ByteData? data = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (data == null) throw StateError('Could not create receipt image.');
      await ThermalPrinterService.instance.printPng(data.buffer.asUint8List(), paperMm: _paper.mm);
      _toast('Sample receipt sent to the printer.');
    } on PrinterException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('Could not print the sample receipt.');
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _forPrint = false;
          _guides = true;
        });
      }
    }
  }

  Future<void> _reset() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Reset receipt design?', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        content: const Text('Margins, text and options go back to normal. Your logo file is kept.', style: TextStyle(color: AppColors.lightTextSecondary, height: 1.4)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Reset', style: TextStyle(fontWeight: FontWeight.w800))),
        ],
      ),
    );
    if (ok != true) return;
    await store.reset();
    _header.text = d.headerText;
    _footer.text = d.footerText;
    _footer2.text = d.footerText2;
  }

  // ---------------------------------------------------------------------- ui

  static const _tabs = <(IconData, String)>[
    (Icons.image_rounded, 'Logo'),
    (Icons.crop_free_rounded, 'Margins'),
    (Icons.storefront_rounded, 'Header'),
    (Icons.visibility_rounded, 'Details'),
    (Icons.format_size_rounded, 'Text'),
  ];

  Widget _tabBar(double s) => SizedBox(
        height: 44 * s,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: EdgeInsets.symmetric(horizontal: 12 * s),
          itemCount: _tabs.length,
          separatorBuilder: (_, __) => SizedBox(width: 8 * s),
          itemBuilder: (_, i) {
            final sel = _tab == i;
            return GestureDetector(
              onTap: () => setState(() => _tab = i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                padding: EdgeInsets.symmetric(horizontal: 14 * s),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: sel ? AppColors.primary : Colors.white,
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(color: sel ? AppColors.primary : AppColors.lightDivider),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(_tabs[i].$1, size: 16 * s, color: sel ? Colors.white : AppColors.lightTextSecondary),
                  SizedBox(width: 6 * s),
                  Text(_tabs[i].$2, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w900, color: sel ? Colors.white : AppColors.lightTextPrimary)),
                ]),
              ),
            );
          },
        ),
      );

  Widget _activeSection(double s) {
    switch (_tab) {
      case 0:
        return _section(s, Icons.image_rounded, 'Logo', 'Print your shop logo at the top of the receipt.', _logoSection(s));
      case 1:
        return _section(s, Icons.crop_free_rounded, 'Margins', 'Empty space around the receipt. Blue dotted lines in the preview show it.', _marginSection(s));
      case 2:
        return _section(s, Icons.storefront_rounded, 'Header', 'What is printed at the top.', _headerSection(s));
      case 3:
        return _section(s, Icons.visibility_rounded, 'Details', 'Turn each part of the bill on or off.', _detailSwitches(s));
      default:
        return _section(s, Icons.format_size_rounded, 'Text', 'Size and weight of the text.', _textSection(s));
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    // Preview stays pinned on top; the section tabs switch what is edited
    // below it. While the keyboard is open the preview and bottom bar hide so
    // nothing can overflow on a small screen.
    final keyboardOpen = _keyboardOpen || MediaQuery.viewInsetsOf(context).bottom > 0;
    final content = Column(children: [
      if (!widget.embedded) _header_(s),
      if (!keyboardOpen) _previewCard(s),
      Padding(padding: EdgeInsets.only(top: keyboardOpen ? 8 * s : 2 * s, bottom: 4 * s), child: _tabBar(s)),
      Expanded(
        child: ListView(
          physics: const BouncingScrollPhysics(),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: EdgeInsets.fromLTRB(12 * s, 0, 12 * s, 14 * s),
          children: [_activeSection(s)],
        ),
      ),
      if (!keyboardOpen) _bottomBar(s),
    ]);
    if (widget.embedded) return content;
    return Scaffold(backgroundColor: AppColors.lightBackground, body: content);
  }

  Widget _header_(double s) => SafeArea(
        bottom: false,
        child: Container(
          height: 60 * s,
          padding: EdgeInsets.symmetric(horizontal: 12 * s),
          decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
          child: Row(children: [
            AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
            Expanded(
              child: Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('Customize Receipt', style: TextStyle(fontSize: 17 * s, fontWeight: FontWeight.w900)),
                Text('Saved automatically', style: TextStyle(fontSize: 10.5 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
              ]),
            ),
            SizedBox(width: 42 * s),
          ]),
        ),
      );

  Widget _previewCard(double s) {
    final bill = _bill;
    final mmPx = ThermalReceipt.pxPerMm(_paper);
    return Container(
      margin: EdgeInsets.fromLTRB(12 * s, 8 * s, 12 * s, 6 * s),
      padding: EdgeInsets.fromLTRB(10 * s, 8 * s, 10 * s, 10 * s),
      decoration: BoxDecoration(
        color: const Color(0xFF2B323B),
        borderRadius: BorderRadius.circular(18 * s),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          Icon(Icons.receipt_long_rounded, size: 15 * s, color: Colors.white70),
          SizedBox(width: 6 * s),
          Text('Live preview', style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w900, color: Colors.white)),
          const Spacer(),
          GestureDetector(
            onTap: () => setState(() => _guides = !_guides),
            child: Padding(
              padding: EdgeInsets.only(right: 8 * s),
              child: Icon(_guides ? Icons.grid_4x4_rounded : Icons.grid_off_rounded, size: 17 * s, color: _guides ? const Color(0xFF7DB3FF) : Colors.white54),
            ),
          ),
          _paperChip(s, BillPaper.mm58),
          SizedBox(width: 6 * s),
          _paperChip(s, BillPaper.mm80),
        ]),
        SizedBox(height: 8 * s),
        // The paper is shown at a readable width and scrolls, so a long 80mm
        // bill is never shrunk into an unreadable thumbnail.
        SizedBox(
          height: 250 * s,
          child: bill == null
              ? const Center(child: CircularProgressIndicator())
              : ClipRRect(
                  borderRadius: BorderRadius.circular(6 * s),
                  child: Container(
                    color: const Color(0xFF3A424C),
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: EdgeInsets.symmetric(vertical: 8 * s),
                      child: Center(
                        child: SizedBox(
                          width: 300 * s,
                          child: FittedBox(
                            fit: BoxFit.fitWidth,
                            child: Container(
                              decoration: const BoxDecoration(boxShadow: [BoxShadow(color: Color(0x66000000), blurRadius: 10, offset: Offset(0, 4))]),
                              child: Stack(children: [
                                RepaintBoundary(key: _captureKey, child: ThermalReceipt(bill: bill, paper: _paper, design: d, showBranding: _forPrint)),
                                if (_guides)
                                  Positioned.fill(
                                    child: IgnorePointer(
                                      child: CustomPaint(painter: _MarginGuides(d.marginLeft * mmPx, d.marginTop * mmPx, d.marginRight * mmPx, d.marginBottom * mmPx)),
                                    ),
                                  ),
                              ]),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
        ),
      ]),
    );
  }

  Widget _paperChip(double s, BillPaper p) {
    final sel = _paper == p;
    return GestureDetector(
      onTap: () => setState(() => _paper = p),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 11 * s, vertical: 4 * s),
        decoration: BoxDecoration(
          color: sel ? AppColors.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: sel ? AppColors.primary : Colors.white38),
        ),
        child: Text(p.label, style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w900, color: Colors.white)),
      ),
    );
  }

  Widget _section(double s, IconData icon, String title, String sub, Widget child) => Container(
        margin: EdgeInsets.only(top: 10 * s),
        padding: EdgeInsets.all(13 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18 * s),
          border: Border.all(color: AppColors.lightCardBorder),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 10 * s, offset: Offset(0, 4 * s))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 32 * s,
              height: 32 * s,
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), shape: BoxShape.circle),
              child: Icon(icon, color: AppColors.primary, size: 17 * s),
            ),
            SizedBox(width: 9 * s),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w900)),
                Text(sub, style: TextStyle(fontSize: 10.5 * s, color: AppColors.lightTextSecondary)),
              ]),
            ),
          ]),
          SizedBox(height: 11 * s),
          child,
        ]),
      );

  /// A fixed line the user cannot change: shown with a lock, no switch.
  Widget _lockedRow(double s, String label) => Container(
        margin: EdgeInsets.only(bottom: 6 * s),
        padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 12 * s),
        decoration: BoxDecoration(color: AppColors.lightBackground, borderRadius: BorderRadius.circular(13 * s)),
        child: Row(children: [
          Expanded(child: Text(label, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800))),
          Text('Fixed', style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary)),
          SizedBox(width: 6 * s),
          Icon(Icons.lock_rounded, size: 16 * s, color: AppColors.lightTextSecondary),
        ]),
      );

  Widget _switchRow(double s, String label, bool value, ValueChanged<bool> onChanged) => Container(
        margin: EdgeInsets.only(bottom: 6 * s),
        padding: EdgeInsets.symmetric(horizontal: 12 * s),
        decoration: BoxDecoration(color: AppColors.lightBackground, borderRadius: BorderRadius.circular(13 * s)),
        child: Row(children: [
          Expanded(child: Text(label, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800))),
          Switch.adaptive(value: value, activeColor: AppColors.primary, onChanged: onChanged),
        ]),
      );

  Widget _chips(List<String> labels, int selected, ValueChanged<int> onTap) => Row(children: [
        for (var i = 0; i < labels.length; i++) ...[
          if (i > 0) const SizedBox(width: 7),
          Expanded(
            child: GestureDetector(
              onTap: () => onTap(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                padding: const EdgeInsets.symmetric(vertical: 10),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: selected == i ? AppColors.primary : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: selected == i ? AppColors.primary : AppColors.lightDivider, width: 1.2),
                ),
                child: Text(labels[i], style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: selected == i ? Colors.white : AppColors.lightTextPrimary)),
              ),
            ),
          ),
        ],
      ]);

  InputDecoration _fieldDeco(String label, {String? hint}) => InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: AppColors.lightBackground,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none),
      );

  // ---- logo
  Widget _logoSection(double s) {
    final has = (d.logoPath ?? '').isNotEmpty;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _switchRow(s, 'Print logo', d.showLogo, (v) => _set(d.copyWith(showLogo: v))),
      Row(children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: _pickLogo,
            icon: const Icon(Icons.photo_library_rounded, size: 18),
            label: Text(has ? 'Change logo' : 'Choose logo', style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        ),
        if (has) ...[
          const SizedBox(width: 8),
          IconButton(
            tooltip: 'Remove logo',
            onPressed: () => _set(d.copyWith(clearLogo: true)),
            icon: const Icon(Icons.delete_outline_rounded, color: AppColors.expense),
          ),
        ],
      ]),
      const SizedBox(height: 6),
      TextButton.icon(
        onPressed: _useBusinessPhoto,
        icon: const Icon(Icons.storefront_rounded, size: 17),
        label: const Text('Use my business photo', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      if (has) ...[
        const SizedBox(height: 4),
        Row(children: [
          const Expanded(child: Text('Logo size', style: TextStyle(fontWeight: FontWeight.w700))),
          Text('${d.logoWidthPct.round()}%', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
        ]),
        Slider(
          min: 20,
          max: 100,
          divisions: 16,
          value: d.logoWidthPct.clamp(20.0, 100.0).toDouble(),
          onChanged: (v) => _set(d.copyWith(logoWidthPct: v)),
        ),
        const Text('Position', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        _chips(const ['Left', 'Center', 'Right'], d.logoAlign, (i) => _set(d.copyWith(logoAlign: i))),
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Sharp black & white', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('Recommended. Thermal printers cannot print colours or soft greys.', style: TextStyle(fontSize: 11.5)),
          value: d.logoHighContrast,
          onChanged: (v) => _set(d.copyWith(logoHighContrast: v)),
        ),
      ] else
        const Padding(
          padding: EdgeInsets.only(top: 4),
          child: Text('Tip: a simple dark logo on a white background prints best.', style: TextStyle(fontSize: 11.5, color: AppColors.lightTextSecondary)),
        ),
    ]);
  }

  // ---- margins
  Widget _marginPresets(double s) {
    Widget chip(String t, double side, double vert) {
      final on = d.marginLeft == side && d.marginRight == side && d.marginTop == vert && d.marginBottom == vert;
      return Expanded(
        child: GestureDetector(
          onTap: () => _set(d.copyWith(marginLeft: side, marginRight: side, marginTop: vert, marginBottom: vert)),
          child: Container(
            margin: EdgeInsets.only(right: 6 * s),
            padding: EdgeInsets.symmetric(vertical: 10 * s),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: on ? AppColors.primary.withValues(alpha: .10) : Colors.white,
              borderRadius: BorderRadius.circular(12 * s),
              border: Border.all(color: on ? AppColors.primary : AppColors.lightDivider, width: on ? 1.5 : 1),
            ),
            child: Text(t, style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w900, color: on ? AppColors.primary : AppColors.lightTextPrimary)),
          ),
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.only(bottom: 12 * s),
      child: Row(children: [
        chip('Narrow', 1, 2),
        chip('Normal', 2, 3.5),
        chip('Wide', 4, 5),
      ]),
    );
  }

  Widget _marginSection(double s) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_marginPresets(s), _marginEditor(s)]);

  Widget _marginEditor(double s) => MarginEditor(
        left: d.marginLeft,
        right: d.marginRight,
        top: d.marginTop,
        bottom: d.marginBottom,
        maxSide: ReceiptSettings.maxSideMargin,
        maxVertical: ReceiptSettings.maxVerticalMargin,
        onChanged: (l, r, t, b) => _set(d.copyWith(marginLeft: l, marginRight: r, marginTop: t, marginBottom: b)),
        resetLabel: 'Reset margins',
        onReset: () => _set(d.copyWith(
          marginLeft: ReceiptSettings.defaults.marginLeft,
          marginRight: ReceiptSettings.defaults.marginRight,
          marginTop: ReceiptSettings.defaults.marginTop,
          marginBottom: ReceiptSettings.defaults.marginBottom,
        )),
        caption: 'If the printer cuts the edge of the receipt, increase Left / Right. To change the full print width use Print width in Receipt Printer.',
      );

  // ---- header
  Widget _headerSection(double s) => Column(children: [
        _switchRow(s, 'Business name', d.showBusinessName, (v) => _set(d.copyWith(showBusinessName: v))),
        _switchRow(s, 'Address', d.showAddress, (v) => _set(d.copyWith(showAddress: v))),
        _switchRow(s, 'Phone number', d.showPhone, (v) => _set(d.copyWith(showPhone: v))),
        const SizedBox(height: 4),
        TextField(
          controller: _header,
          maxLines: 2,
          minLines: 1,
          maxLength: 80,
          onChanged: (v) => _set(d.copyWith(headerText: v)),
          style: const TextStyle(fontWeight: FontWeight.w700),
          decoration: _fieldDeco('Extra line under address', hint: 'e.g. NTN: 1234567-8  /  Open 9am - 9pm'),
        ),
      ]);

  // ---- details
  Widget _detailSwitches(double s) => Column(children: [
        _switchRow(s, 'Invoice number', d.showInvoiceNo, (v) => _set(d.copyWith(showInvoiceNo: v))),
        _switchRow(s, 'Date & time', d.showDate, (v) => _set(d.copyWith(showDate: v))),
        _switchRow(s, 'Customer / supplier', d.showParty, (v) => _set(d.copyWith(showParty: v))),
        _switchRow(s, 'Payment type', d.showPayment, (v) => _set(d.copyWith(showPayment: v))),
        _switchRow(s, 'Products / Qty count', d.showQtySummary, (v) => _set(d.copyWith(showQtySummary: v))),
        _switchRow(s, 'Discount', d.showDiscount, (v) => _set(d.copyWith(showDiscount: v))),
        _switchRow(s, 'Tax', d.showTax, (v) => _set(d.copyWith(showTax: v))),
        _switchRow(s, 'Paid & balance', d.showPaidBalance, (v) => _set(d.copyWith(showPaidBalance: v))),
        _switchRow(s, '"PAID" stamp', d.showPaidStamp, (v) => _set(d.copyWith(showPaidStamp: v))),
      ]);

  // ---- footer
  Widget _footerSection(double s) => Column(children: [
        TextField(
          controller: _footer,
          maxLines: 2,
          minLines: 1,
          maxLength: 80,
          onChanged: (v) => _set(d.copyWith(footerText: v)),
          style: const TextStyle(fontWeight: FontWeight.w700),
          decoration: _fieldDeco('Thank-you message'),
        ),
        TextField(
          controller: _footer2,
          maxLines: 3,
          minLines: 1,
          maxLength: 120,
          onChanged: (v) => _set(d.copyWith(footerText2: v)),
          style: const TextStyle(fontWeight: FontWeight.w700),
          decoration: _fieldDeco('Extra footer line', hint: 'e.g. Goods once sold will not be returned'),
        ),
        _lockedRow(s, Branding.poweredBy),
      ]);

  // ---- text
  Widget _textSection(double s) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Expanded(child: Text('Text size', style: TextStyle(fontWeight: FontWeight.w700))),
          Text('${(d.fontScale * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
        ]),
        Slider(
          min: .8,
          max: 1.3,
          divisions: 10,
          value: d.fontScale.clamp(.8, 1.3).toDouble(),
          onChanged: (v) => _set(d.copyWith(fontScale: (v * 20).round() / 20)),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Extra bold text', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('Use if the print looks faint or light.', style: TextStyle(fontSize: 11.5)),
          value: d.bold,
          onChanged: (v) => _set(d.copyWith(bold: v)),
        ),
      ]);

  Widget _bottomBar(double s) => Container(
        padding: EdgeInsets.fromLTRB(12 * s, 8 * s, 12 * s, 10 * s),
        decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.lightDivider))),
        child: SafeArea(
          top: false,
          child: Row(children: [
            SizedBox(
              height: 46 * s,
              child: OutlinedButton.icon(
                onPressed: _busy ? null : _reset,
                icon: Icon(Icons.restart_alt_rounded, size: 18 * s),
                label: Text('Reset', style: TextStyle(fontSize: 11.5 * s, fontWeight: FontWeight.w900)),
                style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13 * s))),
              ),
            ),
            SizedBox(width: 8 * s),
            Expanded(
              child: SizedBox(
                height: 46 * s,
                child: FilledButton.icon(
                  onPressed: _busy ? null : _testPrint,
                  icon: Icon(Icons.print_rounded, size: 18 * s),
                  label: Text(_busy ? 'Printing...' : 'Print Sample Receipt (${_paper.label})', style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w900)),
                  style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13 * s))),
                ),
              ),
            ),
            if (!widget.embedded) SizedBox(width: 8 * s),
            if (!widget.embedded) SizedBox(
              height: 46 * s,
              child: FilledButton(
                onPressed: () => Navigator.pop(context),
                style: FilledButton.styleFrom(backgroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13 * s))),
                child: Text('Done', style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w900)),
              ),
            ),
          ]),
        ),
      );
}

/// Dotted grey rectangle showing where the margins end (preview only, never printed).
class _MarginGuides extends CustomPainter {
  final double l, t, r, b;
  const _MarginGuides(this.l, this.t, this.r, this.b);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTRB(l, t, size.width - r, size.height - b);
    if (rect.width <= 0 || rect.height <= 0) return;
    final paint = Paint()
      ..color = const Color(0xFF3B82F6).withValues(alpha: .55)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    const dash = 4.0, gap = 3.0;
    void line(Offset a, Offset c) {
      final total = (c - a).distance;
      final dir = (c - a) / total;
      var x = 0.0;
      while (x < total) {
        final end = (x + dash).clamp(0.0, total).toDouble();
        canvas.drawLine(a + dir * x, a + dir * end, paint);
        x += dash + gap;
      }
    }

    line(rect.topLeft, rect.topRight);
    line(rect.topRight, rect.bottomRight);
    line(rect.bottomRight, rect.bottomLeft);
    line(rect.bottomLeft, rect.topLeft);
  }

  @override
  bool shouldRepaint(_MarginGuides o) => o.l != l || o.t != t || o.r != r || o.b != b;
}
