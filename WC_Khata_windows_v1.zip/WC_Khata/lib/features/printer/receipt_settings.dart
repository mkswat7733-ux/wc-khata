import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Everything the user can customise on a thermal receipt (58 mm / 80 mm):
/// logo, margins, which parts are shown, header / footer text and text size.
/// The same settings drive the preview, the printed receipt, and the shared PDF.
@immutable
class ReceiptSettings {
  // ---- logo
  final bool showLogo;
  final String? logoPath;

  /// Logo width as a percentage of the printable width (20..100).
  final double logoWidthPct;

  /// 0 = left, 1 = centre, 2 = right.
  final int logoAlign;

  /// High contrast black & white logo (prints sharper on thermal paper).
  final bool logoHighContrast;

  // ---- margins (millimetres)
  final double marginLeft, marginRight, marginTop, marginBottom;

  // ---- header
  final bool showBusinessName, showAddress, showPhone;
  final String headerText;

  // ---- details
  final bool showInvoiceNo, showDate, showParty, showPayment, showQtySummary;
  final bool showDiscount, showTax, showPaidBalance, showPaidStamp;

  // ---- footer
  final String footerText;
  final String footerText2;
  // The 'Powered by WebdSoft Company' line is fixed (see Branding.poweredBy):
  // it is always printed and has no setting.

  // ---- text
  /// 0.8 .. 1.3 (1.0 = normal)
  final double fontScale;
  final bool bold;

  const ReceiptSettings({
    this.showLogo = true,
    this.logoPath,
    this.logoWidthPct = 55,
    this.logoAlign = 1,
    this.logoHighContrast = true,
    this.marginLeft = 1.5,
    this.marginRight = 1.5,
    this.marginTop = 3.5,
    this.marginBottom = 3.5,
    this.showBusinessName = true,
    this.showAddress = true,
    this.showPhone = true,
    this.headerText = '',
    this.showInvoiceNo = true,
    this.showDate = true,
    this.showParty = true,
    this.showPayment = true,
    this.showQtySummary = true,
    this.showDiscount = true,
    this.showTax = true,
    this.showPaidBalance = true,
    this.showPaidStamp = true,
    this.footerText = 'Thank you for your business!',
    this.footerText2 = '',
    this.fontScale = 1.0,
    this.bold = false,
  });

  static const ReceiptSettings defaults = ReceiptSettings();

  static const double maxSideMargin = 12;
  static const double maxVerticalMargin = 25;

  bool get hasLogo => showLogo && (logoPath ?? '').trim().isNotEmpty;

  ReceiptSettings copyWith({
    bool? showLogo,
    String? logoPath,
    bool clearLogo = false,
    double? logoWidthPct,
    int? logoAlign,
    bool? logoHighContrast,
    double? marginLeft,
    double? marginRight,
    double? marginTop,
    double? marginBottom,
    bool? showBusinessName,
    bool? showAddress,
    bool? showPhone,
    String? headerText,
    bool? showInvoiceNo,
    bool? showDate,
    bool? showParty,
    bool? showPayment,
    bool? showQtySummary,
    bool? showDiscount,
    bool? showTax,
    bool? showPaidBalance,
    bool? showPaidStamp,
    String? footerText,
    String? footerText2,
    double? fontScale,
    bool? bold,
  }) =>
      ReceiptSettings(
        showLogo: showLogo ?? this.showLogo,
        logoPath: clearLogo ? null : (logoPath ?? this.logoPath),
        logoWidthPct: (logoWidthPct ?? this.logoWidthPct).clamp(20.0, 100.0).toDouble(),
        logoAlign: (logoAlign ?? this.logoAlign).clamp(0, 2),
        logoHighContrast: logoHighContrast ?? this.logoHighContrast,
        marginLeft: _m(marginLeft ?? this.marginLeft, maxSideMargin),
        marginRight: _m(marginRight ?? this.marginRight, maxSideMargin),
        marginTop: _m(marginTop ?? this.marginTop, maxVerticalMargin),
        marginBottom: _m(marginBottom ?? this.marginBottom, maxVerticalMargin),
        showBusinessName: showBusinessName ?? this.showBusinessName,
        showAddress: showAddress ?? this.showAddress,
        showPhone: showPhone ?? this.showPhone,
        headerText: headerText ?? this.headerText,
        showInvoiceNo: showInvoiceNo ?? this.showInvoiceNo,
        showDate: showDate ?? this.showDate,
        showParty: showParty ?? this.showParty,
        showPayment: showPayment ?? this.showPayment,
        showQtySummary: showQtySummary ?? this.showQtySummary,
        showDiscount: showDiscount ?? this.showDiscount,
        showTax: showTax ?? this.showTax,
        showPaidBalance: showPaidBalance ?? this.showPaidBalance,
        showPaidStamp: showPaidStamp ?? this.showPaidStamp,
        footerText: footerText ?? this.footerText,
        footerText2: footerText2 ?? this.footerText2,
        fontScale: (fontScale ?? this.fontScale).clamp(0.8, 1.3).toDouble(),
        bold: bold ?? this.bold,
      );

  static double _m(double v, double max) => ((v.clamp(0.0, max)) * 2).round() / 2;

  Map<String, dynamic> toJson() => {
        'showLogo': showLogo,
        'logoPath': logoPath,
        'logoWidthPct': logoWidthPct,
        'logoAlign': logoAlign,
        'logoHighContrast': logoHighContrast,
        'marginLeft': marginLeft,
        'marginRight': marginRight,
        'marginTop': marginTop,
        'marginBottom': marginBottom,
        'showBusinessName': showBusinessName,
        'showAddress': showAddress,
        'showPhone': showPhone,
        'headerText': headerText,
        'showInvoiceNo': showInvoiceNo,
        'showDate': showDate,
        'showParty': showParty,
        'showPayment': showPayment,
        'showQtySummary': showQtySummary,
        'showDiscount': showDiscount,
        'showTax': showTax,
        'showPaidBalance': showPaidBalance,
        'showPaidStamp': showPaidStamp,
        'footerText': footerText,
        'footerText2': footerText2,
        'fontScale': fontScale,
        'bold': bold,
      };

  factory ReceiptSettings.fromJson(Map<String, dynamic> j) {
    const d = ReceiptSettings.defaults;
    bool b(String k, bool def) => j[k] is bool ? j[k] as bool : def;
    double n(String k, double def) => (j[k] as num?)?.toDouble() ?? def;
    String s(String k, String def) => j[k] is String ? j[k] as String : def;
    return ReceiptSettings(
      showLogo: b('showLogo', d.showLogo),
      logoPath: (j['logoPath'] as String?)?.trim().isEmpty ?? true ? null : j['logoPath'] as String,
      logoWidthPct: n('logoWidthPct', d.logoWidthPct).clamp(20.0, 100.0).toDouble(),
      logoAlign: ((j['logoAlign'] as num?)?.toInt() ?? d.logoAlign).clamp(0, 2),
      logoHighContrast: b('logoHighContrast', d.logoHighContrast),
      marginLeft: _m(n('marginLeft', d.marginLeft), maxSideMargin),
      marginRight: _m(n('marginRight', d.marginRight), maxSideMargin),
      marginTop: _m(n('marginTop', d.marginTop), maxVerticalMargin),
      marginBottom: _m(n('marginBottom', d.marginBottom), maxVerticalMargin),
      showBusinessName: b('showBusinessName', d.showBusinessName),
      showAddress: b('showAddress', d.showAddress),
      showPhone: b('showPhone', d.showPhone),
      headerText: s('headerText', d.headerText),
      showInvoiceNo: b('showInvoiceNo', d.showInvoiceNo),
      showDate: b('showDate', d.showDate),
      showParty: b('showParty', d.showParty),
      showPayment: b('showPayment', d.showPayment),
      showQtySummary: b('showQtySummary', d.showQtySummary),
      showDiscount: b('showDiscount', d.showDiscount),
      showTax: b('showTax', d.showTax),
      showPaidBalance: b('showPaidBalance', d.showPaidBalance),
      showPaidStamp: b('showPaidStamp', d.showPaidStamp),
      footerText: s('footerText', d.footerText),
      footerText2: s('footerText2', d.footerText2),
      fontScale: n('fontScale', d.fontScale).clamp(0.8, 1.3).toDouble(),
      bold: b('bold', d.bold),
    );
  }
}

/// Loads / saves [ReceiptSettings]. Every change is saved at once and every
/// screen that listens (Printer Settings, designer, receipt preview) updates.
class ReceiptSettingsService extends ChangeNotifier {
  ReceiptSettingsService._();
  static final ReceiptSettingsService instance = ReceiptSettingsService._();

  static const String _key = 'receipt_design_v1';

  ReceiptSettings _value = ReceiptSettings.defaults;
  bool _loaded = false;

  ReceiptSettings get value => _value;

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      if (raw != null) {
        _value = ReceiptSettings.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
      }
    } catch (_) {}
    notifyListeners();
  }

  Future<void> update(ReceiptSettings next) async {
    _value = next;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, jsonEncode(next.toJson()));
    } catch (_) {}
  }

  Future<void> reset() => update(ReceiptSettings.defaults.copyWith(logoPath: _value.logoPath));
}
