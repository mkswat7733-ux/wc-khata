import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import '../../app/theme/app_theme.dart';
import '../../app/user_preferences_controller.dart';
import '../../core/widgets/app_bottom_sheet.dart';
import '../../core/widgets/modern_header.dart';
import '../../data/models/profile_model.dart';
import '../../data/repositories/profile_repository.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/app_message.dart';


class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, this.onBack});

  /// Profile doubles as a root bottom-nav tab (no back needed there,
  /// so pass null) and a screen pushed from Settings/Sidebar (pass
  /// `() => Navigator.pop(context)` there so the header's back chip
  /// actually does something).
  final VoidCallback? onBack;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _repo = ProfileRepository();
  final _nameCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _ownerCtrl = TextEditingController();
  final _designationCtrl = TextEditingController();
  final _taglineCtrl = TextEditingController();
  final _websiteCtrl = TextEditingController();
  final _whatsappCtrl = TextEditingController();
  ProfileModel? _profile;
  String? _photoPath;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _addressCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _ownerCtrl.dispose();
    _designationCtrl.dispose();
    _taglineCtrl.dispose();
    _websiteCtrl.dispose();
    _whatsappCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final p = await _repo.getOrCreate();
    if (!mounted) return;
    setState(() {
      _profile = p;
      _nameCtrl.text = p.name ?? '';
      _addressCtrl.text = p.address ?? '';
      _emailCtrl.text = p.email ?? '';
      _phoneCtrl.text = p.phone ?? '';
      _ownerCtrl.text = p.ownerName ?? '';
      _designationCtrl.text = p.designation ?? '';
      _taglineCtrl.text = p.tagline ?? '';
      _websiteCtrl.text = p.website ?? '';
      _whatsappCtrl.text = p.whatsapp ?? '';
      _photoPath = p.photoPath;
    });
  }

  Future<void> _pickPhoto() async {
    await showAppBottomSheet(
      context: context,
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.photo_library_outlined, color: AppColors.primary),
            title: const Text('Choose from Gallery'),
            onTap: () async {
              Navigator.pop(ctx);
              await _pickFromGallery();
            },
          ),
          if (_photoPath != null)
            ListTile(
              leading: const Icon(Icons.delete_outline, color: AppColors.expense),
              title: const Text('Remove Photo'),
              onTap: () {
                Navigator.pop(ctx);
                setState(() => _photoPath = null);
              },
            ),
        ],
      ),
    );
  }

  Future<void> _pickFromGallery() async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
        maxWidth: 720,
      );
      if (picked == null) return;

      // Copy into a stable app-owned location under a fixed filename so
      // the saved path never depends on the OS picker's temp cache,
      // which can be cleared independently of the app.
      final dir = await getApplicationDocumentsDirectory();
      final ext = picked.path.split('.').last;
      final dest = File('${dir.path}/profile_photo.$ext');
      await File(picked.path).copy(dest.path);

      if (!mounted) return;
      setState(() => _photoPath = dest.path);
    } catch (e) {
      if (!mounted) return;
      AppMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Couldn't open the photo picker. Please try again.")),
      );
    }
  }

  Future<void> _save() async {
    if (_profile == null || _saving) return;
    setState(() => _saving = true);
    final updated = _profile!.copyWith(
      name: _nameCtrl.text.trim(),
      address: _addressCtrl.text.trim(),
      email: _emailCtrl.text.trim(),
      phone: _phoneCtrl.text.trim(),
      ownerName: _ownerCtrl.text.trim(),
      designation: _designationCtrl.text.trim(),
      tagline: _taglineCtrl.text.trim(),
      website: _websiteCtrl.text.trim(),
      whatsapp: _whatsappCtrl.text.trim(),
      photoPath: _photoPath,
      clearPhoto: _photoPath == null,
    );
    await _repo.save(updated);
    if (!mounted) return;
    // Propagates instantly to every other screen: home header avatar,
    // and every currency amount app-wide (Finance, Goals, Budget,
    // Reports, etc.) via CurrencyFormatter.defaultSymbol.
    context.read<UserPreferencesController>().applyProfile(updated);
    setState(() {
      _profile = updated;
      _saving = false;
    });
    AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile saved')));
  }

  Widget _sectionTitle(String text, IconData icon) => Padding(
        padding: const EdgeInsets.only(bottom: 10, top: 2),
        child: Row(
          children: [
            Icon(icon, size: 18, color: AppColors.primary),
            const SizedBox(width: 8),
            Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
          ],
        ),
      );

  Widget _field(
    String label,
    TextEditingController controller,
    String hint, {
    required IconData icon,
    TextInputType? type,
    int lines = 1,
    TextCapitalization caps = TextCapitalization.none,
  }) =>
      Padding(
        padding: const EdgeInsets.only(bottom: AppDimensions.spaceMd),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: AppTextStyles.bodyMedium),
            const SizedBox(height: 6),
            TextField(
              controller: controller,
              keyboardType: type,
              maxLines: lines,
              textCapitalization: caps,
              decoration: InputDecoration(hintText: hint, prefixIcon: Icon(icon, size: 20)),
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (_profile == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final hasPhoto = _photoPath != null && File(_photoPath!).existsSync();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(
            title: 'Profile',
            onBack: widget.onBack ?? () { if (Navigator.canPop(context)) Navigator.pop(context); },
            trailing: _saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : AppButton3D(
                    label: 'Save',
                    compact: true,
                    color: AppColors.primary,
                    onPressed: _save,
                  ),
          ),
          Expanded(
            child: ListView(
        padding: const EdgeInsets.all(AppDimensions.spaceMd),
        children: [
          Center(
            child: GestureDetector(
              onTap: _pickPhoto,
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 44,
                    backgroundColor: AppColors.primary.withValues(alpha: 0.1),
                    backgroundImage: hasPhoto ? FileImage(File(_photoPath!)) : null,
                    child: hasPhoto ? null : const Icon(Icons.person, size: 40, color: AppColors.primary),
                  ),
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                      child: const Icon(Icons.edit, size: 14, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppDimensions.spaceLg),
          _sectionTitle('Administrator / Owner', Icons.verified_user_rounded),
          _field('Administrator / Owner Name', _ownerCtrl, 'Enter Your Name', icon: Icons.person_rounded, caps: TextCapitalization.words),
          _field('Designation', _designationCtrl, 'e.g. Owner, Managing Director', icon: Icons.badge_rounded, caps: TextCapitalization.words),
          const SizedBox(height: 4),
          _sectionTitle('Business Details', Icons.storefront_rounded),
          _field('Business Name', _nameCtrl, 'Your business name', icon: Icons.business_rounded, caps: TextCapitalization.words),
          _field('Tagline / Slogan (optional)', _taglineCtrl, 'e.g. Quality you can trust', icon: Icons.auto_awesome_rounded, caps: TextCapitalization.sentences),
          _field('Mobile Number', _phoneCtrl, 'Business mobile number', icon: Icons.phone_rounded, type: TextInputType.phone),
          _field('WhatsApp Number (optional)', _whatsappCtrl, 'WhatsApp number', icon: Icons.chat_rounded, type: TextInputType.phone),
          _field('Email', _emailCtrl, 'Business email', icon: Icons.email_rounded, type: TextInputType.emailAddress),
          _field('Website (optional)', _websiteCtrl, 'www.yourbusiness.com', icon: Icons.language_rounded, type: TextInputType.url),
          _field('Address (optional, stays on this device)', _addressCtrl, 'Shop / office address', icon: Icons.location_on_rounded, lines: 2, caps: TextCapitalization.sentences),
          Container(
            margin: const EdgeInsets.only(top: 4, bottom: 24),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                const Icon(Icons.badge_outlined, color: AppColors.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'These details can be shown on your Business Card. Choose what to show from Business Card > Customize.',
                    style: TextStyle(fontSize: 12, color: isDark ? Colors.white70 : AppColors.lightTextSecondary),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
          ),
        ],
      ),
    );
  }
}
