import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../app/theme/app_theme.dart';
import '../../core/services/item_image_store.dart';
import '../../core/services/scanner_settings_service.dart';
import '../../core/services/scanner_sound_service.dart';
import '../items/product_scan_screen.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/utils/unit_math.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/widgets/app_message.dart';
import '../items/item_repository.dart';
import '../ledger/ledger_party.dart';
import 'purchase_bill_repository.dart';
import 'purchase_checkout_screen.dart';
import 'purchase_line_dialog.dart';

/// Step 2 of a purchase: pick the products that were bought.
/// Same layout as New Sale - search / scan, a grid of all stock, the added
/// products at the bottom (tap one to edit it), the total and Next.
class NewPurchaseScreen extends StatefulWidget {
  final LedgerParty supplier;
  const NewPurchaseScreen({super.key, required this.supplier});

  @override
  State<NewPurchaseScreen> createState() => _NewPurchaseScreenState();
}

class _NewPurchaseScreenState extends State<NewPurchaseScreen> with SingleTickerProviderStateMixin {
  final _repo = ItemRepository();
  final _search = TextEditingController();
  final _scanner = MobileScannerController(detectionSpeed: DetectionSpeed.unrestricted);
  late final AnimationController _scanAnimation;

  List<ItemRecord> _items = [];
  final List<PurchaseLine> _cart = [];
  bool _loading = true;
  bool _scanning = false;
  String _query = '';
  String? _lastCode;
  DateTime? _lastScan;
  bool _autoCloseScanner = true;
  String _scanFeedback = 'none';
  bool _scanBusy = false;
  bool _cameraErrorReported = false;

  @override
  void initState() {
    super.initState();
    _scanAnimation = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat();
    unawaited(ScannerSoundService.instance.warmUp());
    _loadScannerSetting();
    _load();
  }

  @override
  void dispose() {
    _scanAnimation.dispose();
    _search.dispose();
    _scanner.dispose();
    super.dispose();
  }

  Future<void> _loadScannerSetting() async {
    final value = await ScannerSettingsService.instance.getAutoClose();
    if (mounted) setState(() => _autoCloseScanner = value);
  }

  Future<void> _load() async {
    final items = await _repo.getItems();
    if (mounted) setState(() { _items = items; _loading = false; });
  }

  // ------------------------------------------------------------------ cart

  PurchaseLine? _lineOf(ItemRecord item) {
    for (final l in _cart) {
      if (l.item.id == item.id) return l;
    }
    return null;
  }

  void _change(PurchaseLine line, double delta) {
    setState(() {
      final next = line.qty + delta;
      if (next <= 0) {
        _cart.remove(line);
      } else {
        line.qty = next;
      }
    });
  }

  bool _dialogOpen = false;

  /// Tap on a stock card, its + button or a scanned barcode: the quantity and
  /// cost price popup opens. "Add" puts a new product on the bill; a product
  /// that is already on the bill is edited instead.
  Future<void> _tapItem(ItemRecord item) async {
    final existing = _lineOf(item);
    await _editLine(existing ?? PurchaseLine(item: item), isNew: existing == null);
  }

  Future<void> _editLine(PurchaseLine line, {bool isNew = false}) async {
    if (_dialogOpen) return;
    _dialogOpen = true;
    PurchaseLine? result;
    try {
      result = await showPurchaseLineDialog(context, line: line, isEdit: !isNew);
    } finally {
      _dialogOpen = false;
    }
    final r = result;
    if (!mounted || r == null) return;
    setState(() {
      if (isNew) {
        _cart.add(r);
      } else {
        line.qty = r.qty;
        line.unitCost = r.unitCost;
        line.lineDiscount = r.lineDiscount;
        line.retailPrice = r.retailPrice;
      }
    });
  }

  double get _total => PurchaseCalc.r2(_cart.fold<double>(0, (a, l) => a + l.net));

  List<ItemRecord> get _filtered {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return _items;
    return _items.where((e) => e.name.toLowerCase().contains(q) || (e.barcode ?? '').toLowerCase().contains(q)).toList();
  }

  Future<void> _next() async {
    if (_cart.isEmpty) {
      AppMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('Add at least one product.')));
      return;
    }
    await Navigator.push<void>(
      context,
      MaterialPageRoute(builder: (_) => PurchaseCheckoutScreen(supplier: widget.supplier, lines: _cart.map((e) => e.copy()).toList())),
    );
    if (mounted) {
      await _load();
      setState(_cart.clear);
    }
  }

  // --------------------------------------------------------------- scanner

  Future<void> _closeScanner() async {
    if (!_scanning) return;
    try { await _scanner.stop(); } catch (_) {}
    if (mounted) setState(() { _scanning = false; _scanBusy = false; _scanFeedback = 'none'; });
  }

  Future<void> _afterScan({required int closeMs, required int keepMs}) async {
    if (_autoCloseScanner) {
      await Future<void>.delayed(Duration(milliseconds: closeMs));
      await _closeScanner();
    } else {
      await Future<void>.delayed(Duration(milliseconds: keepMs));
      if (mounted && _scanning) {
        _scanBusy = false;
        _cameraErrorReported = false;
        setState(() => _scanFeedback = 'none');
      }
    }
  }

  Future<void> _handleScannerFailure({String message = 'Scanner error. Please try again.'}) async {
    if (_scanBusy || !_scanning || _cameraErrorReported) return;
    _cameraErrorReported = true;
    if (mounted) setState(() => _scanFeedback = 'error');
    unawaited(ScannerSoundService.instance.playBarcodeError());
    if (mounted) {
      AppMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(message), duration: const Duration(milliseconds: 700)));
    }
    await _afterScan(closeMs: 350, keepMs: 700);
  }

  void _openScanner() {
    if (_scanning) return;
    _cameraErrorReported = false;
    _scanBusy = false;
    setState(() { _scanning = true; _scanFeedback = 'none'; });
  }

  ItemRecord? _findItemByCode(String code) {
    for (final e in _items) {
      if (e.barcode == code) return e;
    }
    return null;
  }

  /// Scan a product by its picture (like a barcode); the quantity / cost popup
  /// then opens for it.
  Future<void> _scanByPicture() async {
    if (_scanning) await _closeScanner();
    if (!mounted || _dialogOpen) return;
    final item = await Navigator.push<ItemRecord>(context, MaterialPageRoute(builder: (_) => ProductScanScreen(items: _items)));
    if (item == null || !mounted) return;
    await _tapItem(item);
  }

  Future<void> _onScan(BarcodeCapture capture) async {
    if (_scanBusy || !_scanning || _dialogOpen) return;
    String? code;
    for (final b in capture.barcodes) {
      final raw = b.rawValue?.trim();
      if (raw != null && raw.isNotEmpty) { code = raw; break; }
    }
    if (code == null) {
      await _handleScannerFailure(message: 'Could not read this barcode.');
      return;
    }
    final now = DateTime.now();
    if (_lastCode == code && _lastScan != null && now.difference(_lastScan!) < const Duration(milliseconds: 300)) return;
    _lastCode = code;
    _lastScan = now;
    _scanBusy = true;

    final item = _findItemByCode(code);
    if (item == null) {
      if (mounted) setState(() => _scanFeedback = 'error');
      unawaited(ScannerSoundService.instance.playBarcodeError());
      if (mounted) {
        AppMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(content: Text('No product found for this barcode.'), duration: Duration(milliseconds: 650)));
      }
      await _afterScan(closeMs: 350, keepMs: 650);
      return;
    }
    unawaited(ScannerSoundService.instance.playBarcodeSuccess());
    if (mounted) setState(() => _scanFeedback = 'success');
    await _afterScan(closeMs: 280, keepMs: 550);
    if (mounted) await _tapItem(item);
  }

  // ----------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        SafeArea(bottom: false, child: _header(s)),
        if (_scanning) _scannerView(s) else _searchBar(s),
        Expanded(child: Padding(padding: EdgeInsets.fromLTRB(14 * s, 10 * s, 14 * s, 0), child: _itemList(s))),
        _cartBar(s),
      ]),
    );
  }

  Widget _header(double s) => Container(
        height: 58 * s,
        padding: EdgeInsets.symmetric(horizontal: 14 * s),
        decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
        child: Row(children: [
          AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
          Expanded(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('New Purchase', style: TextStyle(fontSize: 19 * s, height: 1.1, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
              Text(
                widget.supplier.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w700, color: AppColors.primary),
              ),
            ]),
          ),
          // Scan the product by its picture (the barcode scanner stays in the search bar).
          AppGlassIconButton(icon: Icons.image_search_rounded, iconColor: AppColors.primary, onTap: _scanByPicture),
        ]),
      );

  Widget _searchBar(double s) => Padding(
        padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 0),
        child: Container(
          height: 48 * s,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16 * s),
            border: Border.all(color: AppColors.lightCardBorder),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 10)],
          ),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _search,
                onChanged: (v) => setState(() => _query = v),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.search_rounded, color: AppColors.primary, size: 21 * s),
                  hintText: 'Search product by name or barcode',
                  hintStyle: TextStyle(fontSize: 12 * s, color: AppColors.lightTextSecondary),
                ),
              ),
            ),
            IconButton(onPressed: _openScanner, icon: Icon(Icons.qr_code_scanner_rounded, color: AppColors.primary, size: 24 * s)),
            SizedBox(width: 3 * s),
          ]),
        ),
      );

  Widget _scannerView(double s) => Container(
        height: 210 * s,
        margin: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 0),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(22 * s)),
        child: Stack(children: [
          Positioned.fill(
            child: MobileScanner(
              controller: _scanner,
              onDetect: _onScan,
              onDetectError: (error, stack) => unawaited(_handleScannerFailure()),
              errorBuilder: (context, error) => Container(
                color: Colors.black,
                alignment: Alignment.center,
                child: const Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.camera_alt_rounded, color: Colors.white70, size: 34),
                  SizedBox(height: 8),
                  Text('Scanner error', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                ]),
              ),
            ),
          ),
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _scanAnimation,
                builder: (_, __) => CustomPaint(painter: _PurchaseScannerPainter(progress: _scanAnimation.value, feedback: _scanFeedback)),
              ),
            ),
          ),
          Positioned(top: 10 * s, left: 10 * s, child: _roundBlack(Icons.close_rounded, _closeScanner)),
          Positioned(top: 10 * s, right: 10 * s, child: _roundBlack(Icons.flash_on_rounded, () => _scanner.toggleTorch())),
          Positioned(
            bottom: 10 * s,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 6 * s),
                decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(99)),
                child: Text('Scan product barcode / QR', style: TextStyle(color: Colors.white, fontSize: 9 * s, fontWeight: FontWeight.w700)),
              ),
            ),
          ),
        ]),
      );

  Widget _roundBlack(IconData icon, VoidCallback onTap) => Material(
        color: Colors.black54,
        shape: const CircleBorder(),
        child: InkWell(onTap: onTap, customBorder: const CircleBorder(), child: Padding(padding: const EdgeInsets.all(9), child: Icon(icon, color: Colors.white))),
      );

  // ------------------------------------------------------------- stock grid

  Widget _itemList(double s) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20 * s),
          border: Border.all(color: AppColors.lightCardBorder),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 12)],
        ),
        clipBehavior: Clip.antiAlias,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _filtered.isEmpty
                ? Center(
                    child: Text(
                      _items.isEmpty ? 'No products added yet.' : 'No matching products.',
                      style: TextStyle(color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600),
                    ),
                  )
                : LayoutBuilder(builder: (context, constraints) {
                    final gap = 8 * s;
                    final width = (constraints.maxWidth - (20 * s) - (2 * gap)) / 3;
                    return GridView.builder(
                      padding: EdgeInsets.fromLTRB(10 * s, 10 * s, 10 * s, 12 * s),
                      physics: const ClampingScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: gap,
                        mainAxisSpacing: 10 * s,
                        mainAxisExtent: width,
                      ),
                      itemCount: _filtered.length,
                      itemBuilder: (_, i) => _stockCard(_filtered[i], s),
                    );
                  }),
      );

  String _fmtQty(double v) => UnitMath.fmt(v, dp: 2);

  Widget _stockCard(ItemRecord item, double s) {
    final line = _lineOf(item);
    const red = Color(0xFFDC2626);
    const orange = Color(0xFFF59E0B);
    const green = Color(0xFF16A34A);
    final tracked = item.trackStock;
    final out = tracked && item.qty <= 0;
    final low = tracked && !out && item.lowStock > 0 && item.qty <= item.lowStock;
    final badgeColor = !tracked ? const Color(0xFF64748B) : (out ? red : (low ? orange : green));
    final badgeText = !tracked ? 'No stock count' : (out ? 'Out of stock' : 'In Stock ${_fmtQty(item.qty)}');
    final picked = ItemImageStore.resolve(item.imagePath);
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16 * s),
      child: InkWell(
        onTap: () => _tapItem(item),
        borderRadius: BorderRadius.circular(16 * s),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16 * s),
            border: Border.all(color: line != null ? AppColors.primary.withValues(alpha: .45) : AppColors.lightCardBorder),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .035), blurRadius: 8 * s, offset: Offset(0, 3 * s))],
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Stack(children: [
                Positioned.fill(
                  child: Container(
                    alignment: Alignment.center,
                    padding: EdgeInsets.all(4 * s),
                    child: picked != null
                        ? Image.file(picked, width: double.infinity, height: double.infinity, fit: BoxFit.contain)
                        : Icon(Icons.inventory_2_outlined, color: AppColors.primary, size: 24 * s),
                  ),
                ),
                Positioned(
                  top: 4 * s,
                  right: 4 * s,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 5 * s, vertical: 2 * s),
                    decoration: BoxDecoration(color: badgeColor, borderRadius: BorderRadius.circular(99)),
                    child: Text(badgeText, maxLines: 1, style: TextStyle(fontSize: 7.5 * s, height: 1.1, fontWeight: FontWeight.w900, color: Colors.white)),
                  ),
                ),
              ]),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(5 * s, 2 * s, 5 * s, 4 * s),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9 * s, height: 1.05, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
                SizedBox(height: 1 * s),
                Text(
                  item.purchaseUnitPrice > 0 ? 'Cost ${CurrencyFormatter.formatCompact(item.purchaseUnitPrice)}' : 'No cost yet',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 8 * s, height: 1.05, fontWeight: FontWeight.w800, color: AppColors.primary),
                ),
                SizedBox(height: 2 * s),
                Row(children: [
                  _mini(Icons.remove_rounded, line == null ? () {} : () => _change(line, -1), s, enabled: line != null),
                  Expanded(
                    child: Center(
                      child: Text(line == null ? '0' : _fmtQty(line.qty), maxLines: 1, style: TextStyle(fontSize: 9 * s, height: 1, fontWeight: FontWeight.w900, color: AppColors.lightTextPrimary)),
                    ),
                  ),
                  _mini(Icons.add_rounded, () => _tapItem(item), s),
                ]),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _mini(IconData icon, VoidCallback onTap, double s, {bool enabled = true}) => InkWell(
        onTap: enabled ? onTap : null,
        child: Container(
          width: 22 * s,
          height: 22 * s,
          decoration: BoxDecoration(color: enabled ? Colors.white : const Color(0xFFE5E7EB), borderRadius: BorderRadius.circular(7 * s)),
          child: Icon(icon, size: 13 * s, color: enabled ? AppColors.primary : AppColors.lightTextSecondary.withValues(alpha: .5)),
        ),
      );

  // --------------------------------------------------------------- cart bar

  Widget _thumb(ItemRecord item, double s) {
    final picked = ItemImageStore.resolve(item.imagePath);
    return Container(
      width: 52 * s,
      height: 52 * s,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(13 * s)),
      child: picked != null ? Image.file(picked, fit: BoxFit.contain) : Icon(Icons.inventory_2_rounded, color: AppColors.primary, size: 24 * s),
    );
  }

  Widget _cartBar(double s) => Container(
        padding: EdgeInsets.fromLTRB(14 * s, 7 * s, 14 * s, 10 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          border: const Border(top: BorderSide(color: AppColors.lightDivider)),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .06), blurRadius: 12)],
        ),
        child: SafeArea(
          top: false,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (_cart.isNotEmpty) ...[
              SizedBox(
                height: 64 * s,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: _cart.length,
                  separatorBuilder: (_, __) => SizedBox(width: 8 * s),
                  itemBuilder: (_, i) => _cartChip(_cart[i], s),
                ),
              ),
              SizedBox(height: 7 * s),
            ],
            Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text('${_cart.length} products', style: TextStyle(fontSize: 10 * s, color: AppColors.lightTextSecondary)),
                  Text(CurrencyFormatter.formatCompact(_total), style: TextStyle(fontSize: 17 * s, fontWeight: FontWeight.w900, color: AppColors.lightTextPrimary)),
                  if (_cart.isNotEmpty) Text('Tap a product to edit', style: TextStyle(fontSize: 8 * s, fontWeight: FontWeight.w700, color: AppColors.primary)),
                ]),
              ),
              SizedBox(width: 12 * s),
              SizedBox(
                width: 118 * s,
                height: 46 * s,
                child: FilledButton(
                  onPressed: _cart.isEmpty ? null : _next,
                  style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14 * s))),
                  child: Text('Next', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13 * s)),
                ),
              ),
            ]),
          ]),
        ),
      );

  Widget _cartChip(PurchaseLine line, double s) => Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12 * s),
        child: InkWell(
          onTap: () => _editLine(line),
          borderRadius: BorderRadius.circular(12 * s),
          child: Container(
            width: 158 * s,
            padding: EdgeInsets.symmetric(horizontal: 7 * s, vertical: 5 * s),
            decoration: BoxDecoration(
              color: AppColors.lightBackground,
              borderRadius: BorderRadius.circular(12 * s),
              border: Border.all(color: line.unitCost <= 0 ? const Color(0xFFF59E0B) : AppColors.lightCardBorder),
            ),
            child: Row(children: [
              _thumb(line.item, s),
              SizedBox(width: 6 * s),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(line.item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9 * s, fontWeight: FontWeight.w800)),
                  Text(
                    line.unitCost <= 0 ? 'Set price' : CurrencyFormatter.formatCompact(line.net),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 8.5 * s, fontWeight: FontWeight.w800, color: line.unitCost <= 0 ? const Color(0xFFF59E0B) : AppColors.primary),
                  ),
                  SizedBox(height: 2 * s),
                  Row(children: [
                    _mini(Icons.remove_rounded, () => _change(line, -1), s),
                    Expanded(child: Center(child: Text(_fmtQty(line.qty), maxLines: 1, style: TextStyle(fontSize: 9 * s, fontWeight: FontWeight.w900)))),
                    _mini(Icons.add_rounded, () => _change(line, 1), s),
                  ]),
                ]),
              ),
            ]),
          ),
        ),
      );
}

class _PurchaseScannerPainter extends CustomPainter {
  final double progress;
  final String feedback;
  const _PurchaseScannerPainter({required this.progress, required this.feedback});

  @override
  void paint(Canvas c, Size s) {
    final box = Rect.fromCenter(center: Offset(s.width / 2, s.height / 2), width: s.width * .64, height: s.width * .64);
    final isSuccess = feedback == 'success';
    final isError = feedback == 'error';
    final baseColor = isSuccess ? Colors.greenAccent : isError ? Colors.redAccent : AppColors.primary;
    final pulse = .5 + .5 * math.sin(progress * math.pi * 2);
    c.drawRRect(
      RRect.fromRectAndRadius(box, const Radius.circular(22)),
      Paint()
        ..color = baseColor.withValues(alpha: isSuccess || isError ? .28 + .18 * pulse : .18 + .18 * pulse)
        ..style = PaintingStyle.stroke
        ..strokeWidth = isSuccess ? 11 : 8,
    );
    c.drawRRect(
      RRect.fromRectAndRadius(box, const Radius.circular(22)),
      Paint()
        ..color = baseColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = isSuccess ? 5 : 3,
    );
    final y = box.top + box.height * progress;
    c.drawLine(
      Offset(box.left + 10, y),
      Offset(box.right - 10, y),
      Paint()
        ..color = isError ? Colors.redAccent : isSuccess ? Colors.greenAccent : Colors.white.withValues(alpha: .9)
        ..strokeWidth = isSuccess || isError ? 4 : 2.2
        ..strokeCap = StrokeCap.round,
    );
    if (isSuccess) {
      final path = Path()
        ..moveTo(box.center.dx - 34, box.center.dy)
        ..lineTo(box.center.dx - 10, box.center.dy + 24)
        ..lineTo(box.center.dx + 38, box.center.dy - 28);
      c.drawPath(
        path,
        Paint()
          ..color = Colors.greenAccent
          ..style = PaintingStyle.stroke
          ..strokeWidth = 6
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _PurchaseScannerPainter old) => old.progress != progress || old.feedback != feedback;
}
