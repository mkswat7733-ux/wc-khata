import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../../core/services/data_events.dart';
import '../items/item_repository.dart';
import '../ledger/ledger_party.dart';
import '../ledger/ledger_repository.dart';
import '../sale/sale_repository.dart';

/// One product on a purchase bill.
///
///   gross = qty * unitCost            (before any discount)
///   net   = gross - lineDiscount      (what this line really costs)
///
/// Qty and cost are always in the product's BASE (inner) unit, the same way
/// stock, cost price and sale price are stored everywhere else in the app.
class PurchaseLine {
  final ItemRecord item;
  double qty;
  double unitCost;
  double lineDiscount;

  /// Retail (sale) price per base unit. Saved on the product with the bill, so
  /// every later sale's profit / loss is worked out from it.
  double retailPrice;

  PurchaseLine({required this.item, this.qty = 1, double? unitCost, this.lineDiscount = 0, double? retailPrice})
      : unitCost = unitCost ?? item.purchaseUnitPrice,
        retailPrice = retailPrice ?? item.price;

  double get gross => PurchaseCalc.r2(qty * unitCost);
  double get discount => PurchaseCalc.r2(lineDiscount.clamp(0, gross).toDouble());
  double get net => PurchaseCalc.r2(gross - discount);

  PurchaseLine copy() => PurchaseLine(item: item, qty: qty, unitCost: unitCost, lineDiscount: lineDiscount, retailPrice: retailPrice);
}

class PurchaseBreakdown {
  final double subtotal; // sum of line nets (the bill's "gross total")
  final double discount;
  final double total; // net total = what we owe the supplier
  const PurchaseBreakdown({required this.subtotal, required this.discount, required this.total});
}

/// Single source of truth for purchase bill formulas.
///
///   subtotal = sum(line net)
///   discount = clamp(discount, 0, subtotal)
///   total    = subtotal - discount
class PurchaseCalc {
  PurchaseCalc._();

  static double r2(double v) => (v * 100).roundToDouble() / 100;
  static double r4(double v) => (v * 10000).roundToDouble() / 10000;

  static PurchaseBreakdown compute(Iterable<PurchaseLine> lines, {double discount = 0}) {
    final sub = r2(lines.fold<double>(0, (a, l) => a + l.net));
    final disc = r2((discount.isFinite ? discount : 0).clamp(0, sub).toDouble());
    return PurchaseBreakdown(subtotal: sub, discount: disc, total: r2(sub - disc));
  }
}

class PurchaseBillRepository {
  final LedgerRepository _ledger = LedgerRepository();

  /// All suppliers (A-Z), each with the live khata balance.
  Future<List<LedgerParty>> getSuppliers() async {
    final all = await _ledger.getParties();
    return all.where((p) => p.type == LedgerPartyType.supplier).toList();
  }

  /// Saves a purchase bill and keeps EVERYTHING in step in one transaction:
  ///  * the bill + its products,
  ///  * product stock (+qty, only for products that manage quantity),
  ///  * product cost price (net cost per unit, bill discount included),
  ///  * supplier khata (bill = total, payment = paid now) and the Cashbook.
  Future<SavedSale> savePurchase({
    required int supplierId,
    required List<PurchaseLine> lines,
    double discountAmount = 0,
    required double paidAmount,
  }) async {
    if (lines.isEmpty) throw ArgumentError('Add at least one product.');
    for (final l in lines) {
      if (!l.qty.isFinite || l.qty <= 0) throw ArgumentError('Invalid quantity for ${l.item.name}.');
      if (!l.unitCost.isFinite || l.unitCost < 0) throw ArgumentError('Invalid price for ${l.item.name}.');
    }
    const maxAmount = 10000000.0;
    final calc = PurchaseCalc.compute(lines, discount: discountAmount);
    if (calc.subtotal > maxAmount || calc.total > maxAmount || paidAmount > maxAmount) {
      throw ArgumentError('Amount must be 1 crore or less.');
    }
    if (!paidAmount.isFinite || paidAmount < 0 || paidAmount > calc.total + 0.005) {
      throw ArgumentError('Invalid paid amount.');
    }
    final paid = PurchaseCalc.r2(paidAmount > calc.total ? calc.total : paidAmount);

    final db = await AppDatabase.instance.database;
    final now = DateTime.now();
    final invoiceNo = 'PUR-${DateFormatLike(now)}-${now.microsecondsSinceEpoch.toString().substring(8)}';
    final paymentType = paid >= calc.total - 0.005 ? 'cash' : 'credit';
    // Bill discount is shared between the products in proportion to their
    // cost, so each product's cost price reflects what it really cost.
    final factor = calc.subtotal > 0 ? calc.total / calc.subtotal : 1.0;
    late int invoiceId;
    try {
      await db.transaction((txn) async {
        final supplier = await txn.query(DBConstants.tableLedgerParties, columns: ['id', 'type'], where: 'id = ?', whereArgs: [supplierId], limit: 1);
        if (supplier.isEmpty) throw ArgumentError('Supplier not found.');

        // Stock per product (a product could appear on two lines).
        final qtyByItem = <int, double>{};
        final costByItem = <int, double>{}; // effective unit cost of the LAST line of the item
        final retailByItem = <int, double>{}; // retail price of the LAST line of the item
        for (final l in lines) {
          qtyByItem[l.item.id] = (qtyByItem[l.item.id] ?? 0) + l.qty;
          costByItem[l.item.id] = PurchaseCalc.r4(l.net * factor / l.qty);
          retailByItem[l.item.id] = l.retailPrice;
        }

        invoiceId = await txn.insert(DBConstants.tablePurchaseInvoices, {
          'invoice_no': invoiceNo,
          'supplier_id': supplierId,
          'payment_type': paymentType,
          'subtotal': calc.subtotal,
          'discount_amount': calc.discount,
          'total': calc.total,
          'paid_amount': paid,
          'date': now.toIso8601String(),
          'created_at': now.toIso8601String(),
        });
        for (final l in lines) {
          await txn.insert(DBConstants.tablePurchaseInvoiceItems, {
            'purchase_invoice_id': invoiceId,
            'item_id': l.item.id,
            'item_name': l.item.name,
            'unit': l.item.baseUnit,
            'qty': l.qty,
            'unit_cost': l.unitCost,
            'line_discount': l.discount,
            'total': l.net,
          });
        }

        for (final entry in qtyByItem.entries) {
          final rows = await txn.query(DBConstants.tableItems, columns: ['qty', 'track_stock'], where: 'id = ?', whereArgs: [entry.key], limit: 1);
          if (rows.isEmpty) throw ArgumentError('Product not found.');
          final tracked = ((rows.first['track_stock'] as num?) ?? 1) != 0;
          // Purchased stock is always ADDED to what the product holds
          // (100 in stock + 100 purchased = 200).
          final delta = entry.value;
          if (tracked && delta.abs() > 0.0000001) {
            await txn.rawUpdate('UPDATE ${DBConstants.tableItems} SET qty = qty + ?, updated_at = ? WHERE id = ?', [delta, now.toIso8601String(), entry.key]);
          }
          await txn.update(
            DBConstants.tableItems,
            {
              'purchase_unit_price': costByItem[entry.key],
              if ((retailByItem[entry.key] ?? 0) > 0) 'price': retailByItem[entry.key],
              'supplier_id': supplierId,
              'updated_at': now.toIso8601String(),
            },
            where: 'id = ?',
            whereArgs: [entry.key],
          );
        }

        await _ledger.postPurchaseBillEntries(txn, supplierId: supplierId, invoiceNo: invoiceNo, total: calc.total, paid: paid, date: now);
      });
    } finally {
      DataEvents.changed();
    }
    return (await getById(invoiceId))!;
  }

  /// The newest purchase bill that contains [itemId] (id + date), or null.
  Future<({int id, DateTime date})?> latestBillRefForItem(int itemId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
      'SELECT i.id AS id, i.date AS date FROM ${DBConstants.tablePurchaseInvoices} i '
      'JOIN ${DBConstants.tablePurchaseInvoiceItems} it ON it.purchase_invoice_id = i.id '
      'WHERE it.item_id = ? ORDER BY i.date DESC, i.id DESC LIMIT 1',
      [itemId],
    );
    if (rows.isEmpty) return null;
    return (id: rows.first['id'] as int, date: DateTime.parse(rows.first['date'] as String));
  }

  /// Rebuilds a saved purchase bill in the shape the receipt / invoice screens
  /// already understand. Product price on each row is the NET cost per unit,
  /// so every row adds up to the bill's subtotal.
  Future<SavedSale?> getById(int id) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query(DBConstants.tablePurchaseInvoices, where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    final r = rows.first;
    final lineRows = await db.query(DBConstants.tablePurchaseInvoiceItems, where: 'purchase_invoice_id = ?', whereArgs: [id], orderBy: 'id ASC');
    final lines = <SaleLine>[];
    for (final row in lineRows) {
      final itemId = row['item_id'] as int;
      final itemRows = await db.query(DBConstants.tableItems, where: 'id = ?', whereArgs: [itemId], limit: 1);
      final ir = itemRows.isEmpty ? null : itemRows.first;
      final qty = (row['qty'] as num).toDouble();
      final net = (row['total'] as num).toDouble();
      final unit = qty > 0 ? net / qty : 0.0;
      final item = ItemRecord(
        id: itemId,
        name: row['item_name'] as String,
        categoryId: ir?['category_id'] as int?,
        category: 'General',
        unit: (row['unit'] as String?) ?? '',
        qty: (ir?['qty'] as num?)?.toDouble() ?? 0,
        lowStock: (ir?['low_stock'] as num?)?.toDouble() ?? 0,
        price: (ir?['price'] as num?)?.toDouble() ?? unit,
        imagePath: ir?['image_path'] as String?,
        barcode: ir?['barcode'] as String?,
        supplierId: r['supplier_id'] as int?,
        purchaseType: r['payment_type'] as String?,
        purchaseAmount: 0,
        purchaseUnitPrice: unit,
        purchasePaid: 0,
        purchaseDate: null,
      );
      lines.add(SaleLine(item: item, qty: qty, unitPrice: unit, unitCost: unit, retailPrice: item.price));
    }
    return SavedSale(
      id: id,
      invoiceNo: r['invoice_no'] as String,
      total: (r['total'] as num).toDouble(),
      paid: (r['paid_amount'] as num).toDouble(),
      paymentType: r['payment_type'] as String,
      date: DateTime.parse(r['date'] as String),
      customerId: r['supplier_id'] as int?, // the supplier of this bill
      lines: lines,
      subtotal: (r['subtotal'] as num).toDouble(),
      discountAmount: (r['discount_amount'] as num).toDouble(),
    );
  }
}
