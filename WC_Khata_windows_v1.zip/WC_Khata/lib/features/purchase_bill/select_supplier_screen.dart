import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/widgets/app_message.dart';
import '../ledger/add_party_screen.dart';
import '../ledger/both_star_badge.dart';
import '../ledger/ledger_party.dart';
import 'new_purchase_screen.dart';
import 'purchase_bill_repository.dart';

/// Step 1 of a purchase: pick the supplier.
/// Search bar, a "New Supplier" button (opens the existing add-supplier
/// screen) and a container listing every supplier that was added.
class SelectSupplierScreen extends StatefulWidget {
  const SelectSupplierScreen({super.key});

  @override
  State<SelectSupplierScreen> createState() => _SelectSupplierScreenState();
}

class _SelectSupplierScreenState extends State<SelectSupplierScreen> {
  final _repo = PurchaseBillRepository();
  final _search = TextEditingController();
  List<LedgerParty> _suppliers = [];
  bool _loading = true;
  String _query = '';
  int? _selectedId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final list = await _repo.getSuppliers();
    if (!mounted) return;
    setState(() {
      _suppliers = list;
      _loading = false;
      // A supplier that no longer exists can't stay selected.
      if (_selectedId != null && !list.any((p) => p.id == _selectedId)) _selectedId = null;
    });
  }

  List<LedgerParty> get _filtered {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return _suppliers;
    return _suppliers.where((p) => p.name.toLowerCase().contains(q) || (p.phone ?? '').toLowerCase().contains(q)).toList();
  }

  LedgerParty? get _selected {
    for (final p in _suppliers) {
      if (p.id == _selectedId) return p;
    }
    return null;
  }

  Future<void> _newSupplier() async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const AddPartyScreen(type: LedgerPartyType.supplier, returnAfterSelection: true)),
    );
    if (saved == true) await _load();
  }

  Future<void> _next() async {
    final supplier = _selected;
    if (supplier == null) {
      AppMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('Select a supplier first.')));
      return;
    }
    await Navigator.push<void>(context, MaterialPageRoute(builder: (_) => NewPurchaseScreen(supplier: supplier)));
    if (mounted) await _load();
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    final selected = _selected;
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        SafeArea(bottom: false, child: _header(s)),
        _searchBar(s),
        _newSupplierButton(s),
        Expanded(child: Padding(padding: EdgeInsets.fromLTRB(14 * s, 10 * s, 14 * s, 0), child: _list(s))),
        _bottomBar(s, selected),
      ]),
    );
  }

  Widget _header(double s) => Container(
        height: 58 * s,
        padding: EdgeInsets.symmetric(horizontal: 14 * s),
        decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
        child: Row(children: [
          AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
          Expanded(
            child: Center(
              child: Text('Select Supplier', style: TextStyle(fontSize: 19 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
            ),
          ),
          SizedBox(width: 42 * s),
        ]),
      );

  Widget _searchBar(double s) => Padding(
        padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 0),
        child: Container(
          height: 48 * s,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16 * s),
            border: Border.all(color: AppColors.lightCardBorder),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 10)],
          ),
          child: TextField(
            controller: _search,
            onChanged: (v) => setState(() => _query = v),
            decoration: InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(Icons.search_rounded, color: AppColors.primary, size: 21 * s),
              hintText: 'Search supplier by name or phone',
              hintStyle: TextStyle(fontSize: 12 * s, color: AppColors.lightTextSecondary),
            ),
          ),
        ),
      );

  Widget _newSupplierButton(double s) => Padding(
        padding: EdgeInsets.fromLTRB(14 * s, 10 * s, 14 * s, 0),
        child: SizedBox(
          width: double.infinity,
          height: 46 * s,
          child: OutlinedButton.icon(
            onPressed: _newSupplier,
            icon: Icon(Icons.person_add_alt_1_rounded, size: 19 * s),
            label: Text('New Supplier', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13 * s)),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.primary,
              backgroundColor: Colors.white,
              side: BorderSide(color: AppColors.primary.withValues(alpha: .45), width: 1.2),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15 * s)),
            ),
          ),
        ),
      );

  Widget _list(double s) {
    final list = _filtered;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20 * s),
        border: Border.all(color: AppColors.lightCardBorder),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 12)],
      ),
      clipBehavior: Clip.antiAlias,
      child: _loading
          ? const Center(child: CircularProgressIndicator())
          : list.isEmpty
              ? _empty(s)
              : ListView.builder(
                  physics: const ClampingScrollPhysics(),
                  padding: EdgeInsets.fromLTRB(10 * s, 10 * s, 10 * s, 12 * s),
                  itemCount: list.length,
                  itemBuilder: (_, i) => _tile(s, list[i]),
                ),
    );
  }

  Widget _empty(double s) => Center(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24 * s),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 58 * s,
              height: 58 * s,
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), shape: BoxShape.circle),
              child: Icon(Icons.local_shipping_rounded, color: AppColors.primary, size: 27 * s),
            ),
            SizedBox(height: 10 * s),
            Text(
              _suppliers.isEmpty ? 'No suppliers yet' : 'No matching suppliers',
              style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary),
            ),
            SizedBox(height: 4 * s),
            Text(
              _suppliers.isEmpty ? 'Tap "New Supplier" to add your first supplier.' : 'Try another name or phone number.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11 * s, color: AppColors.lightTextSecondary),
            ),
          ]),
        ),
      );

  Widget _tile(double s, LedgerParty p) {
    final isSelected = p.id == _selectedId;
    final balance = p.balance;
    String? balanceText;
    Color balanceColor = AppColors.lightTextSecondary;
    if (balance.abs() > 0.004) {
      final owe = p.isPayable;
      balanceText = '${owe ? 'You owe' : 'Advance'} ${CurrencyFormatter.formatCompact(balance.abs())}';
      balanceColor = owe ? const Color(0xFFDC2626) : const Color(0xFF16A34A);
    }
    return Padding(
      padding: EdgeInsets.only(bottom: 8 * s),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16 * s),
        child: InkWell(
          borderRadius: BorderRadius.circular(16 * s),
          onTap: () => setState(() => _selectedId = p.id),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 11 * s, vertical: 10 * s),
            decoration: BoxDecoration(
              color: isSelected ? AppColors.primary.withValues(alpha: .07) : const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(16 * s),
              border: Border.all(color: isSelected ? AppColors.primary : AppColors.lightCardBorder, width: isSelected ? 1.5 : 1),
            ),
            child: Row(children: [
              CircleAvatar(
                radius: 21 * s,
                backgroundColor: AppColors.primary.withValues(alpha: .10),
                child: Text(
                  p.name.trim().isEmpty ? '?' : p.name.trim()[0].toUpperCase(),
                  style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w900, fontSize: 15 * s),
                ),
              ),
              SizedBox(width: 10 * s),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Flexible(
                      child: Text(
                        p.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 13.5 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary),
                      ),
                    ),
                    if (p.isBoth) ...[SizedBox(width: 6 * s), BothStarBadge(size: 17 * s)],
                  ]),
                  if ((p.phone ?? '').trim().isNotEmpty) ...[
                    SizedBox(height: 2 * s),
                    Text(p.phone!, style: TextStyle(fontSize: 10.8 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w500)),
                  ],
                  if (balanceText != null) ...[
                    SizedBox(height: 2 * s),
                    Text(balanceText, style: TextStyle(fontSize: 10.5 * s, color: balanceColor, fontWeight: FontWeight.w800)),
                  ],
                ]),
              ),
              Icon(
                isSelected ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                color: isSelected ? AppColors.primary : AppColors.lightTextSecondary,
                size: 22 * s,
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _bottomBar(double s, LedgerParty? selected) => Container(
        padding: EdgeInsets.fromLTRB(14 * s, 8 * s, 14 * s, 10 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          border: const Border(top: BorderSide(color: AppColors.lightDivider)),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .06), blurRadius: 12)],
        ),
        child: SafeArea(
          top: false,
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text('Supplier', style: TextStyle(fontSize: 10 * s, color: AppColors.lightTextSecondary)),
                Text(
                  selected?.name ?? 'Not selected',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14 * s,
                    fontWeight: FontWeight.w900,
                    color: selected == null ? AppColors.lightTextSecondary : AppColors.lightTextPrimary,
                  ),
                ),
              ]),
            ),
            SizedBox(width: 12 * s),
            SizedBox(
              width: 118 * s,
              height: 46 * s,
              child: FilledButton(
                onPressed: selected == null ? null : _next,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14 * s)),
                ),
                child: Text('Next', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13 * s)),
              ),
            ),
          ]),
        ),
      );
}
