import 'package:sqflite/sqflite.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../../core/services/data_events.dart';
import '../ledger/ledger_repository.dart';
import 'pricing_calc.dart';

/// One purchase of a product (stock bought, optionally from a supplier).
class PurchaseRecord {
  final int id;
  final int itemId;
  final String itemName;
  final String unit;
  final int? supplierId;
  final String? supplierName;
  final String type; // 'cash' | 'credit'
  final double qty;
  final double unitCost;
  final double total;
  final double paid;
  final DateTime date;
  final String? note;
  final int? cashTxId;

  const PurchaseRecord({
    required this.id,
    required this.itemId,
    required this.itemName,
    required this.unit,
    required this.supplierId,
    required this.supplierName,
    required this.type,
    required this.qty,
    required this.unitCost,
    required this.total,
    required this.paid,
    required this.date,
    required this.note,
    required this.cashTxId,
  });

  /// > 0 still owed to the supplier, < 0 paid extra (receivable).
  double get due => PricingCalc.r2(total - paid);

  static PurchaseRecord fromRow(Map<String, Object?> r) => PurchaseRecord(
        id: r['id'] as int,
        itemId: r['item_id'] as int,
        itemName: r['item_name'] as String,
        unit: (r['unit'] as String?) ?? '',
        supplierId: r['supplier_id'] as int?,
        supplierName: r['supplier_name'] as String?,
        type: (r['purchase_type'] as String?) ?? 'cash',
        qty: (r['qty'] as num).toDouble(),
        unitCost: (r['unit_cost'] as num).toDouble(),
        total: (r['total'] as num).toDouble(),
        paid: (r['paid'] as num).toDouble(),
        date: DateTime.tryParse(r['purchase_date'] as String) ?? DateTime.now(),
        note: r['note'] as String?,
        cashTxId: r['cash_tx_id'] as int?,
      );
}

class PurchaseRepository {
  final LedgerRepository _ledger = LedgerRepository();

  static const _select = '''
    SELECT p.*, s.name AS supplier_name
    FROM ${DBConstants.tablePurchases} p
    LEFT JOIN ${DBConstants.tableLedgerParties} s ON s.id = p.supplier_id
  ''';

  Future<List<PurchaseRecord>> getAll({int? itemId, int limit = 300}) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
      '$_select ${itemId == null ? '' : 'WHERE p.item_id = ?'} ORDER BY p.purchase_date DESC, p.id DESC LIMIT $limit',
      itemId == null ? [] : [itemId],
    );
    return rows.map(PurchaseRecord.fromRow).toList();
  }

  Future<PurchaseRecord?> getById(int id) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('$_select WHERE p.id = ? LIMIT 1', [id]);
    return rows.isEmpty ? null : PurchaseRecord.fromRow(rows.first);
  }

  /// Ids of every product that has at least one purchase.
  Future<Set<int>> purchasedItemIds() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('SELECT DISTINCT item_id FROM ${DBConstants.tablePurchases}');
    return rows.map((r) => r['item_id'] as int).toSet();
  }

  Future<PurchaseRecord?> latestForItem(int itemId) async {
    final all = await getAll(itemId: itemId, limit: 1);
    return all.isEmpty ? null : all.first;
  }

  /// Creates ([id] null) or edits a purchase and keeps EVERYTHING in step in
  /// one transaction:
  ///  * product stock  (+qty, or +difference when editing; only when the
  ///    product has "manage quantity" on),
  ///  * product cost price (latest purchase) and, optionally, retail price,
  ///  * supplier ledger bill + payment, and the Cashbook movement.
  /// Returns the purchase id.
  Future<int> save({
    int? id,
    required int itemId,
    required int? supplierId,
    required String type,
    required double qty,
    required double unitCost,
    double? retailPrice,
    required double paid,
    required DateTime date,
    bool cashOut = true,
    String? note,
  }) async {
    const maxAmount = 10000000.0;
    if (!qty.isFinite || qty <= 0) throw ArgumentError('Enter a valid quantity.');
    if (!unitCost.isFinite || unitCost < 0) throw ArgumentError('Enter a valid purchase price.');
    final total = PricingCalc.r2(qty * unitCost);
    if (total > maxAmount || unitCost > maxAmount || (retailPrice ?? 0) > maxAmount || paid > maxAmount) {
      throw ArgumentError('Amount must be 1 crore or less.');
    }
    if (supplierId != null && type == 'credit' && (!paid.isFinite || paid < 0)) throw ArgumentError('Enter a valid paid amount.');

    final db = await AppDatabase.instance.database;
    try {
      return await db.transaction((txn) async {
        final itemRows = await txn.query(DBConstants.tableItems, where: 'id = ?', whereArgs: [itemId], limit: 1);
        if (itemRows.isEmpty) throw ArgumentError('Product not found.');
        final item = itemRows.first;
        final tracked = ((item['track_stock'] as num?) ?? 1) != 0;
        final name = item['name'] as String;
        final unit = item['unit'] as String;
        final now = DateTime.now();
        final settled = supplierId != null ? (type == 'credit' ? paid : total) : (cashOut ? total : 0.0);
        final savedType = supplierId != null ? type : 'cash';

        Map<String, Object?>? old;
        if (id != null) {
          final oldRows = await txn.query(DBConstants.tablePurchases, where: 'id = ?', whereArgs: [id], limit: 1);
          if (oldRows.isEmpty) throw ArgumentError('Purchase not found.');
          old = oldRows.first;
          if (old['item_id'] != itemId) throw ArgumentError('The product of a purchase cannot be changed.');
        }
        final oldQty = old == null ? 0.0 : (old['qty'] as num).toDouble();
        final oldCashTx = old?['cash_tx_id'] as int?;

        final values = <String, Object?>{
          'item_id': itemId,
          'item_name': name,
          'unit': unit,
          'supplier_id': supplierId,
          'purchase_type': savedType,
          'qty': qty,
          'unit_cost': unitCost,
          'total': total,
          'paid': settled,
          'purchase_date': date.toIso8601String(),
          'note': (note == null || note.trim().isEmpty) ? null : note.trim(),
          'updated_at': now.toIso8601String(),
        };
        late final int pid;
        if (old == null) {
          pid = await txn.insert(DBConstants.tablePurchases, {...values, 'created_at': now.toIso8601String()});
        } else {
          pid = id!;
          await txn.update(DBConstants.tablePurchases, values, where: 'id = ?', whereArgs: [pid]);
        }

        // Stock: add what was bought (only the difference when editing), on top
        // of what the product already holds (100 + 100 = 200).
        final stockDelta = qty - oldQty;
        if (tracked && stockDelta.abs() > 0.0000001) {
          await txn.rawUpdate('UPDATE ${DBConstants.tableItems} SET qty = qty + ?, updated_at = ? WHERE id = ?', [stockDelta, now.toIso8601String(), itemId]);
        }

        // Product cost = cost of its latest purchase; retail only when this
        // purchase is the latest one.
        final latest = await txn.query(DBConstants.tablePurchases, columns: ['id', 'unit_cost', 'supplier_id'], where: 'item_id = ?', whereArgs: [itemId], orderBy: 'purchase_date DESC, id DESC', limit: 1);
        final isLatest = latest.isNotEmpty && latest.first['id'] == pid;
        final itemUpdate = <String, Object?>{
          'purchase_unit_price': latest.isEmpty ? unitCost : (latest.first['unit_cost'] as num).toDouble(),
          'supplier_id': latest.isEmpty ? supplierId : latest.first['supplier_id'],
          'updated_at': now.toIso8601String(),
        };
        if (isLatest && retailPrice != null && retailPrice > 0) itemUpdate['price'] = retailPrice;
        await txn.update(DBConstants.tableItems, itemUpdate, where: 'id = ?', whereArgs: [itemId]);

        // Supplier ledger + Cashbook.
        final cashTx = await _ledger.syncPurchaseEntries(
          txn,
          purchaseId: pid,
          itemId: itemId,
          supplierId: supplierId,
          itemName: name,
          total: total,
          settled: settled,
          purchaseType: savedType,
          date: date,
          oldCashTxId: oldCashTx,
          cashPurchase: supplierId == null && cashOut,
        );
        await txn.update(DBConstants.tablePurchases, {'cash_tx_id': cashTx}, where: 'id = ?', whereArgs: [pid]);
        return pid;
      });
    } finally {
      DataEvents.changed();
    }
  }

  /// Deletes a purchase and undoes it everywhere: stock, supplier ledger
  /// entries, Cashbook movement, and the product's cost price.
  Future<void> delete(int id) async {
    final db = await AppDatabase.instance.database;
    try {
      await db.transaction((txn) async {
        final rows = await txn.query(DBConstants.tablePurchases, where: 'id = ?', whereArgs: [id], limit: 1);
        if (rows.isEmpty) return;
        final p = rows.first;
        final itemId = p['item_id'] as int;
        final now = DateTime.now();
        final itemRows = await txn.query(DBConstants.tableItems, columns: ['track_stock'], where: 'id = ?', whereArgs: [itemId], limit: 1);
        if (itemRows.isNotEmpty && ((itemRows.first['track_stock'] as num?) ?? 1) != 0) {
          await txn.rawUpdate('UPDATE ${DBConstants.tableItems} SET qty = MAX(qty - ?, 0), updated_at = ? WHERE id = ?', [(p['qty'] as num).toDouble(), now.toIso8601String(), itemId]);
        }
        await _ledger.syncPurchaseEntries(
          txn,
          purchaseId: id,
          itemId: itemId,
          supplierId: null,
          itemName: p['item_name'] as String,
          total: 0,
          settled: 0,
          purchaseType: 'cash',
          date: now,
          oldCashTxId: p['cash_tx_id'] as int?,
          remove: true,
        );
        await txn.delete(DBConstants.tablePurchases, where: 'id = ?', whereArgs: [id]);
        final latest = await txn.query(DBConstants.tablePurchases, columns: ['unit_cost', 'supplier_id'], where: 'item_id = ?', whereArgs: [itemId], orderBy: 'purchase_date DESC, id DESC', limit: 1);
        if (latest.isNotEmpty && itemRows.isNotEmpty) {
          await txn.update(DBConstants.tableItems, {'purchase_unit_price': (latest.first['unit_cost'] as num).toDouble(), 'supplier_id': latest.first['supplier_id']}, where: 'id = ?', whereArgs: [itemId]);
        }
      });
    } finally {
      DataEvents.changed();
    }
  }
}
