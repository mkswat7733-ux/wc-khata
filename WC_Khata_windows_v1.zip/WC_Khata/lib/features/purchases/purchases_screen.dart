import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../../app/theme/app_theme.dart';
import '../../core/services/data_events.dart';
import '../../core/services/item_image_store.dart';
import '../../core/utils/amount_limit.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/widgets/app_message.dart';
import '../items/barcode_scanner_screen.dart';
import '../items/item_repository.dart';
import '../items/new_item_screen.dart';
import '../items/purchase_invoice_screen.dart';
import '../ledger/add_party_screen.dart';
import '../ledger/both_star_badge.dart';
import '../ledger/ledger_party.dart';
import '../../core/utils/unit_math.dart';
import 'pricing_calc.dart';
import 'purchase_repository.dart';

/// Purchases: buy stock of a product (optionally from a supplier).
///
/// Saving a purchase adds the quantity to the product's stock, sets its cost
/// (and retail) price, posts the supplier's bill / payment in the supplier
/// ledger and the Cashbook - and editing or deleting it undoes / redoes all of
/// that, so every screen and report stays in step.
class PurchasesScreen extends StatefulWidget {
  /// Opens straight into edit mode for this purchase (from a purchase receipt).
  final int? editPurchaseId;

  /// Opens with this product already selected (e.g. from a low-stock alert).
  final int? initialItemId;
  const PurchasesScreen({super.key, this.editPurchaseId, this.initialItemId});

  @override
  State<PurchasesScreen> createState() => _PurchasesScreenState();
}

class _PurchasesScreenState extends State<PurchasesScreen> {
  final _itemRepo = ItemRepository();
  final _repo = PurchaseRepository();
  final _qty = TextEditingController();
  final _cost = TextEditingController();
  final _margin = TextEditingController();
  final _retail = TextEditingController();
  final _paid = TextEditingController();
  // Inner / Outer unit system: Box Qty + Strips Qty fill _qty (the quantity in
  // INNER units), and "P. Price" (total) is linked both ways to the price per
  // inner unit (_cost).
  final _boxQty = TextEditingController();
  final _stripQty = TextEditingController();
  final _pTotal = TextEditingController();
  bool _syncingQty = false;
  bool _openingStock = false; // product already holds stock and has no purchase yet
  bool _syncingPrice = false;
  String _priceDriver = 'unit'; // which of price-per-inner / P. Price was typed last

  List<ItemRecord> _items = [];
  List<Map<String, Object?>> _suppliers = [];
  ItemRecord? _selected;
  Map<String, Object?>? _supplier;
  PurchaseRecord? _editing;
  String _type = 'cash';
  DateTime _date = DateTime.now();
  // A purchase without a supplier is always paid from the Cashbook.
  final bool _cashOut = true;
  bool _saving = false;
  bool _syncing = false;
  String _driver = 'retail'; // which of margin / retail was typed last
  VoidCallback? _unlistenData;

  @override
  void initState() {
    super.initState();
    _cost.addListener(_onCost);
    _cost.addListener(_onCostForTotal);
    _pTotal.addListener(_onTotalTyped);
    _boxQty.addListener(_onBoxStrip);
    _stripQty.addListener(_onBoxStrip);
    _margin.addListener(_onMargin);
    _retail.addListener(_onRetail);
    _loadAll();
    _unlistenData = DataEvents.listen(() { if (mounted) _reloadLists(); });
  }

  @override
  void dispose() {
    _unlistenData?.call();
    for (final c in [_qty, _cost, _margin, _retail, _paid, _boxQty, _stripQty, _pTotal]) { c.dispose(); }
    super.dispose();
  }

  // ------------------------------------------------------------------ data
  Future<void> _loadAll() async {
    final items = await _itemRepo.getItems();
    final suppliers = await _itemRepo.getSuppliers();
    if (!mounted) return;
    setState(() { _items = items; _suppliers = suppliers; });
    if (widget.editPurchaseId != null) {
      final p = await _repo.getById(widget.editPurchaseId!);
      if (p != null && mounted) _startEdit(p);
    } else if (widget.initialItemId != null) {
      final match = items.where((e) => e.id == widget.initialItemId);
      if (match.isNotEmpty && mounted) _select(match.first);
    }
  }

  Future<void> _reloadLists() async {
    final items = await _itemRepo.getItems();
    final suppliers = await _itemRepo.getSuppliers();
    if (!mounted) return;
    setState(() {
      _items = items;
      _suppliers = suppliers;
      if (_selected != null) {
        final fresh = items.where((e) => e.id == _selected!.id);
        if (fresh.isNotEmpty) _selected = fresh.first;
      }
    });
  }

  // ------------------------------------------------- inner / outer units
  bool get _unitMode => _selected?.hasUnitSystem == true;

  /// Box + Strips typed -> quantity in inner units, and the total follows.
  void _onBoxStrip() {
    if (_syncingQty || !_unitMode) return;
    final it = _selected!;
    _syncingQty = true;
    final base = UnitMath.toBase(_d(_boxQty), _d(_stripQty), it.unitsPerOuter);
    _setText(_qty, base > 0 ? _num(base) : '');
    _syncingQty = false;
    _recalcPriceFromQty();
    if (mounted) setState(() {});
  }

  void _recalcPriceFromQty() {
    if (!_unitMode || _syncingPrice) return;
    _syncingPrice = true;
    final qty = _d(_qty);
    if (_priceDriver == 'unit') {
      _setText(_pTotal, (qty > 0 && _cost.text.trim().isNotEmpty) ? _money(PricingCalc.r2(qty * _d(_cost))) : '');
    } else if (qty > 0 && _pTotal.text.trim().isNotEmpty) {
      _setText(_cost, _num(_d(_pTotal) / qty));
    }
    _syncingPrice = false;
  }

  /// Price per inner unit typed -> P. Price (total) = qty x price.
  void _onCostForTotal() {
    if (!_unitMode || _syncingPrice) return;
    _priceDriver = 'unit';
    _syncingPrice = true;
    final qty = _d(_qty);
    _setText(_pTotal, (qty > 0 && _cost.text.trim().isNotEmpty) ? _money(PricingCalc.r2(qty * _d(_cost))) : '');
    _syncingPrice = false;
  }

  /// P. Price (total) typed -> price per inner unit = total / qty.
  void _onTotalTyped() {
    if (!_unitMode || _syncingPrice) return;
    _priceDriver = 'total';
    _syncingPrice = true;
    final qty = _d(_qty);
    if (_pTotal.text.trim().isEmpty) {
      _setText(_cost, '');
    } else if (qty > 0) {
      _setText(_cost, _num(_d(_pTotal) / qty));
    }
    _syncingPrice = false;
    if (mounted) setState(() {});
  }

  // --------------------------------------------------------------- helpers
  double _d(TextEditingController c) => double.tryParse(c.text.trim()) ?? 0;
  String _money(double v) => v.truncateToDouble() == v ? v.toInt().toString() : v.toStringAsFixed(2);
  String _num(double v) => v.truncateToDouble() == v ? v.toInt().toString() : double.parse(v.toStringAsFixed(4)).toString();
  String get _cur => CurrencyFormatter.label;

  double get _total => PricingCalc.r2(_d(_qty) * _d(_cost));
  double get _paidNow => _supplier == null ? (_cashOut ? _total : 0) : (_type == 'cash' ? _total : _d(_paid));
  double get _due => PricingCalc.r2(_total - _paidNow);

  void _message(String text) => AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(text)));

  // ------------------------------------------------- margin <-> retail sync
  void _setText(TextEditingController c, String v) { if (c.text != v) c.text = v; }

  void _onCost() {
    if (_syncing) return;
    _syncing = true;
    final cost = _d(_cost);
    if (_driver == 'margin') {
      if (cost > 0) _setText(_retail, _num(PricingCalc.retailFromMargin(cost, _d(_margin))));
    } else {
      final retail = _d(_retail);
      _setText(_margin, retail > 0 ? PricingCalc.pctText(PricingCalc.marginFromRetail(cost, retail)) : '');
    }
    _syncing = false;
    if (mounted) setState(() {});
  }

  void _onMargin() {
    if (_syncing) return;
    _driver = 'margin';
    _syncing = true;
    var pct = _d(_margin);
    if (pct > PricingCalc.maxMargin) { pct = PricingCalc.maxMargin; _margin.text = PricingCalc.pctText(pct); }
    final cost = _d(_cost);
    if (cost > 0) _setText(_retail, _num(PricingCalc.retailFromMargin(cost, pct)));
    _syncing = false;
    if (mounted) setState(() {});
  }

  void _onRetail() {
    if (_syncing) return;
    _driver = 'retail';
    _syncing = true;
    final retail = _d(_retail);
    _setText(_margin, retail > 0 ? PricingCalc.pctText(PricingCalc.marginFromRetail(_d(_cost), retail)) : '');
    _syncing = false;
    if (mounted) setState(() {});
  }

  // ----------------------------------------------------------------- form
  void _select(ItemRecord item) {
    _openingStock = false;
    _syncing = true;
    _selected = item;
    _priceDriver = 'unit';
    _boxQty.clear();
    _stripQty.clear();
    _pTotal.clear();
    _qty.clear();
    _setText(_cost, item.purchaseUnitPrice > 0 ? _num(item.purchaseUnitPrice) : '');
    _setText(_retail, item.price > 0 ? _num(item.price) : '');
    _setText(_margin, (item.price > 0) ? PricingCalc.pctText(PricingCalc.marginFromRetail(item.purchaseUnitPrice, item.price)) : '');
    _driver = 'retail';
    _syncing = false;
    final last = item.supplierId == null ? null : _suppliers.where((x) => x['id'] == item.supplierId);
    _supplier = (last != null && last.isNotEmpty) ? last.first : null;
    _type = 'cash';
    _paid.clear();
    _date = DateTime.now();
    setState(() {});
  }

  void _clearForm() {
    _openingStock = false;
    _syncing = true;
    for (final c in [_qty, _cost, _margin, _retail, _paid, _boxQty, _stripQty, _pTotal]) { c.clear(); }
    _syncing = false;
    setState(() {
      _selected = null;
      _supplier = null;
      _editing = null;
      _type = 'cash';
        _date = DateTime.now();
      _driver = 'retail';
    });
  }

  void _startEdit(PurchaseRecord p) {
    final matches = _items.where((e) => e.id == p.itemId);
    if (matches.isEmpty) {
      _message('This product was deleted, so its purchase cannot be edited.');
      return;
    }
    final item = matches.first;
    final sup = p.supplierId == null ? null : _suppliers.where((x) => x['id'] == p.supplierId);
    _selected = item;
    _syncing = true;
    _syncingQty = true;
    _syncingPrice = true;
    _priceDriver = 'unit';
    if (item.hasUnitSystem) {
      _setText(_boxQty, UnitMath.fmt(UnitMath.outerPart(p.qty, item.unitsPerOuter)));
      _setText(_stripQty, UnitMath.fmt(UnitMath.innerPart(p.qty, item.unitsPerOuter)));
      _setText(_pTotal, _money(p.total));
    } else {
      _boxQty.clear(); _stripQty.clear(); _pTotal.clear();
    }
    _syncingQty = false;
    _syncingPrice = false;
    _setText(_qty, _num(p.qty));
    _setText(_cost, _num(p.unitCost));
    _setText(_retail, item.price > 0 ? _num(item.price) : '');
    _setText(_margin, item.price > 0 ? PricingCalc.pctText(PricingCalc.marginFromRetail(p.unitCost, item.price)) : '');
    _setText(_paid, p.supplierId != null && p.type == 'credit' ? _num(p.paid) : '');
    _syncing = false;
    setState(() {
      _editing = p;
      _selected = item;
      _supplier = (sup != null && sup.isNotEmpty) ? sup.first : null;
      _type = p.type;
      _date = p.date;
      _driver = 'retail';
    });
  }

  Future<void> _pickDate() async {
    final date = await showDatePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDate: _date);
    if (date != null && mounted) setState(() => _date = date);
  }

  Future<void> _save() async {
    if (_saving) return;
    final item = _selected;
    if (item == null) { _message('Select a product first.'); return; }
    final qty = _d(_qty);
    final cost = _d(_cost);
    final retail = _d(_retail);
    if (qty <= 0) { _message('Enter the quantity you purchased.'); return; }
    if (_cost.text.trim().isEmpty) { _message('Enter the purchase price.'); return; }
    if (AmountLimit.exceeds(cost) || AmountLimit.exceeds(retail) || AmountLimit.exceeds(_total) || AmountLimit.exceeds(_d(_paid))) { AmountLimit.showMessage(context); return; }
    if (_supplier != null && _total <= 0) { _message('A supplier purchase needs a purchase price above zero.'); return; }
    setState(() => _saving = true);
    try {
      final wasEditing = _editing != null;
      final id = await _repo.save(
        id: _editing?.id,
        itemId: item.id,
        supplierId: _supplier == null ? null : _supplier!['id'] as int,
        type: _type,
        qty: qty,
        unitCost: cost,
        retailPrice: retail > 0 ? retail : null,
        paid: _d(_paid),
        date: _date,
        cashOut: _cashOut,
      );
      if (!mounted) return;
      if (widget.editPurchaseId != null) { Navigator.pop(context, true); return; }
      final saved = await _repo.getById(id);
      _clearForm();
      await _reloadLists();
      if (!mounted) return;
      _message(wasEditing ? 'Purchase updated.' : 'Purchase saved. Stock and ledger updated.');
      if (!wasEditing && saved != null && saved.supplierId != null) {
        await Navigator.push<bool>(context, MaterialPageRoute<bool>(builder: (_) => PurchaseInvoiceScreen(purchase: saved)));
        if (mounted) await _reloadLists();
      }
    } on ArgumentError catch (e) {
      if (mounted) _message(e.message.toString());
    } catch (_) {
      if (mounted) _message('Could not save the purchase. Please try again.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  /// Scan a barcode / QR: the product loads straight into the form when it is
  /// already in stock, otherwise the New Product screen opens with the scanned
  /// code filled in.
  Future<void> _scanProduct() async {
    final value = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const BarcodeScannerScreen()));
    final code = value?.trim() ?? '';
    if (code.isEmpty || !mounted) return;
    final found = await _itemRepo.getItemByBarcode(code);
    if (!mounted) return;
    if (found != null) {
      await _reloadLists();
      if (mounted) _select(found);
      return;
    }
    await _openAddProduct(barcode: code);
  }

  Future<void> _openAddProduct({String? barcode}) async {
    NewItemScreen.lastSavedId = null;
    final added = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => NewItemScreen(initialBarcode: barcode)));
    if (added != true || !mounted) return;
    await _reloadLists();
    final id = NewItemScreen.lastSavedId;
    if (id == null) return;
    final matches = _items.where((e) => e.id == id);
    if (matches.isNotEmpty && mounted) _select(matches.first);
  }

  // ------------------------------------------------------------------- UI
  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    final item = _selected;
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        SafeArea(
          bottom: false,
          child: Container(
            height: 58 * s,
            padding: EdgeInsets.symmetric(horizontal: 14 * s),
            decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
            child: Row(children: [
              AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
              Expanded(child: Center(child: Text(_editing != null ? 'Edit Purchase' : 'Purchases', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 19 * s, fontWeight: FontWeight.w800)))),
              SizedBox(width: 42 * s),
            ]),
          ),
        ),
        Expanded(
          child: ListView(padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 28 * s), children: [
            if (_editing != null) _editBanner(s),
            Row(children: [
              Expanded(child: Text('Select Product', style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800))),
              TextButton.icon(
                onPressed: _editing != null ? null : _openAddProduct,
                icon: Icon(Icons.add_circle_outline_rounded, size: 17 * s),
                label: Text('Add Product', style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w800)),
                style: TextButton.styleFrom(visualDensity: VisualDensity.compact, padding: EdgeInsets.symmetric(horizontal: 8 * s)),
              ),
            ]),
            SizedBox(height: 4 * s),
            Row(children: [
              Expanded(child: _productBox(s)),
              SizedBox(width: 8 * s),
              _scanButton(s),
            ]),
            if (item != null) ...[
              SizedBox(height: 16 * s),
              _section('Purchase Details', s),
              SizedBox(height: 9 * s),
              if (_openingStock) Container(
                margin: EdgeInsets.only(bottom: 10 * s),
                padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 9 * s),
                decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .07), borderRadius: BorderRadius.circular(13 * s), border: Border.all(color: AppColors.primary.withValues(alpha: .3))),
                child: Row(children: [
                  Icon(Icons.inventory_2_rounded, color: AppColors.primary, size: 18 * s),
                  SizedBox(width: 8 * s),
                  Expanded(child: Text('Existing stock is loaded in Quantity. Enter the purchase price and save - it becomes this product\'s first purchase and the stock is not added twice. Change the quantity if the real purchased amount is different.', style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w700))),
                ]),
              ),
              if (item.hasUnitSystem) ..._unitPurchaseFields(s, item) else
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(child: _field('Quantity (${item.unit})', _qty, Icons.inventory_rounded, s)),
                SizedBox(width: 10 * s),
                Expanded(child: _field('Purchase Price / Unit', _cost, Icons.shopping_cart_checkout_rounded, s, money: true, prefix: '$_cur ')),
              ]),
              SizedBox(height: 10 * s),
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(flex: 2, child: _field('Profit %', _margin, Icons.percent_rounded, s, suffix: '%')),
                SizedBox(width: 10 * s),
                Expanded(flex: 3, child: _field('Retail (Sale) Price', _retail, Icons.sell_rounded, s, money: true, prefix: '$_cur ')),
              ]),
              SizedBox(height: 10 * s),
              _profitCard(s, item),
              SizedBox(height: 10 * s),
              _totalBox(s),
              SizedBox(height: 16 * s),
              _section('Supplier & Payment', s),
              SizedBox(height: 9 * s),
              _dropBox(s, 'Supplier', _supplier == null ? 'No supplier (cash purchase)' : _supplier!['name'] as String, Icons.local_shipping_rounded, _pickSupplier),
              SizedBox(height: 10 * s),
              if (_supplier != null) ...[
                Row(children: [Expanded(child: _choice('Cash', 'cash', s)), SizedBox(width: 10 * s), Expanded(child: _choice('Credit', 'credit', s))]),
                if (_type == 'credit') ...[
                  SizedBox(height: 10 * s),
                  _field('Amount Paid Now', _paid, Icons.payments_rounded, s, money: true, prefix: '$_cur ', onChanged: (_) => setState(() {})),
                ],
              ],
              SizedBox(height: 10 * s),
              _dateTile(s),
              SizedBox(height: 12 * s),
              _summaryCard(s),
              SizedBox(height: 16 * s),
              Row(children: [
                if (_editing != null) ...[
                  Expanded(child: SizedBox(height: 52 * s, child: OutlinedButton(onPressed: _saving ? null : _clearForm, style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15 * s))), child: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w800))))),
                  SizedBox(width: 10 * s),
                ],
                Expanded(
                  flex: 2,
                  child: SizedBox(
                    height: 52 * s,
                    child: FilledButton.icon(
                      onPressed: _saving ? null : _save,
                      icon: _saving ? const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : Icon(_editing != null ? Icons.save_rounded : Icons.add_shopping_cart_rounded),
                      label: Text(_editing != null ? 'Save Changes' : 'Save Purchase', style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800)),
                      style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15 * s))),
                    ),
                  ),
                ),
              ]),
            ],
          ]),
        ),
      ]),
    );
  }

  /// Box Qty / Strips Qty, then Purchase Price per Strip and P. Price (total).
  List<Widget> _unitPurchaseFields(double s, ItemRecord item) {
    final outer = item.outerUnit ?? 'Outer';
    final inner = item.innerUnit ?? 'Inner';
    return [
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: _field('$outer Qty', _boxQty, Icons.inventory_2_rounded, s)),
        SizedBox(width: 10 * s),
        Expanded(child: _field('$inner Qty', _stripQty, Icons.view_module_rounded, s)),
      ]),
      SizedBox(height: 4 * s),
      Text('1 $outer = ${UnitMath.fmt(item.unitsPerOuter)} $inner', style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary)),
      SizedBox(height: 8 * s),
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: _field('Purchase Price per $inner', _cost, Icons.shopping_cart_checkout_rounded, s, money: true, prefix: '$_cur ')),
        SizedBox(width: 10 * s),
        Expanded(child: _field('P. Price (Total)', _pTotal, Icons.payments_rounded, s, money: true, prefix: '$_cur ')),
      ]),
    ];
  }

  Widget _editBanner(double s) => Container(
    margin: EdgeInsets.only(bottom: 10 * s),
    padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 9 * s),
    decoration: BoxDecoration(color: const Color(0xFFFFF7E6), borderRadius: BorderRadius.circular(13 * s), border: Border.all(color: const Color(0xFFF59E0B).withValues(alpha: .5))),
    child: Row(children: [
      Icon(Icons.edit_note_rounded, color: const Color(0xFFB45309), size: 20 * s),
      SizedBox(width: 8 * s),
      Expanded(child: Text('Editing purchase PUR-${_editing!.id.toString().padLeft(5, '0')} - stock, supplier ledger and Cashbook are updated when you save.', style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w700, color: const Color(0xFF92400E)))),
      TextButton(
        onPressed: () async {
          final it = _selected;
          if (it == null) return;
          await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => NewItemScreen(item: it)));
          if (mounted) await _reloadLists();
        },
        style: TextButton.styleFrom(visualDensity: VisualDensity.compact, padding: EdgeInsets.symmetric(horizontal: 6 * s)),
        child: Text('Product\ndetails', textAlign: TextAlign.center, style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w800)),
      ),
    ]),
  );

  Widget _section(String text, double s) => Row(children: [
    Container(width: 4 * s, height: 18 * s, decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(8))),
    SizedBox(width: 8 * s),
    Text(text, style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
  ]);

  Widget _field(String label, TextEditingController c, IconData icon, double s, {bool money = false, String? prefix, String? suffix, ValueChanged<String>? onChanged}) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label, style: TextStyle(fontSize: 11.5 * s, fontWeight: FontWeight.w700)),
      SizedBox(height: 6 * s),
      TextField(
        controller: c,
        onChanged: onChanged ?? (_) => setState(() {}),
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: money ? const [MaxAmountFormatter()] : [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')), LengthLimitingTextInputFormatter(10)],
        decoration: InputDecoration(
          // Currency symbol is a real prefix icon so it is ALWAYS visible
          // (prefixText only appears once the box is focused).
          prefixIcon: prefix == null
              ? Icon(icon, color: AppColors.primary, size: 19 * s)
              : Padding(
                  padding: EdgeInsets.only(left: 12 * s, right: 6 * s),
                  child: Center(widthFactor: 1, child: Text(prefix.trim(), style: TextStyle(fontSize: 13.5 * s, fontWeight: FontWeight.w800, color: AppColors.primary))),
                ),
          prefixIconConstraints: prefix == null ? null : const BoxConstraints(minWidth: 0, minHeight: 0),
          suffixText: suffix,
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 14 * s),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14 * s), borderSide: const BorderSide(color: AppColors.lightCardBorder)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14 * s), borderSide: const BorderSide(color: AppColors.lightCardBorder)),
        ),
      ),
    ],
  );

  Widget _dropBox(double s, String label, String value, IconData icon, VoidCallback onTap) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label, style: TextStyle(fontSize: 11.5 * s, fontWeight: FontWeight.w700)),
      SizedBox(height: 6 * s),
      Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14 * s),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14 * s),
          child: Container(
            height: 49 * s,
            padding: EdgeInsets.symmetric(horizontal: 12 * s),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: AppColors.lightCardBorder)),
            child: Row(children: [
              Icon(icon, color: AppColors.primary, size: 19 * s),
              SizedBox(width: 9 * s),
              Expanded(child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w700))),
              const Icon(Icons.keyboard_arrow_down_rounded),
            ]),
          ),
        ),
      ),
    ],
  );

  Widget _thumb(ItemRecord item, double size, double s) {
    final file = ItemImageStore.resolve(item.imagePath);
    return Container(
      width: size * s,
      height: size * s,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .08), borderRadius: BorderRadius.circular(12 * s)),
      child: file != null ? Image.file(file, fit: BoxFit.cover) : Icon(Icons.inventory_2_rounded, color: AppColors.primary, size: (size * .5) * s),
    );
  }

  Widget _scanButton(double s) {
    final enabled = _editing == null;
    return Material(
      color: AppColors.primary.withValues(alpha: enabled ? .10 : .04),
      borderRadius: BorderRadius.circular(16 * s),
      child: InkWell(
        onTap: enabled ? _scanProduct : null,
        borderRadius: BorderRadius.circular(16 * s),
        child: Container(
          width: 58 * s,
          height: 58 * s,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(16 * s), border: Border.all(color: AppColors.primary.withValues(alpha: enabled ? .45 : .15))),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.qr_code_scanner_rounded, color: AppColors.primary.withValues(alpha: enabled ? 1 : .4), size: 23 * s),
            SizedBox(height: 2 * s),
            Text('Scan', style: TextStyle(fontSize: 9.5 * s, fontWeight: FontWeight.w800, color: AppColors.primary.withValues(alpha: enabled ? 1 : .4))),
          ]),
        ),
      ),
    );
  }

  Widget _productBox(double s) {
    final item = _selected;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16 * s),
      child: InkWell(
        onTap: _editing != null ? null : _pickProduct,
        borderRadius: BorderRadius.circular(16 * s),
        child: Container(
          constraints: BoxConstraints(minHeight: 58 * s),
          padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 9 * s),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(16 * s), border: Border.all(color: item != null ? AppColors.primary.withValues(alpha: .5) : AppColors.lightCardBorder)),
          child: Row(children: [
            if (item != null) ...[_thumb(item, 42, s), SizedBox(width: 10 * s)] else ...[Icon(Icons.search_rounded, color: AppColors.primary, size: 22 * s), SizedBox(width: 10 * s)],
            Expanded(
              child: item == null
                  ? Text('Search and select a product', style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary))
                  : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13.5 * s, fontWeight: FontWeight.w900)),
                      SizedBox(height: 3 * s),
                      Text(
                        '${item.trackStock ? 'Stock ${item.stockText}' : 'Quantity not managed'}  •  Sale $_cur ${_money(item.price)}  •  Cost $_cur ${_money(item.purchaseUnitPrice)}',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary),
                      ),
                    ]),
            ),
            if (_editing == null) const Icon(Icons.keyboard_arrow_down_rounded),
          ]),
        ),
      ),
    );
  }

  Future<void> _pickProduct() async {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    final picked = await showModalBottomSheet<ItemRecord>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        var q = '';
        return StatefulBuilder(builder: (ctx, setSheet) {
          final list = _items.where((e) {
            final query = q.trim().toLowerCase();
            return query.isEmpty || e.name.toLowerCase().contains(query) || (e.barcode ?? '').contains(query);
          }).toList()
            ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
          return Container(
            height: MediaQuery.sizeOf(ctx).height * .78,
            decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
            child: Column(children: [
              const SizedBox(height: 10),
              Container(width: 42, height: 4, decoration: BoxDecoration(color: AppColors.lightDivider, borderRadius: BorderRadius.circular(99))),
              Padding(
                padding: EdgeInsets.fromLTRB(16 * s, 14 * s, 8 * s, 8 * s),
                child: Row(children: [
                  Expanded(child: Text('Select Product', style: TextStyle(fontSize: 18 * s, fontWeight: FontWeight.w800))),
                  TextButton.icon(
                    onPressed: () { Navigator.pop(ctx); _openAddProduct(); },
                    icon: Icon(Icons.add_circle_outline_rounded, size: 17 * s),
                    label: Text('Add Product', style: TextStyle(fontSize: 11.5 * s, fontWeight: FontWeight.w800)),
                  ),
                ]),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16 * s),
                child: Container(
                  height: 44 * s,
                  decoration: BoxDecoration(color: AppColors.lightBackground, borderRadius: BorderRadius.circular(13 * s)),
                  child: TextField(
                    onChanged: (v) => setSheet(() => q = v),
                    decoration: InputDecoration(border: InputBorder.none, prefixIcon: Icon(Icons.search_rounded, size: 19 * s), hintText: 'Search name or barcode'),
                  ),
                ),
              ),
              SizedBox(height: 6 * s),
              Expanded(
                child: list.isEmpty
                    ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.inventory_2_outlined, color: AppColors.primary, size: 34 * s),
                        SizedBox(height: 8 * s),
                        Text(_items.isEmpty ? 'No products yet' : 'No product found', style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w800)),
                        SizedBox(height: 8 * s),
                        FilledButton.icon(onPressed: () { Navigator.pop(ctx); _openAddProduct(); }, icon: const Icon(Icons.add_rounded), label: const Text('Add Product')),
                      ]))
                    : ListView.builder(
                        itemCount: list.length,
                        itemBuilder: (_, i) {
                          final e = list[i];
                          final selected = _selected?.id == e.id;
                          return ListTile(
                            onTap: () => Navigator.pop(ctx, e),
                            leading: _thumb(e, 40, s),
                            title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text('${e.trackStock ? 'Stock ${e.stockText}' : e.unit}  •  $_cur ${_money(e.price)}', style: const TextStyle(fontSize: 11.5)),
                            trailing: Icon(selected ? Icons.check_circle_rounded : Icons.chevron_right_rounded, color: selected ? AppColors.primary : AppColors.lightTextSecondary),
                          );
                        },
                      ),
              ),
            ]),
          );
        });
      },
    );
    if (picked != null && mounted) _select(picked);
  }

  Widget _profitCard(double s, ItemRecord item) {
    final cost = _d(_cost);
    final retail = _d(_retail);
    final qty = _d(_qty);
    final perUnit = PricingCalc.profitPerUnit(cost, retail);
    final isProfit = perUnit >= 0;
    final accent = isProfit ? Colors.green.shade700 : Colors.red.shade700;
    final hasData = retail > 0 && cost > 0;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 10 * s),
      decoration: BoxDecoration(color: (hasData ? accent : Colors.grey).withValues(alpha: .07), borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: (hasData ? accent : Colors.grey).withValues(alpha: .2))),
      child: Row(children: [
        Container(width: 32 * s, height: 32 * s, decoration: BoxDecoration(color: (hasData ? accent : Colors.grey).withValues(alpha: .12), borderRadius: BorderRadius.circular(10 * s)), child: Icon(isProfit ? Icons.trending_up_rounded : Icons.trending_down_rounded, color: hasData ? accent : Colors.grey, size: 18 * s)),
        SizedBox(width: 9 * s),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(hasData ? (isProfit ? 'Profit / Unit' : 'Loss / Unit') : 'Profit / Unit', style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary)),
            SizedBox(height: 2 * s),
            Text(
              hasData ? '$_cur ${_money(perUnit.abs())}  (${PricingCalc.pctText(PricingCalc.marginFromRetail(cost, retail).abs())}%)${qty > 0 ? '  •  ${_num(qty)} ${item.unit} = $_cur ${_money(PricingCalc.r2(perUnit * qty).abs())}' : ''}' : 'Enter purchase price and profit % or retail price',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w900, color: hasData ? accent : AppColors.lightTextSecondary),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _totalBox(double s) => Container(
    width: double.infinity,
    padding: EdgeInsets.symmetric(horizontal: 13 * s, vertical: 12 * s),
    decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .055), borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: AppColors.primary.withValues(alpha: .16))),
    child: Row(children: [
      Icon(Icons.calculate_rounded, color: AppColors.primary, size: 20 * s),
      SizedBox(width: 9 * s),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Purchase Total', style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary)),
        SizedBox(height: 2 * s),
        Text('${_num(_d(_qty))} × ${_money(_d(_cost))} = $_cur ${_money(_total)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w900)),
      ])),
    ]),
  );

  Widget _choice(String title, String value, double s) => InkWell(
    onTap: () => setState(() => _type = value),
    borderRadius: BorderRadius.circular(14 * s),
    child: Container(
      padding: EdgeInsets.all(12 * s),
      decoration: BoxDecoration(color: _type == value ? AppColors.primary.withValues(alpha: .1) : Colors.white, borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: _type == value ? AppColors.primary : AppColors.lightCardBorder)),
      child: Row(children: [
        Icon(value == 'cash' ? Icons.payments_rounded : Icons.credit_score_rounded, color: AppColors.primary, size: 19 * s),
        SizedBox(width: 8 * s),
        Text(title, style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w800)),
      ]),
    ),
  );

  Widget _dateTile(double s) => InkWell(
    onTap: _pickDate,
    borderRadius: BorderRadius.circular(14 * s),
    child: Container(
      height: 49 * s,
      padding: EdgeInsets.symmetric(horizontal: 12 * s),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: AppColors.lightCardBorder)),
      child: Row(children: [
        Icon(Icons.calendar_month_rounded, color: AppColors.primary, size: 19 * s),
        SizedBox(width: 9 * s),
        Text(DateFormat('dd MMM yyyy').format(_date), style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w700)),
        const Spacer(),
        const Icon(Icons.keyboard_arrow_down_rounded),
      ]),
    ),
  );

  Widget _summaryCard(double s) {
    final total = _total;
    final paid = _paidNow;
    final due = _due;
    final Color accent;
    final String label;
    final String value;
    if (_supplier == null) {
      accent = Colors.green.shade700;
      label = _cashOut ? 'Paid in cash' : 'Not recorded in Cashbook';
      value = '$_cur ${_money(_cashOut ? total : 0)}';
    } else if (due > 0.004) {
      accent = Colors.red.shade700; label = 'Due (Payable to Supplier)'; value = '$_cur ${_money(due)}';
    } else if (due < -0.004) {
      accent = Colors.green.shade700; label = 'Extra Paid (Receivable from Supplier)'; value = '$_cur ${_money(-due)}';
    } else {
      accent = Colors.green.shade700; label = 'Fully Paid'; value = '$_cur 0';
    }
    Widget row(String l, String v, {Color? color, bool bold = false}) => Padding(
      padding: EdgeInsets.symmetric(vertical: 3 * s),
      child: Row(children: [
        Expanded(child: Text(l, style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary))),
        Text(v, style: TextStyle(fontSize: (bold ? 15 : 12.5) * s, fontWeight: FontWeight.w900, color: color ?? AppColors.lightTextPrimary)),
      ]),
    );
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(14 * s, 10 * s, 14 * s, 10 * s),
      decoration: BoxDecoration(color: accent.withValues(alpha: .06), borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: accent.withValues(alpha: .35))),
      child: Column(children: [
        row('Total', '$_cur ${_money(total)}'),
        if (_supplier != null) row('Paid', '$_cur ${_money(paid)}', color: Colors.green.shade700),
        Divider(height: 12 * s, color: accent.withValues(alpha: .25)),
        row(label, value, color: accent, bold: true),
      ]),
    );
  }

  // ------------------------------------------------------------ supplier
  Future<void> _openSupplierManager() async {
    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const AddPartyScreen(type: LedgerPartyType.supplier, returnAfterSelection: true)));
    if (saved == true) {
      await _reloadLists();
      if (mounted) await _pickSupplier();
    }
  }

  Future<void> _pickSupplier() async {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    final value = await showModalBottomSheet<Map<String, Object?>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        height: MediaQuery.sizeOf(ctx).height * .72,
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
        child: Column(children: [
          const SizedBox(height: 10),
          Container(width: 42, height: 4, decoration: BoxDecoration(color: AppColors.lightDivider, borderRadius: BorderRadius.circular(99))),
          Padding(
            padding: EdgeInsets.fromLTRB(16 * s, 14 * s, 16 * s, 10 * s),
            child: Row(children: [
              Expanded(child: Text('Select Supplier', style: TextStyle(fontSize: 18 * s, fontWeight: FontWeight.w800))),
              TextButton.icon(
                onPressed: () { Navigator.pop(ctx); _openSupplierManager(); },
                icon: Icon(Icons.person_add_alt_1_rounded, size: 17 * s),
                label: Text('Add Supplier', style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w800)),
              ),
            ]),
          ),
          Expanded(
            child: ListView(padding: EdgeInsets.symmetric(horizontal: 8 * s), children: [
              ListTile(onTap: () => Navigator.pop(ctx, {}), leading: const Icon(Icons.clear_rounded), title: const Text('No Supplier (cash purchase)')),
              ..._suppliers.map((x) => ListTile(
                    onTap: () => Navigator.pop(ctx, x),
                    leading: CircleAvatar(backgroundColor: AppColors.primary.withValues(alpha: .1), child: Icon(Icons.local_shipping_rounded, color: AppColors.primary)),
                    title: Row(children: [Flexible(child: Text(x['name'] as String, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700))), if (x['linked_party_id'] != null) ...[const SizedBox(width: 6), const BothStarBadge(size: 18)]]),
                    subtitle: Text((x['phone'] as String?) ?? ''),
                    trailing: Icon(_supplier?['id'] == x['id'] ? Icons.check_circle_rounded : Icons.chevron_right_rounded, color: _supplier?['id'] == x['id'] ? AppColors.primary : AppColors.lightTextSecondary),
                  )),
            ]),
          ),
        ]),
      ),
    );
    if (value != null && mounted) setState(() => _supplier = value.isEmpty ? null : value);
  }
}
