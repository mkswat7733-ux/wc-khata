import 'package:flutter/material.dart';
import '../ledger/ledger_party.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/modern_header.dart';
import '../../data/models/account_model.dart';
import '../ledger/ledger_repository.dart';
import 'recycle_bin_controller.dart';
import '../../core/widgets/app_message.dart';

class RecycleBinScreen extends StatefulWidget {
  const RecycleBinScreen({super.key});

  @override
  State<RecycleBinScreen> createState() => _RecycleBinScreenState();
}

class _RecycleBinScreenState extends State<RecycleBinScreen> {
  late final RecycleBinController _controller;

  @override
  void initState() {
    super.initState();
    _controller = RecycleBinController();
    _controller.load();
  }

  Future<void> _restoreAccount(AccountModel account) async {
    if (account.id == null) return;
    await _controller.restoreAccount(account.id!);
    if (mounted) {
      AppMessenger.of(context).showSnackBar(
        SnackBar(content: Text('"${account.name}" restored to Accounts')),
      );
    }
  }

  Future<void> _restoreTransaction(DeletedLedgerTransaction item) async {
    await _controller.restoreTransaction(item.transaction.id);
    if (mounted) {
      AppMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Transaction restored to ${item.partyName}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return ChangeNotifierProvider.value(
      value: _controller,
      child: Scaffold(
        backgroundColor: isDark ? AppColors.darkBackground : AppColors.lightBackground,
        body: Column(
          children: [
            ModernHeader(title: 'Recycle Bin', onBack: () => Navigator.pop(context)),
            Expanded(
              child: Consumer<RecycleBinController>(
                builder: (context, c, _) {
                  if (c.isLoading) return const Center(child: CircularProgressIndicator());
                  if (c.deletedAccounts.isEmpty && c.deletedTransactions.isEmpty) {
                    return Center(
                      child: Padding(
                        padding: const EdgeInsets.all(AppDimensions.spaceLg),
                        child: Text(
                          'Recycle Bin is empty.\nDeleted records can be restored for 60 days.',
                          textAlign: TextAlign.center,
                          style: AppTextStyles.body.copyWith(color: AppColors.lightTextSecondary),
                        ),
                      ),
                    );
                  }
                  return RefreshIndicator(
                    onRefresh: _controller.load,
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.all(AppDimensions.spaceMd),
                      children: [
                        if (c.deletedTransactions.isNotEmpty) ...[
                          _sectionTitle('Deleted transactions'),
                          ...c.deletedTransactions.map((item) => _deletedTransactionCard(item, isDark)),
                        ],
                        if (c.deletedAccounts.isNotEmpty) ...[
                          _sectionTitle('Deleted accounts'),
                          ...c.deletedAccounts.map((account) => _deletedAccountCard(account, isDark)),
                        ],
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(bottom: AppDimensions.spaceSm, top: AppDimensions.spaceSm),
        child: Text(text, style: AppTextStyles.caption.copyWith(color: AppColors.lightTextSecondary)),
      );

  Widget _deletedTransactionCard(DeletedLedgerTransaction item, bool isDark) {
    final t = item.transaction;
    final isRecv = item.partyType == LedgerPartyType.supplier ? t.type != 'receive' : t.type == 'receive';
    final color = isRecv ? AppColors.income : AppColors.expense;
    final deletedAt = t.deletedAt ?? DateTime.now();
    final daysLeft = 60 - DateTime.now().difference(deletedAt).inDays;
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimensions.spaceSm),
      child: Container(
        padding: const EdgeInsets.all(AppDimensions.spaceMd),
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkSurface : AppColors.lightSurface,
          borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
          boxShadow: isDark ? null : [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Row(
          children: [
            Container(
              width: AppDimensions.iconContainerSize,
              height: AppDimensions.iconContainerSize,
              decoration: BoxDecoration(color: color.withValues(alpha: .10), borderRadius: BorderRadius.circular(AppDimensions.radiusSm)),
              child: Icon(isRecv ? Icons.south_west_rounded : Icons.north_east_rounded, color: color),
            ),
            const SizedBox(width: AppDimensions.spaceMd),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.partyName, style: AppTextStyles.bodyMedium),
                  Text('${isRecv ? 'Receive' : 'Pay'} • ${CurrencyFormatter.formatCompact(t.amount)}', style: AppTextStyles.caption),
                  Text('${DateFormat('dd MMM yyyy, hh:mm a').format(t.date)} • $daysLeft days left', style: AppTextStyles.caption.copyWith(color: AppColors.lightTextSecondary)),
                ],
              ),
            ),
            AppButton3D(label: 'Restore', icon: Icons.restore, compact: true, onPressed: () => _restoreTransaction(item)),
          ],
        ),
      ),
    );
  }

  Widget _deletedAccountCard(AccountModel account, bool isDark) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimensions.spaceSm),
      child: Container(
        padding: const EdgeInsets.all(AppDimensions.spaceMd),
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkSurface : AppColors.lightSurface,
          borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
          boxShadow: isDark ? null : [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Row(
          children: [
            Container(
              width: AppDimensions.iconContainerSize,
              height: AppDimensions.iconContainerSize,
              decoration: BoxDecoration(color: AppColors.lightTextSecondary.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(AppDimensions.radiusSm)),
              child: const Icon(Icons.account_balance_wallet_outlined, color: AppColors.lightTextSecondary),
            ),
            const SizedBox(width: AppDimensions.spaceMd),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(account.name, style: AppTextStyles.bodyMedium),
                  Text(CurrencyFormatter.formatCompact(account.currentBalance), style: AppTextStyles.caption.copyWith(color: AppColors.lightTextSecondary)),
                ],
              ),
            ),
            AppButton3D(label: 'Restore', icon: Icons.restore, compact: true, onPressed: () => _restoreAccount(account)),
          ],
        ),
      ),
    );
  }
}
