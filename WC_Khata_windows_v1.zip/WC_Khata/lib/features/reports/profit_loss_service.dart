import '../../data/repositories/transaction_repository.dart';
import '../sale/sale_calculator.dart';
import '../sale/sale_repository.dart';

/// Result of one Profit & Loss calculation.
class ProfitLossResult {
  /// Sum of (sale price - cost price) over every bill in the period.
  /// Negative when bills were sold below cost.
  final double grossProfit;

  /// Running expenses only (rent, electricity, salary ...). Never contains
  /// stock purchases, supplier payments or customer refunds.
  final double expenses;

  const ProfitLossResult({required this.grossProfit, required this.expenses});

  /// Profit - Expenses. Positive = profit, negative = loss.
  double get net => SaleCalc.r2(grossProfit - expenses);
  double get profit => net > 0 ? net : 0;
  double get loss => net < 0 ? -net : 0;
}

/// The ONE place that decides profit / loss, so Home, Sale, End of Day and
/// reports can never disagree.
///
///   Profit            = product profit (sale price - cost price)
///   Profit - Expenses = final profit, or a loss when expenses are bigger
///
/// e.g. profit 5000, expenses 4500 -> profit 500
///      profit 5000, expenses 6000 -> profit 0, loss 1000
class ProfitLossService {
  final SaleRepository _sales = SaleRepository();
  final TransactionRepository _tx = TransactionRepository();

  Future<ProfitLossResult> forRange(DateTime from, DateTime to) async {
    final pl = await _sales.profitLossInRange(from, to);
    final expenses = await _tx.sumOperatingExpenseInRange(from, to);
    return ProfitLossResult(grossProfit: pl.net, expenses: SaleCalc.r2(expenses));
  }
}
