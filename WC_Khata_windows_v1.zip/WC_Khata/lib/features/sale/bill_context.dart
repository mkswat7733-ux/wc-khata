import 'package:intl/intl.dart';

import '../../data/repositories/profile_repository.dart';
import '../items/item_repository.dart';
import '../ledger/ledger_repository.dart';
import 'sale_repository.dart';

/// Everything the Receipt (image) and the Invoice (PDF) need about one sale,
/// loaded once so both tabs show exactly the same information.
class BillContext {
  final SavedSale sale;
  final String businessName;
  final String? address;
  final String? email;
  final String? phone; // business phone
  final String? customerName;
  final String? customerPhone;

  /// Until the server/API is connected every customer-facing bill keeps a
  /// clear pending ID (same behaviour the old invoice screen had).
  final String invoiceId;

  /// True when this bill is a stock PURCHASE from a supplier (not a sale).
  /// [customerName]/[customerPhone] then hold the supplier's details.
  final bool isPurchase;

  const BillContext({
    required this.sale,
    required this.businessName,
    this.address,
    this.email,
    this.phone,
    this.customerName,
    this.customerPhone,
    this.invoiceId = 'INV-PENDING',
    this.isPurchase = false,
  });

  String get receiptTitle => isPurchase ? 'PURCHASE RECEIPT' : 'SALES RECEIPT';
  String get invoiceTitle => isPurchase ? 'PURCHASE INVOICE' : 'SALES INVOICE';
  String get partyRole => isPurchase ? 'Supplier' : 'Customer';
  String get billToLabel => isPurchase ? 'SUPPLIER' : 'BILL TO';
  String get fallbackParty => isPurchase ? 'Supplier' : 'Walk-in Customer';

  double get balance => sale.total - sale.paid;
  bool get isPaid => balance <= 0.005;
  bool get isPartial => !isPaid && sale.paid > 0.005;
  double get totalQty => sale.lines.fold<double>(0, (s, l) => s + l.qty);
  String get paymentLabel => sale.paymentType == 'credit' ? 'Credit' : 'Cash';

  static final NumberFormat _num = NumberFormat('#,##0.00');
  static String money(double v) => _num.format(v);

  static final NumberFormat _whole = NumberFormat('#,##0');
  /// Receipt amounts: no ".00" on whole amounts (1,250), real decimals kept (1,250.50).
  static String moneyShort(double v) {
    final r = (v * 100).round() / 100;
    return r == r.truncateToDouble() ? _whole.format(r) : _num.format(r);
  }
  static String qty(double v) => v.truncateToDouble() == v ? v.toInt().toString() : v.toStringAsFixed(2);
  static String dateTime(DateTime d) => DateFormat('dd MMM yyyy, hh:mm a').format(d);

  static Future<BillContext> load(SavedSale sale, String? customerName) async {
    String? business;
    String? address;
    String? email;
    String? bizPhone;
    try {
      final profile = await ProfileRepository().getOrCreate();
      business = profile.name?.trim();
      address = profile.address?.trim();
      email = profile.email?.trim();
      bizPhone = profile.phone?.trim();
    } catch (_) {}

    String? name = customerName;
    String? phone;
    if (sale.customerId != null) {
      try {
        final party = await LedgerRepository().getPartyById(sale.customerId!);
        name ??= party?.name;
        phone = party?.phone;
      } catch (_) {}
    }

    String? clean(String? v) => (v == null || v.isEmpty) ? null : v;
    return BillContext(
      sale: sale,
      businessName: clean(business) ?? 'WC Khata',
      address: clean(address),
      email: clean(email),
      phone: clean(bizPhone),
      customerName: clean(name),
      customerPhone: clean(phone),
    );
  }

  /// A purchase is stored on the product itself, so the bill is rebuilt from it.
  /// Quantity is derived from amount / unit cost, because [ItemRecord.qty] is the
  /// CURRENT stock (it drops as the product is sold).
  static SavedSale purchaseAsSale(ItemRecord item) {
    final unit = item.purchaseUnitPrice > 0
        ? item.purchaseUnitPrice
        : (item.qty > 0 ? item.purchaseAmount / item.qty : 0.0);
    final qty = unit > 0 ? item.purchaseAmount / unit : item.qty;
    final line = SaleLine(item: item, qty: qty, unitPrice: unit, unitCost: unit, retailPrice: item.price);
    return SavedSale(
      id: item.id,
      invoiceNo: purchaseInvoiceId(item),
      total: item.purchaseAmount,
      paid: item.purchasePaid > item.purchaseAmount ? item.purchaseAmount : item.purchasePaid,
      paymentType: item.purchaseType ?? 'cash',
      date: item.purchaseDate ?? DateTime.now(),
      customerId: item.supplierId,
      lines: [line],
      subtotal: item.purchaseAmount,
    );
  }

  /// A multi-item purchase bill ([sale.customerId] holds the supplier id).
  static Future<BillContext> loadPurchaseBill(SavedSale sale, String? supplierName) async {
    final base = await load(sale, supplierName);
    return BillContext(
      sale: base.sale,
      businessName: base.businessName,
      address: base.address,
      email: base.email,
      phone: base.phone,
      customerName: base.customerName,
      customerPhone: base.customerPhone,
      invoiceId: sale.invoiceNo,
      isPurchase: true,
    );
  }

  static String purchaseInvoiceId(ItemRecord item) => 'PUR-${item.id.toString().padLeft(5, '0')}';

  static Future<BillContext> loadPurchase(ItemRecord item) async {
    final base = await load(purchaseAsSale(item), null);
    return BillContext(
      sale: base.sale,
      businessName: base.businessName,
      address: base.address,
      email: base.email,
      phone: base.phone,
      customerName: base.customerName,
      customerPhone: base.customerPhone,
      invoiceId: purchaseInvoiceId(item),
      isPurchase: true,
    );
  }
}
