/// The three sizes a bill (sale or purchase) can be produced in.
///
/// This is the single place that defines how each paper behaves, so the
/// preview, the printer, the PDF and the receipt layout can never disagree:
///
///  - [mm58]: narrow thermal roll, compact stacked layout.
///  - [mm80]: wide thermal roll, proper Product | Qty | Price | Total columns.
///  - [a4]  : full page invoice (PDF), printed through the system printer.
///
/// For thermal papers [designWidth] is the logical width the receipt is laid
/// out in. The captured image is then scaled to the printer's real dot width
/// (58mm = 384 dots, 80mm = 576 dots, tunable from the Printer screen), so the
/// receipt always fills the roll edge to edge whatever phone it was made on.
enum BillPaper {
  mm58(label: '58mm', mm: 58, printMm: 48, designWidth: 226, fontBase: 11, hPad: 5, caption: '58mm roll  |  compact layout'),
  mm80(label: '80mm', mm: 80, printMm: 72, designWidth: 312, fontBase: 13, hPad: 8, caption: '80mm roll  |  column layout'),
  a4(label: 'A4', mm: 210, printMm: 210, designWidth: 0, fontBase: 0, hPad: 0, caption: 'A4 page  |  full invoice');

  final String label;

  /// Paper width in millimetres (A4 = 210).
  final int mm;

  /// Width the print head can really print (58mm roll = 48mm = 384 dots,
  /// 80mm roll = 72mm = 576 dots at 203 dpi). Margins are measured inside it,
  /// so 1 mm of margin on screen is 1 mm on the paper.
  final int printMm;

  /// Logical layout width of the receipt widget (thermal only).
  final double designWidth;

  /// Base font size of the receipt (thermal only).
  final double fontBase;

  /// Horizontal padding inside the receipt (thermal only).
  final double hPad;

  /// Short hint shown under the tabs.
  final String caption;

  const BillPaper({
    required this.label,
    required this.mm,
    required this.printMm,
    required this.designWidth,
    required this.fontBase,
    required this.hPad,
    required this.caption,
  });

  bool get isThermal => this != BillPaper.a4;

  /// Wide enough for a real column table.
  bool get usesColumns => this == BillPaper.mm80;

  /// 58 / 80 for thermal rolls, null for A4 (used for the printer service).
  int? get thermalMm => isThermal ? mm : null;

  static BillPaper fromThermalMm(int? mm) => mm == 80 ? BillPaper.mm80 : BillPaper.mm58;

  static BillPaper fromName(String? name) {
    for (final p in BillPaper.values) {
      if (p.name == name) return p;
    }
    return BillPaper.mm58;
  }
}
