import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../app/theme/app_theme.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import 'sale_repository.dart';
import 'hidden_cost_box.dart';
import '../../core/widgets/app_message.dart';
import '../../core/utils/amount_limit.dart';

class SalePriceEditorScreen extends StatefulWidget {
  final SaleLine line;
  const SalePriceEditorScreen({super.key, required this.line});

  @override
  State<SalePriceEditorScreen> createState() => _SalePriceEditorScreenState();
}

class _SalePriceEditorScreenState extends State<SalePriceEditorScreen> {
  // Price for this bill (the base price). A discount NEVER rewrites this field.
  late final TextEditingController _price;
  late final TextEditingController _discRs;   // discount per unit (currency)
  late final TextEditingController _discPct;  // discount per unit (% of the price)
  late final TextEditingController _lineTotal; // bill line total = (price - discount) x qty, editable
  bool _costVisible = false;
  bool _syncing = false;

  double get _retail => widget.line.retailPrice;
  double get _qty => widget.line.qty;
  double _v(TextEditingController c) => double.tryParse(c.text.trim()) ?? 0;

  static String _trim(double v, {int dp = 2}) =>
      v <= 0 ? '0' : v.toStringAsFixed(dp).replaceFirst(RegExp(r'\.?0+$'), '');

  @override
  void initState() {
    super.initState();
    final net = widget.line.unitPrice;
    // Base price = the catalogue retail price when the bill price is below it
    // (the gap is the discount), otherwise the bill price itself.
    final base = (_retail > net) ? _retail : net;
    final rs = base > net ? base - net : 0.0;
    _price = TextEditingController(text: base.toStringAsFixed(2));
    _discRs = TextEditingController(text: _trim(rs));
    _discPct = TextEditingController(text: base > 0 ? _trim(rs / base * 100) : '0');
    _lineTotal = TextEditingController(text: (net * widget.line.qty).toStringAsFixed(2));
    _price.addListener(_onPrice);
    _discRs.addListener(_onDiscRs);
    _discPct.addListener(_onDiscPct);
    _lineTotal.addListener(_onLineTotal);
  }

  @override
  void dispose() {
    _price.dispose();
    _discRs.dispose();
    _discPct.dispose();
    _lineTotal.dispose();
    super.dispose();
  }

  double get _netUnit {
    final n = _v(_price) - _v(_discRs);
    return n < 0 ? 0 : n;
  }

  void _refreshTotal() => _lineTotal.text = (_netUnit * _qty).toStringAsFixed(2);

  /// Price typed -> the discount stays as entered (capped at the price) and
  /// only the percentage and the line total follow.
  void _onPrice() {
    if (_syncing) return;
    _syncing = true;
    final p = _v(_price);
    var rs = _v(_discRs);
    if (rs > p) { rs = p; _discRs.text = _trim(rs); }
    _discPct.text = p > 0 ? _trim(rs / p * 100) : '0';
    _refreshTotal();
    _syncing = false;
    if (mounted) setState(() {});
  }

  /// Discount (currency, per unit) typed -> percentage + line total. The price
  /// field is left alone.
  void _onDiscRs() {
    if (_syncing) return;
    _syncing = true;
    final p = _v(_price);
    var rs = _v(_discRs);
    if (rs > p) { rs = p; _discRs.text = _trim(rs); }
    _discPct.text = p > 0 ? _trim(rs / p * 100) : '0';
    _refreshTotal();
    _syncing = false;
    if (mounted) setState(() {});
  }

  /// Discount (%) typed -> discount per unit + line total. The price field is
  /// left alone.
  void _onDiscPct() {
    if (_syncing) return;
    _syncing = true;
    final p = _v(_price);
    var pct = _v(_discPct);
    if (pct > 100) { pct = 100; _discPct.text = '100'; }
    final rs = double.parse((p * pct / 100).toStringAsFixed(2));
    _discRs.text = _trim(rs);
    _refreshTotal();
    _syncing = false;
    if (mounted) setState(() {});
  }

  /// Line total typed -> price per unit after discount = total / qty. A lower
  /// total becomes a discount on the price; a higher total raises the price.
  void _onLineTotal() {
    if (_syncing) return;
    if (_qty <= 0) return;
    _syncing = true;
    final net = _v(_lineTotal) / _qty;
    final p = _v(_price);
    if (net <= p) {
      final rs = double.parse((p - net).toStringAsFixed(2));
      _discRs.text = _trim(rs);
      _discPct.text = p > 0 ? _trim(rs / p * 100) : '0';
    } else {
      _price.text = net.toStringAsFixed(2);
      _discRs.text = '0';
      _discPct.text = '0';
    }
    _syncing = false;
    if (mounted) setState(() {});
  }

  void _apply() {
    final value = _netUnit;
    final total = _v(_lineTotal);
    if (AmountLimit.exceeds(value) || AmountLimit.exceeds(total)) {
      AmountLimit.showMessage(context);
      return;
    }
    if (!value.isFinite || value < 0 || _price.text.trim().isEmpty) {
      AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid price.')));
      return;
    }
    FocusManager.instance.primaryFocus?.unfocus();
    // The bill keeps the price AFTER discount; profit / loss is worked out from it.
    Navigator.pop(context, double.parse(value.toStringAsFixed(4)));
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    final qtyText = _trim(widget.line.qty, dp: 3);
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          SafeArea(
            bottom: false,
            child: Container(
              height: 58 * s,
              padding: EdgeInsets.symmetric(horizontal: 14 * s),
              decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
              child: Row(
                children: [
                  AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
                  Expanded(child: Center(child: Text('Change Bill Price', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 19 * s, fontWeight: FontWeight.w800)))),
                  SizedBox(width: 42 * s),
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(14 * s),
              children: [
                Container(
                  padding: EdgeInsets.all(16 * s),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20 * s), border: Border.all(color: AppColors.lightCardBorder), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .045), blurRadius: 12)]),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(widget.line.item.name, style: TextStyle(fontSize: 16 * s, fontWeight: FontWeight.w900)),
                    SizedBox(height: 5 * s),
                    Text('Quantity: $qtyText ${widget.line.item.baseUnit}', style: TextStyle(fontSize: 11 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
                  ]),
                ),
                SizedBox(height: 12 * s),
                HiddenCostBox(value: widget.line.unitCost, scale: s, onVisibilityChanged: (v) => setState(() => _costVisible = v)),
                SizedBox(height: 12 * s),
                _priceCard(s),
                SizedBox(height: 12 * s),
                _discountCard(s),
                SizedBox(height: 12 * s),
                _netCard(s),
                SizedBox(height: 18 * s),
                SizedBox(height: 52 * s, width: double.infinity, child: FilledButton(onPressed: _apply, style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15 * s))), child: const Text('Apply', style: TextStyle(fontWeight: FontWeight.w800)))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _box(double s, Widget child) => Container(
        width: double.infinity,
        padding: EdgeInsets.all(15 * s),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20 * s), border: Border.all(color: AppColors.lightCardBorder), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .045), blurRadius: 12)]),
        child: child,
      );

  InputDecoration _dec(double s, {String? label, String? prefix, String? suffix}) => InputDecoration(
        labelText: label,
        prefixText: prefix,
        suffixText: suffix,
        filled: true,
        fillColor: AppColors.lightBackground,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14 * s), borderSide: BorderSide.none),
      );

  /// Retail price per unit - editable, for this bill only.
  Widget _priceCard(double s) => _box(
        s,
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Retail Price / ${widget.line.item.baseUnit}', style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800)),
          SizedBox(height: 10 * s),
          TextField(
            controller: _price,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: const [MaxAmountFormatter()],
            decoration: _dec(s, prefix: '${CurrencyFormatter.label} '),
          ),
          SizedBox(height: 4 * s),
          Text('Changes the price on this bill only', style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary)),
        ]),
      );

  Widget _discountCard(double s) {
    final discTotal = _v(_discRs) * _qty;
    return _box(
      s,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Discount (per ${widget.line.item.baseUnit})', style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800)),
        SizedBox(height: 10 * s),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            flex: 3,
            child: TextField(
              controller: _discRs,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: const [MaxAmountFormatter()],
              decoration: _dec(s, label: 'Discount (${CurrencyFormatter.label})', prefix: '${CurrencyFormatter.label} '),
            ),
          ),
          SizedBox(width: 10 * s),
          Expanded(
            flex: 2,
            child: TextField(
              controller: _discPct,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')), LengthLimitingTextInputFormatter(6)],
              decoration: _dec(s, label: 'Discount (%)', suffix: '%'),
            ),
          ),
        ]),
        if (discTotal > 0.004) ...[
          SizedBox(height: 10 * s),
          _bigRow('Discount on ${_trim(widget.line.qty, dp: 3)} qty', discTotal, s, const Color(0xFFDC2626)),
        ],
      ]),
    );
  }

  /// Net total of the line - editable - and, once the cost is revealed with
  /// the eye button, the profit / loss.
  Widget _netCard(double s) {
    final net = _netUnit;
    final pl = (net - widget.line.unitCost) * _qty;
    final isLoss = pl < -0.005;
    final isProfit = pl > 0.005;
    const red = Color(0xFFDC2626);
    const green = Color(0xFF16A34A);
    final plColor = isLoss ? red : (isProfit ? green : AppColors.lightTextSecondary);
    final plLabel = isLoss ? 'Loss' : (isProfit ? 'Profit' : 'No Profit / No Loss');
    final plIcon = isLoss ? Icons.trending_down_rounded : (isProfit ? Icons.trending_up_rounded : Icons.remove_rounded);
    return _box(
      s,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Net Total', style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800)),
        SizedBox(height: 10 * s),
        TextField(
          controller: _lineTotal,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: const [MaxAmountFormatter()],
          style: TextStyle(fontSize: 24 * s, fontWeight: FontWeight.w900, color: AppColors.primary),
          decoration: InputDecoration(
            prefixText: '${CurrencyFormatter.label} ',
            prefixStyle: TextStyle(fontSize: 18 * s, fontWeight: FontWeight.w800, color: AppColors.primary),
            suffixIcon: Icon(Icons.edit_rounded, size: 18 * s, color: AppColors.primary),
            filled: true,
            fillColor: AppColors.primary.withValues(alpha: .06),
            contentPadding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 14 * s),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14 * s), borderSide: BorderSide.none),
          ),
        ),
        SizedBox(height: 10 * s),
        _bigRow('Price after discount / ${widget.line.item.baseUnit}', net, s, AppColors.lightTextPrimary),
        // Profit / loss stays blank (space reserved) until the cost price is
        // revealed with the eye button.
        Visibility(
          visible: _costVisible,
          maintainSize: true,
          maintainAnimation: true,
          maintainState: true,
          child: Container(
            margin: EdgeInsets.only(top: 12 * s),
            padding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 13 * s),
            decoration: BoxDecoration(color: plColor.withValues(alpha: .09), borderRadius: BorderRadius.circular(14 * s), border: Border.all(color: plColor.withValues(alpha: .3))),
            child: Row(children: [
              Icon(plIcon, color: plColor, size: 24 * s),
              SizedBox(width: 9 * s),
              Expanded(child: Text(plLabel, style: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w800, color: plColor))),
              Text(CurrencyFormatter.formatCompact(pl.abs()), style: TextStyle(fontSize: 20 * s, fontWeight: FontWeight.w900, color: plColor)),
            ]),
          ),
        ),
        SizedBox(
          height: 30 * s,
          child: (_costVisible && isLoss)
              ? Padding(
                  padding: EdgeInsets.only(top: 8 * s),
                  child: Row(children: [
                    Icon(Icons.warning_amber_rounded, size: 16 * s, color: red),
                    SizedBox(width: 5 * s),
                    Expanded(child: Text('This product is being sold below its cost price (loss).', style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w700, color: red))),
                  ]),
                )
              : null,
        ),
      ]),
    );
  }

  Widget _bigRow(String label, double value, double s, Color color) => Row(children: [
        Expanded(child: Text(label, style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w700))),
        Text(CurrencyFormatter.formatCompact(value), style: TextStyle(fontSize: 16 * s, fontWeight: FontWeight.w900, color: color)),
      ]);
}

class SaleTotalEditorScreen extends StatefulWidget {
  final double currentTotal;
  const SaleTotalEditorScreen({super.key, required this.currentTotal});
  @override State<SaleTotalEditorScreen> createState() => _SaleTotalEditorScreenState();
}

class _SaleTotalEditorScreenState extends State<SaleTotalEditorScreen> {
  late final TextEditingController _controller;
  @override void initState() { super.initState(); _controller = TextEditingController(text: widget.currentTotal.toStringAsFixed(2)); }
  @override void dispose() { _controller.dispose(); super.dispose(); }
  void _apply() {
    final v = double.tryParse(_controller.text.trim());
    if (AmountLimit.exceeds(v)) { AmountLimit.showMessage(context); return; }
    if (v == null || !v.isFinite || v < 0) { AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid total.'))); return; }
    FocusManager.instance.primaryFocus?.unfocus();
    Navigator.pop(context, v);
  }
  @override Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(backgroundColor: AppColors.lightBackground, body: Column(children: [
      SafeArea(bottom: false, child: Container(height: 58*s, padding: EdgeInsets.symmetric(horizontal: 14*s), decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))), child: Row(children: [AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)), Expanded(child: Center(child: Text('Change Bill Total', style: TextStyle(fontSize: 19*s, fontWeight: FontWeight.w800)))), SizedBox(width: 42*s)]))),
      Expanded(child: ListView(padding: EdgeInsets.all(14*s), children: [Container(padding: EdgeInsets.all(16*s), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20*s), border: Border.all(color: AppColors.lightCardBorder)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Final amount for this bill', style: TextStyle(fontSize: 14*s, fontWeight: FontWeight.w800)), SizedBox(height: 10*s), TextField(controller: _controller, autofocus: true, keyboardType: const TextInputType.numberWithOptions(decimal: true), inputFormatters: const [MaxAmountFormatter()], decoration: InputDecoration(prefixText: '${CurrencyFormatter.label} ', filled: true, fillColor: AppColors.lightBackground, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14*s), borderSide: BorderSide.none)))])), SizedBox(height: 18*s), SizedBox(height: 52*s, child: FilledButton(onPressed: _apply, style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15*s))), child: const Text('Apply Total', style: TextStyle(fontWeight: FontWeight.w800))))]))
    ]));
  }
}
