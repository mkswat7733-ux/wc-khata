import '../../core/services/data_events.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../app/theme/app_theme.dart';
import '../../core/utils/currency_formatter.dart';
import 'sale_controller.dart';
import 'sale_repository.dart';
import 'new_sale_screen.dart';
import 'sale_invoice_screen.dart';

class SaleScreen extends StatefulWidget {
  const SaleScreen({super.key});

  @override
  State<SaleScreen> createState() => _SaleScreenState();
}

class _SaleScreenState extends State<SaleScreen> with SingleTickerProviderStateMixin {
  late final SaleController _controller;
  VoidCallback? _unlistenData;
  late final AnimationController _animationController;
  double _s = 1.0;

  @override
  void initState() {
    super.initState();
    _controller = SaleController()..load();
    _unlistenData = DataEvents.listen(() { if (mounted) _controller.refresh(); });
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
  }

  @override
  void dispose() {
    _unlistenData?.call();
    _animationController.dispose();
    _controller.dispose();
    super.dispose();
  }

  Animation<double> _stagger(int index) {
    final begin = (index * 0.12).clamp(0.0, 0.62);
    final end = (begin + 0.38).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _animationController,
      curve: Interval(begin, end, curve: Curves.easeOutCubic),
    );
  }

  Widget _reveal(int index, Widget child) {
    final animation = _stagger(index);
    return FadeTransition(
      opacity: animation,
      child: SlideTransition(
        position: animation.drive(
          Tween(begin: const Offset(0, 0.055), end: Offset.zero),
        ),
        child: child,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    _s = (MediaQuery.of(context).size.width / 390).clamp(0.82, 1.2);

    return ChangeNotifierProvider.value(
      value: _controller,
      child: Consumer<SaleController>(
        builder: (context, c, _) {
          if (c.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          return LayoutBuilder(
            builder: (context, constraints) {
              return Padding(
                padding: EdgeInsets.fromLTRB(14 * _s, 14 * _s, 14 * _s, 10 * _s),
                child: Column(
                  children: [
                    _reveal(0, _buildTodayCards(c)),
                    SizedBox(height: 10 * _s),
                    _reveal(1, _buildPaymentTypeCards(c)),
                    SizedBox(height: 14 * _s),
                    Expanded(
                      child: _reveal(2, _buildRecentSalesSection(c)),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildTodayCards(SaleController c) {
    return Row(
      children: [
        Expanded(
          child: _summaryCard(
            title: "Today's Sales",
            value: CurrencyFormatter.formatCompact(c.todaySales),
            icon: Icons.point_of_sale_rounded,
            accent: AppColors.primary,
          ),
        ),
        SizedBox(width: 10 * _s),
        Expanded(
          child: _summaryCard(
            title: 'Today Customers',
            value: '${c.todayCustomers}',
            icon: Icons.people_alt_rounded,
            accent: const Color(0xFF7C3AED),
          ),
        ),
      ],
    );
  }

  Widget _buildPaymentTypeCards(SaleController c) {
    return Row(
      children: [
        Expanded(
          child: _summaryCard(
            title: 'Cash Sales',
            value: '${c.todayCashSales}',
            icon: null,
            accent: const Color(0xFF16A34A),
          ),
        ),
        SizedBox(width: 10 * _s),
        Expanded(
          child: _summaryCard(
            title: 'Credit Sales',
            value: '${c.todayCreditSales}',
            icon: null,
            accent: const Color(0xFFDC2626),
          ),
        ),
      ],
    );
  }

  Widget _summaryCard({
    required String title,
    required String value,
    IconData? icon,
    required Color accent,
  }) {
    return Container(
      padding: EdgeInsets.fromLTRB(12 * _s, 11 * _s, 12 * _s, 12 * _s),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18 * _s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.055),
            blurRadius: 12 * _s,
            offset: Offset(0, 5 * _s),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Container(
                  width: 31 * _s,
                  height: 31 * _s,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(10 * _s),
                  ),
                  child: Icon(icon, color: accent, size: 17 * _s),
                ),
                SizedBox(width: 7 * _s),
              ],
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: accent,
                    fontSize: 11 * _s,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 9 * _s),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: accent,
              fontSize: 18 * _s,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentSalesSection(SaleController c) {
    final s = _s;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.055),
            blurRadius: 14 * s,
            offset: Offset(0, 5 * s),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Column(
            children: [
              Padding(
                padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 12 * s, 9 * s),
                child: Row(
                  children: [
                    Text(
                      'Recent Sales',
                      style: TextStyle(
                        color: AppColors.lightTextPrimary,
                        fontSize: 15 * s,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 9 * s, vertical: 4 * s),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(99),
                      ),
                      child: Text(
                        '${c.recentSales.length}',
                        style: TextStyle(
                          color: AppColors.primary,
                          fontSize: 10.5 * s,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Divider(height: 1, color: AppColors.lightDivider),
              Expanded(
                child: c.recentSales.isEmpty
                    ? ListView(
                        physics: const ClampingScrollPhysics(),
                        padding: EdgeInsets.symmetric(vertical: 42 * s),
                        children: [_buildEmptyRecentSales(s)],
                      )
                    : ListView.builder(
                        physics: const ClampingScrollPhysics(),
                        padding: EdgeInsets.fromLTRB(10 * s, 10 * s, 10 * s, 8 * s),
                        itemCount: c.recentSales.length,
                        itemBuilder: (context, index) =>
                            _buildSaleTile(c, c.recentSales[index]),
                      ),
              ),
            ],
          ),
          Positioned(
            right: 12 * s,
            bottom: 12 * s,
            child: _PressableSaleButton(
              onTap: () async {
                await Navigator.push<void>(
                  context,
                  MaterialPageRoute(builder: (_) => const NewSaleScreen()),
                );
                if (mounted) await c.refresh();
              },
              child: Container(
                width: 50 * s,
                height: 50 * s,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF4C8DFF), AppColors.primary],
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withValues(alpha: .35),
                      blurRadius: 12 * s,
                      offset: Offset(0, 5 * s),
                    ),
                  ],
                ),
                child: Icon(
                  Icons.add_shopping_cart_rounded,
                  color: Colors.white,
                  size: 22 * s,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyRecentSales(double s) {
    return Column(
      children: [
        Container(
          width: 54 * s,
          height: 54 * s,
          decoration: BoxDecoration(
            color: AppColors.primary.withValues(alpha: 0.08),
            shape: BoxShape.circle,
          ),
          child: Icon(
            Icons.point_of_sale_rounded,
            color: AppColors.primary,
            size: 25 * s,
          ),
        ),
        SizedBox(height: 12 * s),
        Text(
          'No recent sales yet',
          style: TextStyle(
            color: AppColors.lightTextPrimary,
            fontSize: 13.5 * s,
            fontWeight: FontWeight.w800,
          ),
        ),
        SizedBox(height: 4 * s),
        Text(
          'Your latest sales will appear here.',
          style: TextStyle(
            color: AppColors.lightTextSecondary,
            fontSize: 11 * s,
          ),
        ),
      ],
    );
  }

  Widget _buildSaleTile(SaleController c, SaleSummary sale) {
    final s = _s;
    final date = DateFormat('dd MMM, hh:mm a').format(sale.date);
    final subtitle = sale.customerName ?? (sale.paymentType == 'credit' ? 'Credit sale' : 'Cash sale');
    return Padding(
      padding: EdgeInsets.only(bottom: 6*s),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(15*s),
        child: InkWell(
          borderRadius: BorderRadius.circular(15*s),
          onTap: () async {
            final fullSale = await SaleRepository().getSaleById(sale.id);
            if (!mounted || fullSale == null) return;
            await Navigator.push(context, MaterialPageRoute(builder: (_) => SaleInvoiceScreen(sale: fullSale, customerName: sale.customerName)));
            if (mounted) await c.refresh();
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 10*s, vertical: 10*s),
            decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(15*s), border: Border.all(color: AppColors.lightDivider.withValues(alpha:.8))),
            child: Row(children: [
              Container(width: 40*s, height: 40*s, decoration: BoxDecoration(color: const Color(0xFF16A34A).withValues(alpha:.10), borderRadius: BorderRadius.circular(12*s)), child: Icon(Icons.shopping_bag_rounded, color: const Color(0xFF16A34A), size: 19*s)),
              SizedBox(width: 10*s),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(sale.invoiceNo, style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 13.5*s, fontWeight: FontWeight.w800)),
                SizedBox(height: 2*s),
                Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 10.8*s, fontWeight: FontWeight.w500)),
                SizedBox(height: 2*s),
                Text(date, style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 9.8*s)),
              ])),
              SizedBox(width: 8*s),
              Text(CurrencyFormatter.formatCompact(sale.total), style: TextStyle(color: const Color(0xFF16A34A), fontSize: 13.5*s, fontWeight: FontWeight.w800)),
            ]),
          ),
        ),
      ),
    );
  }
}

class _PressableSaleButton extends StatefulWidget {
  final VoidCallback onTap;
  final Widget child;

  const _PressableSaleButton({required this.onTap, required this.child});

  @override
  State<_PressableSaleButton> createState() => _PressableSaleButtonState();
}

class _PressableSaleButtonState extends State<_PressableSaleButton> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (mounted) setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => _setPressed(true),
      onTapUp: (_) => _setPressed(false),
      onTapCancel: () => _setPressed(false),
      child: AnimatedScale(
        scale: _pressed ? 0.92 : 1.0,
        duration: const Duration(milliseconds: 100),
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
  }
}
