import 'dart:convert';
import 'dart:typed_data';

import '../../core/utils/branding.dart';
import '../../core/utils/currency_formatter.dart';
import '../printer/receipt_settings.dart';
import 'bill_context.dart';

/// The same bill as [ThermalReceipt], but as plain ESC/POS TEXT that the
/// printer draws with its own built-in font.
///
/// Why: the picture version is ~100 KB per bill (every row of 576 dots has to
/// cross Bluetooth), and a thermal printer's Bluetooth chip is slow, so the
/// paper moves "step by step" while it waits for data. The text version is
/// 1-2 KB, so the bill is received in a blink and prints in one continuous
/// run. Used for 58 mm and 80 mm; the picture version stays for anything
/// text cannot show (shop logo, Urdu / non-English characters).
class ThermalTextReceipt {
  ThermalTextReceipt._();

  /// Returns null when this bill cannot be printed as text (logo, or a
  /// character the printer font does not have). The caller then prints the
  /// picture version instead, so nothing is ever lost.
  static Uint8List? build({
    required BillContext bill,
    required ReceiptSettings design,
    required int columns,
  }) {
    if (design.hasLogo) return null;

    final c = columns.clamp(32, 64);
    final b = BytesBuilder();
    var ok = true;

    String a(String? s) {
      var t = (s ?? '')
          .replaceAll('₨', 'Rs')
          .replaceAll('–', '-')
          .replaceAll('—', '-')
          .replaceAll('’', "'")
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      for (final u in t.codeUnits) {
        if (u < 32 || u > 126) {
          ok = false;
          t = '';
          break;
        }
      }
      return t;
    }

    void cmd(List<int> x) => b.add(x);
    void raw(String s) => b.add(ascii.encode('$s\n'));
    void style({bool bold = false, int size = 0, int align = 0}) {
      cmd([0x1B, 0x61, align]);
      cmd([0x1B, 0x45, bold ? 1 : 0]);
      cmd([0x1D, 0x21, size]);
    }

    int eff(int size) => c ~/ ((size >> 4) + 1);

    void center(String? text, {bool bold = false, int size = 0}) {
      final t = a(text);
      if (t.isEmpty) return;
      style(bold: bold, size: size, align: 1);
      for (final l in _wrap(t, eff(size))) {
        raw(l);
      }
      style();
    }

    void lr(String left, String? right, {bool bold = false, int size = 0}) {
      final l = a(left);
      var r = a(right);
      final w = eff(size);
      style(bold: bold, size: size);
      if (l.length + r.length + 1 <= w) {
        raw(l + ' ' * (w - l.length - r.length) + r);
      } else {
        raw(l.length > w ? l.substring(0, w) : l);
        if (r.length > w) r = r.substring(r.length - w);
        raw(' ' * (w - r.length) + r);
      }
      style();
    }

    void rule({String ch = '-'}) => raw(ch * c);

    final sale = bill.sale;
    final symbol = a(CurrencyFormatter.defaultSymbol);
    String money(double v) => '$symbol ${BillContext.moneyShort(v)}'.trim();

    cmd([0x1B, 0x40]); // initialise

    // ------------------------------------------------------------- header
    if (design.showBusinessName) {
      final name = a(bill.businessName).toUpperCase();
      // Big letters only when the name fits at double width.
      center(name, bold: true, size: name.length <= c ~/ 2 ? 0x11 : 0x01);
    }
    if (design.showAddress) center(bill.address);
    if (design.showPhone && (bill.phone ?? '').isNotEmpty) center('Tel: ${bill.phone}', bold: true);
    center(design.headerText, bold: true);
    rule(ch: '=');
    center(bill.receiptTitle, bold: true, size: 0x01);
    rule(ch: '=');

    // ---------------------------------------------------------- bill info
    if (design.showInvoiceNo) lr('Invoice:', bill.invoiceId);
    if (design.showDate) lr('Date:', BillContext.dateTime(sale.date));
    if (design.showParty && bill.customerName != null) lr('${bill.partyRole}:', bill.customerName);
    if (design.showPayment) lr('Payment:', bill.paymentLabel);

    // -------------------------------------------------------------- items
    rule(ch: '=');
    if (c >= 40) {
      // Wide paper (80 mm): table  ITEM | QTY | RATE | AMOUNT.
      const qW = 5, rW = 9, aW = 10;
      final nameW = c - qW - rW - aW;
      style(bold: true);
      raw('ITEM'.padRight(nameW) + 'QTY'.padLeft(qW) + 'RATE'.padLeft(rW) + 'AMOUNT'.padLeft(aW));
      style();
      rule();
      for (var i = 0; i < sale.lines.length; i++) {
        final ln = sale.lines[i];
        final nameLines = _wrap(a('${i + 1}. ${ln.item.name}'), nameW);
        final nums = BillContext.qty(ln.qty).padLeft(qW) +
            BillContext.moneyShort(ln.unitPrice).padLeft(rW) +
            BillContext.moneyShort(ln.total).padLeft(aW);
        style(bold: true);
        raw(nameLines.first.padRight(nameW) + nums);
        for (final extra in nameLines.skip(1)) {
          raw(extra);
        }
        style();
      }
    } else {
      // Narrow paper (58 mm): "1. Item name" then "qty x rate ..... amount".
      for (var i = 0; i < sale.lines.length; i++) {
        final ln = sale.lines[i];
        style(bold: true);
        for (final l in _wrap(a('${i + 1}. ${ln.item.name}'), c)) {
          raw(l);
        }
        style();
        lr('   ${BillContext.qty(ln.qty)} x ${BillContext.moneyShort(ln.unitPrice)}', BillContext.moneyShort(ln.total), bold: true);
        if (i != sale.lines.length - 1) rule();
      }
    }
    rule(ch: '=');

    // ------------------------------------------------------------- totals
    if (design.showQtySummary) lr('Items / Qty', '${sale.lines.length} / ${BillContext.qty(bill.totalQty)}');
    lr('Sub Total', money(sale.subtotal));
    if (design.showDiscount && sale.discountAmount > 0) lr('Discount', '- ${money(sale.discountAmount)}');
    if (design.showTax && sale.taxAmount > 0) lr('Tax (${sale.taxRate.toStringAsFixed(2)}%)', money(sale.taxAmount));
    rule();
    lr('NET TOTAL', money(sale.total), bold: true, size: 0x01);
    rule();
    if (design.showPaidBalance) {
      lr(bill.isPurchase ? 'Paid' : 'Received', money(sale.paid));
      lr(bill.isPaid ? 'Balance' : 'Balance Due', money(bill.balance < 0 ? 0 : bill.balance), bold: !bill.isPaid);
    }
    rule();
    if (design.showPaidStamp && bill.isPaid) center('*** PAID ***', bold: true, size: 0x01);
    if (design.footerText.trim().isNotEmpty) center(design.footerText);
    if (design.footerText2.trim().isNotEmpty) center(design.footerText2);
    center(Branding.poweredBy);

    cmd([0x1B, 0x64, 0x04]); // feed
    cmd([0x1D, 0x56, 0x42, 0x00]); // partial cut (ignored if no cutter)

    return ok ? b.toBytes() : null;
  }

  static List<String> _wrap(String s, int w) {
    final out = <String>[];
    var cur = '';
    for (final word in s.split(' ')) {
      var wd = word;
      while (wd.length > w) {
        if (cur.isNotEmpty) {
          out.add(cur);
          cur = '';
        }
        out.add(wd.substring(0, w));
        wd = wd.substring(w);
      }
      if (cur.isEmpty) {
        cur = wd;
      } else if (cur.length + 1 + wd.length <= w) {
        cur = '$cur $wd';
      } else {
        out.add(cur);
        cur = wd;
      }
    }
    if (cur.isNotEmpty) out.add(cur);
    return out.isEmpty ? [''] : out;
  }
}
