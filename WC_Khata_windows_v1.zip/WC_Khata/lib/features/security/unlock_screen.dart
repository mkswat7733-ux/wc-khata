import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/services/pending_notification.dart';
import '../../data/repositories/security_settings_repository.dart';
import '../../app/routes/root_shell.dart';
import '../notifications/notifications_screen.dart';
import '../../core/widgets/app_button_3d.dart';

/// Shown ONLY when password protection is enabled in Settings > Security.
/// This is the app's single lock mechanism — no biometrics, PIN, or
/// pattern exist anywhere in the codebase.
class UnlockScreen extends StatefulWidget {
  const UnlockScreen({super.key});

  @override
  State<UnlockScreen> createState() => _UnlockScreenState();
}

class _UnlockScreenState extends State<UnlockScreen> {
  final _repo = SecuritySettingsRepository();
  final _controller = TextEditingController();
  String? _error;
  bool _checking = false;

  Future<void> _submit() async {
    setState(() {
      _checking = true;
      _error = null;
    });
    final valid = await _repo.verifyPassword(_controller.text);
    if (!mounted) return;
    if (valid) {
      // A bill/subscription reminder notification is what brought the
      // app here (see NotificationService) -> land on Notifications
      // instead of Home, now that the password gate is satisfied.
      final payload = PendingNotification.consume();
      final destination = payload != null ? NotificationsScreen(initialPayload: payload) : const RootShell();
      Navigator.of(context).pushReplacement(
        AppTransitions.seamless(destination),
      );
    } else {
      setState(() {
        _checking = false;
        _error = 'Incorrect password. Please try again.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.spaceLg),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  color: AppColors.primary.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.lock, color: AppColors.primary, size: 30),
              ),
              const SizedBox(height: AppDimensions.spaceLg),
              const Text('Enter Password', style: AppTextStyles.h2),
              const SizedBox(height: 6),
              Text(
                'Your data is protected locally on this device',
                style: AppTextStyles.body.copyWith(color: AppColors.lightTextSecondary),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: AppDimensions.spaceLg),
              TextField(
                controller: _controller,
                obscureText: true,
                autofocus: true,
                textAlign: TextAlign.center,
                onSubmitted: (_) => _submit(),
                decoration: InputDecoration(
                  hintText: 'Password',
                  errorText: _error,
                ),
              ),
              const SizedBox(height: AppDimensions.spaceMd),
              SizedBox(
                width: double.infinity,
                child: AppButton3D(
                  expand: true,
                  onPressed: _checking ? null : _submit,
                  label: 'Unlock',
                  icon: Icons.lock_open_rounded,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
