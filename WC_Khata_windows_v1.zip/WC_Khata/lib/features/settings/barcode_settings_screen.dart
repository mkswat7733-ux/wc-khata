import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/services/barcode_generator_service.dart';
import '../../core/widgets/modern_header.dart';
import '../../core/widgets/app_message.dart';

class BarcodeSettingsScreen extends StatefulWidget {
  const BarcodeSettingsScreen({super.key});

  @override
  State<BarcodeSettingsScreen> createState() => _BarcodeSettingsScreenState();
}

class _BarcodeSettingsScreenState extends State<BarcodeSettingsScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _animation;
  final _starting = TextEditingController();
  bool _enabled = false;
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _animation = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..forward();
    _load();
  }

  Future<void> _load() async {
    final service = BarcodeGeneratorService.instance;
    final enabled = await service.isEnabled();
    final next = await service.getNextNumber();
    if (!mounted) return;
    setState(() {
      _enabled = enabled;
      _starting.text = next;
      _loading = false;
    });
  }

  Future<void> _saveNumber() async {
    final value = _starting.text.trim();
    if (!RegExp(r'^\d+$').hasMatch(value)) {
      _message('Enter numbers only, for example 100000.');
      return;
    }
    setState(() => _saving = true);
    final ok = await BarcodeGeneratorService.instance.setStartingNumber(value);
    if (mounted) {
      setState(() => _saving = false);
      _message(ok ? 'Barcode starting number saved.' : 'Could not save starting number.');
    }
  }

  Future<void> _toggle(bool value) async {
    if (value && !RegExp(r'^\d+$').hasMatch(_starting.text.trim())) {
      _starting.text = BarcodeGeneratorService.defaultStartingNumber;
    }
    setState(() => _enabled = value);
    await BarcodeGeneratorService.instance.setEnabled(value);
    if (value) await _saveNumber();
  }

  void _message(String text) {
    AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    _animation.dispose();
    _starting.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Barcode System', onBack: () => Navigator.pop(context)),
          if (_loading)
            const Expanded(child: Center(child: CircularProgressIndicator()))
          else
            Expanded(
              child: ListView(
                padding: EdgeInsets.all(14 * s),
                children: [
                  _animatedCard(s, 0, _mainToggle(s)),
                  if (_enabled) ...[
                    SizedBox(height: 12 * s),
                    _animatedCard(s, 1, _startingCard(s)),
                    SizedBox(height: 12 * s),
                    _animatedCard(s, 2, _infoCard(s)),
                  ],
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _animatedCard(double s, int index, Widget child) {
    final begin = (index * .16).clamp(0.0, .5);
    final animation = CurvedAnimation(parent: _animation, curve: Interval(begin, (begin + .55).clamp(0.0, 1.0), curve: Curves.easeOutCubic));
    return FadeTransition(
      opacity: animation,
      child: SlideTransition(position: animation.drive(Tween(begin: const Offset(0, .08), end: Offset.zero)), child: child),
    );
  }

  Widget _card(double s, Widget child) => Container(
        padding: EdgeInsets.all(13 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18 * s),
          border: Border.all(color: AppColors.lightCardBorder),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .055), blurRadius: 12 * s, offset: Offset(0, 5 * s))],
        ),
        child: child,
      );

  Widget _mainToggle(double s) => _card(s, Row(children: [
        Container(width: 44*s, height: 44*s, decoration: BoxDecoration(color: AppColors.primary.withValues(alpha:.10), shape: BoxShape.circle), child: Icon(Icons.auto_awesome_rounded, color: AppColors.primary, size: 21*s)),
        SizedBox(width: 11*s),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Generate Barcode', style: TextStyle(fontSize: 14*s, fontWeight: FontWeight.w800)),
          SizedBox(height: 3*s),
          Text('Automatically assign a serial barcode to new products.', style: TextStyle(fontSize: 10.5*s, color: AppColors.lightTextSecondary)),
        ])),
        Switch.adaptive(value: _enabled, onChanged: _toggle, activeColor: AppColors.primary),
      ]));

  Widget _startingCard(double s) => _card(s, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(Icons.numbers_rounded, color: AppColors.primary, size: 21*s), SizedBox(width: 8*s), Text('Enter starting number', style: TextStyle(fontSize: 14*s, fontWeight: FontWeight.w800))]),
        SizedBox(height: 6*s),
        Text('The next new product will use this number. Every saved product then increases it by 1.', style: TextStyle(fontSize: 10.5*s, color: AppColors.lightTextSecondary)),
        SizedBox(height: 11*s),
        TextField(
          controller: _starting,
          keyboardType: TextInputType.number,
          style: TextStyle(fontSize: 15*s, fontWeight: FontWeight.w800),
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.qr_code_2_rounded, color: AppColors.primary, size: 21*s),
            hintText: '100000',
            filled: true,
            fillColor: AppColors.lightBackground,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14*s), borderSide: BorderSide.none),
          ),
        ),
        SizedBox(height: 10*s),
        SizedBox(width: double.infinity, height: 46*s, child: FilledButton.icon(
          onPressed: _saving ? null : _saveNumber,
          icon: _saving ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Icon(Icons.save_rounded, size: 18),
          label: const Text('Save Starting Number', style: TextStyle(fontWeight: FontWeight.w800)),
          style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14*s))),
        )),
      ]));

  Widget _infoCard(double s) => _card(s, Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 20*s),
        SizedBox(width: 9*s),
        Expanded(child: Text('Example: start at 100000 → 100001 → 100002. Each product also gets a printable barcode label with its product name and barcode number.', style: TextStyle(fontSize: 10.5*s, height: 1.4, color: AppColors.lightTextSecondary))),
      ]));
}
