import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../../../core/services/thermal_printer_service.dart';

/// Exports the exact card that is on screen (so preview == download).
class BcExport {
  BcExport._();

  /// 3.5 x 2 inch ratio, 90 mm wide.
  static const double _pageW = 90 * PdfPageFormat.mm;
  static const double _pageH = _pageW * 200 / 350;

  /// Captures the [RepaintBoundary] behind [key] as a high resolution PNG
  /// (350x200 logical * 6 = 2100x1200 px).
  static Future<Uint8List> capturePng(GlobalKey key, {double pixelRatio = 6}) async {
    // Let any pending frame (image decode, layout) finish first.
    await WidgetsBinding.instance.endOfFrame;
    final context = key.currentContext;
    if (context == null) throw StateError('Card is not on screen');
    final boundary = context.findRenderObject() as RenderRepaintBoundary;
    final ui.Image image = await boundary.toImage(pixelRatio: pixelRatio);
    final ByteData? data = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    if (data == null) throw StateError('Could not encode card image');
    return data.buffer.asUint8List();
  }

  /// Print-ready PDF: page 1 = front, page 2 = back.
  static Future<Uint8List> buildPdf(Uint8List front, Uint8List back) async {
    final doc = pw.Document(title: 'Business Card', creator: 'WC Khata');
    const format = PdfPageFormat(_pageW, _pageH, marginAll: 0);
    for (final bytes in [front, back]) {
      final image = pw.MemoryImage(bytes);
      doc.addPage(
        pw.Page(
          pageFormat: format,
          margin: pw.EdgeInsets.zero,
          build: (_) => pw.Image(image, fit: pw.BoxFit.fill, width: _pageW, height: _pageH),
        ),
      );
    }
    return doc.save();
  }

  /// Opens the system "save as" dialog. Returns true when saved.
  static Future<bool> save({
    required Uint8List bytes,
    required String fileName,
    required String extension,
    String dialogTitle = 'Save Business Card',
  }) async {
    final path = await FilePicker.platform.saveFile(
      dialogTitle: dialogTitle,
      fileName: '$fileName.$extension',
      type: FileType.custom,
      allowedExtensions: [extension],
      bytes: bytes,
    );
    if (path == null || path.isEmpty) return false;
    // Mobile pickers write the supplied bytes themselves; desktop pickers
    // only return a path, so make sure the file really has content.
    try {
      final file = File(path);
      if (!await file.exists() || await file.length() == 0) {
        await file.writeAsBytes(bytes, flush: true);
      }
    } catch (_) {
      // Some Android providers return a content URI that dart:io cannot
      // open; in that case the picker has already written the bytes.
    }
    return true;
  }

  static Future<void> printPdf(Uint8List pdf) {
    return ThermalPrinterService.instance.printPdf(pdf);
  }

  /// Shares front + back as two PNG images (works with WhatsApp, etc.).
  static Future<void> shareImages(Uint8List front, Uint8List back) async {
    final dir = await getTemporaryDirectory();
    final frontFile = File('${dir.path}/BusinessCard_Front.png');
    final backFile = File('${dir.path}/BusinessCard_Back.png');
    await frontFile.writeAsBytes(front, flush: true);
    await backFile.writeAsBytes(back, flush: true);
    await Share.shareXFiles(
      [XFile(frontFile.path, mimeType: 'image/png'), XFile(backFile.path, mimeType: 'image/png')],
      text: 'My business card',
    );
  }
}
