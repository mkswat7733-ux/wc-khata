import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:barcode_widget/barcode_widget.dart';
import 'package:flutter/material.dart';
import 'card_models.dart';

/// Draws one side of a business card at the fixed logical size
/// ([kCardW] x [kCardH]). Wrap it in a [RepaintBoundary] to export it.
class BcCard extends StatelessWidget {
  final BcTemplate template;
  final BcData data;
  final bool back;

  const BcCard({super.key, required this.template, required this.data, this.back = false});

  @override
  Widget build(BuildContext context) {
    final accent = data.accent ?? template.accent;
    final c = _Ctx(
      d: data,
      fg: template.fg,
      muted: template.fg.withValues(alpha: template.dark ? .72 : .62),
      accent: accent,
      onAccent: accent.computeLuminance() > .55 ? const Color(0xFF111111) : Colors.white,
      dark: template.dark,
    );

    final isDesign = template.art == BcArt.design;
    final Widget face;
    if (isDesign) {
      face = _designFace(c, template.layout, back);
    } else if (back) {
      face = _backFace(c, template);
    } else {
      switch (template.layout) {
        case BcLayout.left:
          face = _leftFront(c);
          break;
        case BcLayout.center:
          face = _centerFront(c);
          break;
        case BcLayout.split:
          face = _splitFront(c);
          break;
        case BcLayout.minimal:
          face = _minimalFront(c);
          break;
        case BcLayout.glass:
          face = _glassFront(c);
          break;
        case BcLayout.banner:
          face = _bannerFront(c);
          break;
        default:
          face = _leftFront(c);
          break;
      }
    }

    // Fixed text scale so a user's system font size can never change an
    // exported card.
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.noScaling),
      child: DefaultTextStyle(
        style: TextStyle(color: c.fg, fontSize: 10, decoration: TextDecoration.none, fontWeight: FontWeight.w400),
        child: SizedBox(
          width: kCardW,
          height: kCardH,
          child: ClipRect(
            child: Stack(
              fit: StackFit.expand,
              children: [
                DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: template.gradient,
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
                CustomPaint(
                  painter: isDesign
                      ? _DesignPainter(_designArt(template.layout, back), accent)
                      : _ArtPainter(template.art, accent, template.dark, back),
                ),
                face,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// A scaled, rounded, shadowed card for screens. Pass [captureKey] to be
/// able to export exactly this card as an image.
class BcPreview extends StatelessWidget {
  final BcTemplate template;
  final BcData data;
  final bool back;
  final GlobalKey? captureKey;
  final double radius;

  const BcPreview({
    super.key,
    required this.template,
    required this.data,
    this.back = false,
    this.captureKey,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: (data.accent ?? template.accent).withValues(alpha: .28),
            blurRadius: 22,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: AspectRatio(
          aspectRatio: kCardW / kCardH,
          child: FittedBox(
            fit: BoxFit.contain,
            child: RepaintBoundary(
              key: captureKey,
              child: BcCard(template: template, data: data, back: back),
            ),
          ),
        ),
      ),
    );
  }
}

class _Ctx {
  final BcData d;
  final Color fg;
  final Color muted;
  final Color accent;
  final Color onAccent;
  final bool dark;

  const _Ctx({
    required this.d,
    required this.fg,
    required this.muted,
    required this.accent,
    required this.onAccent,
    required this.dark,
  });
}

// ---------------------------------------------------------------------------
// Shared pieces
// ---------------------------------------------------------------------------

Widget _fit(String text, TextStyle style, {Alignment alignment = Alignment.centerLeft}) {
  return FittedBox(
    fit: BoxFit.scaleDown,
    alignment: alignment,
    child: Text(text, maxLines: 1, style: style),
  );
}

/// Logo if the user has one, otherwise a gradient monogram tile.
Widget _logoBox(_Ctx c, double size, {double? radius, bool invert = false}) {
  final r = radius ?? size * .27;
  final logo = c.d.logo;
  final BoxDecoration deco;
  if (logo != null) {
    // No white tile / shadow behind a real logo, so a transparent PNG shows
    // directly on the card artwork.
    deco = BoxDecoration(borderRadius: BorderRadius.circular(r));
  } else if (invert) {
    deco = BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(r),
      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .18), blurRadius: 10, offset: const Offset(0, 4))],
    );
  } else {
    deco = BoxDecoration(
      gradient: LinearGradient(
        colors: [c.accent, Color.lerp(c.accent, Colors.black, .30)!],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      borderRadius: BorderRadius.circular(r),
      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .22), blurRadius: 10, offset: const Offset(0, 4))],
    );
  }

  Widget monogram() => Center(
        child: Text(
          c.d.initials,
          style: TextStyle(
            color: invert ? c.accent : c.onAccent,
            fontSize: size * (c.d.initials.length > 1 ? .36 : .46),
            fontWeight: FontWeight.w900,
            letterSpacing: .5,
          ),
        ),
      );

  return Container(
    width: size,
    height: size,
    decoration: deco,
    clipBehavior: Clip.antiAlias,
    child: logo != null
        ? Image.file(
            logo,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => monogram(),
          )
        : monogram(),
  );
}

Widget _info(_Ctx c, IconData icon, String text, {double size = 9.5, int lines = 1, Color? color}) {
  return Row(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Icon(icon, size: size + 2, color: c.accent),
      const SizedBox(width: 5),
      Flexible(
        child: Text(
          text,
          maxLines: lines,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: size, color: color ?? c.fg, height: 1.2, fontWeight: FontWeight.w500),
        ),
      ),
    ],
  );
}

/// Phone + email shown in a compact row on the front side.
Widget _frontContacts(_Ctx c, {MainAxisAlignment align = MainAxisAlignment.start}) {
  final items = <Widget>[
    if (c.d.phone != null) Flexible(child: _info(c, Icons.phone_rounded, c.d.phone!, size: 9)),
    if (c.d.email != null) Flexible(child: _info(c, Icons.mail_rounded, c.d.email!, size: 9)),
  ];
  if (items.isEmpty) return const SizedBox.shrink();
  if (items.length == 2) items.insert(1, const SizedBox(width: 14));
  return Row(mainAxisAlignment: align, mainAxisSize: MainAxisSize.max, children: items);
}

TextStyle _titleStyle(_Ctx c, {double size = 8.5, double spacing = 1.6, Color? color}) =>
    TextStyle(fontSize: size, color: color ?? c.accent, fontWeight: FontWeight.w800, letterSpacing: spacing);

Widget _accentBar(_Ctx c, {double w = 30, double h = 3}) => Container(
      width: w,
      height: h,
      decoration: BoxDecoration(color: c.accent, borderRadius: BorderRadius.circular(h)),
    );

Widget _glassPanel(Widget child, {double radius = 18, EdgeInsets padding = const EdgeInsets.all(16)}) {
  return ClipRRect(
    borderRadius: BorderRadius.circular(radius),
    child: BackdropFilter(
      filter: ui.ImageFilter.blur(sigmaX: 14, sigmaY: 14),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .16),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: Colors.white.withValues(alpha: .38), width: 1),
        ),
        child: child,
      ),
    ),
  );
}

// ---------------------------------------------------------------------------
// Front layouts
// ---------------------------------------------------------------------------

Widget _leftFront(_Ctx c) {
  final d = c.d;
  return Padding(
    padding: const EdgeInsets.fromLTRB(22, 20, 22, 18),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (d.showLogo) ...[_logoBox(c, 46), const SizedBox(width: 12)],
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (d.business != null)
                    _fit(d.business!, TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: c.fg, letterSpacing: .2)),
                  if (d.tagline != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(d.tagline!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9.5, color: c.muted)),
                    ),
                ],
              ),
            ),
          ],
        ),
        const Spacer(),
        if (d.owner != null) _fit(d.owner!, TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: c.fg)),
        if (d.title != null)
          Padding(padding: const EdgeInsets.only(top: 2), child: Text(d.title!.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: _titleStyle(c))),
        if (d.phone != null || d.email != null) ...[
          const SizedBox(height: 10),
          _accentBar(c, w: 24, h: 2),
          const SizedBox(height: 8),
          _frontContacts(c),
        ],
      ],
    ),
  );
}

Widget _centerFront(_Ctx c) {
  final d = c.d;
  return Padding(
    padding: const EdgeInsets.fromLTRB(22, 16, 22, 14),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        if (d.showLogo) ...[_logoBox(c, 40), const SizedBox(height: 7)],
        if (d.business != null)
          _fit(d.business!.toUpperCase(), TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: c.fg, letterSpacing: 2.6), alignment: Alignment.center),
        if (d.tagline != null)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(d.tagline!, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: TextStyle(fontSize: 9, color: c.muted, fontStyle: FontStyle.italic)),
          ),
        const SizedBox(height: 7),
        _accentBar(c, w: 38, h: 2),
        const Spacer(),
        if (d.owner != null) _fit(d.owner!, TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: c.fg), alignment: Alignment.center),
        if (d.title != null)
          Padding(padding: const EdgeInsets.only(top: 2), child: Text(d.title!.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: _titleStyle(c, size: 8, spacing: 1.8))),
        const Spacer(),
        _frontContacts(c, align: MainAxisAlignment.center),
      ],
    ),
  );
}

Widget _splitFront(_Ctx c) {
  final d = c.d;
  return Stack(
    children: [
      Positioned(
        left: 0,
        top: 0,
        bottom: 0,
        width: kCardW * .36,
        child: Center(
          child: d.showLogo
              ? _logoBox(c, 64, invert: true, radius: 18)
              : Icon(Icons.storefront_rounded, size: 40, color: c.onAccent),
        ),
      ),
      Positioned.fill(
        left: kCardW * .44,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(4, 20, 20, 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (d.business != null) _fit(d.business!, TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: c.fg)),
              if (d.tagline != null)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(d.tagline!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: c.muted)),
                ),
              const SizedBox(height: 9),
              _accentBar(c, w: 28),
              const SizedBox(height: 9),
              if (d.owner != null) _fit(d.owner!, TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: c.fg)),
              if (d.title != null)
                Padding(padding: const EdgeInsets.only(top: 2), child: Text(d.title!.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: _titleStyle(c, size: 8))),
              const Spacer(),
              if (d.phone != null) _info(c, Icons.phone_rounded, d.phone!, size: 9),
              if (d.phone != null && d.email != null) const SizedBox(height: 4),
              if (d.email != null) _info(c, Icons.mail_rounded, d.email!, size: 9),
            ],
          ),
        ),
      ),
    ],
  );
}

Widget _minimalFront(_Ctx c) {
  final d = c.d;
  return Padding(
    padding: const EdgeInsets.fromLTRB(24, 22, 24, 18),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _accentBar(c, w: 26, h: 4),
                  if (d.business != null) ...[
                    const SizedBox(height: 8),
                    Text(d.business!.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, color: c.muted, fontWeight: FontWeight.w700, letterSpacing: 2.4)),
                  ],
                  if (d.tagline != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(d.tagline!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: c.muted)),
                    ),
                ],
              ),
            ),
            if (d.showLogo) ...[const SizedBox(width: 10), _logoBox(c, 42, radius: 12)],
          ],
        ),
        const Spacer(),
        if (d.owner != null) _fit(d.owner!, TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: c.fg, height: 1.1)),
        if (d.title != null)
          Padding(padding: const EdgeInsets.only(top: 3), child: Text(d.title!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: c.accent, fontWeight: FontWeight.w700))),
        if (d.phone != null || d.email != null) ...[
          const SizedBox(height: 12),
          _frontContacts(c),
        ],
      ],
    ),
  );
}

Widget _glassFront(_Ctx c) {
  final d = c.d;
  return Padding(
    padding: const EdgeInsets.all(14),
    child: SizedBox.expand(
      child: _glassPanel(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                if (d.showLogo) ...[_logoBox(c, 40, radius: 12), const SizedBox(width: 11)],
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (d.business != null) _fit(d.business!, TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: c.fg)),
                      if (d.tagline != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 1),
                          child: Text(d.tagline!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: c.muted)),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const Spacer(),
            if (d.owner != null) _fit(d.owner!, TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: c.fg)),
            if (d.title != null)
              Padding(padding: const EdgeInsets.only(top: 2), child: Text(d.title!.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: _titleStyle(c, size: 8))),
            if (d.phone != null || d.email != null) ...[
              const SizedBox(height: 8),
              _frontContacts(c),
            ],
          ],
        ),
      ),
    ),
  );
}

Widget _bannerFront(_Ctx c) {
  final d = c.d;
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        height: 68,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [c.accent, Color.lerp(c.accent, Colors.black, .18)!]),
        ),
        child: Row(
          children: [
            if (d.showLogo) ...[_logoBox(c, 40, invert: true, radius: 11), const SizedBox(width: 12)],
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (d.business != null) _fit(d.business!, TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: c.onAccent)),
                  if (d.tagline != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 1),
                      child: Text(d.tagline!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: c.onAccent.withValues(alpha: .8))),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
      Expanded(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (d.owner != null) _fit(d.owner!, TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: c.fg)),
              if (d.title != null)
                Padding(padding: const EdgeInsets.only(top: 2), child: Text(d.title!.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: _titleStyle(c, size: 8.5))),
              const Spacer(),
              _frontContacts(c),
            ],
          ),
        ),
      ),
    ],
  );
}

// ---------------------------------------------------------------------------
// Back side (contact details + QR)
// ---------------------------------------------------------------------------

Widget _backFace(_Ctx c, BcTemplate t) {
  final d = c.d;
  final nameLine = [if (d.owner != null) d.owner!, if (d.title != null) d.title!].join('  |  ');

  final infos = <Widget>[
    if (d.phone != null) _info(c, Icons.phone_rounded, d.phone!, size: 9.5),
    if (d.whatsapp != null) _info(c, Icons.chat_rounded, d.whatsapp!, size: 9.5),
    if (d.email != null) _info(c, Icons.mail_rounded, d.email!, size: 9.5),
    if (d.website != null) _info(c, Icons.language_rounded, d.website!, size: 9.5),
    if (d.address != null) _info(c, Icons.location_on_rounded, d.address!, size: 9.5, lines: 2),
  ];

  final Widget left = Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      if (d.business != null) _fit(d.business!, TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: c.fg)),
      if (nameLine.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Text(nameLine, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: c.muted)),
        ),
      if (d.business != null || nameLine.isNotEmpty) ...[
        const SizedBox(height: 8),
        _accentBar(c, w: 24, h: 2),
        const SizedBox(height: 9),
      ],
      for (var i = 0; i < infos.length; i++)
        Padding(padding: EdgeInsets.only(bottom: i == infos.length - 1 ? 0 : 6), child: infos[i]),
    ],
  );

  final Widget qr = Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Container(
        width: 96,
        height: 96,
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .22), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: BarcodeWidget(
          barcode: Barcode.qrCode(errorCorrectLevel: BarcodeQRCorrectionLevel.medium),
          data: d.vcard,
          color: const Color(0xFF111111),
          backgroundColor: Colors.white,
          drawText: false,
        ),
      ),
      const SizedBox(height: 6),
      Text('SCAN TO SAVE', style: TextStyle(fontSize: 7, letterSpacing: 1.6, color: c.muted, fontWeight: FontWeight.w700)),
    ],
  );

  final Widget content = Row(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Expanded(child: left),
      if (d.showQr) ...[const SizedBox(width: 14), qr],
    ],
  );

  if (t.layout == BcLayout.glass) {
    return Padding(
      padding: const EdgeInsets.all(14),
      child: SizedBox.expand(child: _glassPanel(content, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12))),
    );
  }
  return Padding(padding: const EdgeInsets.fromLTRB(22, 16, 22, 16), child: content);
}

// ---------------------------------------------------------------------------
// Background art
// ---------------------------------------------------------------------------

class _ArtPainter extends CustomPainter {
  final BcArt art;
  final Color accent;
  final bool dark;
  final bool flip;

  const _ArtPainter(this.art, this.accent, this.dark, this.flip);

  void _orb(Canvas canvas, Offset center, double radius, Color color, double alpha) {
    final rect = Rect.fromCircle(center: center, radius: radius);
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..shader = RadialGradient(
          colors: [color.withValues(alpha: alpha), color.withValues(alpha: 0)],
        ).createShader(rect),
    );
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    canvas.save();
    if (flip) {
      canvas.translate(w, 0);
      canvas.scale(-1, 1);
    }

    switch (art) {
      case BcArt.aurora:
        _orb(canvas, Offset(w * .92, h * .08), h * .95, accent, .50);
        _orb(canvas, Offset(w * .04, h * 1.0), h * .85, const Color(0xFF7C3AED), .55);
        final ring = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1;
        ring.color = accent.withValues(alpha: .28);
        canvas.drawCircle(Offset(w * .92, h * .1), h * .55, ring);
        ring.color = accent.withValues(alpha: .14);
        canvas.drawCircle(Offset(w * .92, h * .1), h * .78, ring);
        break;

      case BcArt.gold:
        final line = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = accent.withValues(alpha: .75);
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(9, 9, w - 18, h - 18), const Radius.circular(8)), line);
        line.color = accent.withValues(alpha: .28);
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(14, 14, w - 28, h - 28), const Radius.circular(5)), line);
        final corner = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.2
          ..strokeCap = StrokeCap.round
          ..color = accent;
        const l = 16.0;
        const o = 9.0;
        canvas.drawPath(Path()..moveTo(o, o + l)..lineTo(o, o + 4)..quadraticBezierTo(o, o, o + 4, o)..lineTo(o + l, o), corner);
        canvas.drawPath(Path()..moveTo(w - o, o + l)..lineTo(w - o, o + 4)..quadraticBezierTo(w - o, o, w - o - 4, o)..lineTo(w - o - l, o), corner);
        canvas.drawPath(Path()..moveTo(o, h - o - l)..lineTo(o, h - o - 4)..quadraticBezierTo(o, h - o, o + 4, h - o)..lineTo(o + l, h - o), corner);
        canvas.drawPath(Path()..moveTo(w - o, h - o - l)..lineTo(w - o, h - o - 4)..quadraticBezierTo(w - o, h - o, w - o - 4, h - o)..lineTo(w - o - l, h - o), corner);
        _orb(canvas, Offset(w * .5, -h * .1), h * .9, accent, .16);
        break;

      case BcArt.ivory:
        canvas.drawCircle(Offset(w * .9, h * .12), h * .78, Paint()..color = accent.withValues(alpha: .07));
        canvas.drawCircle(Offset(w * 1.0, h * .98), h * .5, Paint()..color = accent.withValues(alpha: .06));
        canvas.drawRect(Rect.fromLTWH(0, 0, 5, h), Paint()..color = accent);
        break;

      case BcArt.corner:
        final path = Path()
          ..moveTo(0, 0)
          ..lineTo(w * .42, 0)
          ..lineTo(w * .31, h)
          ..lineTo(0, h)
          ..close();
        canvas.drawPath(
          path,
          Paint()
            ..shader = LinearGradient(
              colors: [accent, Color.lerp(accent, Colors.black, .35)!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(Rect.fromLTWH(0, 0, w * .42, h)),
        );
        final light = Path()
          ..moveTo(w * .30, 0)
          ..lineTo(w * .42, 0)
          ..lineTo(w * .31, h)
          ..lineTo(w * .22, h)
          ..close();
        canvas.drawPath(light, Paint()..color = Colors.white.withValues(alpha: .12));
        final dot = Paint()..color = accent.withValues(alpha: .16);
        for (var i = 0; i < 5; i++) {
          for (var j = 0; j < 4; j++) {
            canvas.drawCircle(Offset(w - 18 - i * 9, h - 16 - j * 9), 1.6, dot);
          }
        }
        break;

      case BcArt.wave:
        for (var i = 0; i < 4; i++) {
          final base = h * (.58 + .1 * i);
          final amp = 9.0 + 4 * i;
          final path = Path()..moveTo(0, h);
          path.lineTo(0, base);
          for (double x = 0; x <= w; x += 4) {
            path.lineTo(x, base + math.sin((x / w) * math.pi * 2 + i * 1.3) * amp);
          }
          path.lineTo(w, h);
          path.close();
          canvas.drawPath(path, Paint()..color = Colors.white.withValues(alpha: .07 + .035 * i));
        }
        _orb(canvas, Offset(w * .95, h * .05), h * .8, accent, .30);
        break;

      case BcArt.glass:
        _orb(canvas, Offset(w * .12, h * .15), h * .75, accent, .65);
        _orb(canvas, Offset(w * .95, h * .95), h * .85, const Color(0xFF22D3EE), .45);
        _orb(canvas, Offset(w * .6, h * .1), h * .45, Colors.white, .22);
        break;

      case BcArt.neon:
        final grid = Paint()
          ..strokeWidth = 1
          ..color = Colors.white.withValues(alpha: .045);
        for (double x = 0; x <= w; x += 22) {
          canvas.drawLine(Offset(x, 0), Offset(x, h), grid);
        }
        for (double y = 0; y <= h; y += 22) {
          canvas.drawLine(Offset(0, y), Offset(w, y), grid);
        }
        _orb(canvas, Offset(w * .95, h * .95), h * .9, accent, .32);
        _orb(canvas, Offset(w * .02, h * .02), h * .6, const Color(0xFF6D28D9), .35);
        final rect = RRect.fromRectAndRadius(Rect.fromLTWH(8, 8, w - 16, h - 16), const Radius.circular(14));
        canvas.drawRRect(
          rect,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 4
            ..color = accent.withValues(alpha: .7)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
        );
        canvas.drawRRect(
          rect,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.3
            ..color = accent,
        );
        break;

      case BcArt.pastel:
        canvas.drawCircle(Offset(w * .92, h * .1), 78, Paint()..color = accent.withValues(alpha: .14));
        canvas.drawCircle(Offset(w * .76, h * .32), 38, Paint()..color = accent.withValues(alpha: .11));
        canvas.drawCircle(Offset(w * .04, h * .98), 64, Paint()..color = accent.withValues(alpha: .10));
        canvas.drawCircle(
          Offset(w * .2, h * .6),
          22,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.2
            ..color = accent.withValues(alpha: .22),
        );
        break;

      case BcArt.mono:
        final tri = Path()
          ..moveTo(w, h * .52)
          ..lineTo(w, h)
          ..lineTo(w * .60, h)
          ..close();
        canvas.drawPath(tri, Paint()..color = accent);
        final tri2 = Path()
          ..moveTo(w, h * .70)
          ..lineTo(w, h)
          ..lineTo(w * .78, h)
          ..close();
        canvas.drawPath(tri2, Paint()..color = Colors.black.withValues(alpha: .18));
        break;

      case BcArt.design:
        break;

      case BcArt.navy:
        final stripe = Paint()
          ..strokeWidth = 10
          ..color = Colors.white.withValues(alpha: .035);
        for (double x = -h; x < w + h; x += 26) {
          canvas.drawLine(Offset(x, h), Offset(x + h, 0), stripe);
        }
        _orb(canvas, Offset(w * .95, h * .85), h * .7, accent, .20);
        canvas.drawRect(Rect.fromLTWH(0, h - 4, w, 4), Paint()..color = accent);
        break;
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _ArtPainter old) =>
      old.art != art || old.accent != accent || old.dark != dark || old.flip != flip;
}

// ---------------------------------------------------------------------------
// Designed templates: Salford, Rimberio, Seagull, Liceria, Arowwai, Borcelle
// Artwork is stored as simple vector paths (M L C Q Z O) in a 350 x 200 space.
// Fill / stroke values: '#RRGGBB', 'A' (the card accent) or 'g:#a,#b,#c'
// (diagonal gradient).
// ---------------------------------------------------------------------------

class _Shape {
  final String d;
  final String? fill;
  final String? stroke;
  final double sw;
  final double op;
  const _Shape(this.d, {this.fill, this.stroke, this.sw = 1, this.op = 1});
}

Path _svgPath(String d) {
  final path = Path();
  final tokens = RegExp(r'[MLCQZO]|-?\d*\.?\d+').allMatches(d).map((m) => m.group(0)!).toList();
  final isCmd = RegExp(r'^[MLCQZO]$');
  var i = 0;
  double n() => double.parse(tokens[i++]);
  var cmd = 'M';
  while (i < tokens.length) {
    if (isCmd.hasMatch(tokens[i])) {
      cmd = tokens[i++];
      if (cmd == 'Z') {
        path.close();
        continue;
      }
    }
    switch (cmd) {
      case 'M':
        {
          final x = n();
          final y = n();
          path.moveTo(x, y);
          cmd = 'L';
        }
        break;
      case 'L':
        {
          final x = n();
          final y = n();
          path.lineTo(x, y);
        }
        break;
      case 'C':
        {
          final a = n(), b = n(), c = n(), e = n(), f = n(), g = n();
          path.cubicTo(a, b, c, e, f, g);
        }
        break;
      case 'Q':
        {
          final a = n(), b = n(), c = n(), e = n();
          path.quadraticBezierTo(a, b, c, e);
        }
        break;
      case 'O':
        {
          final cx = n();
          final cy = n();
          final rad = n();
          path.addOval(Rect.fromCircle(center: Offset(cx, cy), radius: rad));
          cmd = 'M';
        }
        break;
      default:
        i++;
    }
  }
  return path;
}

Color _hexColor(String s) => Color(int.parse('FF${s.substring(1)}', radix: 16));

class _DesignPainter extends CustomPainter {
  final List<_Shape> shapes;
  final Color accent;
  const _DesignPainter(this.shapes, this.accent);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / kCardW, size.height / kCardH);
    for (final s in shapes) {
      final path = _svgPath(s.d);
      final fill = s.fill;
      if (fill != null) {
        final p = Paint()..style = PaintingStyle.fill..isAntiAlias = true;
        if (fill == 'A') {
          p.color = accent.withValues(alpha: s.op);
        } else if (fill.startsWith('g:')) {
          final cols = fill.substring(2).split(',').map(_hexColor).toList();
          p.shader = LinearGradient(colors: cols, begin: Alignment.topLeft, end: Alignment.bottomRight)
              .createShader(path.getBounds());
        } else {
          p.color = _hexColor(fill).withValues(alpha: s.op);
        }
        canvas.drawPath(path, p);
      }
      final stroke = s.stroke;
      if (stroke != null) {
        final base = stroke == 'A' ? accent : _hexColor(stroke);
        canvas.drawPath(
          path,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = s.sw
            ..isAntiAlias = true
            ..color = base.withValues(alpha: s.op),
        );
      }
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _DesignPainter old) => old.shapes != shapes || old.accent != accent;
}

const _salfordDetailArt = <_Shape>[
  _Shape('M 105 0 C 110 35 150 70 144 105 C 140 135 134 170 131 200 L 172 200 C 168 170 155 140 152 100 C 150 55 165 25 192 0 Z', fill: '#FDB913'),
  _Shape('M 105 0 C 110 35 150 70 144 105 C 140 135 134 170 131 200 L 140.02 200 C 141.48 170 143.3 136.1 145.76 103.9 C 150 66.7 122.1 32.8 124.14 0 Z', fill: 'A'),
  _Shape('M 131.1 0 C 126.5 32 150 65.5 146.4 103.5 L 150.88 100.7 C 150 57.1 157.3 26.4 179.82 0 Z', fill: '#0A4668'),
  _Shape('M0 0 L105 0 C110 35 150 70 144 105 C140 135 134 170 131 200 L0 200 Z', fill: '#0B3050'),
];

const _salfordLogoArt = <_Shape>[
  _Shape('M0 83 C25 125 70 168 120 200 L0 200 Z', fill: 'A'),
  _Shape('M0 120 C30 160 80 188 135 200 L110 200 C70 185 30 160 0 130 Z', fill: '#FDB913'),
  _Shape('M0 142 C30 175 70 195 110 200 L0 200 Z', fill: '#0B3050'),
  _Shape('M350 144 C300 175 250 195 205 200 L350 200 Z', fill: '#FDB913'),
  _Shape('M350 168 C320 185 290 196 262 200 L350 200 Z', fill: 'A'),
];

const _rimberioDetailArt = <_Shape>[
  _Shape('M 47 76 Q 25 98 47 120 L 193 266 Q 215 288 237 266 L 383 120 Q 405 98 383 76 L 237 -70 Q 215 -92 193 -70 Z', fill: '#0C0F12'),
  _Shape('M 71 78 Q 51 98 71 118 L 195 242 Q 215 262 235 242 L 359 118 Q 379 98 359 78 L 235 -46 Q 215 -66 195 -46 Z', fill: '#12151A'),
  _Shape('M 95 80 Q 77 98 95 116 L 197 218 Q 215 236 233 218 L 335 116 Q 353 98 335 80 L 233 -22 Q 215 -40 197 -22 Z', fill: '#171B20'),
  _Shape('M 99 82 Q 83 98 99 114 L 199 214 Q 215 230 231 214 L 331 114 Q 347 98 331 82 L 231 -18 Q 215 -34 199 -18 Z', stroke: 'A', sw: 0.9, op: 0.85),
  _Shape('M0 0 L58 0 C34 26 22 60 26 95 C30 125 46 160 68 200 L0 200 Z', fill: 'g:#F7E7A6,#D4AF37,#8A5A12'),
  _Shape('M60 0 C38 30 24 60 28 95 C32 125 50 160 76 200', stroke: 'A', sw: 0.6, op: 0.55),
  _Shape('M72 0 C50 30 36 60 40 95 C44 125 62 160 88 200', stroke: 'A', sw: 0.5, op: 0.33),
];

const _rimberioLogoArt = <_Shape>[
  _Shape('M 22 78 Q 0 100 22 122 L 153 253 Q 175 275 197 253 L 328 122 Q 350 100 328 78 L 197 -53 Q 175 -75 153 -53 Z', fill: '#0C0F12'),
  _Shape('M 45 80 Q 25 100 45 120 L 155 230 Q 175 250 195 230 L 305 120 Q 325 100 305 80 L 195 -30 Q 175 -50 155 -30 Z', fill: '#12151A'),
  _Shape('M 67 82 Q 49 100 67 118 L 157 208 Q 175 226 193 208 L 283 118 Q 301 100 283 82 L 193 -8 Q 175 -26 157 -8 Z', fill: '#171B20'),
  _Shape('M 71 84 Q 55 100 71 116 L 159 204 Q 175 220 191 204 L 279 116 Q 295 100 279 84 L 191 -4 Q 175 -20 159 -4 Z', stroke: 'A', sw: 0.9, op: 0.85),
  _Shape('M0 0 L82 0 C48 22 18 62 0 112 Z', fill: 'g:#F7E7A6,#D4AF37,#8A5A12'),
  _Shape('M350 200 L268 200 C302 178 332 138 350 88 Z', fill: 'g:#F7E7A6,#D4AF37,#8A5A12'),
  _Shape('M0 150 C20 125 40 108 60 98', stroke: 'A', sw: 0.5, op: 0.5),
  _Shape('M350 50 C330 75 310 92 290 102', stroke: 'A', sw: 0.5, op: 0.5),
];

const _seagullDetailArt = <_Shape>[
  _Shape('M258 0 L322 0 L350 70 L350 96 Z', fill: 'g:#FFF3C4,#E2B84A,#9A6A18'),
  _Shape('M308 0 L350 0 L350 72 Z', fill: '#0B4F7D'),
  _Shape('M334 0 L350 0 L350 32 Z', fill: '#08406A'),
  _Shape('M0 112 L86 200 L0 200 Z', fill: 'g:#FFF3C4,#E2B84A,#9A6A18'),
  _Shape('M0 132 L66 200 L0 200 Z', fill: '#0B4F7D'),
  _Shape('M0 164 L36 200 L0 200 Z', fill: '#08406A'),
  _Shape('M60 200 L96 200 L84 194 Z', fill: 'g:#FFF3C4,#E2B84A,#9A6A18'),
  _Shape('M141 88 L291 88 L291 90.4 L141 90.4 Z', fill: '#6B5A12'),
];

const _seagullLogoArt = <_Shape>[
  _Shape('M258 0 L322 0 L350 70 L350 96 Z', fill: 'g:#FFF3C4,#E2B84A,#9A6A18'),
  _Shape('M308 0 L350 0 L350 72 Z', fill: '#0B4F7D'),
  _Shape('M334 0 L350 0 L350 32 Z', fill: '#08406A'),
  _Shape('M0 112 L86 200 L0 200 Z', fill: 'g:#FFF3C4,#E2B84A,#9A6A18'),
  _Shape('M0 132 L66 200 L0 200 Z', fill: '#0B4F7D'),
  _Shape('M0 164 L36 200 L0 200 Z', fill: '#08406A'),
  _Shape('M60 200 L96 200 L84 194 Z', fill: 'g:#FFF3C4,#E2B84A,#9A6A18'),
];

const _liceriaDetailArt = <_Shape>[
  _Shape('M0 0 L236 0 L224 12 L0 12 Z', fill: '#0B1445'),
  _Shape('M0 192 L350 192 L350 200 L0 200 Z', fill: '#0B1445'),
  _Shape('M179 192 L221 142 L269 142 L315 192 L287 192 L245 154 L207 192 Z', fill: 'A'),
  _Shape('M221 142 L231 142 L193 192 L179 192 Z', fill: '#D9A300', op: 0.6),
];

const _liceriaLogoArt = <_Shape>[
  _Shape('M0 0 L350 0 L350 10 L0 10 Z', fill: '#0B1445'),
  _Shape('M0 190 L350 190 L350 200 L0 200 Z', fill: '#0B1445'),
  _Shape('M238 10 L254 10 L283 38 L316 0 L350 0 L350 12 L286 58 Z', fill: 'A'),
  _Shape('M 112 190 L 96 190 L 67 162 L 34 200 L 0 200 L 0 188 L 64 142 Z', fill: 'A'),
];

const _arowwaiDetailArt = <_Shape>[
  _Shape('M0 40 L120 0 M0 40 L90 200 M120 0 L90 200 M120 0 L250 90 M90 200 L250 90 M250 90 L350 40 M250 90 L300 200 M90 200 L300 200 M0 40 L250 90 M60 120 L350 140 M175 0 L120 0 M175 0 L250 90 M350 40 L300 200 M0 140 L90 200 M175 0 L90 200', stroke: '#6a4a22', sw: 0.6, op: 0.5),
  _Shape('M244 0 L270 0 L350 72 L350 92 Z', fill: '#4A2A07'),
  _Shape('M276 0 L350 0 L350 70 Z', fill: 'A'),
  _Shape('M312 0 L350 0 L350 40 Z', fill: '#FF9800'),
  _Shape('M0 138 L70 200 L0 200 Z', fill: '#4A2A07'),
  _Shape('M0 154 L46 200 L0 200 Z', fill: 'A'),
  _Shape('M0 176 L24 200 L0 200 Z', fill: '#FF9800'),
];

const _arowwaiLogoArt = <_Shape>[
  _Shape('M0 40 L120 0 M0 40 L90 200 M120 0 L90 200 M120 0 L250 90 M90 200 L250 90 M250 90 L350 40 M250 90 L300 200 M90 200 L300 200 M0 40 L250 90 M60 120 L350 140 M175 0 L120 0 M175 0 L250 90 M350 40 L300 200 M0 140 L90 200 M175 0 L90 200', stroke: '#6a4a22', sw: 0.6, op: 0.5),
  _Shape('M236 0 L262 0 L350 80 L350 104 Z', fill: '#4A2A07'),
  _Shape('M262 0 L350 0 L350 92 Z', fill: 'A'),
  _Shape('M306 0 L350 0 L350 46 Z', fill: '#FF9800'),
  _Shape('M0 120 L80 200 L0 200 Z', fill: '#4A2A07'),
  _Shape('M0 146 L54 200 L0 200 Z', fill: 'A'),
  _Shape('M0 172 L28 200 L0 200 Z', fill: '#FF9800'),
];

const _borcelleDetailArt = <_Shape>[
  _Shape('M204 200 C224 186 294 176 350 138 L350 200 Z', fill: 'g:#4E0C07,#3A0804,#5C1209'),
  _Shape('O 315 105 76', fill: 'g:#4E0C07,#3A0804,#5C1209'),
  _Shape('O 315 105 76', stroke: '#C9A24B', sw: 3.2),
  _Shape('O 315 105 69', stroke: '#C9A24B', sw: 0.7, op: 0.7),
  _Shape('M150 0 L186 0 C232 36 292 38 350 24 L350 42 C290 58 216 54 150 0 Z', fill: 'g:#F7E7A6,#D4AF37,#8A5A12'),
  _Shape('M156 200 C200 166 292 160 350 118 L350 138 C294 176 226 186 204 200 Z', fill: 'g:#F7E7A6,#D4AF37,#8A5A12'),
];

const _borcelleLogoArt = <_Shape>[
  _Shape('M0 0 L350 0 L350 200 L0 200 Z', fill: 'g:#3A0804,#4E0C07,#6B1409'),
  _Shape('M0 168 C90 150 170 126 236 108 C290 94 330 66 350 22 L350 44 C326 92 290 116 238 130 C170 148 90 170 0 186 Z', fill: 'g:#F7E7A6,#D4AF37,#8A5A12'),
  _Shape('M0 176 C90 160 170 138 236 120 C290 106 330 84 350 56', stroke: '#E8C766', sw: 0.5, op: 0.8),
  _Shape('M0 182 C90 168 170 148 236 130 C290 116 330 98 350 74', stroke: '#E8C766', sw: 0.5, op: 0.6),
  _Shape('M200 200 C262 182 330 150 350 112 L350 200 Z', fill: '#FFFFFF'),
  _Shape('O 245 118 58', fill: 'g:#4E0C07,#3A0804'),
  _Shape('O 245 118 58', stroke: '#C9A24B', sw: 3),
  _Shape('O 245 118 51', stroke: '#C9A24B', sw: 0.8, op: 0.8),
];

/// FRONT of a designed card = logo side. BACK = details side (+ QR).
List<_Shape> _designArt(BcLayout l, bool back) {
  switch (l) {
    case BcLayout.salford:
      return back ? _salfordDetailArt : _salfordLogoArt;
    case BcLayout.rimberio:
      return back ? _rimberioDetailArt : _rimberioLogoArt;
    case BcLayout.seagull:
      return back ? _seagullDetailArt : _seagullLogoArt;
    case BcLayout.liceria:
      return back ? _liceriaDetailArt : _liceriaLogoArt;
    case BcLayout.arowwai:
      return back ? _arowwaiDetailArt : _arowwaiLogoArt;
    case BcLayout.borcelle:
      return back ? _borcelleDetailArt : _borcelleLogoArt;
    default:
      return const <_Shape>[];
  }
}

class _Ci {
  final IconData icon;
  final String text;
  const _Ci(this.icon, this.text);
}

List<_Ci> _dContacts(BcData d, List<String> order) {
  final out = <_Ci>[];
  for (final k in order) {
    switch (k) {
      case 'phone':
        final v = d.phone ?? d.whatsapp;
        if (v != null) out.add(_Ci(Icons.phone_rounded, v));
        break;
      case 'email':
        if (d.email != null) out.add(_Ci(Icons.mail_rounded, d.email!));
        break;
      case 'web':
        if (d.website != null) out.add(_Ci(Icons.language_rounded, d.website!));
        break;
      case 'address':
        if (d.address != null) out.add(_Ci(Icons.location_on_rounded, d.address!));
        break;
    }
  }
  return out;
}

Widget _dIcon(IconData icon, double size, Color bg, Color fg, {bool square = false}) {
  return Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: bg,
      shape: square ? BoxShape.rectangle : BoxShape.circle,
      borderRadius: square ? BorderRadius.circular(size * .24) : null,
    ),
    child: Icon(icon, size: size * .58, color: fg),
  );
}

Widget _dRow(
  _Ci ci, {
  required double icon,
  required Color iconBg,
  required Color iconFg,
  required Color text,
  double size = 10,
  bool square = false,
  bool right = false,
  double gap = 7,
  double spacing = 0,
}) {
  final t = Flexible(
    child: Text(
      ci.text,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      textAlign: right ? TextAlign.right : TextAlign.left,
      style: TextStyle(fontSize: size, color: text, fontWeight: FontWeight.w500, height: 1.15, letterSpacing: spacing),
    ),
  );
  final ic = _dIcon(ci.icon, icon, iconBg, iconFg, square: square);
  return Row(
    mainAxisSize: MainAxisSize.max,
    mainAxisAlignment: right ? MainAxisAlignment.end : MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: right ? [t, SizedBox(width: gap), ic] : [ic, SizedBox(width: gap), t],
  );
}

Widget _dRows(List<_Ci> items, double gap, Widget Function(_Ci) build, {bool right = false}) {
  return Column(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: right ? CrossAxisAlignment.end : CrossAxisAlignment.start,
    children: [
      for (var i = 0; i < items.length; i++) ...[
        if (i > 0) SizedBox(height: gap),
        build(items[i]),
      ],
    ],
  );
}

/// The user's logo (replaces the sample logo of the design). Without a logo a
/// neat monogram is drawn. [tile] is kept for layout compatibility; the logo is
/// drawn without a white background.
Widget _dLogo(_Ctx c, double w, double h, {bool tile = false, bool circle = false}) {
  final d = c.d;
  if (!d.showLogo) return SizedBox(width: w, height: h);
  final side = math.min(w, h);
  final bw = circle ? side : w;
  final bh = circle ? side : h;
  final radius = BorderRadius.circular(circle ? side : side * .2);

  Widget mono() => Text(
        d.initials,
        style: TextStyle(
          color: c.onAccent,
          fontSize: side * (d.initials.length > 1 ? .38 : .5),
          fontWeight: FontWeight.w900,
        ),
      );

  final logo = d.logo;
  final Widget body;
  if (logo == null) {
    body = Container(
      width: bw,
      height: bh,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: c.accent, borderRadius: radius),
      child: mono(),
    );
  } else if (tile) {
    // Logo sits directly on the artwork (no white tile behind it).
    final timg = Image.file(
      logo,
      fit: circle ? BoxFit.cover : BoxFit.contain,
      errorBuilder: (_, __, ___) => Center(child: mono()),
    );
    body = SizedBox(width: bw, height: bh, child: circle ? ClipOval(child: timg) : timg);
  } else {
    final img = Image.file(
      logo,
      fit: circle ? BoxFit.cover : BoxFit.contain,
      errorBuilder: (_, __, ___) => Center(child: mono()),
    );
    body = SizedBox(width: bw, height: bh, child: circle ? ClipOval(child: img) : img);
  }
  return SizedBox(width: w, height: h, child: Center(child: body));
}

/// White QR tile (vCard of the profile) used on the back of designed cards.
Widget _dQr(_Ctx c, double size) {
  return Container(
    width: size,
    height: size,
    padding: EdgeInsets.all(size * .07),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(size * .12),
      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .22), blurRadius: 8, offset: const Offset(0, 3))],
    ),
    child: BarcodeWidget(
      barcode: Barcode.qrCode(errorCorrectLevel: BarcodeQRCorrectionLevel.medium),
      data: c.d.vcard,
      color: const Color(0xFF111111),
      backgroundColor: Colors.white,
      drawText: false,
    ),
  );
}

/// Centres [children] inside a box starting at [left] (used when the QR takes
/// the other side of the card).
Widget _sideGroup(List<Widget> children, {required double left, required double width, double top = 0, double bottom = 0}) {
  return Positioned(
    left: left,
    width: width,
    top: top,
    bottom: bottom,
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: children)),
  );
}

Widget _designFace(_Ctx c, BcLayout l, bool back) {
  switch (l) {
    case BcLayout.salford:
      return back ? _salfordDetail(c) : _salfordLogo(c);
    case BcLayout.rimberio:
      return back ? _rimberioDetail(c) : _rimberioLogo(c);
    case BcLayout.seagull:
      return back ? _seagullDetail(c) : _seagullLogo(c);
    case BcLayout.liceria:
      return back ? _liceriaDetail(c) : _liceriaLogo(c);
    case BcLayout.arowwai:
      return back ? _arowwaiDetail(c) : _arowwaiLogo(c);
    case BcLayout.borcelle:
      return back ? _borcelleDetail(c) : _borcelleLogo(c);
    default:
      return const SizedBox.shrink();
  }
}

Widget _centered(List<Widget> children, {double width = 230, double lift = 0}) {
  return Center(
    child: Padding(
      padding: EdgeInsets.only(bottom: lift),
      child: SizedBox(
        width: width,
        child: Column(mainAxisSize: MainAxisSize.min, children: children),
      ),
    ),
  );
}

// Every contact row is: icon first, then text.

Widget _plain(String text, TextStyle style, {double? left, double? right, double? top, double? width}) {
  return Positioned(
    left: left,
    right: right,
    top: top,
    width: width,
    child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: style),
  );
}

// ---- Salford ---------------------------------------------------------------

Widget _salfordLogo(_Ctx c) {
  final d = c.d;
  return _centered(
    [
      _dLogo(c, 66, 66),
      if (d.business != null)
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: _fit(
            d.business!.toUpperCase(),
            TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: c.fg, letterSpacing: .6),
            alignment: Alignment.center,
          ),
        ),
    ],
    lift: 22,
  );
}

Widget _salfordDetail(_Ctx c) {
  final d = c.d;
  const navy = Color(0xFF0B3050);
  final rows = _dContacts(d, ['phone', 'email', 'web', 'address']);
  return Stack(
    children: [
      Positioned(
        left: 12,
        width: 108,
        top: d.showQr ? 20 : 56,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _dLogo(c, d.showQr ? 40 : 46, d.showQr ? 40 : 46, tile: true),
            if (d.business != null)
              Padding(
                padding: const EdgeInsets.only(top: 7),
                child: _fit(
                  d.business!.toUpperCase(),
                  const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white, letterSpacing: .3),
                  alignment: Alignment.center,
                ),
              ),
          ],
        ),
      ),
      if (d.showQr) Positioned(left: 36, top: 112, child: _dQr(c, 60)),
      if (d.owner != null)
        Positioned(
          left: 176,
          right: 14,
          top: 24,
          child: _fit(d.owner!, const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: navy)),
        ),
      if (d.title != null)
        _plain(d.title!, TextStyle(fontSize: 12, color: Color.lerp(c.accent, Colors.black, .12), fontWeight: FontWeight.w500), left: 176, right: 14, top: 52),
      if (rows.isNotEmpty)
        Positioned(
          left: 176,
          right: 12,
          top: 90,
          child: _dRows(
            rows,
            7,
            (ci) => _dRow(ci, icon: 16, iconBg: c.accent, iconFg: Colors.white, text: navy, size: 9.5, square: true, gap: 7),
          ),
        ),
    ],
  );
}

// ---- Rimberio --------------------------------------------------------------

Widget _rimberioLogo(_Ctx c) {
  final d = c.d;
  return _centered(
    [
      _dLogo(c, 54, 54, tile: true, circle: true),
      if (d.business != null)
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: _fit(
            d.business!.toUpperCase(),
            const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white, letterSpacing: 1.6),
            alignment: Alignment.center,
          ),
        ),
    ],
    width: 170,
    lift: 8,
  );
}

Widget _rimberioDetail(_Ctx c) {
  final d = c.d;
  final rows = _dContacts(d, ['email', 'phone', 'address', 'web']);
  return Stack(
    children: [
      if (d.owner != null)
        Positioned(
          left: 98,
          right: 18,
          top: 22,
          child: _fit(
            d.owner!.toUpperCase(),
            const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: .4),
          ),
        ),
      if (d.title != null)
        _plain(d.title!.toUpperCase(), TextStyle(fontSize: 11, color: c.accent, fontWeight: FontWeight.w500, letterSpacing: 1.1), left: 98, right: 18, top: 56),
      if (rows.isNotEmpty)
        Positioned(
          left: 98,
          width: d.showQr ? 172 : 232,
          top: 92,
          child: _dRows(
            rows,
            6,
            (ci) => _dRow(ci, icon: 16, iconBg: c.accent, iconFg: const Color(0xFF111111), text: Colors.white, size: 10.5, gap: 8),
          ),
        ),
      if (d.showQr) Positioned(left: 278, top: 108, child: _dQr(c, 54)),
    ],
  );
}

// ---- Seagull ---------------------------------------------------------------

Widget _seagullLogo(_Ctx c) {
  final d = c.d;
  const brown = Color(0xFF4A3A08);
  return _centered(
    [
      _dLogo(c, 84, 84),
      if (d.business != null)
        Padding(
          padding: const EdgeInsets.only(top: 14),
          child: _fit(
            d.business!.toUpperCase(),
            const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: brown, letterSpacing: 3),
            alignment: Alignment.center,
          ),
        ),
      if (d.website != null)
        Padding(
          padding: const EdgeInsets.only(top: 7),
          child: _fit(d.website!, const TextStyle(fontSize: 10.5, color: brown, letterSpacing: .8), alignment: Alignment.center),
        ),
    ],
    lift: 4,
  );
}

Widget _seagullDetail(_Ctx c) {
  final d = c.d;
  var rows = _dContacts(d, ['phone', 'email', 'address', 'web']);
  if (rows.length > 3) rows = rows.take(3).toList();
  return Stack(
    children: [
      if (d.showQr) ...[
        Positioned(left: 50, top: 30, child: _dLogo(c, 80, 74)),
        Positioned(left: 62, top: 112, child: _dQr(c, 56)),
      ] else
        Positioned(left: 30, top: 55, child: _dLogo(c, 78, 92)),
      if (d.owner != null)
        Positioned(
          left: 141,
          right: 52,
          top: 32,
          child: _fit(d.owner!.toUpperCase(), TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: c.fg, letterSpacing: 1)),
        ),
      if (d.title != null)
        _plain(d.title!, TextStyle(fontSize: 12, color: c.fg, letterSpacing: 1), left: 141, right: 50, top: 57),
      if (rows.isNotEmpty)
        Positioned(
          left: 140,
          right: 16,
          top: 98,
          child: _dRows(
            rows,
            10,
            (ci) => _dRow(ci, icon: 16, iconBg: c.accent, iconFg: Colors.white, text: c.fg, size: 10.5, gap: 8, spacing: .2),
          ),
        ),
    ],
  );
}

// ---- Liceria ---------------------------------------------------------------

Widget _liceriaLogo(_Ctx c) {
  final d = c.d;
  return _centered(
    [
      _dLogo(c, 90, 62),
      if (d.business != null)
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: _fit(
            d.business!.toUpperCase(),
            TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: c.fg, letterSpacing: .4),
            alignment: Alignment.center,
          ),
        ),
      if (d.tagline != null)
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: _fit(d.tagline!, TextStyle(fontSize: 10.5, color: c.fg, letterSpacing: 1.1), alignment: Alignment.center),
        ),
    ],
    width: 240,
    lift: 2,
  );
}

Widget _liceriaDetail(_Ctx c) {
  final d = c.d;
  final rows = _dContacts(d, ['phone', 'web', 'email', 'address']);
  return Stack(
    children: [
      if (d.owner != null)
        Positioned(
          left: 17,
          width: 195,
          top: 26,
          child: _fit(d.owner!, TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: c.fg)),
        ),
      if (d.title != null) _plain(d.title!, TextStyle(fontSize: 11.5, color: c.fg), left: 17, width: 195, top: 49),
      Positioned(left: 17, top: 66, child: _accentBar(c, w: 20, h: 1.6)),
      if (rows.isNotEmpty)
        Positioned(
          left: 15,
          width: 188,
          top: 76,
          child: _dRows(
            rows,
            5,
            (ci) => _dRow(ci, icon: 18, iconBg: c.accent, iconFg: c.fg, text: c.fg, size: 9.5, gap: 7),
          ),
        ),
      Positioned(
        left: 224,
        width: 104,
        top: 14,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _dLogo(c, 54, 34),
            if (d.business != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: _fit(
                  d.business!.toUpperCase(),
                  TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: c.fg, letterSpacing: .3),
                  alignment: Alignment.center,
                ),
              ),
            if (d.tagline != null)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: _fit(d.tagline!, TextStyle(fontSize: 8, color: c.fg, letterSpacing: .8), alignment: Alignment.center),
              ),
          ],
        ),
      ),
      if (d.showQr) Positioned(left: 251, top: 86, child: _dQr(c, 50)),
    ],
  );
}

// ---- Arowwai ---------------------------------------------------------------

Widget _arowwaiLogo(_Ctx c) {
  final d = c.d;
  return Center(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _dLogo(c, 66, 66, tile: true),
          const SizedBox(width: 12),
          Flexible(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (d.business != null)
                  _fit(d.business!.toUpperCase(), TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: c.fg, letterSpacing: .3)),
                if (d.tagline != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(d.tagline!.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: c.fg)),
                  ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget _arowwaiDetail(_Ctx c) {
  final d = c.d;
  var rows = _dContacts(d, ['phone', 'email', 'address', 'web']);
  if (rows.length > 3) rows = rows.take(3).toList();
  return Stack(
    children: [
      Positioned(left: d.showQr ? 44 : 34, top: d.showQr ? 38 : 58, child: _dLogo(c, d.showQr ? 66 : 80, d.showQr ? 66 : 80, tile: true)),
      if (d.showQr) Positioned(left: 51, top: 116, child: _dQr(c, 52)),
      Positioned(left: 127, top: 44, child: Container(width: 1.8, height: 112, color: c.accent)),
      if (d.owner != null)
        Positioned(
          left: 144,
          right: 18,
          top: 46,
          child: _fit(d.owner!.toUpperCase(), TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: c.fg, letterSpacing: .3)),
        ),
      if (d.title != null) _plain(d.title!.toUpperCase(), TextStyle(fontSize: 12, color: c.fg), left: 144, right: 18, top: 70),
      if (rows.isNotEmpty)
        Positioned(
          left: 143,
          right: 12,
          top: 94,
          child: _dRows(
            rows,
            6,
            (ci) => _dRow(ci, icon: 18, iconBg: c.accent, iconFg: const Color(0xFF2B1804), text: c.fg, size: 11, gap: 8),
          ),
        ),
    ],
  );
}

// ---- Borcelle --------------------------------------------------------------

Widget _borcelleLogo(_Ctx c) {
  final d = c.d;
  return Stack(
    children: [
      Positioned(left: 20, top: 38, child: _dLogo(c, 30, 30, tile: true, circle: true)),
      if (d.business != null)
        Positioned(
          left: 58,
          width: 170,
          top: 41,
          child: _fit(d.business!.toUpperCase(), const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white, letterSpacing: 1)),
        ),
      Positioned(left: 245 - 31, top: 118 - 31, child: _dLogo(c, 62, 62, tile: true, circle: true)),
    ],
  );
}

Widget _borcelleDetail(_Ctx c) {
  final d = c.d;
  final rows = _dContacts(d, ['phone', 'web', 'email', 'address']);
  return Stack(
    children: [
      Positioned(left: 27, top: 25, child: _dLogo(c, 27, 27, circle: true)),
      if (d.business != null)
        Positioned(
          left: 62,
          width: 112,
          top: 27,
          child: _fit(d.business!.toUpperCase(), TextStyle(fontSize: 17.5, fontWeight: FontWeight.w800, color: c.fg, letterSpacing: .8)),
        ),
      Positioned(left: 28, top: 57, child: Container(width: 116, height: 1.5, color: c.fg)),
      if (d.owner != null)
        Positioned(
          left: 28,
          width: 150,
          top: 63,
          child: _fit(d.owner!.toUpperCase(), TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: c.fg, letterSpacing: .3)),
        ),
      if (d.title != null)
        _plain(d.title!.toUpperCase(), TextStyle(fontSize: 9, color: c.muted, letterSpacing: 2.4), left: 28, width: 150, top: 81),
      if (rows.isNotEmpty)
        Positioned(
          left: 27,
          width: 150,
          top: 104,
          child: _dRows(
            rows,
            5,
            (ci) => _dRow(ci, icon: 15, iconBg: c.fg, iconFg: c.accent, text: c.fg, size: 9.5, gap: 7, spacing: .3),
          ),
        ),
      if (d.showQr) Positioned(left: 262, top: 72, child: _dQr(c, 66)),
    ],
  );
}
