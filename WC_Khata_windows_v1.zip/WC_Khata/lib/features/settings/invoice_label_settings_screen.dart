
import '../../core/utils/currency_formatter.dart';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../data/models/profile_model.dart';
import '../../data/repositories/profile_repository.dart';
import 'template_service.dart';
import 'label_sizes.dart';
import 'label_designer_screen.dart';
import '../../core/services/thermal_printer_service.dart';
import '../printer/printer_gate.dart';
import '../printer/receipt_designer_screen.dart';
import '../../core/widgets/app_message.dart';

class InvoiceLabelSettingsScreen extends StatefulWidget {
  const InvoiceLabelSettingsScreen({super.key});
  @override State<InvoiceLabelSettingsScreen> createState()=>_InvoiceLabelSettingsScreenState();
}

class _InvoiceLabelSettingsScreenState extends State<InvoiceLabelSettingsScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _animation;
  TemplateKind _kind=TemplateKind.invoice;
  int _section=0; // 0 = Templates (use), 1 = Customize Templates (edit)
  bool _receipt=false; // third tab: 58mm / 80mm receipt design
  List<DocumentTemplate> _all=[];
  bool _loading=true;
  String? _activeId;
  final TextEditingController _search = TextEditingController();

  @override void initState(){super.initState(); _animation=AnimationController(vsync:this,duration:const Duration(milliseconds:700))..forward(); _load();}
  @override void dispose(){_animation.dispose();_search.dispose();super.dispose();}
  Future<void> _load() async { setState(()=>_loading=true); final list=await TemplateService.instance.all(); final active=await TemplateService.instance.active(_kind); if(mounted)setState((){_all=list;_activeId=active.id;_loading=false;}); }
  List<DocumentTemplate> get _items=>_all.where((x)=>x.kind==_kind).where((x){
    final q=_search.text.trim().toLowerCase();
    if(q.isNotEmpty && !x.name.toLowerCase().contains(q)) return false;
    return true;
  }).toList();

  void _toast(String s){if(!mounted)return;AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content:Text(s)));}

  Future<void> _open(DocumentTemplate t) async {
    await Navigator.push(context,MaterialPageRoute(builder:(_)=>TemplatePreviewScreen(template:t)));
    await _load();
  }

  Future<void> _customize(DocumentTemplate t) async {
    final r=await Navigator.push<DocumentTemplate>(context,MaterialPageRoute(builder:(_)=>t.kind==TemplateKind.label?LabelDesignerScreen(template:t):TemplateEditorScreen(kind:t.kind,template:t)));
    if(r!=null){await TemplateService.instance.save(r);await _load();}
  }

  Future<void> _customizeActive() async {
    final active=await TemplateService.instance.active(_kind);
    if(!mounted)return;
    await _customize(active);
  }

  Future<void> _activate(DocumentTemplate t) async {await TemplateService.instance.setActive(t);await _load();setState(()=>_activeId=t.id);_toast('${t.name} is now active.');}

  Future<void> _delete(DocumentTemplate t) async {
    if(t.builtIn)return;
    await TemplateService.instance.deleteCreated(t.id);await _load();_toast('Template deleted.');
  }

  @override Widget build(BuildContext context){
    final s=(MediaQuery.sizeOf(context).width/390).clamp(.82,1.2).toDouble();
    return Scaffold(
      backgroundColor:AppColors.lightBackground,
      body:Column(children:[
        _header(s),
        if(_receipt) ...[
          Padding(padding:EdgeInsets.fromLTRB(12*s,8*s,12*s,0),child:_kindTabs(s)),
          const Expanded(child:ReceiptDesignerPanel(embedded:true)),
        ] else ...[
        Padding(
          padding:EdgeInsets.fromLTRB(12*s,8*s,12*s,0),
          child:TextField(
            controller:_search,
            onChanged:(_)=>setState((){}),
            decoration:InputDecoration(
              hintText:'Search templates...',
              prefixIcon:const Icon(Icons.search_rounded,size:20),
              suffixIcon:_search.text.isEmpty?null:IconButton(icon:const Icon(Icons.close_rounded,size:18),onPressed:(){_search.clear();setState((){});}),
              filled:true,fillColor:Colors.white,
              contentPadding:EdgeInsets.symmetric(vertical:10*s),
              border:OutlineInputBorder(borderRadius:BorderRadius.circular(13*s),borderSide:BorderSide(color:AppColors.lightCardBorder)),
              enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(13*s),borderSide:BorderSide(color:AppColors.lightCardBorder)),
            ),
          ),
        ),
        Padding(padding:EdgeInsets.fromLTRB(12*s,8*s,12*s,0),child:_kindTabs(s)),
        Padding(padding:EdgeInsets.fromLTRB(12*s,7*s,12*s,7*s),child:_sectionTabs(s)),
        Expanded(
          child:_loading
            ? const Center(child:CircularProgressIndicator())
            : Padding(
                padding:EdgeInsets.symmetric(horizontal:12*s),
                child:Container(
                  width:double.infinity,
                  decoration:BoxDecoration(
                    color:Colors.white,
                    borderRadius:BorderRadius.circular(18*s),
                    border:Border.all(color:AppColors.lightCardBorder),
                    boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:.045),blurRadius:14,offset:Offset(0,5*s))],
                  ),
                  child:_items.isEmpty
                    ? _empty(s)
                    : GridView.builder(
                        padding:EdgeInsets.all(10*s),
                        physics:const BouncingScrollPhysics(),
                        itemCount:_items.length,
                        gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount:2,crossAxisSpacing:9*s,mainAxisSpacing:9*s,
                          childAspectRatio:_kind==TemplateKind.invoice?0.83:0.90,
                        ),
                        itemBuilder:(c,i)=>_card(_items[i],s),
                      ),
                ),
              ),
        ),
        Padding(
          padding:EdgeInsets.fromLTRB(12*s,8*s,12*s,9*s),
          child:SizedBox(width:double.infinity,child:_bottomButton(s,Icons.tune_rounded,'Customize Active Template',AppColors.primary,_customizeActive)),
        ),
        ],
      ]),
    );
  }

  Widget _header(double s)=>SafeArea(bottom:false,child:Container(height:60*s,padding:EdgeInsets.symmetric(horizontal:12*s),decoration:const BoxDecoration(color:Colors.white,border:Border(bottom:BorderSide(color:AppColors.lightDivider))),child:Row(children:[
    AppGlassIconButton(icon:Icons.arrow_back_rounded,onTap:()=>Navigator.pop(context)),Expanded(child:Center(child:Text('Invoice / Label Settings',style:TextStyle(fontSize:18*s,fontWeight:FontWeight.w900)))),SizedBox(width:42*s)
  ])));

  Widget _kindTabs(double s)=>Container(height:43*s,padding:const EdgeInsets.all(4),decoration:BoxDecoration(color:const Color(0xFFF0F2F5),borderRadius:BorderRadius.circular(13*s)),child:Row(children:[
    _tab(s,'Invoice',TemplateKind.invoice,!_receipt&&_kind==TemplateKind.invoice),_tab(s,'Label',TemplateKind.label,!_receipt&&_kind==TemplateKind.label),_receiptTab(s)
  ]));
  Widget _receiptTab(double s)=>Expanded(child:GestureDetector(onTap:()=>setState(()=>_receipt=true),child:AnimatedContainer(duration:const Duration(milliseconds:180),alignment:Alignment.center,decoration:BoxDecoration(color:_receipt?Colors.white:Colors.transparent,borderRadius:BorderRadius.circular(10*s),boxShadow:_receipt?[const BoxShadow(color:Color(0x14000000),blurRadius:6,offset:Offset(0,2))]:null),child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.receipt_rounded,size:17*s,color:_receipt?AppColors.primary:AppColors.lightTextSecondary),SizedBox(width:4*s),Flexible(child:FittedBox(fit:BoxFit.scaleDown,child:Text('58/80mm Receipt',maxLines:1,style:TextStyle(fontSize:12*s,fontWeight:FontWeight.w800,color:_receipt?AppColors.lightTextPrimary:AppColors.lightTextSecondary))))]))));
  Widget _tab(double s,String text,TemplateKind k,bool selected)=>Expanded(child:GestureDetector(onTap:() async { setState((){_kind=k;_receipt=false;}); final a=await TemplateService.instance.active(k); if(mounted)setState(()=>_activeId=a.id); },child:AnimatedContainer(duration:const Duration(milliseconds:180),alignment:Alignment.center,decoration:BoxDecoration(color:selected?Colors.white:Colors.transparent,borderRadius:BorderRadius.circular(10*s),boxShadow:selected?[const BoxShadow(color:Color(0x14000000),blurRadius:6,offset:Offset(0,2))]:null),child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(k==TemplateKind.invoice?Icons.receipt_long_rounded:Icons.qr_code_2_rounded,size:17*s,color:selected?AppColors.primary:AppColors.lightTextSecondary),SizedBox(width:5*s),Text(text,style:TextStyle(fontSize:12*s,fontWeight:FontWeight.w800,color:selected?AppColors.lightTextPrimary:AppColors.lightTextSecondary))]))));
  Widget _sectionTabs(double s)=>Row(children:List.generate(2,(i){final labels=['Templates','Customize Templates'];return Expanded(child:GestureDetector(onTap:()=>setState(()=>_section=i),child:Container(padding:EdgeInsets.symmetric(vertical:9*s),margin:EdgeInsets.only(right:i<1?6*s:0),decoration:BoxDecoration(color:_section==i?AppColors.primary.withValues(alpha:.10):Colors.white,borderRadius:BorderRadius.circular(11*s),border:Border.all(color:_section==i?AppColors.primary.withValues(alpha:.25):AppColors.lightCardBorder)),child:Text(labels[i],textAlign:TextAlign.center,maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(fontSize:11.5*s,fontWeight:FontWeight.w800,color:_section==i?AppColors.primary:AppColors.lightTextSecondary)))));}));

  Widget _card(DocumentTemplate t, double s) {
    return FadeTransition(
      opacity: CurvedAnimation(parent: _animation, curve: Curves.easeOut),
      child: GestureDetector(
        onTap: () => _section == 1 ? _customize(t) : _open(t),
        child: Container(
          padding: EdgeInsets.all(8 * s),
          decoration: BoxDecoration(
            color: const Color(0xFFF9FAFB),
            borderRadius: BorderRadius.circular(14 * s),
            border: Border.all(color: AppColors.lightCardBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Stack(
                  children: [
                    Positioned.fill(child: _miniPreview(t, s)),
                    if (_activeId == t.id)
                      Positioned(
                        top: 3 * s,
                        right: 3 * s,
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 6 * s, vertical: 3 * s),
                          decoration: BoxDecoration(
                            color: const Color(0xFF16A34A),
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: Text('ACTIVE', style: TextStyle(color: Colors.white, fontSize: 7 * s, fontWeight: FontWeight.w900)),
                        ),
                      ),
                  ],
                ),
              ),
              SizedBox(height: 6 * s),
              Text(t.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w900)),
              SizedBox(height: 5 * s),
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 29 * s,
                      child: OutlinedButton(
                        onPressed: () => _section == 1 ? _customize(t) : _open(t),
                        style: OutlinedButton.styleFrom(
                          padding: EdgeInsets.zero,
                          side: BorderSide(color: AppColors.primary.withValues(alpha: .22)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8 * s)),
                        ),
                        child: Text(_section == 1 ? 'Customize' : 'Use Template', style: TextStyle(fontSize: 9 * s, fontWeight: FontWeight.w800, color: AppColors.primary)),
                      ),
                    ),
                  ),
                  if (!t.builtIn) ...[
                    SizedBox(width: 4 * s),
                    IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints.tightFor(width: 27, height: 29),
                      onPressed: () => _delete(t),
                      icon: Icon(Icons.delete_outline_rounded, size: 16 * s, color: Colors.redAccent),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _miniPreview(DocumentTemplate t, double s) {
    return ClipRRect(borderRadius:BorderRadius.circular(7*s),child:TemplatePreviewMini(template:t));
  }

  Widget _empty(double s)=>Padding(padding:EdgeInsets.all(30*s),child:Column(children:[Icon(Icons.layers_clear_rounded,size:34*s,color:AppColors.lightTextSecondary),SizedBox(height:8*s),Text('No templates found',style:TextStyle(fontSize:13*s,fontWeight:FontWeight.w800)),SizedBox(height:3*s),Text('Try a different search to find a ${_kind==TemplateKind.invoice?'invoice':'barcode label'} template.',textAlign:TextAlign.center,style:TextStyle(fontSize:10*s,color:AppColors.lightTextSecondary))]));

  Widget _bottomButton(double s,IconData icon,String text,Color color,VoidCallback onTap)=>SizedBox(height:48*s,child:FilledButton.icon(onPressed:onTap,icon:Icon(icon,size:18*s),label:Text(text,style:TextStyle(fontSize:12*s,fontWeight:FontWeight.w900)),style:FilledButton.styleFrom(backgroundColor:color,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(13*s)))));
}

class TemplatePreviewScreen extends StatefulWidget {
  final DocumentTemplate template;
  const TemplatePreviewScreen({super.key,required this.template});
  @override State<TemplatePreviewScreen> createState()=>_TemplatePreviewScreenState();
}
class _TemplatePreviewScreenState extends State<TemplatePreviewScreen> {
  bool _busy = false;

  void _toast(String message) {
    if (!mounted) return;
    AppMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<Uint8List> _pdf() async {
    final t=widget.template;
    final accent=PdfColor.fromInt(t.accent);
    final profile=await ProfileRepository().getOrCreate();
    pw.MemoryImage? logo;
    final logoPath=t.logoPath??profile.photoPath;
    if(logoPath!=null && logoPath.trim().isNotEmpty){
      try{logo=pw.MemoryImage(await File(logoPath).readAsBytes());}catch(_){}
    }
    final business=(profile.name?.trim().isNotEmpty??false)?profile.name!.trim():'Business Name';
    final email=(profile.email?.trim().isNotEmpty??false)?profile.email!.trim():'';
    final address=(profile.address?.trim().isNotEmpty??false)?profile.address!.trim():'';
    final doc=pw.Document(title:t.name);

    if(t.kind==TemplateKind.invoice){
      doc.addPage(pw.Page(
        pageFormat:PdfPageFormat.a4,
        margin:const pw.EdgeInsets.all(28),
        build:(_)=>pw.Column(
          crossAxisAlignment:pw.CrossAxisAlignment.start,
          children:[
            if(t.showBusiness || (t.showLogo && logo!=null))pw.Row(
              crossAxisAlignment:pw.CrossAxisAlignment.start,
              children:[
                if(t.showLogo && logo!=null)pw.Padding(padding:const pw.EdgeInsets.only(right:8),child:pw.Image(logo!,width:42,height:42,fit:pw.BoxFit.contain)),
                if(t.showBusiness)pw.Expanded(child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[
                  pw.Text(business,style:pw.TextStyle(fontSize:20,color:accent,fontWeight:pw.FontWeight.bold)),
                  if(address.isNotEmpty)pw.Text(address,style:const pw.TextStyle(fontSize:8,color:PdfColors.grey600)),
                  if(email.isNotEmpty)pw.Text(email,style:const pw.TextStyle(fontSize:8,color:PdfColors.grey600)),
                ])),
                pw.Container(color:accent,padding:const pw.EdgeInsets.symmetric(horizontal:14,vertical:8),child:pw.Text(t.title,style:const pw.TextStyle(color:PdfColors.white,fontSize:13))),
              ],
            ),
            if(t.showBusiness)pw.SizedBox(height:8),
            pw.Divider(color:accent),
            if(t.showCustomer||t.showInvoiceNumber||t.showPaymentStatus)pw.Padding(
              padding:const pw.EdgeInsets.symmetric(vertical:10),
              child:pw.Row(children:[
                if(t.showCustomer)_pdfBox('BILL TO','Customer Name'),
                if(t.showCustomer&&t.showInvoiceNumber)pw.SizedBox(width:10),
                if(t.showInvoiceNumber)_pdfBox('INVOICE DETAILS','INV-0001 • Today'),
                if(t.showPaymentStatus)pw.Padding(padding:const pw.EdgeInsets.only(left:10),child:pw.Container(padding:const pw.EdgeInsets.all(9),decoration:pw.BoxDecoration(border:pw.Border.all(color:accent),borderRadius:pw.BorderRadius.circular(4)),child:pw.Text('PAID',style:pw.TextStyle(fontSize:9,color:accent,fontWeight:pw.FontWeight.bold)))),
              ]),
            ),
            if(t.showItems)pw.Table(
              border:pw.TableBorder.all(color:PdfColors.grey300),
              children:[
                pw.TableRow(decoration:pw.BoxDecoration(color:accent),children:['#','PRODUCT','QTY','RATE','AMOUNT'].map((x)=>pw.Padding(padding:const pw.EdgeInsets.all(7),child:pw.Text(x,style:const pw.TextStyle(color:PdfColors.white,fontSize:8)))).toList()),
                ...List.generate(5,(i)=>pw.TableRow(children:['${i+1}','Product ${i+1}','0','0','0'].map((x)=>pw.Padding(padding:const pw.EdgeInsets.all(7),child:pw.Text(x,style:const pw.TextStyle(fontSize:8)))).toList())),
              ],
            ),
            pw.SizedBox(height:12),
            if(t.showTotals)pw.Align(alignment:pw.Alignment.centerRight,child:pw.Container(width:180,padding:const pw.EdgeInsets.all(10),color:PdfColors.grey100,child:pw.Text('TOTAL   ${CurrencyFormatter.pdfLabel} 0',style:pw.TextStyle(fontWeight:pw.FontWeight.bold,color:accent)))),
            pw.Spacer(),
            if(t.showFooterMessage)pw.Center(child:pw.Text(t.thankYouMessage,style:pw.TextStyle(fontSize:8,color:accent))),
            pw.SizedBox(height:8),
            pw.Center(child:pw.Text('Powered by WebdSoft Company',style:const pw.TextStyle(fontSize:8,color:PdfColors.grey))),
          ],
        ),
      ));
    }else{
      doc.addPage(LabelPdf.page(
        template:t,
        business:business,
        product:'PRODUCT NAME',
        code:'1234567890',
        price:0,
      ));
    }
    return Uint8List.fromList(await doc.save());
  }

  pw.Widget _pdfBox(String title, String value) {
    return pw.Expanded(
      child: pw.Container(
        padding: const pw.EdgeInsets.all(8),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey300),
          borderRadius: pw.BorderRadius.circular(4),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(title, style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey600)),
            pw.SizedBox(height: 3),
            pw.Text(value, style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      final bytes = await _pdf();
      final path = await FilePicker.platform.saveFile(
        dialogTitle: 'Save Template PDF',
        fileName: '${widget.template.name.replaceAll(' ', '_')}.pdf',
        type: FileType.custom,
        allowedExtensions: const ['pdf'],
        bytes: bytes,
      );
      if (path != null) _toast('PDF saved successfully.');
    } catch (_) {
      _toast('Could not save PDF.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _print() async {
    final isLabel = widget.template.kind == TemplateKind.label;
    if (!(isLabel ? await PrinterGate.ensureLabel(context) : await PrinterGate.ensure(context))) return;
    setState(() => _busy = true);
    try {
      final bytes = await _pdf();
      if (isLabel) {
        await ThermalPrinterService.instance.printLabelPdf(bytes, widthMm: widget.template.labelWidthMm, heightMm: widget.template.labelHeightMm);
        _toast('Sent to the label printer.');
      } else {
        await ThermalPrinterService.instance.printPdf(bytes);
        _toast('Sent to the printer.');
      }
    } on PrinterException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('Could not print.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _activate() async {
    await TemplateService.instance.setActive(widget.template);
    if (!mounted) return;
    _toast('Template activated.');
    Navigator.pop(context, true);
  }

  Future<void> _customize() async {
    final result = await Navigator.push<DocumentTemplate>(
      context,
      MaterialPageRoute(
        builder: (_) => widget.template.kind == TemplateKind.label ? LabelDesignerScreen(template: widget.template) : TemplateEditorScreen(kind: widget.template.kind, template: widget.template),
      ),
    );
    if (result == null || !mounted) return;
    await TemplateService.instance.save(result);
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          SafeArea(
            bottom: false,
            child: Container(
              height: 60 * s,
              padding: EdgeInsets.symmetric(horizontal: 12 * s),
              decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
              child: Row(
                children: [
                  AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
                  Expanded(child: Center(child: Text(widget.template.name, style: TextStyle(fontSize: 17 * s, fontWeight: FontWeight.w900)))),
                  SizedBox(width: 42 * s),
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(12 * s),
              children: [
                Container(
                  padding: EdgeInsets.all(10 * s),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18 * s), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .06), blurRadius: 16, offset: Offset(0, 6 * s))]),
                  child: AspectRatio(
                    aspectRatio: widget.template.kind == TemplateKind.invoice ? 0.707 : widget.template.labelWidthMm / widget.template.labelHeightMm,
                    child: _preview(widget.template, s),
                  ),
                ),
                SizedBox(height: 10 * s),
                Row(
                  children: [
                    Expanded(child: _actionButton(s, 'Customize', Icons.tune_rounded, AppColors.primary, _customize)),
                    SizedBox(width: 7 * s),
                    Expanded(child: _actionButton(s, 'Save', Icons.save_rounded, Colors.black, _save)),
                    SizedBox(width: 7 * s),
                    Expanded(child: _actionButton(s, 'Print', Icons.print_rounded, AppColors.primary, _print)),
                  ],
                ),
                SizedBox(height: 8 * s),
                SizedBox(
                  height: 47 * s,
                  child: FilledButton.icon(
                    onPressed: _busy ? null : _activate,
                    icon: const Icon(Icons.check_circle_rounded),
                    label: Text('Active This Template', style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w900)),
                    style: FilledButton.styleFrom(backgroundColor: const Color(0xFF15803D), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13 * s))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionButton(double s, String title, IconData icon, Color color, VoidCallback action) {
    return SizedBox(
      height: 45 * s,
      child: OutlinedButton.icon(
        onPressed: _busy ? null : action,
        icon: Icon(icon, size: 17 * s, color: color),
        label: Text(title, style: TextStyle(fontSize: 10 * s, fontWeight: FontWeight.w900, color: color)),
        style: OutlinedButton.styleFrom(side: BorderSide(color: color.withValues(alpha: .25)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12 * s))),
      ),
    );
  }

  Widget _preview(DocumentTemplate t, double s) {
    return TemplatePreviewMini(template:t);
  }

  Widget _uiBox(String title, String value, double s, int color) {
    return Container(
      padding: EdgeInsets.all(6 * s),
      decoration: BoxDecoration(border: Border.all(color: Color(color).withValues(alpha: .18)), borderRadius: BorderRadius.circular(5 * s)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: TextStyle(fontSize: 6 * s, color: AppColors.lightTextSecondary)), Text(value, style: TextStyle(fontSize: 7 * s, fontWeight: FontWeight.w800))]),
    );
  }
}


class TemplateEditorScreen extends StatefulWidget {
  final TemplateKind kind;
  final DocumentTemplate template;
  final bool isNew;
  const TemplateEditorScreen({super.key,required this.kind,required this.template,this.isNew=false});
  @override State<TemplateEditorScreen> createState()=>_TemplateEditorScreenState();
}

class _TemplateEditorScreenState extends State<TemplateEditorScreen>{
  late DocumentTemplate _t;
  late TextEditingController _name,_title,_thankYou;

  @override void initState(){
    super.initState();
    _t=widget.template;
    _name=TextEditingController(text:_t.name);
    _title=TextEditingController(text:_t.title);
    _thankYou=TextEditingController(text:_t.thankYouMessage);
  }
  @override void dispose(){_name.dispose();_title.dispose();_thankYou.dispose();super.dispose();}

  void _set(DocumentTemplate t)=>setState(()=>_t=t);

  Future<void> _options() async {
    await showModalBottomSheet(
      context:context,
      isScrollControlled:true,
      backgroundColor:Colors.transparent,
      builder:(_)=>_OptionsSheet(template:_t,onChanged:_set),
    );
  }

  Future<void> _save(bool active) async {
    final t=_t.copyWith(
      name:_name.text.trim().isEmpty?'My Template':_name.text.trim(),
      title:_title.text.trim().isEmpty?(widget.kind==TemplateKind.invoice?'INVOICE':'LABEL'):_title.text.trim(),
      thankYouMessage:_thankYou.text.trim().isEmpty?'Thank you for your business!':_thankYou.text.trim(),
    );
    await TemplateService.instance.save(t);
    if(active) await TemplateService.instance.setActive(t);
    if(mounted) Navigator.pop(context,t);
  }

  @override Widget build(BuildContext context){
    final s=(MediaQuery.sizeOf(context).width/390).clamp(.82,1.2).toDouble();
    return Scaffold(
      backgroundColor:AppColors.lightBackground,
      body:Column(children:[
        SafeArea(
          bottom:false,
          child:Container(
            height:58*s,
            padding:EdgeInsets.symmetric(horizontal:10*s),
            decoration:const BoxDecoration(
              color:Colors.white,
              border:Border(bottom:BorderSide(color:AppColors.lightDivider)),
            ),
            child:Row(children:[
              IconButton(onPressed:()=>Navigator.pop(context),icon:Icon(Icons.arrow_back_rounded,size:23*s)),
              Expanded(child:Text(widget.isNew?'Create ${widget.kind==TemplateKind.invoice?'Invoice':'Label'} Template':'Customize Template',
                style:TextStyle(fontSize:17*s,fontWeight:FontWeight.w900))),
              IconButton(
                tooltip:'Template options',
                onPressed:_options,
                icon:Icon(Icons.tune_rounded,size:22*s),
              ),
            ]),
          ),
        ),
        Expanded(
          child:SingleChildScrollView(
            padding:EdgeInsets.fromLTRB(12*s,10*s,12*s,8*s),
            child:Column(children:[
              if(widget.kind==TemplateKind.label)...[
                Padding(
                  padding:EdgeInsets.only(left:4*s,bottom:6*s),
                  child:Align(alignment:Alignment.centerLeft,child:Text('Label size',style:TextStyle(fontSize:11*s,fontWeight:FontWeight.w800,color:AppColors.lightTextSecondary))),
                ),
                LabelSizePicker(
                  widthMm:_t.labelWidthMm,
                  heightMm:_t.labelHeightMm,
                  onChanged:(w,h)=>_set(_t.copyWith(labelWidthMm:w,labelHeightMm:h)),
                ),
                SizedBox(height:8*s),
                BarcodeHeightSlider(
                  value:_t.barcodeHeightPct,
                  onChanged:(v)=>_set(_t.copyWith(barcodeHeightPct:v)),
                ),
                SizedBox(height:10*s),
              ],
              Container(
                width:double.infinity,
                height:520*s,
                padding:EdgeInsets.all(10*s),
                decoration:BoxDecoration(
                  color:const Color(0xFFE9EDF2),
                  borderRadius:BorderRadius.circular(18*s),
                  border:Border.all(color:AppColors.lightCardBorder),
                ),
                child:Column(children:[
                  Row(children:[
                    Icon(Icons.preview_rounded,size:17*s),
                    SizedBox(width:5*s),
                    Text('Live Template Preview',style:TextStyle(fontSize:12*s,fontWeight:FontWeight.w900)),
                    const Spacer(),
                    Container(
                      padding:EdgeInsets.symmetric(horizontal:8*s,vertical:4*s),
                      decoration:BoxDecoration(color:Color(_t.accent).withValues(alpha:.10),borderRadius:BorderRadius.circular(99)),
                      child:Text('${_enabledCount()} options ON',style:TextStyle(fontSize:8*s,fontWeight:FontWeight.w800,color:Color(_t.accent))),
                    ),
                  ]),
                  SizedBox(height:8*s),
                  Expanded(child:Center(child:AspectRatio(aspectRatio:widget.kind==TemplateKind.invoice?0.707:_t.labelWidthMm/_t.labelHeightMm,child:ClipRRect(borderRadius:BorderRadius.circular(7*s),child:TemplatePreviewMini(template:_t,canvasMode:true))))),
                ]),
              ),
              SizedBox(height:10*s),
              Container(
                width:double.infinity,
                padding:EdgeInsets.all(12*s),
                decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16*s),border:Border.all(color:AppColors.lightCardBorder)),
                child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                  Row(children:[Icon(Icons.tune_rounded,size:17*s,color:AppColors.primary),SizedBox(width:6*s),Text('Invoice / Template Options',style:TextStyle(fontSize:13*s,fontWeight:FontWeight.w900)),const Spacer(),Text('ON / OFF',style:TextStyle(fontSize:9*s,color:AppColors.lightTextSecondary))]),
                  SizedBox(height:7*s),
                  _optionSummary(s),
                  SizedBox(height:8*s),
                  SizedBox(width:double.infinity,height:44*s,child:OutlinedButton.icon(onPressed:_options,icon:Icon(Icons.tune_rounded,size:17*s),label:Text('Manage Options',style:TextStyle(fontSize:11*s,fontWeight:FontWeight.w900)),style:OutlinedButton.styleFrom(foregroundColor:AppColors.primary,side:BorderSide(color:AppColors.primary.withValues(alpha:.25)),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(11*s))))),
                ]),
              ),
            ]),
          ),
        ),
        Padding(
          padding:EdgeInsets.fromLTRB(10*s,0,10*s,9*s),
          child:Row(children:[
            Expanded(child:_bottom(s,'Cancel',Colors.white,AppColors.lightTextPrimary,()=>Navigator.pop(context))),
            SizedBox(width:6*s),
            Expanded(child:_bottom(s,'Save',Colors.black,Colors.white,()=>_save(false))),
            SizedBox(width:6*s),
            Expanded(child:_bottom(s,'Save & Active',const Color(0xFF15803D),Colors.white,()=>_save(true))),
          ]),
        ),
      ]),
    );
  }

  int _enabledCount(){
    if(widget.kind==TemplateKind.label){
      return [_t.showLabelProduct,_t.showLabelPrice,_t.showLabelBarcode,_t.showLabelCode,_t.showLabelBusiness].where((x)=>x).length;
    }
    return [_t.showLogo,_t.showBusiness,_t.showCustomer,_t.showItems,_t.showTotals,_t.showInvoiceNumber,_t.showDate,_t.showPaymentStatus,_t.showDiscount,_t.showTax,_t.showPaid,_t.showBalance,_t.showFooterMessage,_t.showSignature].where((x)=>x).length;
  }

  Widget _optionSummary(double s)=>Wrap(
    spacing:6*s,runSpacing:6*s,
    children:(widget.kind==TemplateKind.label
      ? <String>['Product','Price','Barcode','Barcode No.','Business']
      : <String>['Logo','Business','Customer','Items','Totals','Invoice No','Date','Payment Status','Discount','Tax','Paid','Balance','Thank You','Signature']
    ).map((x)=>Container(
      padding:EdgeInsets.symmetric(horizontal:8*s,vertical:5*s),
      decoration:BoxDecoration(color:AppColors.primary.withValues(alpha:.07),borderRadius:BorderRadius.circular(99)),
      child:Text(x,style:TextStyle(fontSize:8*s,fontWeight:FontWeight.w700,color:AppColors.primary)),
    )).toList(),
  );

  Widget _bottom(double s,String text,Color bg,Color fg,VoidCallback f)=>SizedBox(
    height:45*s,
    child:FilledButton(
      onPressed:f,
      style:FilledButton.styleFrom(
        backgroundColor:bg,foregroundColor:fg,
        side:BorderSide(color:Colors.black.withValues(alpha:.12)),
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(11*s)),
      ),
      child:Text(text,style:TextStyle(fontSize:9*s,fontWeight:FontWeight.w900)),
    ),
  );
}


class _OptionsSheet extends StatefulWidget {
  final DocumentTemplate template;
  final ValueChanged<DocumentTemplate> onChanged;
  const _OptionsSheet({required this.template,required this.onChanged});
  @override State<_OptionsSheet> createState()=>_OptionsSheetState();
}

class _OptionsSheetState extends State<_OptionsSheet> {
  late DocumentTemplate _template;
  @override void initState(){super.initState();_template=widget.template;}

  void _toggle(String label){
    final t=_template;
    DocumentTemplate next;
    switch(label){
      case 'Logo': next=t.copyWith(showLogo:!t.showLogo); break;
      case 'Business Details': next=t.copyWith(showBusiness:!t.showBusiness); break;
      case 'Customer': next=t.copyWith(showCustomer:!t.showCustomer); break;
      case 'Items': next=t.copyWith(showItems:!t.showItems); break;
      case 'Totals': next=t.copyWith(showTotals:!t.showTotals); break;
      case 'Invoice Number': next=t.copyWith(showInvoiceNumber:!t.showInvoiceNumber); break;
      case 'Date': next=t.copyWith(showDate:!t.showDate); break;
      case 'Payment Status': next=t.copyWith(showPaymentStatus:!t.showPaymentStatus); break;
      case 'Discount': next=t.copyWith(showDiscount:!t.showDiscount); break;
      case 'Tax': next=t.copyWith(showTax:!t.showTax); break;
      case 'Paid': next=t.copyWith(showPaid:!t.showPaid); break;
      case 'Balance': next=t.copyWith(showBalance:!t.showBalance); break;
      case 'Thank You': next=t.copyWith(showFooterMessage:!t.showFooterMessage); break;
      case 'Signature': next=t.copyWith(showSignature:!t.showSignature); break;
      case 'Product Name': next=t.copyWith(showLabelProduct:!t.showLabelProduct); break;
      case 'Price': next=t.copyWith(showLabelPrice:!t.showLabelPrice); break;
      case 'Barcode': next=t.copyWith(showLabelBarcode:!t.showLabelBarcode); break;
      case 'Business': next=t.copyWith(showLabelBusiness:!t.showLabelBusiness); break;
      case 'Barcode Number': next=t.copyWith(showLabelCode:!t.showLabelCode); break;
      default: next=t;
    }
    setState(()=>_template=next);
    widget.onChanged(next);
  }

  @override Widget build(BuildContext context){
    final invoiceRows=<MapEntry<String,bool>>[
      MapEntry('Logo',_template.showLogo),
      MapEntry('Business Details',_template.showBusiness),
      MapEntry('Customer',_template.showCustomer),
      MapEntry('Items',_template.showItems),
      MapEntry('Totals',_template.showTotals),
      MapEntry('Invoice Number',_template.showInvoiceNumber),
      MapEntry('Date',_template.showDate),
      MapEntry('Payment Status',_template.showPaymentStatus),
      MapEntry('Discount',_template.showDiscount),
      MapEntry('Tax',_template.showTax),
      MapEntry('Paid',_template.showPaid),
      MapEntry('Balance',_template.showBalance),
      MapEntry('Thank You',_template.showFooterMessage),
      MapEntry('Signature',_template.showSignature),
    ];
    final labelRows=<MapEntry<String,bool>>[
      MapEntry('Product Name',_template.showLabelProduct),MapEntry('Price',_template.showLabelPrice),MapEntry('Barcode',_template.showLabelBarcode),MapEntry('Barcode Number',_template.showLabelCode),MapEntry('Business',_template.showLabelBusiness),
    ];
    final rows=_template.kind==TemplateKind.invoice?invoiceRows:labelRows;
    return SafeArea(
      child:Container(
        decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(22))),
        child:Column(mainAxisSize:MainAxisSize.min,children:[
          const SizedBox(height:12),
          Row(children:[const SizedBox(width:18),const Icon(Icons.tune_rounded),const SizedBox(width:8),Expanded(child:Text(_template.kind==TemplateKind.invoice?'Invoice Options':'Label Options',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)))]),
          const SizedBox(height:4),
          const Text('Turn template sections on or off',style:TextStyle(fontSize:11,color:Colors.grey)),
          const SizedBox(height:6),
          ConstrainedBox(
            constraints:const BoxConstraints(maxHeight:520),
            child:ListView.builder(
              shrinkWrap:true,itemCount:rows.length,
              itemBuilder:(c,i){final row=rows[i];return SwitchListTile(dense:true,title:Text(row.key,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w700)),value:row.value,activeColor:AppColors.primary,onChanged:(_)=>_toggle(row.key));},
            ),
          ),
          Padding(padding:const EdgeInsets.all(14),child:SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>Navigator.pop(context),child:const Text('Done')))),
        ]),
      ),
    );
  }
}


class TemplatePreviewMini extends StatelessWidget {
  final DocumentTemplate template;
  final bool canvasMode;
  const TemplatePreviewMini({super.key,required this.template,this.canvasMode=false});

  @override Widget build(BuildContext context){
    final designSize=template.kind==TemplateKind.invoice?const Size(390,552):Size(template.labelWidthMm*6,template.labelHeightMm*6);
    return LayoutBuilder(builder:(context,constraints)=>Container(
      color:Colors.white,
      alignment:Alignment.center,
      child:FittedBox(
        fit:BoxFit.contain,
        child:SizedBox(width:designSize.width,height:designSize.height,child:_design(context)),
      ),
    ));
  }

  Widget _design(BuildContext context){
    final accent=Color(template.accent);
    return FutureBuilder<ProfileModel>(
      future:ProfileRepository().getOrCreate(),
      builder:(context,snapshot){
        final p=snapshot.data;
        final business=(p?.name?.trim().isNotEmpty??false)?p!.name!.trim():'Business Name';
        final email=(p?.email?.trim().isNotEmpty??false)?p!.email!.trim():'email@example.com';
        final address=(p?.address?.trim().isNotEmpty??false)?p!.address!.trim():'Business Address';
        final photo=p?.photoPath;
        final logoPath=template.logoPath??photo;
        final hasLogo=template.showLogo && logoPath!=null && File(logoPath).existsSync();
        if(template.kind==TemplateKind.label){
          return LabelPreview(template:template,business:business);
        }
        return Container(
          color:Colors.white,padding:const EdgeInsets.all(14),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
              if(hasLogo)Padding(padding:const EdgeInsets.only(right:8),child:ClipRRect(borderRadius:BorderRadius.circular(5),child:Image.file(File(logoPath!),width:38,height:38,fit:BoxFit.contain))),
              if(template.showBusiness)Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(business,maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(fontSize:15,fontWeight:FontWeight.w900,color:accent)),Text(address,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:7,color:Colors.grey)),Text(email,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:7,color:Colors.grey))])),
              Text(template.title,style:TextStyle(fontSize:12,fontWeight:FontWeight.w900,color:accent)),
            ]),
            const SizedBox(height:8),Container(height:3,color:accent),
            const SizedBox(height:8),
            Row(children:[if(template.showCustomer)Expanded(child:_box('BILL TO','Customer Name')),if(template.showCustomer&&template.showInvoiceNumber)const SizedBox(width:7),if(template.showInvoiceNumber)Expanded(child:_box('INVOICE','INV-0001')),if(template.showPaymentStatus)const SizedBox(width:7),if(template.showPaymentStatus)_status(accent)]),
            const SizedBox(height:8),
            if(template.showItems)Expanded(child:Container(decoration:BoxDecoration(color:const Color(0xFFF7F8FA),border:Border.all(color:accent.withValues(alpha:.12)),borderRadius:BorderRadius.circular(4)),child:Column(children:[Container(height:25,decoration:BoxDecoration(color:accent,borderRadius:const BorderRadius.vertical(top:Radius.circular(4))),child:const Row(children:[Expanded(child:Text('ITEM',style:TextStyle(color:Colors.white,fontSize:7,fontWeight:FontWeight.w800))),Text('QTY',style:TextStyle(color:Colors.white,fontSize:7,fontWeight:FontWeight.w800)),SizedBox(width:28),Text('AMOUNT',style:TextStyle(color:Colors.white,fontSize:7,fontWeight:FontWeight.w800)),SizedBox(width:6)])),...List.generate(5,(i)=>Padding(padding:const EdgeInsets.symmetric(horizontal:7,vertical:5),child:Row(children:[Expanded(child:Container(height:5,color:Colors.black12)),const SizedBox(width:8),Container(width:18,height:5,color:Colors.black12),const SizedBox(width:16),Container(width:42,height:5,color:Colors.black12)])))]))),
            if(template.showDiscount||template.showTax||template.showPaid||template.showBalance||template.showTotals)const SizedBox(height:8),
            if(template.showTotals)Align(alignment:Alignment.centerRight,child:Container(width:185,padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:accent.withValues(alpha:.06),borderRadius:BorderRadius.circular(5)),child:Column(children:[_line('Subtotal','${CurrencyFormatter.label} 0'),if(template.showDiscount)_line('Discount','${CurrencyFormatter.label} 0'),if(template.showTax)_line('Tax','${CurrencyFormatter.label} 0'),if(template.showPaid)_line('Paid','${CurrencyFormatter.label} 0'),if(template.showBalance)_line('Balance','${CurrencyFormatter.label} 0'),_line('TOTAL','${CurrencyFormatter.label} 0',strong:true,color:accent)]))),
            const Spacer(),
            if(template.showSignature)Align(alignment:Alignment.centerRight,child:const Text('Signature __________________',style:TextStyle(fontSize:7,color:Colors.grey))),
            if(template.showFooterMessage)Center(child:Text(template.thankYouMessage,maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(fontSize:7,color:accent,fontWeight:FontWeight.w700))),
            const SizedBox(height:4),const Center(child:Text('Powered by WebdSoft Company',style:TextStyle(fontSize:6,color:Colors.grey))),
          ]),
        );
      },
    );
  }

  Widget _box(String title,String value)=>Container(padding:const EdgeInsets.all(7),decoration:BoxDecoration(color:const Color(0xFFF7F8FA),borderRadius:BorderRadius.circular(4)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:6,color:Colors.grey)),const SizedBox(height:3),Text(value,style:const TextStyle(fontSize:8,fontWeight:FontWeight.w800))]));
  Widget _status(Color accent)=>Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:9),decoration:BoxDecoration(border:Border.all(color:accent),borderRadius:BorderRadius.circular(4)),child:Text('PAID',style:TextStyle(fontSize:7,fontWeight:FontWeight.w900,color:accent)));
  Widget _line(String a,String b,{bool strong=false,Color? color})=>Padding(padding:const EdgeInsets.symmetric(vertical:2),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(a,style:TextStyle(fontSize:7,fontWeight:strong?FontWeight.w900:FontWeight.w500,color:color)),Text(b,style:TextStyle(fontSize:7,fontWeight:strong?FontWeight.w900:FontWeight.w700,color:color))]));
}

