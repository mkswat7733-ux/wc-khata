import '../../core/utils/currency_formatter.dart';
import 'dart:math' as math;
import 'package:barcode_widget/barcode_widget.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../app/theme/app_theme.dart';
import 'template_service.dart';

/// One standard barcode label size (millimetres).
class LabelSize {
  final String group;
  final String name;
  final double w, h;
  const LabelSize(this.group, this.name, this.w, this.h);

  String get id => '${_n(w)}x${_n(h)}';
  String get dims => '${_n(w)} × ${_n(h)} mm';
  bool matches(double ow, double oh) => (w - ow).abs() < .05 && (h - oh).abs() < .05;

  static String _n(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);
}

class LabelSizes {
  LabelSizes._();

  static const defaultW = 50.0, defaultH = 30.0;

  static const List<LabelSize> presets = [
    // Small
    LabelSize('SMALL LABELS', 'Tiny tag', 20, 10),
    LabelSize('SMALL LABELS', 'Mini tag', 25, 15),
    LabelSize('SMALL LABELS', 'Jewellery tag', 30, 15),
    LabelSize('SMALL LABELS', 'Small tag', 30, 20),
    LabelSize('SMALL LABELS', 'Compact', 38, 25),
    // Standard
    LabelSize('STANDARD', 'Slim shelf', 40, 20),
    LabelSize('STANDARD', 'Product tag', 40, 30),
    LabelSize('STANDARD', 'Wide shelf', 50, 25),
    LabelSize('STANDARD', 'Standard (default)', 50, 30),
    LabelSize('STANDARD', 'Tall product', 50, 40),
    LabelSize('STANDARD', 'Retail 58', 58, 40),
    LabelSize('STANDARD', 'Retail 60', 60, 40),
    // Large
    LabelSize('LARGE LABELS', 'Large retail', 70, 40),
    LabelSize('LARGE LABELS', 'Box label', 75, 50),
    LabelSize('LARGE LABELS', 'Wide box', 80, 50),
    LabelSize('LARGE LABELS', 'Carton', 100, 50),
    LabelSize('LARGE LABELS', 'Carton large', 100, 75),
    LabelSize('LARGE LABELS', 'Square', 100, 100),
    LabelSize('LARGE LABELS', 'Shipping', 100, 150),
    // Inch
    LabelSize('INCH SIZES', '1.5 × 1 in', 38.1, 25.4),
    LabelSize('INCH SIZES', '2 × 1 in', 50.8, 25.4),
    LabelSize('INCH SIZES', '3 × 2 in', 76.2, 50.8),
    LabelSize('INCH SIZES', '4 × 2 in', 101.6, 50.8),
    LabelSize('INCH SIZES', '4 × 3 in', 101.6, 76.2),
    LabelSize('INCH SIZES', '4 × 6 in', 101.6, 152.4),
  ];

  static LabelSize? presetFor(double w, double h) {
    for (final p in presets) {
      if (p.matches(w, h)) return p;
    }
    return null;
  }

  /// Scale factor used for fonts/paddings so every size looks balanced.
  static double scaleFor(double w, double h) => math.min(w / 50, h / 30).clamp(.55, 4.0).toDouble();
}

/// Modern rounded drop-down used above the label preview.
class LabelSizePicker extends StatelessWidget {
  final double widthMm, heightMm;
  final void Function(double w, double h) onChanged;
  const LabelSizePicker({super.key, required this.widthMm, required this.heightMm, required this.onChanged});

  static const _customValue = '__custom__';

  String get _value => LabelSizes.presetFor(widthMm, heightMm)?.id ?? _customValue;

  Future<void> _askCustom(BuildContext context) async {
    final wc = TextEditingController(text: LabelSize._n(widthMm));
    final hc = TextEditingController(text: LabelSize._n(heightMm));
    String? error;
    final result = await showDialog<List<double>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: const Text('Custom label size', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Expanded(child: _field(wc, 'Width (mm)')),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('×', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
              Expanded(child: _field(hc, 'Height (mm)')),
            ]),
            if (error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(error!, style: const TextStyle(color: Colors.red, fontSize: 11, fontWeight: FontWeight.w700))),
            const SizedBox(height: 8),
            const Text('Width 15–210 mm, height 10–300 mm', style: TextStyle(fontSize: 10, color: Colors.grey)),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              onPressed: () {
                final w = double.tryParse(wc.text.trim());
                final h = double.tryParse(hc.text.trim());
                if (w == null || h == null || w < 15 || w > 210 || h < 10 || h > 300) {
                  setS(() => error = 'Please enter a valid width and height.');
                  return;
                }
                Navigator.pop(ctx, [w, h]);
              },
              child: const Text('Apply', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      ),
    );
    if (result != null) onChanged(result[0], result[1]);
  }

  Widget _field(TextEditingController c, String label) => TextField(
        controller: c,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: AppColors.lightBackground,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final items = <DropdownMenuItem<String>>[];
    final selected = <Widget>[];
    String? lastGroup;
    for (final p in LabelSizes.presets) {
      if (p.group != lastGroup) {
        lastGroup = p.group;
        items.add(DropdownMenuItem<String>(
          value: 'hdr_${p.group}',
          enabled: false,
          child: Text(p.group, style: TextStyle(fontSize: 9.5, letterSpacing: 1, fontWeight: FontWeight.w900, color: AppColors.primary.withValues(alpha: .8))),
        ));
        selected.add(const SizedBox.shrink());
      }
      final isSel = p.id == _value;
      items.add(DropdownMenuItem<String>(
        value: p.id,
        child: Row(children: [
          Expanded(child: Text(p.dims, style: TextStyle(fontSize: 13, fontWeight: isSel ? FontWeight.w900 : FontWeight.w700))),
          Text(p.name, style: const TextStyle(fontSize: 10.5, color: Colors.grey, fontWeight: FontWeight.w600)),
        ]),
      ));
      selected.add(_selectedText(p.dims, p.name));
    }
    items.add(const DropdownMenuItem<String>(
      value: '__hdr_custom',
      enabled: false,
      child: Text('CUSTOM', style: TextStyle(fontSize: 9.5, letterSpacing: 1, fontWeight: FontWeight.w900, color: Colors.grey)),
    ));
    selected.add(const SizedBox.shrink());
    items.add(DropdownMenuItem<String>(
      value: _customValue,
      child: Row(children: [
        Icon(Icons.edit_rounded, size: 16, color: AppColors.primary),
        const SizedBox(width: 8),
        const Text('Custom size…', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
      ]),
    ));
    selected.add(_selectedText('${LabelSize._n(widthMm)} × ${LabelSize._n(heightMm)} mm', 'Custom'));

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.primary.withValues(alpha: .22)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .05), blurRadius: 12, offset: const Offset(0, 4))],
      ),
      child: Row(children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), shape: BoxShape.circle),
          child: Icon(Icons.straighten_rounded, color: AppColors.primary, size: 18),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _value,
              isExpanded: true,
              borderRadius: BorderRadius.circular(20),
              dropdownColor: Colors.white,
              menuMaxHeight: 420,
              icon: Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.primary, size: 26),
              items: items,
              selectedItemBuilder: (_) => selected,
              onChanged: (v) {
                if (v == null) return;
                if (v == _customValue) {
                  _askCustom(context);
                  return;
                }
                final p = LabelSizes.presets.firstWhere((e) => e.id == v);
                onChanged(p.w, p.h);
              },
            ),
          ),
        ),
      ]),
    );
  }

  Widget _selectedText(String dims, String name) => Align(
        alignment: Alignment.centerLeft,
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Text(dims, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
          const SizedBox(width: 8),
          Flexible(child: Text(name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: Colors.grey, fontWeight: FontWeight.w600))),
        ]),
      );
}

/// Text sizes (pt) used on a label. A size of 0 in the template means
/// "automatic": the size follows the label size so every label looks balanced.
/// The same numbers drive the on-screen preview and the printed PDF, so what
/// the user sees is exactly what prints.
class LabelFonts {
  final double business, product, code, price;
  const LabelFonts(this.business, this.product, this.code, this.price);

  static const double minPt = 3, maxPt = 30;

  /// Preview scale: 1 mm = 6 logical px, 1 pt = 25.4/72 mm.
  static const double pxPerPt = 6 * 25.4 / 72;

  static double autoBusiness(double w, double h) => 5.5 * LabelSizes.scaleFor(w, h);
  static double autoProduct(double w, double h) => 8 * LabelSizes.scaleFor(w, h);
  static double autoCode(double w, double h) => 6 * LabelSizes.scaleFor(w, h);
  static double autoPrice(double w, double h) => 8.5 * LabelSizes.scaleFor(w, h);

  static LabelFonts of(DocumentTemplate t) {
    final w = t.labelWidthMm, h = t.labelHeightMm;
    double pick(double v, double auto) => v > 0 ? v.clamp(minPt, maxPt).toDouble() : auto;
    return LabelFonts(
      pick(t.labelBusinessFs, autoBusiness(w, h)),
      pick(t.labelProductFs, autoProduct(w, h)),
      pick(t.labelCodeFs, autoCode(w, h)),
      pick(t.labelPriceFs, autoPrice(w, h)),
    );
  }
}

/// Shared layout numbers for the preview and the PDF (millimetres).
class _LabelLayout {
  static double padMm(double w, double h) => 1.6 * math.min(LabelSizes.scaleFor(w, h), 1.5);
  static const double gapMm = 0.5;
}

/// Margins of a label in millimetres. A margin the user never set (-1 in the
/// template) is automatic and follows the label size. Margins are limited so at
/// least 8 mm x 4 mm stays free for the content, whatever the label size.
class LabelMargins {
  final double left, right, top, bottom;
  final bool isAuto;
  const LabelMargins(this.left, this.right, this.top, this.bottom, this.isAuto);

  static LabelMargins of(DocumentTemplate t) {
    final w = t.labelWidthMm, h = t.labelHeightMm;
    final auto = _LabelLayout.padMm(w, h);
    final isAuto = t.labelMarginL < 0 && t.labelMarginR < 0 && t.labelMarginT < 0 && t.labelMarginB < 0;
    double pick(double v) => v >= 0 ? v : auto;
    var l = pick(t.labelMarginL), r = pick(t.labelMarginR), tp = pick(t.labelMarginT), b = pick(t.labelMarginB);
    final maxW = math.max(0.0, w - 8), maxH = math.max(0.0, h - 4);
    if (l + r > maxW) {
      final k = maxW / (l + r);
      l *= k;
      r *= k;
    }
    if (tp + b > maxH) {
      final k = maxH / (tp + b);
      tp *= k;
      b *= k;
    }
    return LabelMargins(l, r, tp, b, isAuto);
  }

  /// Largest margin the editor should allow for this label size.
  static double maxSide(double w) => math.max(1.0, ((w - 8) / 2).floorToDouble().clamp(1.0, 20.0).toDouble());
  static double maxVertical(double h) => math.max(1.0, ((h - 4) / 2).floorToDouble().clamp(1.0, 20.0).toDouble());
}

String _labelMoney(double v) => v.truncateToDouble() == v ? v.toInt().toString() : v.toStringAsFixed(2);

/// On-screen label preview with a REAL Code 128 barcode (same as the printed PDF).
class LabelPreview extends StatelessWidget {
  final DocumentTemplate template;
  final String business, product, code;
  final double price;
  const LabelPreview({
    super.key,
    required this.template,
    this.business = 'Business Name',
    this.product = 'PRODUCT NAME',
    this.code = '1234567890',
    this.price = 0,
  });

  @override
  Widget build(BuildContext context) {
    final w = template.labelWidthMm, h = template.labelHeightMm;
    final fonts = LabelFonts.of(template);
    final k = LabelFonts.pxPerPt;
    final accent = Color(template.accent);
    final data = code.trim().isEmpty ? '0000000000' : code.trim();
    final m = LabelMargins.of(template);
    final gap = _LabelLayout.gapMm * 6;

    Widget fit(Widget child) => FittedBox(fit: BoxFit.scaleDown, child: child);

    final children = <Widget>[];
    if (template.showLabelBusiness) {
      children.add(fit(Text(business, maxLines: 1, style: TextStyle(fontSize: fonts.business * k, height: 1.2, fontWeight: FontWeight.w800, color: accent))));
    }
    if (template.showLabelProduct) {
      if (children.isNotEmpty) children.add(SizedBox(height: gap));
      children.add(fit(Text(product, maxLines: 1, style: TextStyle(fontSize: fonts.product * k, height: 1.2, fontWeight: FontWeight.w800, color: Colors.black))));
    }
    if (template.showLabelBarcode) {
      children.add(Expanded(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: gap),
          child: Center(
            child: FractionallySizedBox(
              heightFactor: (template.barcodeHeightPct / 100).clamp(.2, 1.0).toDouble(),
              widthFactor: .94,
              child: BarcodeWidget(
                barcode: Barcode.code128(),
                data: data,
                color: Colors.black,
                backgroundColor: Colors.white,
                drawText: false,
                errorBuilder: (c, e) => const Center(child: Text('Invalid barcode', style: TextStyle(fontSize: 9, color: Colors.red))),
              ),
            ),
          ),
        ),
      ));
      if (template.showLabelCode) {
        children.add(fit(Text(data, maxLines: 1, style: TextStyle(fontSize: fonts.code * k, height: 1.2, fontWeight: FontWeight.w700, color: Colors.black, letterSpacing: .6))));
      }
    } else {
      children.add(const Spacer());
    }
    if (template.showLabelPrice) {
      children.add(SizedBox(height: gap));
      children.add(fit(Text('${CurrencyFormatter.label} ${_labelMoney(price)}', maxLines: 1, style: TextStyle(fontSize: fonts.price * k, height: 1.2, fontWeight: FontWeight.w900, color: accent))));
    }

    return SizedBox(
      width: w * 6,
      height: h * 6,
      child: Container(
        color: Colors.white,
        padding: EdgeInsets.fromLTRB(m.left * 6, m.top * 6, m.right * 6, m.bottom * 6),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: children,
        ),
      ),
    );
  }
}

/// Builds the printable label page for any label size.
class LabelPdf {
  LabelPdf._();

  static pw.Page page({
    required DocumentTemplate template,
    required String business,
    required String product,
    required String code,
    required double price,
  }) {
    const mm = PdfPageFormat.mm;
    final w = template.labelWidthMm, h = template.labelHeightMm;
    final fonts = LabelFonts.of(template);
    final accent = PdfColor.fromInt(template.accent);
    final data = code.trim().isEmpty ? '0000000000' : code.trim();

    final m = LabelMargins.of(template);
    final gap = _LabelLayout.gapMm * mm;
    final innerW = w * mm - (m.left + m.right) * mm;
    final innerH = h * mm - (m.top + m.bottom) * mm;

    double line(double fs) => fs * 1.2;
    var textH = 0.0;
    var gaps = 0;
    if (template.showLabelBusiness) { textH += line(fonts.business); gaps++; }
    if (template.showLabelProduct) { textH += line(fonts.product); gaps++; }
    if (template.showLabelBarcode && template.showLabelCode) { textH += line(fonts.code); }
    if (template.showLabelPrice) { textH += line(fonts.price); gaps++; }
    final free = innerH - textH - gap * (gaps + 2);
    final barH = math.max(3 * mm, free * (template.barcodeHeightPct / 100).clamp(.2, 1.0));

    pw.Widget fit(pw.Widget child) => pw.FittedBox(fit: pw.BoxFit.scaleDown, child: child);

    final children = <pw.Widget>[];
    if (template.showLabelBusiness) {
      children.add(fit(pw.Text(business, maxLines: 1, style: pw.TextStyle(fontSize: fonts.business, color: accent, fontWeight: pw.FontWeight.bold))));
    }
    if (template.showLabelProduct) {
      if (children.isNotEmpty) children.add(pw.SizedBox(height: gap));
      children.add(fit(pw.Text(product, maxLines: 1, style: pw.TextStyle(fontSize: fonts.product, fontWeight: pw.FontWeight.bold))));
    }
    if (template.showLabelBarcode) {
      children.add(pw.SizedBox(height: gap));
      children.add(pw.BarcodeWidget(
        barcode: pw.Barcode.code128(),
        data: data,
        width: innerW * .94,
        height: barH,
        drawText: false,
        color: PdfColors.black,
      ));
      if (template.showLabelCode) {
        children.add(pw.SizedBox(height: gap));
        children.add(fit(pw.Text(data, maxLines: 1, style: pw.TextStyle(fontSize: fonts.code, fontWeight: pw.FontWeight.bold, letterSpacing: .6))));
      }
    }
    if (template.showLabelPrice) {
      children.add(pw.SizedBox(height: gap));
      children.add(fit(pw.Text('${CurrencyFormatter.pdfLabel} ${_labelMoney(price)}', maxLines: 1, style: pw.TextStyle(fontSize: fonts.price, color: accent, fontWeight: pw.FontWeight.bold))));
    }

    return pw.Page(
      pageFormat: PdfPageFormat(w * mm, h * mm, marginAll: 0),
      margin: pw.EdgeInsets.zero,
      build: (_) => pw.Container(
        width: double.infinity,
        height: double.infinity,
        padding: pw.EdgeInsets.fromLTRB(m.left * mm, m.top * mm, m.right * mm, m.bottom * mm),
        child: pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.center,
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: children,
        ),
      ),
    );
  }
}

/// Slider that controls ONLY the height of the barcode lines (width stays the same).
class BarcodeHeightSlider extends StatelessWidget {
  final double value; // percent 20..100
  final ValueChanged<double> onChanged;
  const BarcodeHeightSlider({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final pct = value.round();
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.primary.withValues(alpha: .22)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .05), blurRadius: 12, offset: const Offset(0, 4))],
      ),
      child: Column(children: [
        Row(children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), shape: BoxShape.circle),
            child: Icon(Icons.height_rounded, color: AppColors.primary, size: 19),
          ),
          const SizedBox(width: 10),
          const Expanded(child: Text('Barcode height', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900))),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), borderRadius: BorderRadius.circular(99)),
            child: Text('$pct%', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: AppColors.primary)),
          ),
          const SizedBox(width: 6),
          InkWell(
            borderRadius: BorderRadius.circular(99),
            onTap: pct == 100 ? null : () => onChanged(100),
            child: Padding(
              padding: const EdgeInsets.all(6),
              child: Icon(Icons.refresh_rounded, size: 19, color: pct == 100 ? Colors.grey.shade400 : AppColors.primary),
            ),
          ),
        ]),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 5,
            activeTrackColor: AppColors.primary,
            inactiveTrackColor: AppColors.primary.withValues(alpha: .15),
            thumbColor: AppColors.primary,
            overlayColor: AppColors.primary.withValues(alpha: .12),
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
          ),
          child: Slider(
            value: value.clamp(20.0, 100.0).toDouble(),
            min: 20,
            max: 100,
            divisions: 80,
            onChanged: (v) => onChanged(v.roundToDouble()),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 8),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Short', style: TextStyle(fontSize: 9.5, color: Colors.grey, fontWeight: FontWeight.w700)),
            Text('Tall', style: TextStyle(fontSize: 9.5, color: Colors.grey, fontWeight: FontWeight.w700)),
          ]),
        ),
        const SizedBox(height: 4),
      ]),
    );
  }
}
