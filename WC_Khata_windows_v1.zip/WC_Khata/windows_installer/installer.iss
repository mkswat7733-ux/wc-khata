[Setup]
AppName=WC Khata
AppVersion=1.0.9
AppPublisher=webdsoft
DefaultDirName={autopf}\WC Khata
DefaultGroupName=WC Khata
OutputDir=..\installer_out
OutputBaseFilename=WC_Khata_Setup
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64compatible
DisableProgramGroupPage=yes

[Files]
Source: "..\build\windows\x64\runner\Release\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\WC Khata"; Filename: "{app}\wc_khata.exe"
Name: "{autodesktop}\WC Khata"; Filename: "{app}\wc_khata.exe"

[Run]
Filename: "{app}\wc_khata.exe"; Description: "Open WC Khata"; Flags: nowait postinstall skipifsilent
